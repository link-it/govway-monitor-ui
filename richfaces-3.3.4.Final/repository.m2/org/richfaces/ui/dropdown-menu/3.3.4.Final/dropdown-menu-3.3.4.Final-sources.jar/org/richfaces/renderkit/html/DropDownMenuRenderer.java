/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
import org.ajax4jsf.resource.InternetResource;
//
//
//


import org.richfaces.renderkit.html.DropDownMenuRendererBase;



/**
 * Renderer for component class org.richfaces.renderkit.html.DropDownMenuRenderer
 */
public class DropDownMenuRenderer extends DropDownMenuRendererBase {

	public DropDownMenuRenderer () {
		super();
	}

	// 
	// Declarations
	//
	private final InternetResource[] styles = {
						getResource("css/dropdownmenu.xcss")
	};

private InternetResource[] stylesAll = null;

protected InternetResource[] getStyles() {
	synchronized (this) {
		if (stylesAll == null) {
			InternetResource[] rsrcs = super.getStyles();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = styles == null || styles.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					stylesAll = new InternetResource[0];	
				} else {
					stylesAll = styles;
				}
			} else {
				if (ignoreThis) {
					stylesAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < styles.length; i++ ) {
						rsrcsSet.add(styles[i]);
					}

					stylesAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return stylesAll;
}
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIDropDownMenu.class;
	}

	
	public void doEncodeBegin(ResponseWriter writer, FacesContext context, UIComponent component ) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeBegin(writer, context, (org.richfaces.component.UIDropDownMenu)component, variables );
	}		

	public void doEncodeBegin(ResponseWriter writer, FacesContext context, org.richfaces.component.UIDropDownMenu component, ComponentVariables variables ) throws IOException {
	    java.lang.String clientId = component.getClientId(context);

	 
			variables.setVariable("cspValue", getUtils().getCspNonceValue(context));
			variables.setVariable("cssId", getUtils().getCssId(clientId));
	
	
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("#" + convertToString(clientId) + " { " + convertToString(component.getAttributes().get("style")) + " }\n		." + convertToString(variables.getVariable("cssId")) + "-container-menu-display-none { margin: 0px; padding: 0px; border: 0px; position: absolute; z-index: 100; }"),null);

writer.endElement("style");

		 org.richfaces.component.UIDropDownMenu menu = (org.richfaces.component.UIDropDownMenu) component;
		        if (!menu.getSubmitMode().equalsIgnoreCase("none"))
		        	org.richfaces.component.util.FormUtil.throwEnclFormReqExceptionIfNeed(context,component);
		        
    			if (!menu.isDisabled()) {
    
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ddmenu-label rich-ddmenu-label-unselect " + convertToString(component.getAttributes().get("styleClass")) + " " + convertToString(component.getAttributes().get("labelClass")) );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onmousemove", component.getAttributes().get("onmousemove") );
						getUtils().writeAttribute(writer, "onmouseout", component.getAttributes().get("onmouseout") );
						getUtils().writeAttribute(writer, "onmouseover", component.getAttributes().get("onmouseover") );
			
	
		 } else {  
	
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ddmenu-label-disabled rich-ddmenu-label-unselect " + convertToString(component.getAttributes().get("styleClass")) + " " + convertToString(component.getAttributes().get("disabledLabelClass")) );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onmousemove", component.getAttributes().get("onmousemove") );
						getUtils().writeAttribute(writer, "onmouseout", component.getAttributes().get("onmouseout") );
						getUtils().writeAttribute(writer, "onmouseover", component.getAttributes().get("onmouseover") );
			

		 } if (menu.isDisabled() &&
			(component.getFacet("labelDisabled")!=null && component.getFacet("labelDisabled").isRendered())) {
	
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-label-text-decor" );
			
UIComponent indexChildren_86 = component.getFacet("labelDisabled");
if (null != indexChildren_86 && indexChildren_86 .isRendered()) {
	renderChild(context, indexChildren_86);
}

writer.endElement("div");
			
			} else if(component.getFacet("label")!=null && component.getFacet("label").isRendered()) {
		 
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-label-text-decor" );
			
UIComponent indexChildren_87 = component.getFacet("label");
if (null != indexChildren_87 && indexChildren_87 .isRendered()) {
	renderChild(context, indexChildren_87);
}

writer.endElement("div");
	
					} else { 
		
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-label-text-decor" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "_span" );
			
writer.writeText(convertToString(component.getAttributes().get("value")),null);

writer.endElement("div");
	
					} 
		
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-container-menu-display-none" );
			

	}		
	
    public void doEncodeChildren(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeChildren(writer, context, (org.richfaces.component.UIDropDownMenu)component, variables );
	}		

    public void doEncodeChildren(ResponseWriter writer, FacesContext context, org.richfaces.component.UIDropDownMenu component, ComponentVariables variables) throws IOException {
	    
renderChildren(context, component);


	}		

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getRendersChildren()
	 */
	public boolean getRendersChildren() {
		return true;
	}

	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIDropDownMenu component, ComponentVariables variables) throws IOException {
	  
writer.endElement("div");

		if (!((org.richfaces.component.UIDropDownMenu) component).isDisabled()) {
    
writer.endElement("div");
	
		} else { 
	
writer.endElement("div");
	
		}  
	

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIDropDownMenu)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
