/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.util.Set ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlOrderingList;

public class OrderingListTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * activeItem
		 * Stores active item
		 */
		private ValueExpression _activeItem;
		/**
		 * Stores active item
		 * Setter for activeItem
		 * @param activeItem - new value
		 */
		 public void setActiveItem( ValueExpression  __activeItem ){
			this._activeItem = __activeItem;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxKeys
		 * Defines row keys that are updated after an Ajax request
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * Defines row keys that are updated after an Ajax request
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * bottomControlLabel
		 * Defines a label for a 'Bottom' control
		 */
		private ValueExpression _bottomControlLabel;
		/**
		 * Defines a label for a 'Bottom' control
		 * Setter for bottomControlLabel
		 * @param bottomControlLabel - new value
		 */
		 public void setBottomControlLabel( ValueExpression  __bottomControlLabel ){
			this._bottomControlLabel = __bottomControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * bottomTitle
		 * HTML: alt for last button
		 */
		private ValueExpression _bottomTitle;
		/**
		 * HTML: alt for last button
		 * Setter for bottomTitle
		 * @param bottomTitle - new value
		 */
		 public void setBottomTitle( ValueExpression  __bottomTitle ){
			this._bottomTitle = __bottomTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * captionLabel
		 * Defines caption representation text
		 */
		private ValueExpression _captionLabel;
		/**
		 * Defines caption representation text
		 * Setter for captionLabel
		 * @param captionLabel - new value
		 */
		 public void setCaptionLabel( ValueExpression  __captionLabel ){
			this._captionLabel = __captionLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns. If the CSS class names are comma-separated, 
            	each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
            	the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. 
            	If there are more class names than columns, the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns. If the CSS class names are comma-separated, 
            	each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
            	the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. 
            	If there are more class names than columns, the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding  for a component state for saving or redefinition
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding  for a component state for saving or redefinition
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsHorizontalAlign
		 * Controls horizontal rendering. Possible values:
                "left" - controls should be rendered to the left side of a list.
                "right"- controls should be rendered to the right side of a list. Default value is "right".
		 */
		private ValueExpression _controlsHorizontalAlign;
		/**
		 * Controls horizontal rendering. Possible values:
                "left" - controls should be rendered to the left side of a list.
                "right"- controls should be rendered to the right side of a list. Default value is "right".
		 * Setter for controlsHorizontalAlign
		 * @param controlsHorizontalAlign - new value
		 */
		 public void setControlsHorizontalAlign( ValueExpression  __controlsHorizontalAlign ){
			this._controlsHorizontalAlign = __controlsHorizontalAlign;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsType
		 * Defines type of a control: button or none. Default value is "button".
		 */
		private ValueExpression _controlsType;
		/**
		 * Defines type of a control: button or none. Default value is "button".
		 * Setter for controlsType
		 * @param controlsType - new value
		 */
		 public void setControlsType( ValueExpression  __controlsType ){
			this._controlsType = __controlsType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsVerticalAlign
		 * Controls vertical rendering. Possible values:
                "top" - controls should be rendered aligned to top side of a list.
                "bottom" - controls should be rendered aligned to bottom side of a list.
                "middle" - controls should be rendered centered relatively to a list. Default value is "middle"
		 */
		private ValueExpression _controlsVerticalAlign;
		/**
		 * Controls vertical rendering. Possible values:
                "top" - controls should be rendered aligned to top side of a list.
                "bottom" - controls should be rendered aligned to bottom side of a list.
                "middle" - controls should be rendered centered relatively to a list. Default value is "middle"
		 * Setter for controlsVerticalAlign
		 * @param controlsVerticalAlign - new value
		 */
		 public void setControlsVerticalAlign( ValueExpression  __controlsVerticalAlign ){
			this._controlsVerticalAlign = __controlsVerticalAlign;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * downControlLabel
		 * Defines a label for a 'Down' control
		 */
		private ValueExpression _downControlLabel;
		/**
		 * Defines a label for a 'Down' control
		 * Setter for downControlLabel
		 * @param downControlLabel - new value
		 */
		 public void setDownControlLabel( ValueExpression  __downControlLabel ){
			this._downControlLabel = __downControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * downTitle
		 * HTML: alt for bottom button
		 */
		private ValueExpression _downTitle;
		/**
		 * HTML: alt for bottom button
		 * Setter for downTitle
		 * @param downTitle - new value
		 */
		 public void setDownTitle( ValueExpression  __downTitle ){
			this._downTitle = __downTitle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fastOrderControlsVisible
		 * If "false", 'Top' and 'Bottom' controls aren't displayed. Default value is "true".
		 */
		private ValueExpression _fastOrderControlsVisible;
		/**
		 * If "false", 'Top' and 'Bottom' controls aren't displayed. Default value is "true".
		 * Setter for fastOrderControlsVisible
		 * @param fastOrderControlsVisible - new value
		 */
		 public void setFastOrderControlsVisible( ValueExpression  __fastOrderControlsVisible ){
			this._fastOrderControlsVisible = __fastOrderControlsVisible;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listHeight
		 * Defines height of a list. Default value is "140".
		 */
		private ValueExpression _listHeight;
		/**
		 * Defines height of a list. Default value is "140".
		 * Setter for listHeight
		 * @param listHeight - new value
		 */
		 public void setListHeight( ValueExpression  __listHeight ){
			this._listHeight = __listHeight;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listWidth
		 * Defines width of a list. Default value is "140".
		 */
		private ValueExpression _listWidth;
		/**
		 * Defines width of a list. Default value is "140".
		 * Setter for listWidth
		 * @param listWidth - new value
		 */
		 public void setListWidth( ValueExpression  __listWidth ){
			this._listWidth = __listWidth;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * onbottomclick
		 * The client-side script method to be called when the 'Bottom' button  is clicked
		 */
		private ValueExpression _onbottomclick;
		/**
		 * The client-side script method to be called when the 'Bottom' button  is clicked
		 * Setter for onbottomclick
		 * @param onbottomclick - new value
		 */
		 public void setOnbottomclick( ValueExpression  __onbottomclick ){
			this._onbottomclick = __onbottomclick;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * ondownclick
		 * The client-side script method to be called when the 'Down' button is clicked
		 */
		private ValueExpression _ondownclick;
		/**
		 * The client-side script method to be called when the 'Down' button is clicked
		 * Setter for ondownclick
		 * @param ondownclick - new value
		 */
		 public void setOndownclick( ValueExpression  __ondownclick ){
			this._ondownclick = __ondownclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onheaderclick
		 * The client-side script method to be called when the list header is clicked
		 */
		private ValueExpression _onheaderclick;
		/**
		 * The client-side script method to be called when the list header is clicked
		 * Setter for onheaderclick
		 * @param onheaderclick - new value
		 */
		 public void setOnheaderclick( ValueExpression  __onheaderclick ){
			this._onheaderclick = __onheaderclick;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * onorderchange
		 * The client-side script method to be called before the list order is changed
		 */
		private ValueExpression _onorderchange;
		/**
		 * The client-side script method to be called before the list order is changed
		 * Setter for onorderchange
		 * @param onorderchange - new value
		 */
		 public void setOnorderchange( ValueExpression  __onorderchange ){
			this._onorderchange = __onorderchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onorderchanged
		 * The client-side script method to be called when the list order is changed
		 */
		private ValueExpression _onorderchanged;
		/**
		 * The client-side script method to be called when the list order is changed
		 * Setter for onorderchanged
		 * @param onorderchanged - new value
		 */
		 public void setOnorderchanged( ValueExpression  __onorderchanged ){
			this._onorderchanged = __onorderchanged;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ontopclick
		 * The client-side script method to be called when the 'Top' button is clicked
		 */
		private ValueExpression _ontopclick;
		/**
		 * The client-side script method to be called when the 'Top' button is clicked
		 * Setter for ontopclick
		 * @param ontopclick - new value
		 */
		 public void setOntopclick( ValueExpression  __ontopclick ){
			this._ontopclick = __ontopclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onupclick
		 * The client-side script method to be called when the 'Up' button is clicked
		 */
		private ValueExpression _onupclick;
		/**
		 * The client-side script method to be called when the 'Up' button is clicked
		 * Setter for onupclick
		 * @param onupclick - new value
		 */
		 public void setOnupclick( ValueExpression  __onupclick ){
			this._onupclick = __onupclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * orderControlsVisible
		 * If "false", 'Up' and 'Down' controls aren't displayed. Default value is "true".
		 */
		private ValueExpression _orderControlsVisible;
		/**
		 * If "false", 'Up' and 'Down' controls aren't displayed. Default value is "true".
		 * Setter for orderControlsVisible
		 * @param orderControlsVisible - new value
		 */
		 public void setOrderControlsVisible( ValueExpression  __orderControlsVisible ){
			this._orderControlsVisible = __orderControlsVisible;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows. If the CSS class names are comma-separated, 
            	each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
            	the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. 
            	If there are more class names than rows, the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows. If the CSS class names are comma-separated, 
            	each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
            	the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. 
            	If there are more class names than rows, the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * The attribute provides access to a row key in a Request scope
		 */
		private String _rowKeyVar;
		/**
		 * The attribute provides access to a row key in a Request scope
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( String  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rows
		 * A number of rows to display, or zero for all remaining rows in the list
		 */
		private ValueExpression _rows;
		/**
		 * A number of rows to display, or zero for all remaining rows in the list
		 * Setter for rows
		 * @param rows - new value
		 */
		 public void setRows( ValueExpression  __rows ){
			this._rows = __rows;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selection
		 * Collection which stores a set of selected items
		 */
		private ValueExpression _selection;
		/**
		 * Collection which stores a set of selected items
		 * Setter for selection
		 * @param selection - new value
		 */
		 public void setSelection( ValueExpression  __selection ){
			this._selection = __selection;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showButtonLabels
		 * If "true", shows a label for a button. Default value is "true"
		 */
		private ValueExpression _showButtonLabels;
		/**
		 * If "true", shows a label for a button. Default value is "true"
		 * Setter for showButtonLabels
		 * @param showButtonLabels - new value
		 */
		 public void setShowButtonLabels( ValueExpression  __showButtonLabels ){
			this._showButtonLabels = __showButtonLabels;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * topControlLabel
		 * Defines a label for a 'Top' control
		 */
		private ValueExpression _topControlLabel;
		/**
		 * Defines a label for a 'Top' control
		 * Setter for topControlLabel
		 * @param topControlLabel - new value
		 */
		 public void setTopControlLabel( ValueExpression  __topControlLabel ){
			this._topControlLabel = __topControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topTitle
		 * HTML: alt for first button
		 */
		private ValueExpression _topTitle;
		/**
		 * HTML: alt for first button
		 * Setter for topTitle
		 * @param topTitle - new value
		 */
		 public void setTopTitle( ValueExpression  __topTitle ){
			this._topTitle = __topTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * upControlLabel
		 * Defines a label for a 'Up' control
		 */
		private ValueExpression _upControlLabel;
		/**
		 * Defines a label for a 'Up' control
		 * Setter for upControlLabel
		 * @param upControlLabel - new value
		 */
		 public void setUpControlLabel( ValueExpression  __upControlLabel ){
			this._upControlLabel = __upControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * upTitle
		 * HTML: alt for top button
		 */
		private ValueExpression _upTitle;
		/**
		 * HTML: alt for top button
		 * Setter for upTitle
		 * @param upTitle - new value
		 */
		 public void setUpTitle( ValueExpression  __upTitle ){
			this._upTitle = __upTitle;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * Defines a List or Array of items to be shown in a list
		 */
		private ValueExpression _value;
		/**
		 * Defines a List or Array of items to be shown in a list
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * var
		 * Defines a list on the page
		 */
		private String _var;
		/**
		 * Defines a list on the page
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._activeItem = null;
	 		 		    this._ajaxKeys = null;
	 		 		 		 		    this._bottomControlLabel = null;
	 		 		    this._bottomTitle = null;
	 		 		    this._captionLabel = null;
	 		 		    this._columnClasses = null;
	 		 		    this._componentState = null;
	 		 		    this._controlsHorizontalAlign = null;
	 		 		    this._controlsType = null;
	 		 		    this._controlsVerticalAlign = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._downControlLabel = null;
	 		 		    this._downTitle = null;
	 		 		 		    this._fastOrderControlsVisible = null;
	 		 		 		 		 		 		    this._immediate = null;
	 		 		 		    this._label = null;
	 		 		    this._listHeight = null;
	 		 		    this._listWidth = null;
	 		 		 		 		    this._onbottomclick = null;
	 		 		 		 		    this._ondownclick = null;
	 		 		    this._onheaderclick = null;
	 		 		 		 		 		    this._onorderchange = null;
	 		 		    this._onorderchanged = null;
	 		 		    this._ontopclick = null;
	 		 		    this._onupclick = null;
	 		 		    this._orderControlsVisible = null;
	 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		 		    this._rowClasses = null;
	 		 		 		 		 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		    this._rows = null;
	 		 		    this._selection = null;
	 		 		    this._showButtonLabels = null;
	 		 		 		 		 		 		    this._topControlLabel = null;
	 		 		    this._topTitle = null;
	 		 		    this._upControlLabel = null;
	 		 		    this._upTitle = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlOrderingList comp = (HtmlOrderingList) component;
 		 			 
						if (this._activeItem != null) {
				if (this._activeItem.isLiteralText()) {
					try {
												
						java.lang.Object __activeItem = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeItem.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setActiveItem(__activeItem);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeItem", this._activeItem);
				}
			}
					   		 			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					     		 			 
						if (this._bottomControlLabel != null) {
				if (this._bottomControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __bottomControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bottomControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBottomControlLabel(__bottomControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bottomControlLabel", this._bottomControlLabel);
				}
			}
					   		 			 
						if (this._bottomTitle != null) {
				if (this._bottomTitle.isLiteralText()) {
					try {
												
						java.lang.String __bottomTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bottomTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBottomTitle(__bottomTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bottomTitle", this._bottomTitle);
				}
			}
					   		 			 
						if (this._captionLabel != null) {
				if (this._captionLabel.isLiteralText()) {
					try {
												
						java.lang.String __captionLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._captionLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCaptionLabel(__captionLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("captionLabel", this._captionLabel);
				}
			}
					   		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					   		 			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					   		 			 
						if (this._controlsHorizontalAlign != null) {
				if (this._controlsHorizontalAlign.isLiteralText()) {
					try {
												
						java.lang.String __controlsHorizontalAlign = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsHorizontalAlign.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsHorizontalAlign(__controlsHorizontalAlign);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsHorizontalAlign", this._controlsHorizontalAlign);
				}
			}
					   		 			 
						if (this._controlsType != null) {
				if (this._controlsType.isLiteralText()) {
					try {
												
						java.lang.String __controlsType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsType(__controlsType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsType", this._controlsType);
				}
			}
					   		 			 
						if (this._controlsVerticalAlign != null) {
				if (this._controlsVerticalAlign.isLiteralText()) {
					try {
												
						java.lang.String __controlsVerticalAlign = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsVerticalAlign.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsVerticalAlign(__controlsVerticalAlign);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsVerticalAlign", this._controlsVerticalAlign);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._downControlLabel != null) {
				if (this._downControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __downControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._downControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDownControlLabel(__downControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("downControlLabel", this._downControlLabel);
				}
			}
					   		 			 
						if (this._downTitle != null) {
				if (this._downTitle.isLiteralText()) {
					try {
												
						java.lang.String __downTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._downTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDownTitle(__downTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("downTitle", this._downTitle);
				}
			}
					    		 			 
						if (this._fastOrderControlsVisible != null) {
				if (this._fastOrderControlsVisible.isLiteralText()) {
					try {
												
						Boolean __fastOrderControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fastOrderControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setFastOrderControlsVisible(__fastOrderControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fastOrderControlsVisible", this._fastOrderControlsVisible);
				}
			}
					       		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					    		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					   		 			 
						if (this._listHeight != null) {
				if (this._listHeight.isLiteralText()) {
					try {
												
						java.lang.String __listHeight = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listHeight.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListHeight(__listHeight);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listHeight", this._listHeight);
				}
			}
					   		 			 
						if (this._listWidth != null) {
				if (this._listWidth.isLiteralText()) {
					try {
												
						java.lang.String __listWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListWidth(__listWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listWidth", this._listWidth);
				}
			}
					     		 			 
						if (this._onbottomclick != null) {
				if (this._onbottomclick.isLiteralText()) {
					try {
												
						java.lang.String __onbottomclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbottomclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbottomclick(__onbottomclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbottomclick", this._onbottomclick);
				}
			}
					     		 			 
						if (this._ondownclick != null) {
				if (this._ondownclick.isLiteralText()) {
					try {
												
						java.lang.String __ondownclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondownclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndownclick(__ondownclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondownclick", this._ondownclick);
				}
			}
					   		 			 
						if (this._onheaderclick != null) {
				if (this._onheaderclick.isLiteralText()) {
					try {
												
						java.lang.String __onheaderclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onheaderclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnheaderclick(__onheaderclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onheaderclick", this._onheaderclick);
				}
			}
					      		 			 
						if (this._onorderchange != null) {
				if (this._onorderchange.isLiteralText()) {
					try {
												
						java.lang.String __onorderchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onorderchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnorderchange(__onorderchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onorderchange", this._onorderchange);
				}
			}
					   		 			 
						if (this._onorderchanged != null) {
				if (this._onorderchanged.isLiteralText()) {
					try {
												
						java.lang.String __onorderchanged = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onorderchanged.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnorderchanged(__onorderchanged);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onorderchanged", this._onorderchanged);
				}
			}
					   		 			 
						if (this._ontopclick != null) {
				if (this._ontopclick.isLiteralText()) {
					try {
												
						java.lang.String __ontopclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ontopclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOntopclick(__ontopclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ontopclick", this._ontopclick);
				}
			}
					   		 			 
						if (this._onupclick != null) {
				if (this._onupclick.isLiteralText()) {
					try {
												
						java.lang.String __onupclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onupclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnupclick(__onupclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onupclick", this._onupclick);
				}
			}
					   		 			 
						if (this._orderControlsVisible != null) {
				if (this._orderControlsVisible.isLiteralText()) {
					try {
												
						Boolean __orderControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._orderControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setOrderControlsVisible(__orderControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("orderControlsVisible", this._orderControlsVisible);
				}
			}
					    		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					    		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					       		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
											if (this._rowKeyVar != null) {
					comp.setRowKeyVar(this._rowKeyVar);
				}
									   		 			 
						if (this._rows != null) {
				if (this._rows.isLiteralText()) {
					try {
												
						Integer __rows = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rows.getExpressionString(), 
											Integer.class);
					
												comp.setRows(__rows.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rows", this._rows);
				}
			}
					   		 			 				if(null != this._selection && this._selection.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.OrderingList with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property selection");
				}
			 
						if (this._selection != null) {
				if (this._selection.isLiteralText()) {
					try {
												
						java.util.Set __selection = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selection.getExpressionString(), 
											java.util.Set.class);
					
												comp.setSelection(__selection);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selection", this._selection);
				}
			}
					   		 			 
						if (this._showButtonLabels != null) {
				if (this._showButtonLabels.isLiteralText()) {
					try {
												
						Boolean __showButtonLabels = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showButtonLabels.getExpressionString(), 
											Boolean.class);
					
												comp.setShowButtonLabels(__showButtonLabels.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showButtonLabels", this._showButtonLabels);
				}
			}
					       		 			 
						if (this._topControlLabel != null) {
				if (this._topControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __topControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopControlLabel(__topControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topControlLabel", this._topControlLabel);
				}
			}
					   		 			 
						if (this._topTitle != null) {
				if (this._topTitle.isLiteralText()) {
					try {
												
						java.lang.String __topTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopTitle(__topTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topTitle", this._topTitle);
				}
			}
					   		 			 
						if (this._upControlLabel != null) {
				if (this._upControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __upControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._upControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUpControlLabel(__upControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("upControlLabel", this._upControlLabel);
				}
			}
					   		 			 
						if (this._upTitle != null) {
				if (this._upTitle.isLiteralText()) {
					try {
												
						java.lang.String __upTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._upTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUpTitle(__upTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("upTitle", this._upTitle);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.OrderingList";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.OrderingListRenderer";
			}

}
