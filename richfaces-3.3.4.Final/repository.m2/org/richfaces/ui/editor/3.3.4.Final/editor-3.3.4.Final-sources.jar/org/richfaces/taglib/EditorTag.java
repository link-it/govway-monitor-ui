/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import java.lang.Integer ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlEditor;

public class EditorTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * autoResize
		 * Attribute enables to get the Editor area to resize to the boundaries of the contents.
		 */
		private ValueExpression _autoResize;
		/**
		 * Attribute enables to get the Editor area to resize to the boundaries of the contents.
		 * Setter for autoResize
		 * @param autoResize - new value
		 */
		 public void setAutoResize( ValueExpression  __autoResize ){
			this._autoResize = __autoResize;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * configuration
		 * Attribute defines configuration properties file name
		 */
		private ValueExpression _configuration;
		/**
		 * Attribute defines configuration properties file name
		 * Setter for configuration
		 * @param configuration - new value
		 */
		 public void setConfiguration( ValueExpression  __configuration ){
			this._configuration = __configuration;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * customPlugins
		 * Attribute defines property file name witch contains descriptors of custom plugins
		 */
		private ValueExpression _customPlugins;
		/**
		 * Attribute defines property file name witch contains descriptors of custom plugins
		 * Setter for customPlugins
		 * @param customPlugins - new value
		 */
		 public void setCustomPlugins( ValueExpression  __customPlugins ){
			this._customPlugins = __customPlugins;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * dialogType
		 * Attribute defines how dialogs/popups should be opened. Default value is "modal"
		 */
		private ValueExpression _dialogType;
		/**
		 * Attribute defines how dialogs/popups should be opened. Default value is "modal"
		 * Setter for dialogType
		 * @param dialogType - new value
		 */
		 public void setDialogType( ValueExpression  __dialogType ){
			this._dialogType = __dialogType;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * height
		 * Attribute defines height of component.
		 */
		private ValueExpression _height;
		/**
		 * Attribute defines height of component.
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * inputElementType
		 * ${prop.xmlEncodedDescription}
		 */
		private ValueExpression _inputElementType;
		/**
		 * ${prop.xmlEncodedDescription}
		 * Setter for inputElementType
		 * @param inputElementType - new value
		 */
		 public void setInputElementType( ValueExpression  __inputElementType ){
			this._inputElementType = __inputElementType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * language
		 * Attribute defines Editor language
		 */
		private ValueExpression _language;
		/**
		 * Attribute defines Editor language
		 * Setter for language
		 * @param language - new value
		 */
		 public void setLanguage( ValueExpression  __language ){
			this._language = __language;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * onchange
		 * The client-side script method to be called when the editor content is modified by TinyMCE
		 */
		private ValueExpression _onchange;
		/**
		 * The client-side script method to be called when the editor content is modified by TinyMCE
		 * Setter for onchange
		 * @param onchange - new value
		 */
		 public void setOnchange( ValueExpression  __onchange ){
			this._onchange = __onchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninit
		 * The client-side script method to be called when the initialization of the editor instances is finished
		 */
		private ValueExpression _oninit;
		/**
		 * The client-side script method to be called when the initialization of the editor instances is finished
		 * Setter for oninit
		 * @param oninit - new value
		 */
		 public void setOninit( ValueExpression  __oninit ){
			this._oninit = __oninit;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onsave
		 * The client-side script method to be called when the editor content is extracted/saved
		 */
		private ValueExpression _onsave;
		/**
		 * The client-side script method to be called when the editor content is extracted/saved
		 * Setter for onsave
		 * @param onsave - new value
		 */
		 public void setOnsave( ValueExpression  __onsave ){
			this._onsave = __onsave;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onsetup
		 * The client-side script method to be called before the editor instances get rendered
		 */
		private ValueExpression _onsetup;
		/**
		 * The client-side script method to be called before the editor instances get rendered
		 * Setter for onsetup
		 * @param onsetup - new value
		 */
		 public void setOnsetup( ValueExpression  __onsetup ){
			this._onsetup = __onsetup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * plugins
		 * Attribute defines Editor plugins
		 */
		private ValueExpression _plugins;
		/**
		 * Attribute defines Editor plugins
		 * Setter for plugins
		 * @param plugins - new value
		 */
		 public void setPlugins( ValueExpression  __plugins ){
			this._plugins = __plugins;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * readonly
		 * Attribute defines Editor is readonly
		 */
		private ValueExpression _readonly;
		/**
		 * Attribute defines Editor is readonly
		 * Setter for readonly
		 * @param readonly - new value
		 */
		 public void setReadonly( ValueExpression  __readonly ){
			this._readonly = __readonly;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * skin
		 * Attribute defines Editor skin
		 */
		private ValueExpression _skin;
		/**
		 * Attribute defines Editor skin
		 * Setter for skin
		 * @param skin - new value
		 */
		 public void setSkin( ValueExpression  __skin ){
			this._skin = __skin;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * tabindex
		 * In visual mode the attribute works the same way as "tab_focus" TinyMCE's property the attribute enables 
				you to specify an element ID to focus, when the TAB  key  is pressed .
				You can also use the special ":prev" and ":next"  values that will then place the focus on 
				an input element placed before/after the TinyMCE instance in the DOM. 
				While in "source" mode the attribute works like standard HTML tabindex attribute.
		 */
		private ValueExpression _tabindex;
		/**
		 * In visual mode the attribute works the same way as "tab_focus" TinyMCE's property the attribute enables 
				you to specify an element ID to focus, when the TAB  key  is pressed .
				You can also use the special ":prev" and ":next"  values that will then place the focus on 
				an input element placed before/after the TinyMCE instance in the DOM. 
				While in "source" mode the attribute works like standard HTML tabindex attribute.
		 * Setter for tabindex
		 * @param tabindex - new value
		 */
		 public void setTabindex( ValueExpression  __tabindex ){
			this._tabindex = __tabindex;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * theme
		 * Attribute defines Editor theme
		 */
		private ValueExpression _theme;
		/**
		 * Attribute defines Editor theme
		 * Setter for theme
		 * @param theme - new value
		 */
		 public void setTheme( ValueExpression  __theme ){
			this._theme = __theme;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * useSeamText
		 * Attribute defines if model value should be converted to Seam Text. Default value is "false"
		 */
		private ValueExpression _useSeamText;
		/**
		 * Attribute defines if model value should be converted to Seam Text. Default value is "false"
		 * Setter for useSeamText
		 * @param useSeamText - new value
		 */
		 public void setUseSeamText( ValueExpression  __useSeamText ){
			this._useSeamText = __useSeamText;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * viewMode
		 * Attribute defines if tinyMCE WYSIWYG should be disabled. Default value is "visual"
		 */
		private ValueExpression _viewMode;
		/**
		 * Attribute defines if tinyMCE WYSIWYG should be disabled. Default value is "visual"
		 * Setter for viewMode
		 * @param viewMode - new value
		 */
		 public void setViewMode( ValueExpression  __viewMode ){
			this._viewMode = __viewMode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * Attribute defines width of component.
		 */
		private ValueExpression _width;
		/**
		 * Attribute defines width of component.
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._autoResize = null;
	 		 		 		    this._configuration = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._customPlugins = null;
	 		 		    this._dialogType = null;
	 		 		 		    this._height = null;
	 		 		 		    this._immediate = null;
	 		 		    this._inputElementType = null;
	 		 		    this._label = null;
	 		 		    this._language = null;
	 		 		 		 		    this._onchange = null;
	 		 		    this._oninit = null;
	 		 		    this._onsave = null;
	 		 		    this._onsetup = null;
	 		 		    this._plugins = null;
	 		 		    this._readonly = null;
	 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		    this._skin = null;
	 		 		 		 		    this._tabindex = null;
	 		 		    this._theme = null;
	 		 		 		    this._useSeamText = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		 		    this._viewMode = null;
	 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlEditor comp = (HtmlEditor) component;
 		 			 
						if (this._autoResize != null) {
				if (this._autoResize.isLiteralText()) {
					try {
												
						Boolean __autoResize = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._autoResize.getExpressionString(), 
											Boolean.class);
					
												comp.setAutoResize(__autoResize.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("autoResize", this._autoResize);
				}
			}
					    		 			 
						if (this._configuration != null) {
				if (this._configuration.isLiteralText()) {
					try {
												
						java.lang.String __configuration = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._configuration.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConfiguration(__configuration);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("configuration", this._configuration);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._customPlugins != null) {
				if (this._customPlugins.isLiteralText()) {
					try {
												
						java.lang.String __customPlugins = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._customPlugins.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCustomPlugins(__customPlugins);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("customPlugins", this._customPlugins);
				}
			}
					   		 			 
						if (this._dialogType != null) {
				if (this._dialogType.isLiteralText()) {
					try {
												
						java.lang.String __dialogType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dialogType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDialogType(__dialogType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dialogType", this._dialogType);
				}
			}
					    		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						java.lang.Integer __height = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setHeight(__height);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._inputElementType != null) {
				if (this._inputElementType.isLiteralText()) {
					try {
												
						java.lang.String __inputElementType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._inputElementType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInputElementType(__inputElementType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("inputElementType", this._inputElementType);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					   		 			 
						if (this._language != null) {
				if (this._language.isLiteralText()) {
					try {
												
						java.lang.String __language = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._language.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLanguage(__language);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("language", this._language);
				}
			}
					     		 			 
						if (this._onchange != null) {
				if (this._onchange.isLiteralText()) {
					try {
												
						java.lang.String __onchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnchange(__onchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onchange", this._onchange);
				}
			}
					   		 			 
						if (this._oninit != null) {
				if (this._oninit.isLiteralText()) {
					try {
												
						java.lang.String __oninit = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninit.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninit(__oninit);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninit", this._oninit);
				}
			}
					   		 			 
						if (this._onsave != null) {
				if (this._onsave.isLiteralText()) {
					try {
												
						java.lang.String __onsave = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsave.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsave(__onsave);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsave", this._onsave);
				}
			}
					   		 			 
						if (this._onsetup != null) {
				if (this._onsetup.isLiteralText()) {
					try {
												
						java.lang.String __onsetup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsetup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsetup(__onsetup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsetup", this._onsetup);
				}
			}
					   		 			 
						if (this._plugins != null) {
				if (this._plugins.isLiteralText()) {
					try {
												
						java.lang.String __plugins = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._plugins.getExpressionString(), 
											java.lang.String.class);
					
												comp.setPlugins(__plugins);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("plugins", this._plugins);
				}
			}
					   		 			 
						if (this._readonly != null) {
				if (this._readonly.isLiteralText()) {
					try {
												
						Boolean __readonly = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._readonly.getExpressionString(), 
											Boolean.class);
					
												comp.setReadonly(__readonly.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("readonly", this._readonly);
				}
			}
					    		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					   		 			 
						if (this._skin != null) {
				if (this._skin.isLiteralText()) {
					try {
												
						java.lang.String __skin = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._skin.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSkin(__skin);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("skin", this._skin);
				}
			}
					     		 			 
						if (this._tabindex != null) {
				if (this._tabindex.isLiteralText()) {
					try {
												
						java.lang.String __tabindex = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tabindex.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTabindex(__tabindex);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tabindex", this._tabindex);
				}
			}
					   		 			 
						if (this._theme != null) {
				if (this._theme.isLiteralText()) {
					try {
												
						java.lang.String __theme = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._theme.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTheme(__theme);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("theme", this._theme);
				}
			}
					    		 			 
						if (this._useSeamText != null) {
				if (this._useSeamText.isLiteralText()) {
					try {
												
						Boolean __useSeamText = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._useSeamText.getExpressionString(), 
											Boolean.class);
					
												comp.setUseSeamText(__useSeamText.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("useSeamText", this._useSeamText);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
						if (this._viewMode != null) {
				if (this._viewMode.isLiteralText()) {
					try {
												
						java.lang.String __viewMode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._viewMode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setViewMode(__viewMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("viewMode", this._viewMode);
				}
			}
					   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.Integer __width = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.Editor";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.EditorRenderer";
			}

}
