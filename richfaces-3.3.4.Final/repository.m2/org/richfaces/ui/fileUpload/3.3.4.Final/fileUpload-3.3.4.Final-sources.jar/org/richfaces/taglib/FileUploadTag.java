/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import java.lang.Integer ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlFileUpload;

public class FileUploadTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * acceptedTypes
		 * Files types allowed to upload
		 */
		private ValueExpression _acceptedTypes;
		/**
		 * Files types allowed to upload
		 * Setter for acceptedTypes
		 * @param acceptedTypes - new value
		 */
		 public void setAcceptedTypes( ValueExpression  __acceptedTypes ){
			this._acceptedTypes = __acceptedTypes;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * accesskey
		 * This attribute assigns an access key to an element. An access key is a single character from the document character set. Note: Authors should consider the input method of the expected reader when specifying an accesskey
		 */
		private ValueExpression _accesskey;
		/**
		 * This attribute assigns an access key to an element. An access key is a single character from the document character set. Note: Authors should consider the input method of the expected reader when specifying an accesskey
		 * Setter for accesskey
		 * @param accesskey - new value
		 */
		 public void setAccesskey( ValueExpression  __accesskey ){
			this._accesskey = __accesskey;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * addButtonClass
		 * Assigns one or more space-separated CSS class names to the component 'Add' button
		 */
		private ValueExpression _addButtonClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Add' button
		 * Setter for addButtonClass
		 * @param addButtonClass - new value
		 */
		 public void setAddButtonClass( ValueExpression  __addButtonClass ){
			this._addButtonClass = __addButtonClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * addButtonClassDisabled
		 * Assigns one or more space-separated CSS class names to the component 'Add' button disabled
		 */
		private ValueExpression _addButtonClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Add' button disabled
		 * Setter for addButtonClassDisabled
		 * @param addButtonClassDisabled - new value
		 */
		 public void setAddButtonClassDisabled( ValueExpression  __addButtonClassDisabled ){
			this._addButtonClassDisabled = __addButtonClassDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * addControlLabel
		 * Defines a label for an add button
		 */
		private ValueExpression _addControlLabel;
		/**
		 * Defines a label for an add button
		 * Setter for addControlLabel
		 * @param addControlLabel - new value
		 */
		 public void setAddControlLabel( ValueExpression  __addControlLabel ){
			this._addControlLabel = __addControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxSingle
		 * Boolean attribute which provides possibility to limit JSF tree processing(decoding, conversion/validation, value applying) to the component which send the request only.
				Default value is "false"
		 */
		private ValueExpression _ajaxSingle;
		/**
		 * Boolean attribute which provides possibility to limit JSF tree processing(decoding, conversion/validation, value applying) to the component which send the request only.
				Default value is "false"
		 * Setter for ajaxSingle
		 * @param ajaxSingle - new value
		 */
		 public void setAjaxSingle( ValueExpression  __ajaxSingle ){
			this._ajaxSingle = __ajaxSingle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * allowFlash
		 * Attribute which allow the component to use the flash module that provides file upload functionality [false, true, auto]. Default value is "false"
		 */
		private ValueExpression _allowFlash;
		/**
		 * Attribute which allow the component to use the flash module that provides file upload functionality [false, true, auto]. Default value is "false"
		 * Setter for allowFlash
		 * @param allowFlash - new value
		 */
		 public void setAllowFlash( ValueExpression  __allowFlash ){
			this._allowFlash = __allowFlash;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * alt
		 * For a user agents that cannot display images, forms, or applets, this attribute specifies alternate text. The language of the alternate text is specified by the lang attribute
		 */
		private ValueExpression _alt;
		/**
		 * For a user agents that cannot display images, forms, or applets, this attribute specifies alternate text. The language of the alternate text is specified by the lang attribute
		 * Setter for alt
		 * @param alt - new value
		 */
		 public void setAlt( ValueExpression  __alt ){
			this._alt = __alt;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * autoclear
		 * If this attribute is "true" files will be immediately removed from list after upload completed.
				Default value is "false".
		 */
		private ValueExpression _autoclear;
		/**
		 * If this attribute is "true" files will be immediately removed from list after upload completed.
				Default value is "false".
		 * Setter for autoclear
		 * @param autoclear - new value
		 */
		 public void setAutoclear( ValueExpression  __autoclear ){
			this._autoclear = __autoclear;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * cancelEntryControlLabel
		 * Defines a label for a cancel control
		 */
		private ValueExpression _cancelEntryControlLabel;
		/**
		 * Defines a label for a cancel control
		 * Setter for cancelEntryControlLabel
		 * @param cancelEntryControlLabel - new value
		 */
		 public void setCancelEntryControlLabel( ValueExpression  __cancelEntryControlLabel ){
			this._cancelEntryControlLabel = __cancelEntryControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cleanButtonClass
		 * Assigns one or more space-separated CSS class names to the component 'Clean' button
		 */
		private ValueExpression _cleanButtonClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Clean' button
		 * Setter for cleanButtonClass
		 * @param cleanButtonClass - new value
		 */
		 public void setCleanButtonClass( ValueExpression  __cleanButtonClass ){
			this._cleanButtonClass = __cleanButtonClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cleanButtonClassDisabled
		 * Assigns one or more space-separated CSS class names to the component 'Clean' button disabled
		 */
		private ValueExpression _cleanButtonClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Clean' button disabled
		 * Setter for cleanButtonClassDisabled
		 * @param cleanButtonClassDisabled - new value
		 */
		 public void setCleanButtonClassDisabled( ValueExpression  __cleanButtonClassDisabled ){
			this._cleanButtonClassDisabled = __cleanButtonClassDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * clearAllControlLabel
		 * Defines a label for a clearAll button
		 */
		private ValueExpression _clearAllControlLabel;
		/**
		 * Defines a label for a clearAll button
		 * Setter for clearAllControlLabel
		 * @param clearAllControlLabel - new value
		 */
		 public void setClearAllControlLabel( ValueExpression  __clearAllControlLabel ){
			this._clearAllControlLabel = __clearAllControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * clearControlLabel
		 * Defines a label for a clear control
		 */
		private ValueExpression _clearControlLabel;
		/**
		 * Defines a label for a clear control
		 * Setter for clearControlLabel
		 * @param clearControlLabel - new value
		 */
		 public void setClearControlLabel( ValueExpression  __clearControlLabel ){
			this._clearControlLabel = __clearControlLabel;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * disabled
		 * Attribute 'disabled' provides a possibility to make the whole component disabled if its value equals to "true".
				Default value is "false".
		 */
		private ValueExpression _disabled;
		/**
		 * Attribute 'disabled' provides a possibility to make the whole component disabled if its value equals to "true".
				Default value is "false".
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * doneLabel
		 * Defines a label for a done label
		 */
		private ValueExpression _doneLabel;
		/**
		 * Defines a label for a done label
		 * Setter for doneLabel
		 * @param doneLabel - new value
		 */
		 public void setDoneLabel( ValueExpression  __doneLabel ){
			this._doneLabel = __doneLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * doneLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Done' label
		 */
		private ValueExpression _doneLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Done' label
		 * Setter for doneLabelClass
		 * @param doneLabelClass - new value
		 */
		 public void setDoneLabelClass( ValueExpression  __doneLabelClass ){
			this._doneLabelClass = __doneLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * entryCancelLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Cancel entry' label in fileUpload list
		 */
		private ValueExpression _entryCancelLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Cancel entry' label in fileUpload list
		 * Setter for entryCancelLabelClass
		 * @param entryCancelLabelClass - new value
		 */
		 public void setEntryCancelLabelClass( ValueExpression  __entryCancelLabelClass ){
			this._entryCancelLabelClass = __entryCancelLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * entryClearLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Clear entry' label in fileUpload list
		 */
		private ValueExpression _entryClearLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Clear entry' label in fileUpload list
		 * Setter for entryClearLabelClass
		 * @param entryClearLabelClass - new value
		 */
		 public void setEntryClearLabelClass( ValueExpression  __entryClearLabelClass ){
			this._entryClearLabelClass = __entryClearLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * entryStopLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Stop entry' label in fileUpload list
		 */
		private ValueExpression _entryStopLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Stop entry' label in fileUpload list
		 * Setter for entryStopLabelClass
		 * @param entryStopLabelClass - new value
		 */
		 public void setEntryStopLabelClass( ValueExpression  __entryStopLabelClass ){
			this._entryStopLabelClass = __entryStopLabelClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fileEntryClass
		 * Assigns one or more space-separated CSS class names to the file entries
		 */
		private ValueExpression _fileEntryClass;
		/**
		 * Assigns one or more space-separated CSS class names to the file entries
		 * Setter for fileEntryClass
		 * @param fileEntryClass - new value
		 */
		 public void setFileEntryClass( ValueExpression  __fileEntryClass ){
			this._fileEntryClass = __fileEntryClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * fileEntryClassDisabled
		 * Assigns one or more space-separated CSS class names to the file entries disabled
		 */
		private ValueExpression _fileEntryClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the file entries disabled
		 * Setter for fileEntryClassDisabled
		 * @param fileEntryClassDisabled - new value
		 */
		 public void setFileEntryClassDisabled( ValueExpression  __fileEntryClassDisabled ){
			this._fileEntryClassDisabled = __fileEntryClassDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * fileEntryControlClass
		 * Assigns one or more space-separated CSS class names to the controls of the file entries
		 */
		private ValueExpression _fileEntryControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the controls of the file entries
		 * Setter for fileEntryControlClass
		 * @param fileEntryControlClass - new value
		 */
		 public void setFileEntryControlClass( ValueExpression  __fileEntryControlClass ){
			this._fileEntryControlClass = __fileEntryControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * fileEntryControlClassDisabled
		 * Assigns one or more space-separated CSS class names to the disabled controls of the file entries
		 */
		private ValueExpression _fileEntryControlClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the disabled controls of the file entries
		 * Setter for fileEntryControlClassDisabled
		 * @param fileEntryControlClassDisabled - new value
		 */
		 public void setFileEntryControlClassDisabled( ValueExpression  __fileEntryControlClassDisabled ){
			this._fileEntryControlClassDisabled = __fileEntryControlClassDisabled;
	     }
	  
	 	 		 		 		 	  	  	  
		/*
		 * fileUploadListener
		 * MethodExpression representing an action listener method
				that will be notified after file uploaded.
		 */
		private MethodExpression _fileUploadListener;
		/**
		 * MethodExpression representing an action listener method
				that will be notified after file uploaded.
		 * Setter for fileUploadListener
		 * @param fileUploadListener - new value
		 */
		 public void setFileUploadListener( MethodExpression  __fileUploadListener ){
			this._fileUploadListener = __fileUploadListener;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * immediateUpload
		 * If this attribute is true files will be immediately uploaded after they have been added in list.
				Default value is "false".
		 */
		private ValueExpression _immediateUpload;
		/**
		 * If this attribute is true files will be immediately uploaded after they have been added in list.
				Default value is "false".
		 * Setter for immediateUpload
		 * @param immediateUpload - new value
		 */
		 public void setImmediateUpload( ValueExpression  __immediateUpload ){
			this._immediateUpload = __immediateUpload;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listHeight
		 * Defines height of file list. Default value is "210px".
		 */
		private ValueExpression _listHeight;
		/**
		 * Defines height of file list. Default value is "210px".
		 * Setter for listHeight
		 * @param listHeight - new value
		 */
		 public void setListHeight( ValueExpression  __listHeight ){
			this._listHeight = __listHeight;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listWidth
		 * Defines width of file list. Default value is "400px".
		 */
		private ValueExpression _listWidth;
		/**
		 * Defines width of file list. Default value is "400px".
		 * Setter for listWidth
		 * @param listWidth - new value
		 */
		 public void setListWidth( ValueExpression  __listWidth ){
			this._listWidth = __listWidth;
	     }
	  
	 	 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * locale
		 * Used for locale definition
		 */
		private ValueExpression _locale;
		/**
		 * Used for locale definition
		 * Setter for locale
		 * @param locale - new value
		 */
		 public void setLocale( ValueExpression  __locale ){
			this._locale = __locale;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * maxFilesQuantity
		 * Defines max files count allowed for upload (optional). Default value is "1".
		 */
		private ValueExpression _maxFilesQuantity;
		/**
		 * Defines max files count allowed for upload (optional). Default value is "1".
		 * Setter for maxFilesQuantity
		 * @param maxFilesQuantity - new value
		 */
		 public void setMaxFilesQuantity( ValueExpression  __maxFilesQuantity ){
			this._maxFilesQuantity = __maxFilesQuantity;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * noDuplicate
		 * Defines if component should allow to add files that were already in list. Default value is "false".
		 */
		private ValueExpression _noDuplicate;
		/**
		 * Defines if component should allow to add files that were already in list. Default value is "false".
		 * Setter for noDuplicate
		 * @param noDuplicate - new value
		 */
		 public void setNoDuplicate( ValueExpression  __noDuplicate ){
			this._noDuplicate = __noDuplicate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onadd
		 * The client-side script method to be called before a file is added
		 */
		private ValueExpression _onadd;
		/**
		 * The client-side script method to be called before a file is added
		 * Setter for onadd
		 * @param onadd - new value
		 */
		 public void setOnadd( ValueExpression  __onadd ){
			this._onadd = __onadd;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onblur
		 * The client-side script method to be called when the element loses the focus
		 */
		private ValueExpression _onblur;
		/**
		 * The client-side script method to be called when the element loses the focus
		 * Setter for onblur
		 * @param onblur - new value
		 */
		 public void setOnblur( ValueExpression  __onblur ){
			this._onblur = __onblur;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onchange
		 * The client-side script method to be called when the element value is changed
		 */
		private ValueExpression _onchange;
		/**
		 * The client-side script method to be called when the element value is changed
		 * Setter for onchange
		 * @param onchange - new value
		 */
		 public void setOnchange( ValueExpression  __onchange ){
			this._onchange = __onchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onclear
		 * The client-side script method to be called when a file entry is cleared
		 */
		private ValueExpression _onclear;
		/**
		 * The client-side script method to be called when a file entry is cleared
		 * Setter for onclear
		 * @param onclear - new value
		 */
		 public void setOnclear( ValueExpression  __onclear ){
			this._onclear = __onclear;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * onerror
		 * The client-side script method to be called when a file uploading is interrupted according to any errors
		 */
		private ValueExpression _onerror;
		/**
		 * The client-side script method to be called when a file uploading is interrupted according to any errors
		 * Setter for onerror
		 * @param onerror - new value
		 */
		 public void setOnerror( ValueExpression  __onerror ){
			this._onerror = __onerror;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onfileuploadcomplete
		 * The client-side script method to be called when a file is uploaded to the server
		 */
		private ValueExpression _onfileuploadcomplete;
		/**
		 * The client-side script method to be called when a file is uploaded to the server
		 * Setter for onfileuploadcomplete
		 * @param onfileuploadcomplete - new value
		 */
		 public void setOnfileuploadcomplete( ValueExpression  __onfileuploadcomplete ){
			this._onfileuploadcomplete = __onfileuploadcomplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onfocus
		 * The client-side script method to be called when the element gets the focus
		 */
		private ValueExpression _onfocus;
		/**
		 * The client-side script method to be called when the element gets the focus
		 * Setter for onfocus
		 * @param onfocus - new value
		 */
		 public void setOnfocus( ValueExpression  __onfocus ){
			this._onfocus = __onfocus;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onselect
		 * The client-side script method to be called when some text is selected in the text field. This attribute can be used with the INPUT and TEXTAREA elements.
		 */
		private ValueExpression _onselect;
		/**
		 * The client-side script method to be called when some text is selected in the text field. This attribute can be used with the INPUT and TEXTAREA elements.
		 * Setter for onselect
		 * @param onselect - new value
		 */
		 public void setOnselect( ValueExpression  __onselect ){
			this._onselect = __onselect;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onsizerejected
		 * The client-side script method to be called when a file uploading is rejected by the file size overflow
		 */
		private ValueExpression _onsizerejected;
		/**
		 * The client-side script method to be called when a file uploading is rejected by the file size overflow
		 * Setter for onsizerejected
		 * @param onsizerejected - new value
		 */
		 public void setOnsizerejected( ValueExpression  __onsizerejected ){
			this._onsizerejected = __onsizerejected;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ontyperejected
		 * The client-side script method to be called when a file type is rejected according to the file types allowed
		 */
		private ValueExpression _ontyperejected;
		/**
		 * The client-side script method to be called when a file type is rejected according to the file types allowed
		 * Setter for ontyperejected
		 * @param ontyperejected - new value
		 */
		 public void setOntyperejected( ValueExpression  __ontyperejected ){
			this._ontyperejected = __ontyperejected;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onupload
		 * The client-side script method to be called when a file uploading is started
		 */
		private ValueExpression _onupload;
		/**
		 * The client-side script method to be called when a file uploading is started
		 * Setter for onupload
		 * @param onupload - new value
		 */
		 public void setOnupload( ValueExpression  __onupload ){
			this._onupload = __onupload;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onuploadcanceled
		 * The client-side script method to be called when a file uploading is cancelled
		 */
		private ValueExpression _onuploadcanceled;
		/**
		 * The client-side script method to be called when a file uploading is cancelled
		 * Setter for onuploadcanceled
		 * @param onuploadcanceled - new value
		 */
		 public void setOnuploadcanceled( ValueExpression  __onuploadcanceled ){
			this._onuploadcanceled = __onuploadcanceled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onuploadcomplete
		 * The client-side script method to be called when uploading of all files from the list is completed
		 */
		private ValueExpression _onuploadcomplete;
		/**
		 * The client-side script method to be called when uploading of all files from the list is completed
		 * Setter for onuploadcomplete
		 * @param onuploadcomplete - new value
		 */
		 public void setOnuploadcomplete( ValueExpression  __onuploadcomplete ){
			this._onuploadcomplete = __onuploadcomplete;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * progressLabel
		 * Defines a label for a progress label
		 */
		private ValueExpression _progressLabel;
		/**
		 * Defines a label for a progress label
		 * Setter for progressLabel
		 * @param progressLabel - new value
		 */
		 public void setProgressLabel( ValueExpression  __progressLabel ){
			this._progressLabel = __progressLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * progressLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Progress' label
		 */
		private ValueExpression _progressLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Progress' label
		 * Setter for progressLabelClass
		 * @param progressLabelClass - new value
		 */
		 public void setProgressLabelClass( ValueExpression  __progressLabelClass ){
			this._progressLabelClass = __progressLabelClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * sizeErrorLabel
		 * Defines a label for a size error label
		 */
		private ValueExpression _sizeErrorLabel;
		/**
		 * Defines a label for a size error label
		 * Setter for sizeErrorLabel
		 * @param sizeErrorLabel - new value
		 */
		 public void setSizeErrorLabel( ValueExpression  __sizeErrorLabel ){
			this._sizeErrorLabel = __sizeErrorLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sizeErrorLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Size error' label
		 */
		private ValueExpression _sizeErrorLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Size error' label
		 * Setter for sizeErrorLabelClass
		 * @param sizeErrorLabelClass - new value
		 */
		 public void setSizeErrorLabelClass( ValueExpression  __sizeErrorLabelClass ){
			this._sizeErrorLabelClass = __sizeErrorLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stopButtonClass
		 * Assigns one or more space-separated CSS class names to the component 'Cancel' button
		 */
		private ValueExpression _stopButtonClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Cancel' button
		 * Setter for stopButtonClass
		 * @param stopButtonClass - new value
		 */
		 public void setStopButtonClass( ValueExpression  __stopButtonClass ){
			this._stopButtonClass = __stopButtonClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stopButtonClassDisabled
		 * Assigns one or more space-separated CSS class names to the component 'Cancel' button disabled
		 */
		private ValueExpression _stopButtonClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Cancel' button disabled
		 * Setter for stopButtonClassDisabled
		 * @param stopButtonClassDisabled - new value
		 */
		 public void setStopButtonClassDisabled( ValueExpression  __stopButtonClassDisabled ){
			this._stopButtonClassDisabled = __stopButtonClassDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stopControlLabel
		 * Defines a label for a stop button
		 */
		private ValueExpression _stopControlLabel;
		/**
		 * Defines a label for a stop button
		 * Setter for stopControlLabel
		 * @param stopControlLabel - new value
		 */
		 public void setStopControlLabel( ValueExpression  __stopControlLabel ){
			this._stopControlLabel = __stopControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stopEntryControlLabel
		 * Defines a label for a stop control
		 */
		private ValueExpression _stopEntryControlLabel;
		/**
		 * Defines a label for a stop control
		 * Setter for stopEntryControlLabel
		 * @param stopEntryControlLabel - new value
		 */
		 public void setStopEntryControlLabel( ValueExpression  __stopEntryControlLabel ){
			this._stopEntryControlLabel = __stopEntryControlLabel;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * tabindex
		 * This attribute specifies the position of the current element in the tabbing order for the current document. This value must be a number between 0 and 32767. User agents should ignore leading zeros
		 */
		private ValueExpression _tabindex;
		/**
		 * This attribute specifies the position of the current element in the tabbing order for the current document. This value must be a number between 0 and 32767. User agents should ignore leading zeros
		 * Setter for tabindex
		 * @param tabindex - new value
		 */
		 public void setTabindex( ValueExpression  __tabindex ){
			this._tabindex = __tabindex;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * transferErrorLabel
		 * Defines a label for a transfer error label
		 */
		private ValueExpression _transferErrorLabel;
		/**
		 * Defines a label for a transfer error label
		 * Setter for transferErrorLabel
		 * @param transferErrorLabel - new value
		 */
		 public void setTransferErrorLabel( ValueExpression  __transferErrorLabel ){
			this._transferErrorLabel = __transferErrorLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * transferErrorLabelClass
		 * Assigns one or more space-separated CSS class names to the component 'Transfer error' label
		 */
		private ValueExpression _transferErrorLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Transfer error' label
		 * Setter for transferErrorLabelClass
		 * @param transferErrorLabelClass - new value
		 */
		 public void setTransferErrorLabelClass( ValueExpression  __transferErrorLabelClass ){
			this._transferErrorLabelClass = __transferErrorLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uploadButtonClass
		 * Assigns one or more space-separated CSS class names to the component 'Upload' button
		 */
		private ValueExpression _uploadButtonClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Upload' button
		 * Setter for uploadButtonClass
		 * @param uploadButtonClass - new value
		 */
		 public void setUploadButtonClass( ValueExpression  __uploadButtonClass ){
			this._uploadButtonClass = __uploadButtonClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uploadButtonClassDisabled
		 * Assigns one or more space-separated CSS class names to the component 'Upload' button disabled
		 */
		private ValueExpression _uploadButtonClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the component 'Upload' button disabled
		 * Setter for uploadButtonClassDisabled
		 * @param uploadButtonClassDisabled - new value
		 */
		 public void setUploadButtonClassDisabled( ValueExpression  __uploadButtonClassDisabled ){
			this._uploadButtonClassDisabled = __uploadButtonClassDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uploadControlLabel
		 * Defines a label for an upload button
		 */
		private ValueExpression _uploadControlLabel;
		/**
		 * Defines a label for an upload button
		 * Setter for uploadControlLabel
		 * @param uploadControlLabel - new value
		 */
		 public void setUploadControlLabel( ValueExpression  __uploadControlLabel ){
			this._uploadControlLabel = __uploadControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uploadData
		 * Collection of files uploaded
		 */
		private ValueExpression _uploadData;
		/**
		 * Collection of files uploaded
		 * Setter for uploadData
		 * @param uploadData - new value
		 */
		 public void setUploadData( ValueExpression  __uploadData ){
			this._uploadData = __uploadData;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uploadListClass
		 * Assigns one or more space-separated CSS class names to the upload list
		 */
		private ValueExpression _uploadListClass;
		/**
		 * Assigns one or more space-separated CSS class names to the upload list
		 * Setter for uploadListClass
		 * @param uploadListClass - new value
		 */
		 public void setUploadListClass( ValueExpression  __uploadListClass ){
			this._uploadListClass = __uploadListClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uploadListClassDisabled
		 * Assigns one or more space-separated CSS class names to the upload list disabled
		 */
		private ValueExpression _uploadListClassDisabled;
		/**
		 * Assigns one or more space-separated CSS class names to the upload list disabled
		 * Setter for uploadListClassDisabled
		 * @param uploadListClassDisabled - new value
		 */
		 public void setUploadListClassDisabled( ValueExpression  __uploadListClassDisabled ){
			this._uploadListClassDisabled = __uploadListClassDisabled;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._acceptedTypes = null;
	 		 		 		    this._accesskey = null;
	 		 		    this._addButtonClass = null;
	 		 		    this._addButtonClassDisabled = null;
	 		 		    this._addControlLabel = null;
	 		 		    this._ajaxSingle = null;
	 		 		 		    this._allowFlash = null;
	 		 		    this._alt = null;
	 		 		    this._autoclear = null;
	 		 		 		    this._cancelEntryControlLabel = null;
	 		 		    this._cleanButtonClass = null;
	 		 		    this._cleanButtonClassDisabled = null;
	 		 		    this._clearAllControlLabel = null;
	 		 		    this._clearControlLabel = null;
	 		 		 		 		 		    this._disabled = null;
	 		 		    this._doneLabel = null;
	 		 		    this._doneLabelClass = null;
	 		 		    this._entryCancelLabelClass = null;
	 		 		    this._entryClearLabelClass = null;
	 		 		    this._entryStopLabelClass = null;
	 		 		 		    this._fileEntryClass = null;
	 		 		    this._fileEntryClassDisabled = null;
	 		 		    this._fileEntryControlClass = null;
	 		 		    this._fileEntryControlClassDisabled = null;
	 		 		 		 		    this._fileUploadListener = null;
	 		 		 		 		    this._immediate = null;
	 		 		    this._immediateUpload = null;
	 		 		    this._listHeight = null;
	 		 		    this._listWidth = null;
	 		 		 		 		 		 		 		 		    this._locale = null;
	 		 		    this._maxFilesQuantity = null;
	 		 		 		 		    this._noDuplicate = null;
	 		 		    this._onadd = null;
	 		 		    this._onblur = null;
	 		 		    this._onchange = null;
	 		 		    this._onclear = null;
	 		 		 		 		    this._onerror = null;
	 		 		    this._onfileuploadcomplete = null;
	 		 		    this._onfocus = null;
	 		 		 		 		 		 		 		 		 		 		    this._onselect = null;
	 		 		    this._onsizerejected = null;
	 		 		    this._ontyperejected = null;
	 		 		    this._onupload = null;
	 		 		    this._onuploadcanceled = null;
	 		 		    this._onuploadcomplete = null;
	 		 		 		    this._progressLabel = null;
	 		 		    this._progressLabelClass = null;
	 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		 		    this._sizeErrorLabel = null;
	 		 		    this._sizeErrorLabelClass = null;
	 		 		    this._status = null;
	 		 		    this._stopButtonClass = null;
	 		 		    this._stopButtonClassDisabled = null;
	 		 		    this._stopControlLabel = null;
	 		 		    this._stopEntryControlLabel = null;
	 		 		 		 		    this._tabindex = null;
	 		 		    this._transferErrorLabel = null;
	 		 		    this._transferErrorLabelClass = null;
	 		 		    this._uploadButtonClass = null;
	 		 		    this._uploadButtonClassDisabled = null;
	 		 		    this._uploadControlLabel = null;
	 		 		    this._uploadData = null;
	 		 		    this._uploadListClass = null;
	 		 		    this._uploadListClassDisabled = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlFileUpload comp = (HtmlFileUpload) component;
 		 			 
						if (this._acceptedTypes != null) {
				if (this._acceptedTypes.isLiteralText()) {
					try {
												
						java.lang.String __acceptedTypes = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._acceptedTypes.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAcceptedTypes(__acceptedTypes);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("acceptedTypes", this._acceptedTypes);
				}
			}
					    		 			 
						if (this._accesskey != null) {
				if (this._accesskey.isLiteralText()) {
					try {
												
						java.lang.String __accesskey = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._accesskey.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAccesskey(__accesskey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("accesskey", this._accesskey);
				}
			}
					   		 			 
						if (this._addButtonClass != null) {
				if (this._addButtonClass.isLiteralText()) {
					try {
												
						java.lang.String __addButtonClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._addButtonClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAddButtonClass(__addButtonClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("addButtonClass", this._addButtonClass);
				}
			}
					   		 			 
						if (this._addButtonClassDisabled != null) {
				if (this._addButtonClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __addButtonClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._addButtonClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAddButtonClassDisabled(__addButtonClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("addButtonClassDisabled", this._addButtonClassDisabled);
				}
			}
					   		 			 
						if (this._addControlLabel != null) {
				if (this._addControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __addControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._addControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAddControlLabel(__addControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("addControlLabel", this._addControlLabel);
				}
			}
					   		 			 
						if (this._ajaxSingle != null) {
				if (this._ajaxSingle.isLiteralText()) {
					try {
												
						Boolean __ajaxSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxSingle(__ajaxSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSingle", this._ajaxSingle);
				}
			}
					    		 			 
						if (this._allowFlash != null) {
				if (this._allowFlash.isLiteralText()) {
					try {
												
						java.lang.String __allowFlash = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._allowFlash.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAllowFlash(__allowFlash);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("allowFlash", this._allowFlash);
				}
			}
					   		 			 
						if (this._alt != null) {
				if (this._alt.isLiteralText()) {
					try {
												
						java.lang.String __alt = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._alt.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAlt(__alt);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("alt", this._alt);
				}
			}
					   		 			 
						if (this._autoclear != null) {
				if (this._autoclear.isLiteralText()) {
					try {
												
						Boolean __autoclear = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._autoclear.getExpressionString(), 
											Boolean.class);
					
												comp.setAutoclear(__autoclear.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("autoclear", this._autoclear);
				}
			}
					    		 			 
						if (this._cancelEntryControlLabel != null) {
				if (this._cancelEntryControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __cancelEntryControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cancelEntryControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCancelEntryControlLabel(__cancelEntryControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cancelEntryControlLabel", this._cancelEntryControlLabel);
				}
			}
					   		 			 
						if (this._cleanButtonClass != null) {
				if (this._cleanButtonClass.isLiteralText()) {
					try {
												
						java.lang.String __cleanButtonClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cleanButtonClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCleanButtonClass(__cleanButtonClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cleanButtonClass", this._cleanButtonClass);
				}
			}
					   		 			 
						if (this._cleanButtonClassDisabled != null) {
				if (this._cleanButtonClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __cleanButtonClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cleanButtonClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCleanButtonClassDisabled(__cleanButtonClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cleanButtonClassDisabled", this._cleanButtonClassDisabled);
				}
			}
					   		 			 
						if (this._clearAllControlLabel != null) {
				if (this._clearAllControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __clearAllControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._clearAllControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setClearAllControlLabel(__clearAllControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("clearAllControlLabel", this._clearAllControlLabel);
				}
			}
					   		 			 
						if (this._clearControlLabel != null) {
				if (this._clearControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __clearControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._clearControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setClearControlLabel(__clearControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("clearControlLabel", this._clearControlLabel);
				}
			}
					      		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					   		 			 
						if (this._doneLabel != null) {
				if (this._doneLabel.isLiteralText()) {
					try {
												
						java.lang.String __doneLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._doneLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDoneLabel(__doneLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("doneLabel", this._doneLabel);
				}
			}
					   		 			 
						if (this._doneLabelClass != null) {
				if (this._doneLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __doneLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._doneLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDoneLabelClass(__doneLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("doneLabelClass", this._doneLabelClass);
				}
			}
					   		 			 
						if (this._entryCancelLabelClass != null) {
				if (this._entryCancelLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __entryCancelLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._entryCancelLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEntryCancelLabelClass(__entryCancelLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("entryCancelLabelClass", this._entryCancelLabelClass);
				}
			}
					   		 			 
						if (this._entryClearLabelClass != null) {
				if (this._entryClearLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __entryClearLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._entryClearLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEntryClearLabelClass(__entryClearLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("entryClearLabelClass", this._entryClearLabelClass);
				}
			}
					   		 			 
						if (this._entryStopLabelClass != null) {
				if (this._entryStopLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __entryStopLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._entryStopLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEntryStopLabelClass(__entryStopLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("entryStopLabelClass", this._entryStopLabelClass);
				}
			}
					    		 			 
						if (this._fileEntryClass != null) {
				if (this._fileEntryClass.isLiteralText()) {
					try {
												
						java.lang.String __fileEntryClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fileEntryClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFileEntryClass(__fileEntryClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fileEntryClass", this._fileEntryClass);
				}
			}
					   		 			 
						if (this._fileEntryClassDisabled != null) {
				if (this._fileEntryClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __fileEntryClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fileEntryClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFileEntryClassDisabled(__fileEntryClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fileEntryClassDisabled", this._fileEntryClassDisabled);
				}
			}
					   		 			 
						if (this._fileEntryControlClass != null) {
				if (this._fileEntryControlClass.isLiteralText()) {
					try {
												
						java.lang.String __fileEntryControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fileEntryControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFileEntryControlClass(__fileEntryControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fileEntryControlClass", this._fileEntryControlClass);
				}
			}
					   		 			 
						if (this._fileEntryControlClassDisabled != null) {
				if (this._fileEntryControlClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __fileEntryControlClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fileEntryControlClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFileEntryControlClassDisabled(__fileEntryControlClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fileEntryControlClassDisabled", this._fileEntryControlClassDisabled);
				}
			}
					     		 			if(null != this._fileUploadListener){
             if (!this._fileUploadListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._fileUploadListener);
                ((HtmlFileUpload)component).setFileUploadListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid fileUploadListener value: " + this._fileUploadListener);
             }
			}
		     		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._immediateUpload != null) {
				if (this._immediateUpload.isLiteralText()) {
					try {
												
						Boolean __immediateUpload = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediateUpload.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediateUpload(__immediateUpload.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediateUpload", this._immediateUpload);
				}
			}
					   		 			 
						if (this._listHeight != null) {
				if (this._listHeight.isLiteralText()) {
					try {
												
						java.lang.String __listHeight = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listHeight.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListHeight(__listHeight);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listHeight", this._listHeight);
				}
			}
					   		 			 
						if (this._listWidth != null) {
				if (this._listWidth.isLiteralText()) {
					try {
												
						java.lang.String __listWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListWidth(__listWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listWidth", this._listWidth);
				}
			}
					         		 			 
						if (this._locale != null) {
				if (this._locale.isLiteralText()) {
					try {
												
						java.lang.Object __locale = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._locale.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setLocale(__locale);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("locale", this._locale);
				}
			}
					   		 			 
						if (this._maxFilesQuantity != null) {
				if (this._maxFilesQuantity.isLiteralText()) {
					try {
												
						java.lang.Integer __maxFilesQuantity = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._maxFilesQuantity.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setMaxFilesQuantity(__maxFilesQuantity);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("maxFilesQuantity", this._maxFilesQuantity);
				}
			}
					     		 			 
						if (this._noDuplicate != null) {
				if (this._noDuplicate.isLiteralText()) {
					try {
												
						Boolean __noDuplicate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._noDuplicate.getExpressionString(), 
											Boolean.class);
					
												comp.setNoDuplicate(__noDuplicate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("noDuplicate", this._noDuplicate);
				}
			}
					   		 			 
						if (this._onadd != null) {
				if (this._onadd.isLiteralText()) {
					try {
												
						java.lang.String __onadd = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onadd.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnadd(__onadd);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onadd", this._onadd);
				}
			}
					   		 			 
						if (this._onblur != null) {
				if (this._onblur.isLiteralText()) {
					try {
												
						java.lang.String __onblur = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onblur.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnblur(__onblur);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onblur", this._onblur);
				}
			}
					   		 			 
						if (this._onchange != null) {
				if (this._onchange.isLiteralText()) {
					try {
												
						java.lang.String __onchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnchange(__onchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onchange", this._onchange);
				}
			}
					   		 			 
						if (this._onclear != null) {
				if (this._onclear.isLiteralText()) {
					try {
												
						java.lang.String __onclear = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onclear.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnclear(__onclear);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onclear", this._onclear);
				}
			}
					     		 			 
						if (this._onerror != null) {
				if (this._onerror.isLiteralText()) {
					try {
												
						java.lang.String __onerror = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onerror.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnerror(__onerror);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onerror", this._onerror);
				}
			}
					   		 			 
						if (this._onfileuploadcomplete != null) {
				if (this._onfileuploadcomplete.isLiteralText()) {
					try {
												
						java.lang.String __onfileuploadcomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfileuploadcomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfileuploadcomplete(__onfileuploadcomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfileuploadcomplete", this._onfileuploadcomplete);
				}
			}
					   		 			 
						if (this._onfocus != null) {
				if (this._onfocus.isLiteralText()) {
					try {
												
						java.lang.String __onfocus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfocus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfocus(__onfocus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfocus", this._onfocus);
				}
			}
					           		 			 
						if (this._onselect != null) {
				if (this._onselect.isLiteralText()) {
					try {
												
						java.lang.String __onselect = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselect.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselect(__onselect);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselect", this._onselect);
				}
			}
					   		 			 
						if (this._onsizerejected != null) {
				if (this._onsizerejected.isLiteralText()) {
					try {
												
						java.lang.String __onsizerejected = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsizerejected.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsizerejected(__onsizerejected);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsizerejected", this._onsizerejected);
				}
			}
					   		 			 
						if (this._ontyperejected != null) {
				if (this._ontyperejected.isLiteralText()) {
					try {
												
						java.lang.String __ontyperejected = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ontyperejected.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOntyperejected(__ontyperejected);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ontyperejected", this._ontyperejected);
				}
			}
					   		 			 
						if (this._onupload != null) {
				if (this._onupload.isLiteralText()) {
					try {
												
						java.lang.String __onupload = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onupload.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnupload(__onupload);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onupload", this._onupload);
				}
			}
					   		 			 
						if (this._onuploadcanceled != null) {
				if (this._onuploadcanceled.isLiteralText()) {
					try {
												
						java.lang.String __onuploadcanceled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onuploadcanceled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnuploadcanceled(__onuploadcanceled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onuploadcanceled", this._onuploadcanceled);
				}
			}
					   		 			 
						if (this._onuploadcomplete != null) {
				if (this._onuploadcomplete.isLiteralText()) {
					try {
												
						java.lang.String __onuploadcomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onuploadcomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnuploadcomplete(__onuploadcomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onuploadcomplete", this._onuploadcomplete);
				}
			}
					    		 			 
						if (this._progressLabel != null) {
				if (this._progressLabel.isLiteralText()) {
					try {
												
						java.lang.String __progressLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._progressLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setProgressLabel(__progressLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("progressLabel", this._progressLabel);
				}
			}
					   		 			 
						if (this._progressLabelClass != null) {
				if (this._progressLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __progressLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._progressLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setProgressLabelClass(__progressLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("progressLabelClass", this._progressLabelClass);
				}
			}
					    		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					    		 			 
						if (this._sizeErrorLabel != null) {
				if (this._sizeErrorLabel.isLiteralText()) {
					try {
												
						java.lang.String __sizeErrorLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sizeErrorLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSizeErrorLabel(__sizeErrorLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sizeErrorLabel", this._sizeErrorLabel);
				}
			}
					   		 			 
						if (this._sizeErrorLabelClass != null) {
				if (this._sizeErrorLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __sizeErrorLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sizeErrorLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSizeErrorLabelClass(__sizeErrorLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sizeErrorLabelClass", this._sizeErrorLabelClass);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					   		 			 
						if (this._stopButtonClass != null) {
				if (this._stopButtonClass.isLiteralText()) {
					try {
												
						java.lang.String __stopButtonClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stopButtonClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStopButtonClass(__stopButtonClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stopButtonClass", this._stopButtonClass);
				}
			}
					   		 			 
						if (this._stopButtonClassDisabled != null) {
				if (this._stopButtonClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __stopButtonClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stopButtonClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStopButtonClassDisabled(__stopButtonClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stopButtonClassDisabled", this._stopButtonClassDisabled);
				}
			}
					   		 			 
						if (this._stopControlLabel != null) {
				if (this._stopControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __stopControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stopControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStopControlLabel(__stopControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stopControlLabel", this._stopControlLabel);
				}
			}
					   		 			 
						if (this._stopEntryControlLabel != null) {
				if (this._stopEntryControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __stopEntryControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stopEntryControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStopEntryControlLabel(__stopEntryControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stopEntryControlLabel", this._stopEntryControlLabel);
				}
			}
					     		 			 
						if (this._tabindex != null) {
				if (this._tabindex.isLiteralText()) {
					try {
												
						java.lang.String __tabindex = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tabindex.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTabindex(__tabindex);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tabindex", this._tabindex);
				}
			}
					   		 			 
						if (this._transferErrorLabel != null) {
				if (this._transferErrorLabel.isLiteralText()) {
					try {
												
						java.lang.String __transferErrorLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._transferErrorLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTransferErrorLabel(__transferErrorLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("transferErrorLabel", this._transferErrorLabel);
				}
			}
					   		 			 
						if (this._transferErrorLabelClass != null) {
				if (this._transferErrorLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __transferErrorLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._transferErrorLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTransferErrorLabelClass(__transferErrorLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("transferErrorLabelClass", this._transferErrorLabelClass);
				}
			}
					   		 			 
						if (this._uploadButtonClass != null) {
				if (this._uploadButtonClass.isLiteralText()) {
					try {
												
						java.lang.String __uploadButtonClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uploadButtonClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUploadButtonClass(__uploadButtonClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uploadButtonClass", this._uploadButtonClass);
				}
			}
					   		 			 
						if (this._uploadButtonClassDisabled != null) {
				if (this._uploadButtonClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __uploadButtonClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uploadButtonClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUploadButtonClassDisabled(__uploadButtonClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uploadButtonClassDisabled", this._uploadButtonClassDisabled);
				}
			}
					   		 			 
						if (this._uploadControlLabel != null) {
				if (this._uploadControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __uploadControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uploadControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUploadControlLabel(__uploadControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uploadControlLabel", this._uploadControlLabel);
				}
			}
					   		 			 				if(null != this._uploadData && this._uploadData.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.component.FileUpload with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property uploadData");
				}
			 
						if (this._uploadData != null) {
				if (this._uploadData.isLiteralText()) {
					try {
												
						java.lang.Object __uploadData = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uploadData.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setUploadData(__uploadData);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uploadData", this._uploadData);
				}
			}
					   		 			 
						if (this._uploadListClass != null) {
				if (this._uploadListClass.isLiteralText()) {
					try {
												
						java.lang.String __uploadListClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uploadListClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUploadListClass(__uploadListClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uploadListClass", this._uploadListClass);
				}
			}
					   		 			 
						if (this._uploadListClassDisabled != null) {
				if (this._uploadListClassDisabled.isLiteralText()) {
					try {
												
						java.lang.String __uploadListClassDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uploadListClassDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUploadListClassDisabled(__uploadListClassDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uploadListClassDisabled", this._uploadListClassDisabled);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					         }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.component.FileUpload";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.renderkit.html.FileUploadRenderer";
			}

}
