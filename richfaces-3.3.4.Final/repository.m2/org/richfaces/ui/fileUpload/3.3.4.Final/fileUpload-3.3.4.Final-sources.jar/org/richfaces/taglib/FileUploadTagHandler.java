/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import com.sun.facelets.tag.jsf.ComponentHandler ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import java.lang.Integer ;
import javax.faces.component.UIComponent ;
import javax.faces.component.UIComponent;
import org.richfaces.component.html.HtmlFileUpload;
import com.sun.facelets.tag.jsf.ComponentHandler;
import com.sun.facelets.tag.jsf.ComponentConfig;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
/**
 * @author shura (latest modification by $Author: alexsmirnov $)
 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
 *
 */
public class FileUploadTagHandler extends com.sun.facelets.tag.jsf.ComponentHandler {


  private static final FileUploadTagHandlerMetaRule metaRule = new FileUploadTagHandlerMetaRule();


  
  public FileUploadTagHandler(ComponentConfig config) 
  {
    super(config);
  }
// Metarule
  protected MetaRuleset createMetaRuleset(Class type)
  {
    MetaRuleset m = super.createMetaRuleset(type);
	m.addRule(metaRule);
	return m;
  }

  	/**
	 * @author shura (latest modification by $Author: alexsmirnov $)
	 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
	 *
	 */
	static class FileUploadTagHandlerMetaRule extends MetaRule{

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.MetaRule#applyRule(java.lang.String, com.sun.facelets.tag.TagAttribute, com.sun.facelets.tag.MetadataTarget)
		 */
		public Metadata applyRule(String name, TagAttribute attribute, MetadataTarget meta) {
	        if (meta.isTargetInstanceOf(HtmlFileUpload.class)) {
				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  	            	            
	            if ("fileUploadListener".equals(name)) {
	                    return new fileUploadListenerMapper(attribute);
	            }
				
						  		 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 				 				 				 				 				 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  	            	            
	            if ("validator".equals(name)) {
	                    return new validatorMapper(attribute);
	            }
				
						  		 				 		  		 				 				 		  		 				 		  		 				 			        }
			return null;
		}

	}


    
    
    
    
    
    
    
    
    
    
     
    
    
    
    
    
    
    
    
    
    
    
    
    
     
    
    
    
    
    
    
  		
	static class fileUploadListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.UploadEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public fileUploadListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlFileUpload) instance)
            .setFileUploadListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	    
    
    
    
    
    
    
    
     
    
    
    
    
    
    
    
    
    
      
    
    
            
    
    
    
    
    
    
    
    
     
    
    
    
    
    
    
    
    
    
      
    
    
    
    
    
    
    
    
    
    
  		
	static class validatorMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {javax.faces.context.FacesContext.class,javax.faces.component.UIComponent.class,java.lang.Object.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public validatorMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlFileUpload) instance)
            .setValidator
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	  
     
    
     }
