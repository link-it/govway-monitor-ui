/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlGmap;

public class GmapTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * enableContinuousZoom
		 * Enables continuous smooth zooming for selected browsers. Default value is "false".
		 */
		private ValueExpression _enableContinuousZoom;
		/**
		 * Enables continuous smooth zooming for selected browsers. Default value is "false".
		 * Setter for enableContinuousZoom
		 * @param enableContinuousZoom - new value
		 */
		 public void setEnableContinuousZoom( ValueExpression  __enableContinuousZoom ){
			this._enableContinuousZoom = __enableContinuousZoom;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * enableDoubleClickZoom
		 * Enables zooming in by a double click. Default value is "false".
		 */
		private ValueExpression _enableDoubleClickZoom;
		/**
		 * Enables zooming in by a double click. Default value is "false".
		 * Setter for enableDoubleClickZoom
		 * @param enableDoubleClickZoom - new value
		 */
		 public void setEnableDoubleClickZoom( ValueExpression  __enableDoubleClickZoom ){
			this._enableDoubleClickZoom = __enableDoubleClickZoom;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * enableDragging
		 * Enables a map dragging with the mouse. Default value is "true".
		 */
		private ValueExpression _enableDragging;
		/**
		 * Enables a map dragging with the mouse. Default value is "true".
		 * Setter for enableDragging
		 * @param enableDragging - new value
		 */
		 public void setEnableDragging( ValueExpression  __enableDragging ){
			this._enableDragging = __enableDragging;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * enableInfoWindow
		 * Enables Info Window. Default value is "true".
		 */
		private ValueExpression _enableInfoWindow;
		/**
		 * Enables Info Window. Default value is "true".
		 * Setter for enableInfoWindow
		 * @param enableInfoWindow - new value
		 */
		 public void setEnableInfoWindow( ValueExpression  __enableInfoWindow ){
			this._enableInfoWindow = __enableInfoWindow;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * gmapKey
		 * Google Map key. A single Map API key is valid for a single "directory" on your web server. Default value is "internal".
		 */
		private ValueExpression _gmapKey;
		/**
		 * Google Map key. A single Map API key is valid for a single "directory" on your web server. Default value is "internal".
		 * Setter for gmapKey
		 * @param gmapKey - new value
		 */
		 public void setGmapKey( ValueExpression  __gmapKey ){
			this._gmapKey = __gmapKey;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * gmapVar
		 * The JavaScript variable that is used to access the Google Map API. If you have
			 more than one Google Map components on the same page, use individual
			 key for each of them. The default variable name is "map" (without quotes).
		 */
		private ValueExpression _gmapVar;
		/**
		 * The JavaScript variable that is used to access the Google Map API. If you have
			 more than one Google Map components on the same page, use individual
			 key for each of them. The default variable name is "map" (without quotes).
		 * Setter for gmapVar
		 * @param gmapVar - new value
		 */
		 public void setGmapVar( ValueExpression  __gmapVar ){
			this._gmapVar = __gmapVar;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * lat
		 * Initial latitude coordinate in degrees, as a number between -90 and +90. Default value is "37.9721046".
		 */
		private ValueExpression _lat;
		/**
		 * Initial latitude coordinate in degrees, as a number between -90 and +90. Default value is "37.9721046".
		 * Setter for lat
		 * @param lat - new value
		 */
		 public void setLat( ValueExpression  __lat ){
			this._lat = __lat;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * lng
		 * Initial longitude coordinate in degrees, as a number between -180 and +180. Default value is "-122.0424842834".
		 */
		private ValueExpression _lng;
		/**
		 * Initial longitude coordinate in degrees, as a number between -180 and +180. Default value is "-122.0424842834".
		 * Setter for lng
		 * @param lng - new value
		 */
		 public void setLng( ValueExpression  __lng ){
			this._lng = __lng;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * locale
		 * Used for locale definition.   Default value is "getDefaultLocale()".
		 */
		private ValueExpression _locale;
		/**
		 * Used for locale definition.   Default value is "getDefaultLocale()".
		 * Setter for locale
		 * @param locale - new value
		 */
		 public void setLocale( ValueExpression  __locale ){
			this._locale = __locale;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * mapType
		 * Initial map type. The possible values are  "G_NORMAL_MAP", "G_SATELLITE_MAP",
                        "G_HYBRID_MAP". Default value is "G_SATELLITE_MAP".
		 */
		private ValueExpression _mapType;
		/**
		 * Initial map type. The possible values are  "G_NORMAL_MAP", "G_SATELLITE_MAP",
                        "G_HYBRID_MAP". Default value is "G_SATELLITE_MAP".
		 * Setter for mapType
		 * @param mapType - new value
		 */
		 public void setMapType( ValueExpression  __mapType ){
			this._mapType = __mapType;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * oninit
		 * The client-side script method to be called when the Google Map object is initiated
		 */
		private ValueExpression _oninit;
		/**
		 * The client-side script method to be called when the Google Map object is initiated
		 * Setter for oninit
		 * @param oninit - new value
		 */
		 public void setOninit( ValueExpression  __oninit ){
			this._oninit = __oninit;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * showGLargeMapControl
		 * Shows the GLarge control. Default value is "true".
		 */
		private ValueExpression _showGLargeMapControl;
		/**
		 * Shows the GLarge control. Default value is "true".
		 * Setter for showGLargeMapControl
		 * @param showGLargeMapControl - new value
		 */
		 public void setShowGLargeMapControl( ValueExpression  __showGLargeMapControl ){
			this._showGLargeMapControl = __showGLargeMapControl;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showGMapTypeControl
		 * Shows the Type switch control. Default value is "true".
		 */
		private ValueExpression _showGMapTypeControl;
		/**
		 * Shows the Type switch control. Default value is "true".
		 * Setter for showGMapTypeControl
		 * @param showGMapTypeControl - new value
		 */
		 public void setShowGMapTypeControl( ValueExpression  __showGMapTypeControl ){
			this._showGMapTypeControl = __showGMapTypeControl;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showGScaleControl
		 * It shows the scale control. Default value is "true".
		 */
		private ValueExpression _showGScaleControl;
		/**
		 * It shows the scale control. Default value is "true".
		 * Setter for showGScaleControl
		 * @param showGScaleControl - new value
		 */
		 public void setShowGScaleControl( ValueExpression  __showGScaleControl ){
			this._showGScaleControl = __showGScaleControl;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * warningMessage
		 * The warning message that appears if a browser is not compatible with Google Map.
			Default value is "Your browser does not support Google Maps".
		 */
		private ValueExpression _warningMessage;
		/**
		 * The warning message that appears if a browser is not compatible with Google Map.
			Default value is "Your browser does not support Google Maps".
		 * Setter for warningMessage
		 * @param warningMessage - new value
		 */
		 public void setWarningMessage( ValueExpression  __warningMessage ){
			this._warningMessage = __warningMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * zoom
		 * Initial zoom level as a number between 1 and 18. Default value is "17".
		 */
		private ValueExpression _zoom;
		/**
		 * Initial zoom level as a number between 1 and 18. Default value is "17".
		 * Setter for zoom
		 * @param zoom - new value
		 */
		 public void setZoom( ValueExpression  __zoom ){
			this._zoom = __zoom;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._enableContinuousZoom = null;
	 		 		    this._enableDoubleClickZoom = null;
	 		 		    this._enableDragging = null;
	 		 		    this._enableInfoWindow = null;
	 		 		 		    this._gmapKey = null;
	 		 		    this._gmapVar = null;
	 		 		 		    this._lat = null;
	 		 		    this._lng = null;
	 		 		    this._locale = null;
	 		 		    this._mapType = null;
	 		 		 		 		    this._oninit = null;
	 		 		 		 		 		 		 		 		 		 		 		    this._showGLargeMapControl = null;
	 		 		    this._showGMapTypeControl = null;
	 		 		    this._showGScaleControl = null;
	 		 		 		 		    this._warningMessage = null;
	 		 		    this._zoom = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlGmap comp = (HtmlGmap) component;
  		 			 
						if (this._enableContinuousZoom != null) {
				if (this._enableContinuousZoom.isLiteralText()) {
					try {
												
						java.lang.String __enableContinuousZoom = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enableContinuousZoom.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEnableContinuousZoom(__enableContinuousZoom);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enableContinuousZoom", this._enableContinuousZoom);
				}
			}
					   		 			 
						if (this._enableDoubleClickZoom != null) {
				if (this._enableDoubleClickZoom.isLiteralText()) {
					try {
												
						java.lang.String __enableDoubleClickZoom = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enableDoubleClickZoom.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEnableDoubleClickZoom(__enableDoubleClickZoom);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enableDoubleClickZoom", this._enableDoubleClickZoom);
				}
			}
					   		 			 
						if (this._enableDragging != null) {
				if (this._enableDragging.isLiteralText()) {
					try {
												
						java.lang.String __enableDragging = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enableDragging.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEnableDragging(__enableDragging);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enableDragging", this._enableDragging);
				}
			}
					   		 			 
						if (this._enableInfoWindow != null) {
				if (this._enableInfoWindow.isLiteralText()) {
					try {
												
						java.lang.String __enableInfoWindow = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enableInfoWindow.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEnableInfoWindow(__enableInfoWindow);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enableInfoWindow", this._enableInfoWindow);
				}
			}
					    		 			 
						if (this._gmapKey != null) {
				if (this._gmapKey.isLiteralText()) {
					try {
												
						java.lang.String __gmapKey = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._gmapKey.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGmapKey(__gmapKey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("gmapKey", this._gmapKey);
				}
			}
					   		 			 
						if (this._gmapVar != null) {
				if (this._gmapVar.isLiteralText()) {
					try {
												
						java.lang.String __gmapVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._gmapVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGmapVar(__gmapVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("gmapVar", this._gmapVar);
				}
			}
					    		 			 
						if (this._lat != null) {
				if (this._lat.isLiteralText()) {
					try {
												
						java.lang.String __lat = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lat.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLat(__lat);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lat", this._lat);
				}
			}
					   		 			 
						if (this._lng != null) {
				if (this._lng.isLiteralText()) {
					try {
												
						java.lang.String __lng = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lng.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLng(__lng);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lng", this._lng);
				}
			}
					   		 			 
						if (this._locale != null) {
				if (this._locale.isLiteralText()) {
					try {
												
						java.lang.Object __locale = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._locale.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setLocale(__locale);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("locale", this._locale);
				}
			}
					   		 			 
						if (this._mapType != null) {
				if (this._mapType.isLiteralText()) {
					try {
												
						java.lang.String __mapType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._mapType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMapType(__mapType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("mapType", this._mapType);
				}
			}
					     		 			 
						if (this._oninit != null) {
				if (this._oninit.isLiteralText()) {
					try {
												
						java.lang.String __oninit = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninit.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninit(__oninit);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninit", this._oninit);
				}
			}
					            		 			 
						if (this._showGLargeMapControl != null) {
				if (this._showGLargeMapControl.isLiteralText()) {
					try {
												
						java.lang.String __showGLargeMapControl = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showGLargeMapControl.getExpressionString(), 
											java.lang.String.class);
					
												comp.setShowGLargeMapControl(__showGLargeMapControl);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showGLargeMapControl", this._showGLargeMapControl);
				}
			}
					   		 			 
						if (this._showGMapTypeControl != null) {
				if (this._showGMapTypeControl.isLiteralText()) {
					try {
												
						java.lang.String __showGMapTypeControl = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showGMapTypeControl.getExpressionString(), 
											java.lang.String.class);
					
												comp.setShowGMapTypeControl(__showGMapTypeControl);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showGMapTypeControl", this._showGMapTypeControl);
				}
			}
					   		 			 
						if (this._showGScaleControl != null) {
				if (this._showGScaleControl.isLiteralText()) {
					try {
												
						java.lang.String __showGScaleControl = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showGScaleControl.getExpressionString(), 
											java.lang.String.class);
					
												comp.setShowGScaleControl(__showGScaleControl);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showGScaleControl", this._showGScaleControl);
				}
			}
					     		 			 
						if (this._warningMessage != null) {
				if (this._warningMessage.isLiteralText()) {
					try {
												
						java.lang.String __warningMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._warningMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWarningMessage(__warningMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("warningMessage", this._warningMessage);
				}
			}
					   		 			 
						if (this._zoom != null) {
				if (this._zoom.isLiteralText()) {
					try {
												
						java.lang.String __zoom = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._zoom.getExpressionString(), 
											java.lang.String.class);
					
												comp.setZoom(__zoom);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("zoom", this._zoom);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.Gmap";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.GmapRenderer";
			}

}
