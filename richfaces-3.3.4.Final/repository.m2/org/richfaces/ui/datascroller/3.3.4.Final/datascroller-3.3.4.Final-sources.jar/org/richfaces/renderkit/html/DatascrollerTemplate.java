/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.InternetResource;
//
//
//


import org.richfaces.renderkit.html.DataScrollerRenderer;



/**
 * Renderer for component class org.richfaces.renderkit.html.DatascrollerTemplate
 */
public class DatascrollerTemplate extends DataScrollerRenderer {

	public DatascrollerTemplate () {
		super();
	}

	// 
	// Declarations
	//
	private final InternetResource[] styles = {
						getResource("css/datascroller.xcss")
	};

private InternetResource[] stylesAll = null;

protected InternetResource[] getStyles() {
	synchronized (this) {
		if (stylesAll == null) {
			InternetResource[] rsrcs = super.getStyles();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = styles == null || styles.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					stylesAll = new InternetResource[0];	
				} else {
					stylesAll = styles;
				}
			} else {
				if (ignoreThis) {
					stylesAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < styles.length; i++ ) {
						rsrcsSet.add(styles[i]);
					}

					stylesAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return stylesAll;
}
	private final InternetResource[] scripts = {
						new org.ajax4jsf.javascript.PrototypeScript()
						,
				new org.ajax4jsf.javascript.AjaxScript()
						,
				getResource("/org/richfaces/renderkit/html/scripts/datascroller.js")
	};

private InternetResource[] scriptsAll = null;

protected InternetResource[] getScripts() {
	synchronized (this) {
		if (scriptsAll == null) {
			InternetResource[] rsrcs = super.getScripts();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = scripts == null || scripts.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					scriptsAll = new InternetResource[0];	
				} else {
					scriptsAll = scripts;
				}
			} else {
				if (ignoreThis) {
					scriptsAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < scripts.length; i++ ) {
						rsrcsSet.add(scripts[i]);
					}

					scriptsAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return scriptsAll;
}
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIDatascroller.class;
	}


	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIDatascroller component, ComponentVariables variables) throws IOException {
	  java.lang.String clientId = component.getClientId(context);

		org.richfaces.component.util.FormUtil.throwEnclFormReqExceptionIfNeed(context,component);		                                               
    
java.lang.String singlePageRenderStyle  = "" ;

		
        int maxPages = component.getMaxPages();
        if (maxPages <= 1) {
            maxPages = 1;
        }

        int pageCount = component.getPageCount();
        int pageIndex = component.getPage();

        org.richfaces.renderkit.html.ControlsState controlsState = getControlsState(context, component, pageIndex, pageCount);
        boolean singlePageRender = true;
		
		if (pageCount == 1 && !component.isRenderIfSinglePage()) {
        	singlePageRenderStyle = "; display: none";
        	singlePageRender = false;
        } else if (!controlsState.isFirstRendered() && !controlsState.isFastRewindRendered() &&
        	!controlsState.isPreviousRendered() && !controlsState.isNextRendered() && 
        	!controlsState.isFastForwardRendered() && !controlsState.isLastRendered() && 
        	pageCount <= 1 ) {
            singlePageRenderStyle = "; display: none";
    		singlePageRender = false;
        }
		
				                                               
    
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-datascr " + convertToString(component.getAttributes().get("styleClass")) );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "style", convertToString(component.getAttributes().get("style")) + " " + convertToString(singlePageRenderStyle) );
			//
// pass thru attributes
//
getUtils().encodeAttributesFromArray(context,component,new String[] {
    "align" ,
	    "dir" ,
	    "lang" ,
	    "onclick" ,
	    "ondblclick" ,
	    "onkeydown" ,
	    "onkeypress" ,
	    "onkeyup" ,
	    "onmousedown" ,
	    "onmousemove" ,
	    "onmouseout" ,
	    "onmouseover" ,
	    "onmouseup" ,
	    "title" ,
	    "xml:lang" });
//
//
//


			
			if (singlePageRender) {
		        renderPages(context, component, pageIndex, pageCount);
					                                               
	    
writer.startElement("table", component);
			getUtils().writeAttribute(writer, "border", "0" );
						getUtils().writeAttribute(writer, "cellpadding", "0" );
						getUtils().writeAttribute(writer, "cellspacing", "1" );
						getUtils().writeAttribute(writer, "class", "rich-dtascroller-table " + convertToString(component.getAttributes().get("tableStyleClass")) );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "_table" );
						getUtils().writeAttribute(writer, "style", "text-align:" + convertToString(component.getAttributes().get("align")) );
			
writer.startElement("tbody", component);

writer.startElement("tr", component);


	                String facet;                         
	                
	                if (controlsState.isFirstRendered()){                       
	                if (controlsState.isFirstEnabled()){
	                  variables.setVariable("buttonClass", "");                  
	                  variables.setVariable("onclick", getOnClick(component.FIRST_FACET_NAME));                        
	                  variables.setVariable("facet", component.FIRST_FACET_NAME);                  
	                  facet=component.FIRST_FACET_NAME;
	                }else{
	                  variables.setVariable("buttonClass", "rich-datascr-button-dsbld");  
	                  variables.setVariable("onclick", "");                                            
	                  variables.setVariable("facet", component.FIRST_DISABLED_FACET_NAME);                                    
	                  facet=component.FIRST_DISABLED_FACET_NAME;
	                };                
	                if(component.getFacet(facet)!=null ) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			

						     if(component.FIRST_FACET_NAME.equals(facet)){
					       
UIComponent indexChildren_63 = component.getFacet("first");
if (null != indexChildren_63 && indexChildren_63 .isRendered()) {
	renderChild(context, indexChildren_63);
}


						     }else{
					       
UIComponent indexChildren_64 = component.getFacet("first_disabled");
if (null != indexChildren_64 && indexChildren_64 .isRendered()) {
	renderChild(context, indexChildren_64);
}


						     }
					       
writer.endElement("td");

	                }else{
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
                    
	                      writer.write("&#171;&#171;");                      
	                    
writer.endElement("td");

	                } 
	                if (controlsState.isControlsSeparatorRendered() && 
	                		(controlsState.isFastRewindRendered() || controlsState.isPreviousRendered())) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-datascr-ctrls-separator" );
			
UIComponent indexChildren_65 = component.getFacet("controlsSeparator");
if (null != indexChildren_65 && indexChildren_65 .isRendered()) {
	renderChild(context, indexChildren_65);
}

writer.endElement("td");

	                }
	                }
	                
                
	                if (controlsState.isFastRewindRendered()){                       
	                if (controlsState.isFastRewindEnabled()){
	                  variables.setVariable("buttonClass", "");  
	                  variables.setVariable("onclick", getOnClick(component.FAST_REWIND_FACET_NAME));                                                                
	                  variables.setVariable("facet", component.FAST_REWIND_FACET_NAME);                                    
	                  facet=component.FAST_REWIND_FACET_NAME;                  
	                }else{
	                    variables.setVariable("buttonClass", "rich-datascr-button-dsbld");  
	                    variables.setVariable("onclick", "");                                                                                    
	                    variables.setVariable("facet", component.FAST_REWIND_DISABLED_FACET_NAME);                                    
	                    facet=component.FAST_REWIND_DISABLED_FACET_NAME;                                      
	                }
	                if(component.getFacet(facet)!=null ) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			

						     if(component.FAST_REWIND_FACET_NAME.equals(facet)){
					       
UIComponent indexChildren_66 = component.getFacet("fastrewind");
if (null != indexChildren_66 && indexChildren_66 .isRendered()) {
	renderChild(context, indexChildren_66);
}


						     }else{
					       
UIComponent indexChildren_67 = component.getFacet("fastrewind_disabled");
if (null != indexChildren_67 && indexChildren_67 .isRendered()) {
	renderChild(context, indexChildren_67);
}


						     }
					       
writer.endElement("td");

	                }else{
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
                    
	                      writer.write("&#171;");                      
	                    
writer.endElement("td");

	                }
	                
	                if (controlsState.isControlsSeparatorRendered() && controlsState.isPreviousRendered()) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-datascr-ctrls-separator" );
			
UIComponent indexChildren_68 = component.getFacet("controlsSeparator");
if (null != indexChildren_68 && indexChildren_68 .isRendered()) {
	renderChild(context, indexChildren_68);
}

writer.endElement("td");

	                }
	                }                
	                
                                                                                 
	                if (controlsState.isPreviousRendered()){                       
	                if (controlsState.isPreviousEnabled()){                     
	                  variables.setVariable("buttonClass", "");  
	                  variables.setVariable("onclick", getOnClick(component.PREVIOUS_FACET_NAME));                                                                
	                  variables.setVariable("facet", component.PREVIOUS_FACET_NAME);                                    
	                  facet=component.PREVIOUS_FACET_NAME;                                    
	                }else{
	                  variables.setVariable("onclick", "");                                                                                    
	                  variables.setVariable("buttonClass", "rich-datascr-button-dsbld");  
	                  variables.setVariable("facet", component.PREVIOUS_DISABLED_FACET_NAME);                                    
	                  facet=component.PREVIOUS_DISABLED_FACET_NAME;                  
	                }
	                if(component.getFacet(facet)!=null ) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			

						     if(component.PREVIOUS_FACET_NAME.equals(facet)){
					       
UIComponent indexChildren_69 = component.getFacet("previous");
if (null != indexChildren_69 && indexChildren_69 .isRendered()) {
	renderChild(context, indexChildren_69);
}


						     }else{
					       
UIComponent indexChildren_70 = component.getFacet("previous_disabled");
if (null != indexChildren_70 && indexChildren_70 .isRendered()) {
	renderChild(context, indexChildren_70);
}


						     }
					       
writer.endElement("td");

	                }else{
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
writer.endElement("td");

	                 }
	                 }                
	                 

	   			        UIComponent pagesFacet = component.getFacet("pages");
	   			        if (pagesFacet !=null && pagesFacet.isRendered()) {
	                
writer.startElement("td", component);


						renderChild(context, pagesFacet);
					
writer.endElement("td");

	   			        } else {
	   			        	renderPager(context, component, pageIndex, pageCount);
	   			        }
	                

	                if (controlsState.isNextRendered()){                       
	                if (controlsState.isNextEnabled()){                                                                               
	                  variables.setVariable("onclick", getOnClick(component.NEXT_FACET_NAME));                                        
	                  variables.setVariable("buttonClass", "");  
	                  variables.setVariable("facet", component.NEXT_FACET_NAME);                                    
	                  facet=component.NEXT_FACET_NAME;                                                      
	                }else{
	                  variables.setVariable("onclick", "");  
	                  variables.setVariable("buttonClass", "rich-datascr-button-dsbld");  
	                  variables.setVariable("facet", component.NEXT_DISABLED_FACET_NAME);                                    
	                  facet=component.NEXT_DISABLED_FACET_NAME;                                    
	                }
	                if(component.getFacet(facet)!=null ) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			

						     if(component.NEXT_FACET_NAME.equals(facet)){
					       
UIComponent indexChildren_71 = component.getFacet("next");
if (null != indexChildren_71 && indexChildren_71 .isRendered()) {
	renderChild(context, indexChildren_71);
}


						     }else{
					       
UIComponent indexChildren_72 = component.getFacet("next_disabled");
if (null != indexChildren_72 && indexChildren_72 .isRendered()) {
	renderChild(context, indexChildren_72);
}


						     }
					       
writer.endElement("td");

	                }else{
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
writer.endElement("td");

	                }
	                
	                if (controlsState.isControlsSeparatorRendered() && 
	                		(controlsState.isFastForwardRendered() || controlsState.isLastRendered())) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-datascr-ctrls-separator" );
			
UIComponent indexChildren_73 = component.getFacet("controlsSeparator");
if (null != indexChildren_73 && indexChildren_73 .isRendered()) {
	renderChild(context, indexChildren_73);
}

writer.endElement("td");

	                }
	                }                
	                

	                if (controlsState.isFastForwardRendered()){                       
	                if (controlsState.isFastForwardEnabled()){                                                                                                                       
	                  variables.setVariable("onclick", getOnClick(component.FAST_FORWARD_FACET_NAME));
	                  variables.setVariable("buttonClass", "");  
	                  variables.setVariable("facet", component.FAST_FORWARD_FACET_NAME);                                    
	                  facet=component.FAST_FORWARD_FACET_NAME;                                                      
	                }
	                else{
	                  variables.setVariable("onclick", "");  
	                  variables.setVariable("buttonClass", "rich-datascr-button-dsbld");  
	                  variables.setVariable("facet", component.FAST_FORWARD_DISABLED_FACET_NAME);                                    
	                  facet=component.FAST_FORWARD_DISABLED_FACET_NAME;                                                      
	                }
	                if(component.getFacet(facet)!=null ) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			

						     if(component.FAST_FORWARD_FACET_NAME.equals(facet)){
					       
UIComponent indexChildren_74 = component.getFacet("fastforward");
if (null != indexChildren_74 && indexChildren_74 .isRendered()) {
	renderChild(context, indexChildren_74);
}


						     }else{
					       
UIComponent indexChildren_75 = component.getFacet("fastforward_disabled");
if (null != indexChildren_75 && indexChildren_75 .isRendered()) {
	renderChild(context, indexChildren_75);
}


						     }
					       
writer.endElement("td");

	                }else{
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
                    
	                      writer.write("&#187;");                      
	                    
writer.endElement("td");

	                }
	                
	                if (controlsState.isControlsSeparatorRendered() && controlsState.isLastRendered()) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-datascr-ctrls-separator" );
			
UIComponent indexChildren_76 = component.getFacet("controlsSeparator");
if (null != indexChildren_76 && indexChildren_76 .isRendered()) {
	renderChild(context, indexChildren_76);
}

writer.endElement("td");

	                }
	                }                
	                

	                if (controlsState.isLastRendered()){                       
	                if (controlsState.isLastEnabled()){                                                                                                                                                             
	                  variables.setVariable("onclick", getOnClick(component.LAST_FACET_NAME));                                        
	                  variables.setVariable("buttonClass", "");  
	                  variables.setVariable("facet", component.LAST_FACET_NAME);                                    
	                  facet=component.LAST_FACET_NAME;                                                                                          
	                }else{
	                  variables.setVariable("onclick", "");                                                            
	                  variables.setVariable("buttonClass", "rich-datascr-button-dsbld");  
	                  variables.setVariable("facet", component.LAST_DISABLED_FACET_NAME);                                    
	                  facet=component.LAST_DISABLED_FACET_NAME;                                                                        
	                }
	                if(component.getFacet(facet)!=null ) {
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			

						     if(component.LAST_FACET_NAME.equals(facet)){
					       
UIComponent indexChildren_77 = component.getFacet("last");
if (null != indexChildren_77 && indexChildren_77 .isRendered()) {
	renderChild(context, indexChildren_77);
}


						     }else{
					       
UIComponent indexChildren_78 = component.getFacet("last_disabled");
if (null != indexChildren_78 && indexChildren_78 .isRendered()) {
	renderChild(context, indexChildren_78);
}


						     }
					       
writer.endElement("td");

	                }else{
	                
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("buttonClass")) + " rich-datascr-button" );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
                    
	                          writer.write("&#187;&#187;");                      
	                        
writer.endElement("td");

	                }
	                }                
	                
writer.endElement("tr");
writer.endElement("tbody");
writer.endElement("table");

			
			}
					                                               
	    
writer.startElement("script", component);
			getUtils().writeAttribute(writer, "type", "text/javascript" );
			
writer.writeText(convertToString("new Richfaces.Datascroller('" + convertToString(clientId) + "', " + convertToString(getSubmitFunction(context,component)) + ");"),null);

writer.endElement("script");
writer.endElement("div");

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIDatascroller)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
