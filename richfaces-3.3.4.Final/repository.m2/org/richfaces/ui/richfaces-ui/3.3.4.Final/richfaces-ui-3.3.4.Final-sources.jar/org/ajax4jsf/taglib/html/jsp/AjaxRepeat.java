/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import javax.faces.convert.Converter ;
import java.util.Set ;
import java.lang.Object ;
import java.lang.String ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;
import org.ajax4jsf.webapp.taglib.UIComponentTagBase ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.HtmlAjaxRepeat;

public class AjaxRepeat extends org.ajax4jsf.webapp.taglib.UIComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * ajaxKeys
		 * This attribute defines row keys that are updated after an AJAX request.
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * This attribute defines row keys that are updated after an AJAX request.
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding  for a component state for saving or redefinition.
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding  for a component state for saving or redefinition.
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * first
		 * A zero-relative row number of the first row to display
		 */
		private ValueExpression _first;
		/**
		 * A zero-relative row number of the first row to display
		 * Setter for first
		 * @param first - new value
		 */
		 public void setFirst( ValueExpression  __first ){
			this._first = __first;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * The attribute  provides access to a row key in a Request scope.
		 */
		private String _rowKeyVar;
		/**
		 * The attribute  provides access to a row key in a Request scope.
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( String  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rows
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 */
		private ValueExpression _rows;
		/**
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 * Setter for rows
		 * @param rows - new value
		 */
		 public void setRows( ValueExpression  __rows ){
			this._rows = __rows;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stateVar
		 * The attribute  provides access to a component state on the client side.
		 */
		private String _stateVar;
		/**
		 * The attribute  provides access to a component state on the client side.
		 * Setter for stateVar
		 * @param stateVar - new value
		 */
		 public void setStateVar( String  __stateVar ){
			this._stateVar = __stateVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component.
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component.
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 */
		private String _var;
		/**
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxKeys = null;
	 		 		 		 		    this._componentState = null;
	 		 		 		    this._first = null;
	 		 		 		 		 		 		 		 		 		 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		    this._rows = null;
	 		 		    this._stateVar = null;
	 		 		    this._value = null;
	 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlAjaxRepeat comp = (HtmlAjaxRepeat) component;
 		 			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					     		 			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					    		 			 
						if (this._first != null) {
				if (this._first.isLiteralText()) {
					try {
												
						Integer __first = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._first.getExpressionString(), 
											Integer.class);
					
												comp.setFirst(__first.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("first", this._first);
				}
			}
					            		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
											if (this._rowKeyVar != null) {
					comp.setRowKeyVar(this._rowKeyVar);
				}
									   		 			 
						if (this._rows != null) {
				if (this._rows.isLiteralText()) {
					try {
												
						Integer __rows = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rows.getExpressionString(), 
											Integer.class);
					
												comp.setRows(__rows.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rows", this._rows);
				}
			}
					   		 			 
											if (this._stateVar != null) {
					comp.setStateVar(this._stateVar);
				}
									   		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.Repeat";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.components.RepeatRenderer";
			}

}
