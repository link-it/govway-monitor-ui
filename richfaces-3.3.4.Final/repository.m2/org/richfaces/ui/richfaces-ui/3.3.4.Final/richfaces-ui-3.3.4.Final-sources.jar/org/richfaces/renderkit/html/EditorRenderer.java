/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.InternetResource;
//
//
//


import org.richfaces.renderkit.EditorRendererBase;



/**
 * Renderer for component class org.richfaces.renderkit.html.EditorRenderer
 */
public class EditorRenderer extends EditorRendererBase {

	public EditorRenderer () {
		super();
	}

	// 
	// Declarations
	//
	private final InternetResource[] styles = {
						getResource("css/editor.xcss")
	};

private InternetResource[] stylesAll = null;

protected InternetResource[] getStyles() {
	synchronized (this) {
		if (stylesAll == null) {
			InternetResource[] rsrcs = super.getStyles();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = styles == null || styles.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					stylesAll = new InternetResource[0];	
				} else {
					stylesAll = styles;
				}
			} else {
				if (ignoreThis) {
					stylesAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < styles.length; i++ ) {
						rsrcsSet.add(styles[i]);
					}

					stylesAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return stylesAll;
}
	private final InternetResource[] scripts = {
						new org.ajax4jsf.javascript.AjaxScript()
						,
				new org.ajax4jsf.javascript.PrototypeScript()
						,
				getResource("scripts/tiny_mce/tiny_mce_src.js")
						,
				getResource("scripts/editor.js")
	};

private InternetResource[] scriptsAll = null;

protected InternetResource[] getScripts() {
	synchronized (this) {
		if (scriptsAll == null) {
			InternetResource[] rsrcs = super.getScripts();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = scripts == null || scripts.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					scriptsAll = new InternetResource[0];	
				} else {
					scriptsAll = scripts;
				}
			} else {
				if (ignoreThis) {
					scriptsAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < scripts.length; i++ ) {
						rsrcsSet.add(scripts[i]);
					}

					scriptsAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return scriptsAll;
}
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIEditor.class;
	}


	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIEditor component, ComponentVariables variables) throws IOException {
	  java.lang.String clientId = component.getClientId(context);
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-editor " + convertToString(component.getAttributes().get("styleClass")) );
						getUtils().writeAttribute(writer, "id", clientId );
			//
// pass thru attributes
//
getUtils().encodeAttributesFromArray(context,component,new String[] {
    "align" ,
	    "dir" ,
	    "lang" ,
	    "onclick" ,
	    "ondblclick" ,
	    "onkeydown" ,
	    "onkeypress" ,
	    "onkeyup" ,
	    "onmousedown" ,
	    "onmousemove" ,
	    "onmouseout" ,
	    "onmouseover" ,
	    "onmouseup" ,
	    "style" ,
	    "title" ,
	    "xml:lang" });
//
//
//


		
		    if(shouldRenderTinyMCE(component)) {
    	
	

	
	    if ("input".equals(component.getAttributes().get("inputElementType"))) {
   	
	
writer.startElement("input", component);
			getUtils().writeAttribute(writer, "id", convertToString(clientId) + "TextArea" );
						getUtils().writeAttribute(writer, "name", convertToString(clientId) + "TextArea" );
						getUtils().writeAttribute(writer, "type", "hidden" );
						getUtils().writeAttribute(writer, "value", getFormattedComponentStringValue(context,component) );
			
writer.endElement("input");

	
	    } else {
   	
	
writer.startElement("textarea", component);
			getUtils().writeAttribute(writer, "id", convertToString(clientId) + "TextArea" );
						getUtils().writeAttribute(writer, "name", convertToString(clientId) + "TextArea" );
						getUtils().writeAttribute(writer, "style", "visibility: hidden" );
			
writer.writeText(convertToString(getFormattedComponentStringValue(context,component)),null);

writer.endElement("textarea");

	
		}
   	
	
writer.startElement("script", component);
			getUtils().writeAttribute(writer, "type", "text/javascript" );
			
writeEditorCustomPluginsParameters(context, component);

writeEditorConfigurationParameters(context, component);

writeEditorConfigurationAttributes(context, component);

writeEditorParameters(context, component);

writer.writeText(convertToString("var richParams = {extScriptSuffix : '" + convertToString(getSriptMappingSuffix(context)) + "', extCssSuffix : '" + convertToString(getCssMappingSuffix(context)) + "', useSeamText : " + convertToString(component.getAttributes().get("useSeamText")) + "};\n       		\n        	new RichEditor('" + convertToString(clientId) + "', richParams, tinyMceParams);"),null);

writer.endElement("script");

		
		    } else {
    	
	
writer.startElement("textarea", component);
			getUtils().writeAttribute(writer, "id", convertToString(clientId) + "TextArea" );
						getUtils().writeAttribute(writer, "name", convertToString(clientId) + "TextArea" );
						getUtils().writeAttribute(writer, "style", getTextAreaStyle(component) );
						getUtils().writeAttribute(writer, "tabindex", component.getAttributes().get("tabindex") );
			
writer.writeText(convertToString(getFormattedComponentStringValue(context,component)),null);

writer.endElement("textarea");

		
		    }
    	
	
writer.endElement("div");

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIEditor)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
