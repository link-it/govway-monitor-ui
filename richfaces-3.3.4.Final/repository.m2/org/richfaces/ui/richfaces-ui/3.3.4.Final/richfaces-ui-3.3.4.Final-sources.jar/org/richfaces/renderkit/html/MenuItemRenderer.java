/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
//
//
//


import org.richfaces.renderkit.html.MenuItemRendererBase;



/**
 * Renderer for component class org.richfaces.renderkit.html.MenuItemRenderer
 */
public class MenuItemRenderer extends MenuItemRendererBase {

	public MenuItemRenderer () {
		super();
	}

	// 
	// Declarations
	//
	private final InternetResource[] styles = {
						getResource("css/menucomponents.xcss")
	};

private InternetResource[] stylesAll = null;

protected InternetResource[] getStyles() {
	synchronized (this) {
		if (stylesAll == null) {
			InternetResource[] rsrcs = super.getStyles();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = styles == null || styles.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					stylesAll = new InternetResource[0];	
				} else {
					stylesAll = styles;
				}
			} else {
				if (ignoreThis) {
					stylesAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < styles.length; i++ ) {
						rsrcsSet.add(styles[i]);
					}

					stylesAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return stylesAll;
}
	private final InternetResource[] scripts = {
						new org.ajax4jsf.javascript.PrototypeScript()
						,
				new org.ajax4jsf.javascript.AjaxScript()
						,
				getResource("/org/richfaces/renderkit/html/scripts/utils.js")
						,
				getResource("/org/ajax4jsf/javascript/scripts/form.js")
						,
				getResource("/org/richfaces/renderkit/html/scripts/form.js")
						,
				getResource("/org/richfaces/renderkit/html/scripts/menu.js")
	};

private InternetResource[] scriptsAll = null;

protected InternetResource[] getScripts() {
	synchronized (this) {
		if (scriptsAll == null) {
			InternetResource[] rsrcs = super.getScripts();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = scripts == null || scripts.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					scriptsAll = new InternetResource[0];	
				} else {
					scriptsAll = scripts;
				}
			} else {
				if (ignoreThis) {
					scriptsAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < scripts.length; i++ ) {
						rsrcsSet.add(scripts[i]);
					}

					scriptsAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return scriptsAll;
}
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIMenuItem.class;
	}


	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIMenuItem component, ComponentVariables variables) throws IOException {
	  
		
		         String mode = resolveSubmitMode(component);
		         if (mode != null && !mode.equalsIgnoreCase("none")) org.richfaces.component.util.FormUtil.throwEnclFormReqExceptionIfNeed(context,component);
				                                               
    
initializeResources(context, component);

initializeStyles(context, component);

java.lang.String clientId = component.getClientId(context);

	 
			variables.setVariable("cspValue", getUtils().getCspNonceValue(context));
			variables.setVariable("cssId", getUtils().getCssId(clientId));
	
	
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("#" + convertToString(clientId) + " { " + convertToString(variables.getVariable("menuItemStyle")) + " }\n		." + convertToString(variables.getVariable("cssId")) + "-icon-style-attr { " + convertToString(component.getAttributes().get("iconStyle")) + " }"),null);

writer.endElement("style");

		if (((org.richfaces.component.UIMenuItem) component).isDisabled()) {
				
	
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuItemClass") );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onclick", "Event.stop(event);" );
			

		} else if(!isNestedInMenu(component)) {
			/*String onselect = (String) component.getAttributes().get("onselect");
	    	if(null!=onselect&&onselect.length()>0){
	    		onselect = onselect+";";	    		  		
	    	}else{
	    		onselect="";
	    	}
	    	variables.setVariable("onselect",onselect);
	    	*/
	    	
	    	String itemHoverClass =  collectItemClasses(context, component, true);
	    	String itemHoverStyle = collectItemInlineStyles(context, component, true);
	    	variables.setVariable("itemHoverClass",itemHoverClass);
	    	variables.setVariable("itemHoverStyles",itemHoverStyle);
	    	
	    	
	    	String itemClass = collectItemClasses(context, component, false);
	    	String itemStyle = collectItemInlineStyles(context, component, false);
	    	variables.setVariable("itemClass",itemClass);
	    	variables.setVariable("itemStyles",itemStyle);
	    	
	    	
	
java.util.HashMap onmouseoutClasses = new java.util.HashMap();
	getUtils().addToScriptHash(onmouseoutClasses, "styleClass", variables.getVariable("itemClass"),  null , ScriptHashVariableWrapper.DEFAULT);

	getUtils().addToScriptHash(onmouseoutClasses, "style", variables.getVariable("itemStyles"),  null , ScriptHashVariableWrapper.DEFAULT);

	getUtils().addToScriptHash(onmouseoutClasses, "iconClass", component.getAttributes().get("iconClass"),  null , ScriptHashVariableWrapper.DEFAULT);

java.util.HashMap onmouseoverClasses = new java.util.HashMap();
	getUtils().addToScriptHash(onmouseoverClasses, "styleClass", variables.getVariable("itemHoverClass"),  null , ScriptHashVariableWrapper.DEFAULT);

	getUtils().addToScriptHash(onmouseoverClasses, "style", variables.getVariable("itemHoverStyles"),  null , ScriptHashVariableWrapper.DEFAULT);

	getUtils().addToScriptHash(onmouseoverClasses, "iconClass", component.getAttributes().get("iconClass"),  null , ScriptHashVariableWrapper.DEFAULT);

writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuItemClass") );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
						getUtils().writeAttribute(writer, "onmouseout", "RichFaces.Menu.Utils.itemMouseOut(event, this, " + convertToString(toScript(onmouseoutClasses)) + ");" );
						getUtils().writeAttribute(writer, "onmouseover", "RichFaces.Menu.Utils.itemMouseOver(event, this, " + convertToString(toScript(onmouseoverClasses)) + ");" );
			
getUtils().encodeAttributes(context, component, "onmousemove,onmousedown,onmouseup");


		} else {
	
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuItemClass") );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onclick", variables.getVariable("onclick") );
			
getUtils().encodeAttributes(context, component, "onmousemove,onmousedown,onmouseup");


		}
	
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", "rich-menu-item-icon " + convertToString(variables.getVariable("iconDisabledClasses")) + " " + convertToString(component.getAttributes().get("iconClass")) + " " + convertToString(variables.getVariable("cssId")) + "-icon-style-attr" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":icon" );
			

				UIComponent iconFacet = getIconFacet((org.richfaces.component.UIMenuItem) component);			
				if (null != iconFacet) {
					renderChild(context, iconFacet);	
				} else {
			
writer.startElement("img", component);
			getUtils().writeAttribute(writer, "alt", "" );
						getUtils().writeAttribute(writer, "height", "16" );
						getUtils().writeAttribute(writer, "src", variables.getVariable("icon") );
						getUtils().writeAttribute(writer, "width", "16" );
			
writer.endElement("img");

				}
			
writer.endElement("span");
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuItemLabelClass") );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":anchor" );
			
writer.writeText(convertToString(component.getAttributes().get("value")),null);

renderChildren(context, component);

writer.endElement("span");

	if (((org.richfaces.component.UIMenuItem) component).isDisabled()) {
	
writer.endElement("div");

		}else if(isNestedInMenu(component)){
	
writer.endElement("div");

		}else {
	
writer.endElement("div");

		}
	

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIMenuItem)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
