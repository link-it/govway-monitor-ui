/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.InternetResource;
//
//
//


import org.richfaces.renderkit.html.MenuGroupRendererBase;



/**
 * Renderer for component class org.richfaces.renderkit.html.MenuGroupRenderer
 */
public class MenuGroupRenderer extends MenuGroupRendererBase {

	public MenuGroupRenderer () {
		super();
	}

	// 
	// Declarations
	//
	private final InternetResource[] styles = {
						getResource("css/menucomponents.xcss")
	};

private InternetResource[] stylesAll = null;

protected InternetResource[] getStyles() {
	synchronized (this) {
		if (stylesAll == null) {
			InternetResource[] rsrcs = super.getStyles();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = styles == null || styles.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					stylesAll = new InternetResource[0];	
				} else {
					stylesAll = styles;
				}
			} else {
				if (ignoreThis) {
					stylesAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < styles.length; i++ ) {
						rsrcsSet.add(styles[i]);
					}

					stylesAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return stylesAll;
}
	private final InternetResource[] scripts = {
						new org.ajax4jsf.javascript.PrototypeScript()
						,
				new org.ajax4jsf.javascript.AjaxScript()
	};

private InternetResource[] scriptsAll = null;

protected InternetResource[] getScripts() {
	synchronized (this) {
		if (scriptsAll == null) {
			InternetResource[] rsrcs = super.getScripts();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = scripts == null || scripts.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					scriptsAll = new InternetResource[0];	
				} else {
					scriptsAll = scripts;
				}
			} else {
				if (ignoreThis) {
					scriptsAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < scripts.length; i++ ) {
						rsrcsSet.add(scripts[i]);
					}

					scriptsAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return scriptsAll;
}
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIMenuGroup.class;
	}


	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIMenuGroup component, ComponentVariables variables) throws IOException {
	  java.lang.String clientId = component.getClientId(context);
initializeResources(context, component);

initializeStyleClasses(context, component);

variables.setVariable("spacer", getResource( "/org/richfaces/renderkit/html/images/spacer.gif" ).getUri(context, component) );


	 
			variables.setVariable("cspValue", getUtils().getCspNonceValue(context));
			variables.setVariable("cssId", getUtils().getCssId(clientId));
	
	
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("#" + convertToString(clientId) + " { " + convertToString(variables.getVariable("menuItemStyle")) + " }\n		." + convertToString(variables.getVariable("cssId")) + "-icon-style-attr { " + convertToString(component.getAttributes().get("iconStyle")) + " }"),null);

writer.endElement("style");

        
            boolean disabled = ((Boolean) component.getAttributes().get("disabled")).booleanValue();
            if (disabled) {
         
    
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuGroupClass") );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onmousemove", variables.getVariable("menuItemMouseMove") );
			
 
        } else { 
    
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuGroupClass") );
						getUtils().writeAttribute(writer, "id", clientId );
						getUtils().writeAttribute(writer, "onmousemove", variables.getVariable("menuItemMouseMove") );
						getUtils().writeAttribute(writer, "onmouseout", "RichFaces.Menu.groupMouseOut(event, this, '" + convertToString(variables.getVariable("menuGroupCustomClass")) + "', '" + convertToString(variables.getVariable("onmouseoutInlineStyles")) + "');" );
						getUtils().writeAttribute(writer, "onmouseover", "RichFaces.Menu.groupMouseOver(event, this, '" + convertToString(variables.getVariable("menuGroupHoverClass")) + "', '" + convertToString(variables.getVariable("onmouseoverInlineStyles")) + "');" );
			
 
        } 
    
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("menuGroupItemIconClass")) + " " + convertToString(component.getAttributes().get("iconClass")) );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":icon" );
			

			
					String iconName = disabled ? "iconDisabled" : "icon";
			        UIComponent iconFacet = component.getFacet(iconName);
			        if (iconFacet !=null && iconFacet.isRendered()) {
						renderChild(context, iconFacet);
					} else if (component.getAttributes().get(iconName)!=null) { 
		
writer.startElement("img", component);
			getUtils().writeAttribute(writer, "alt", "" );
						getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-icon-style-attr" );
						getUtils().writeAttribute(writer, "height", "16" );
						getUtils().writeAttribute(writer, "src", variables.getVariable("actualIcon") );
						getUtils().writeAttribute(writer, "width", "16" );
			
writer.endElement("img");
	
			} else { 
		
writer.startElement("img", component);
			getUtils().writeAttribute(writer, "alt", "" );
						getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-icon-style-attr" );
						getUtils().writeAttribute(writer, "height", "16" );
						getUtils().writeAttribute(writer, "src", variables.getVariable("spacer") );
						getUtils().writeAttribute(writer, "width", "16" );
			
writer.endElement("img");
}
writer.endElement("span");
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", variables.getVariable("menuGroupItemLabelClass") );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":anchor" );
			
writer.writeText(convertToString(component.getAttributes().get("value")),null);

writer.endElement("span");

			
			        String iconFolder = disabled ? "iconFolderDisabled" : "iconFolder";
			        UIComponent iconFolderFacet = component.getFacet(iconFolder);
			        if (iconFolderFacet != null && iconFolderFacet.isRendered()) {
			
		
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-menu-node " + convertToString(variables.getVariable("menuGroupItemFolderClass")) );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":folder" );
			

			
						renderChild(context, iconFolderFacet);
			
		
UIComponent indexChildren_81 = component.getFacet("#{iconFolder}");
if (null != indexChildren_81 && indexChildren_81 .isRendered()) {
	renderChild(context, indexChildren_81);
}

writer.endElement("div");
	
		} else if (component.getAttributes().get(iconFolder)!=null) {
		
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-menu-node " + convertToString(variables.getVariable("menuGroupItemFolderClass")) + " " + convertToString(component.getAttributes().get("iconClass")) );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":folder" );
			
writer.startElement("img", component);
			getUtils().writeAttribute(writer, "alt", "" );
						getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-icon-style-attr" );
						getUtils().writeAttribute(writer, "height", "16" );
						getUtils().writeAttribute(writer, "src", variables.getVariable("actualIconFolder") );
						getUtils().writeAttribute(writer, "width", "16" );
			
writer.endElement("img");
writer.endElement("div");
	
		} else {
		
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-menu-node rich-menu-node-icon " + convertToString(variables.getVariable("menuGroupItemFolderClass")) );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + ":folder" );
			

			writer.write("&#160;");
			
writer.endElement("div");
	
		}
		

        if (disabled) { 
    
writer.endElement("div");
 
        } else { 
    
writer.endElement("div");
 
        } 
    

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIMenuGroup)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
