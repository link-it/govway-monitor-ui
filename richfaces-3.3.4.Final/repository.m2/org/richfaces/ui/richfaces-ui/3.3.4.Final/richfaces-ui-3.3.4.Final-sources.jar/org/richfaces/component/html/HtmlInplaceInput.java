package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIInplaceInput;

public class HtmlInplaceInput extends UIInplaceInput{

static final public  String COMPONENT_FAMILY = "org.richfaces.InplaceInput";

static final public  String COMPONENT_TYPE = "org.richfaces.InplaceInput";

/*
* Defines custom cancel icon
*/
private  String _cancelControlIcon = null;

/*
* Assigns one or more space-separated CSS class names to the component in the changed state
*/
private  String _changedClass = null;

/*
* Assigns one or more space-separated CSS class names to the component hovered in the changed state
*/
private  String _changedHoverClass = null;

/*
* Assigns one or more space-separated CSS class names to the component controls
*/
private  String _controlClass = null;

/*
* Assigns one or more space-separated CSS class names to the component control hovered
*/
private  String _controlHoverClass = null;

/*
* Assigns one or more space-separated CSS class names to the component control pressed
*/
private  String _controlPressedClass = null;

/*
* Positions the controls horizontally. Possible values are "left", "center", "right". Default value is "right".
*/
private  String _controlsHorizontalPosition = null;

/*
* Positions the controls vertically. Possible values are "bottom","center" and "top". Default value is "center"
*/
private  String _controlsVerticalPosition = null;

/*
* The attribute is used to display text while value is undefined
*/
private  String _defaultLabel = null;

/*
* Assigns one or more space-separated CSS class names to the component in the edit state
*/
private  String _editClass = null;

/*
* Provides an option to assign an JavaScript action that initiates the change of the state. Default value is "onclick".
*/
private  String _editEvent = null;

/*
* Sets width of the input field
*/
private  String _inputWidth = null;

/*
* A localized user presentable name for this component.
*/
private  String _label = null;

/*
* Defines how the component is displayed in the layout. Possible values are "block", "inline". Default value is "inline".
*/
private  String _layout = null;

/*
* Sets the maximum width of the input field. Default value is "500px".
*/
private  String _maxInputWidth = null;

/*
* Specifies the maximum number of digits that could be entered into the input field. 
				The maximum number is unlimited by default.
*/
private  int _maxlength = Integer.MIN_VALUE;

private  boolean _maxlengthSet = false;

/*
* Sets the minimum width of the input field. Default value is "40px".
*/
private  String _minInputWidth = null;

/*
* The client-side script method to be called when the component loses the focus
*/
private  String _onblur = null;

/*
* The client-side script method to be called when the component value is changed
*/
private  String _onchange = null;

/*
* The client-side script method to be called when the element is clicked
*/
private  String _onclick = null;

/*
* The client-side script method to be called when the element is double-clicked
*/
private  String _ondblclick = null;

/*
* The client-side script method to be called when the component edit state is activated
*/
private  String _oneditactivated = null;

/*
* The client-side script method to be called before the component edit state is activated
*/
private  String _oneditactivation = null;

/*
* The client-side script method to be called when the component gets the focus
*/
private  String _onfocus = null;

/*
* The client-side script method to be called when the input field is clicked
*/
private  String _oninputclick = null;

/*
* The client-side script method to be called when the input field is double-clicked
*/
private  String _oninputdblclick = null;

/*
* The client-side script method to be called when a key is pressed down in the input field
*/
private  String _oninputkeydown = null;

/*
* The client-side script method to be called when a key is pressed and released in the input field
*/
private  String _oninputkeypress = null;

/*
* The client-side script method to be called when a key is released in the input field
*/
private  String _oninputkeyup = null;

/*
* The client-side script method to be called when a mouse button is pressed down in the input field
*/
private  String _oninputmousedown = null;

/*
* The client-side script method to be called when a pointer is moved within the input field
*/
private  String _oninputmousemove = null;

/*
* The client-side script method to be called when a pointer is moved away from the input field
*/
private  String _oninputmouseout = null;

/*
* The client-side script method to be called when a pointer is moved onto the input field
*/
private  String _oninputmouseover = null;

/*
* The client-side script method to be called when a mouse button is released in the input field
*/
private  String _oninputmouseup = null;

/*
* The client-side script method to be called when a key is pressed down over the element
*/
private  String _onkeydown = null;

/*
* The client-side script method to be called when a key is pressed over the element and released
*/
private  String _onkeypress = null;

/*
* The client-side script method to be called when a key is released
*/
private  String _onkeyup = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the element
*/
private  String _onmousedown = null;

/*
* The client-side script method to be called when a pointer is moved within the element
*/
private  String _onmousemove = null;

/*
* The client-side script method to be called when a pointer is moved away from the element
*/
private  String _onmouseout = null;

/*
* The client-side script method to be called when a pointer is moved onto the element
*/
private  String _onmouseover = null;

/*
* The client-side script method to be called when a mouse button is released
*/
private  String _onmouseup = null;

/*
* The client-side script method to be called when some text is selected in the input field
*/
private  String _onselect = null;

/*
* The client-side script method to be called when the component view state is activated
*/
private  String _onviewactivated = null;

/*
* The client-side script method to be called before the component view state is activated
*/
private  String _onviewactivation = null;

/*
* Defines custom save icon
*/
private  String _saveControlIcon = null;

/*
* Makes the input field select when switched to edit state. Default value is "false"
*/
private  boolean _selectOnEdit = false;

private  boolean _selectOnEditSet = false;

/*
* Serves to display "save" and "cancel" controls. Default value is "false".
*/
private  boolean _showControls = false;

private  boolean _showControlsSet = false;

/*
* Assigns one or more space-separated CSS class names to the component. Corresponds to the HTML "class" attribute.
*/
private  String _styleClass = null;

/*
* Serves to define the tabbing order
*/
private  int _tabindex = Integer.MIN_VALUE;

private  boolean _tabindexSet = false;

/*
* Assigns one or more space-separated CSS class names to the component in the view state
*/
private  String _viewClass = null;

/*
* Assigns one or more space-separated CSS class names to the component hovered in the view state
*/
private  String _viewHoverClass = null;


public HtmlInplaceInput(){
setRendererType("org.richfaces.renderkit.InplaceInputRenderer");
}

public String getCancelControlIcon(){
	if (this._cancelControlIcon != null) {
		return this._cancelControlIcon;
	}
	ValueExpression ve = getValueExpression("cancelControlIcon");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setCancelControlIcon(String _cancelControlIcon){
this._cancelControlIcon = _cancelControlIcon;
}

public String getChangedClass(){
	if (this._changedClass != null) {
		return this._changedClass;
	}
	ValueExpression ve = getValueExpression("changedClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setChangedClass(String _changedClass){
this._changedClass = _changedClass;
}

public String getChangedHoverClass(){
	if (this._changedHoverClass != null) {
		return this._changedHoverClass;
	}
	ValueExpression ve = getValueExpression("changedHoverClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setChangedHoverClass(String _changedHoverClass){
this._changedHoverClass = _changedHoverClass;
}

public String getControlClass(){
	if (this._controlClass != null) {
		return this._controlClass;
	}
	ValueExpression ve = getValueExpression("controlClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setControlClass(String _controlClass){
this._controlClass = _controlClass;
}

public String getControlHoverClass(){
	if (this._controlHoverClass != null) {
		return this._controlHoverClass;
	}
	ValueExpression ve = getValueExpression("controlHoverClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setControlHoverClass(String _controlHoverClass){
this._controlHoverClass = _controlHoverClass;
}

public String getControlPressedClass(){
	if (this._controlPressedClass != null) {
		return this._controlPressedClass;
	}
	ValueExpression ve = getValueExpression("controlPressedClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setControlPressedClass(String _controlPressedClass){
this._controlPressedClass = _controlPressedClass;
}

public String getControlsHorizontalPosition(){
	if (this._controlsHorizontalPosition != null) {
		return this._controlsHorizontalPosition;
	}
	ValueExpression ve = getValueExpression("controlsHorizontalPosition");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "right";
	

}

public void setControlsHorizontalPosition(String _controlsHorizontalPosition){
this._controlsHorizontalPosition = _controlsHorizontalPosition;
}

public String getControlsVerticalPosition(){
	if (this._controlsVerticalPosition != null) {
		return this._controlsVerticalPosition;
	}
	ValueExpression ve = getValueExpression("controlsVerticalPosition");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "center";
	

}

public void setControlsVerticalPosition(String _controlsVerticalPosition){
this._controlsVerticalPosition = _controlsVerticalPosition;
}

public String getDefaultLabel(){
	if (this._defaultLabel != null) {
		return this._defaultLabel;
	}
	ValueExpression ve = getValueExpression("defaultLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setDefaultLabel(String _defaultLabel){
this._defaultLabel = _defaultLabel;
}

public String getEditClass(){
	if (this._editClass != null) {
		return this._editClass;
	}
	ValueExpression ve = getValueExpression("editClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setEditClass(String _editClass){
this._editClass = _editClass;
}

public String getEditEvent(){
	if (this._editEvent != null) {
		return this._editEvent;
	}
	ValueExpression ve = getValueExpression("editEvent");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "onclick";
	

}

public void setEditEvent(String _editEvent){
this._editEvent = _editEvent;
}

public String getInputWidth(){
	if (this._inputWidth != null) {
		return this._inputWidth;
	}
	ValueExpression ve = getValueExpression("inputWidth");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setInputWidth(String _inputWidth){
this._inputWidth = _inputWidth;
}

public String getLabel(){
	if (this._label != null) {
		return this._label;
	}
	ValueExpression ve = getValueExpression("label");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setLabel(String _label){
this._label = _label;
}

public String getLayout(){
	if (this._layout != null) {
		return this._layout;
	}
	ValueExpression ve = getValueExpression("layout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "inline";
	

}

public void setLayout(String _layout){
this._layout = _layout;
}

public String getMaxInputWidth(){
	if (this._maxInputWidth != null) {
		return this._maxInputWidth;
	}
	ValueExpression ve = getValueExpression("maxInputWidth");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "500px";
	

}

public void setMaxInputWidth(String _maxInputWidth){
this._maxInputWidth = _maxInputWidth;
}

public int getMaxlength(){
	if (this._maxlengthSet) {
	    return (this._maxlength);
	}
	ValueExpression ve = getValueExpression("maxlength");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._maxlength);
	    }
	    
	    return value;
	} else {
	    return (this._maxlength);
	}

}

public void setMaxlength(int _maxlength){
this._maxlength = _maxlength;
this._maxlengthSet = true;
}

public String getMinInputWidth(){
	if (this._minInputWidth != null) {
		return this._minInputWidth;
	}
	ValueExpression ve = getValueExpression("minInputWidth");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "40px";
	

}

public void setMinInputWidth(String _minInputWidth){
this._minInputWidth = _minInputWidth;
}

public String getOnblur(){
	if (this._onblur != null) {
		return this._onblur;
	}
	ValueExpression ve = getValueExpression("onblur");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnblur(String _onblur){
this._onblur = _onblur;
}

public String getOnchange(){
	if (this._onchange != null) {
		return this._onchange;
	}
	ValueExpression ve = getValueExpression("onchange");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnchange(String _onchange){
this._onchange = _onchange;
}

public String getOnclick(){
	if (this._onclick != null) {
		return this._onclick;
	}
	ValueExpression ve = getValueExpression("onclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnclick(String _onclick){
this._onclick = _onclick;
}

public String getOndblclick(){
	if (this._ondblclick != null) {
		return this._ondblclick;
	}
	ValueExpression ve = getValueExpression("ondblclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOndblclick(String _ondblclick){
this._ondblclick = _ondblclick;
}

public String getOneditactivated(){
	if (this._oneditactivated != null) {
		return this._oneditactivated;
	}
	ValueExpression ve = getValueExpression("oneditactivated");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOneditactivated(String _oneditactivated){
this._oneditactivated = _oneditactivated;
}

public String getOneditactivation(){
	if (this._oneditactivation != null) {
		return this._oneditactivation;
	}
	ValueExpression ve = getValueExpression("oneditactivation");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOneditactivation(String _oneditactivation){
this._oneditactivation = _oneditactivation;
}

public String getOnfocus(){
	if (this._onfocus != null) {
		return this._onfocus;
	}
	ValueExpression ve = getValueExpression("onfocus");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnfocus(String _onfocus){
this._onfocus = _onfocus;
}

public String getOninputclick(){
	if (this._oninputclick != null) {
		return this._oninputclick;
	}
	ValueExpression ve = getValueExpression("oninputclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputclick(String _oninputclick){
this._oninputclick = _oninputclick;
}

public String getOninputdblclick(){
	if (this._oninputdblclick != null) {
		return this._oninputdblclick;
	}
	ValueExpression ve = getValueExpression("oninputdblclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputdblclick(String _oninputdblclick){
this._oninputdblclick = _oninputdblclick;
}

public String getOninputkeydown(){
	if (this._oninputkeydown != null) {
		return this._oninputkeydown;
	}
	ValueExpression ve = getValueExpression("oninputkeydown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputkeydown(String _oninputkeydown){
this._oninputkeydown = _oninputkeydown;
}

public String getOninputkeypress(){
	if (this._oninputkeypress != null) {
		return this._oninputkeypress;
	}
	ValueExpression ve = getValueExpression("oninputkeypress");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputkeypress(String _oninputkeypress){
this._oninputkeypress = _oninputkeypress;
}

public String getOninputkeyup(){
	if (this._oninputkeyup != null) {
		return this._oninputkeyup;
	}
	ValueExpression ve = getValueExpression("oninputkeyup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputkeyup(String _oninputkeyup){
this._oninputkeyup = _oninputkeyup;
}

public String getOninputmousedown(){
	if (this._oninputmousedown != null) {
		return this._oninputmousedown;
	}
	ValueExpression ve = getValueExpression("oninputmousedown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputmousedown(String _oninputmousedown){
this._oninputmousedown = _oninputmousedown;
}

public String getOninputmousemove(){
	if (this._oninputmousemove != null) {
		return this._oninputmousemove;
	}
	ValueExpression ve = getValueExpression("oninputmousemove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputmousemove(String _oninputmousemove){
this._oninputmousemove = _oninputmousemove;
}

public String getOninputmouseout(){
	if (this._oninputmouseout != null) {
		return this._oninputmouseout;
	}
	ValueExpression ve = getValueExpression("oninputmouseout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputmouseout(String _oninputmouseout){
this._oninputmouseout = _oninputmouseout;
}

public String getOninputmouseover(){
	if (this._oninputmouseover != null) {
		return this._oninputmouseover;
	}
	ValueExpression ve = getValueExpression("oninputmouseover");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputmouseover(String _oninputmouseover){
this._oninputmouseover = _oninputmouseover;
}

public String getOninputmouseup(){
	if (this._oninputmouseup != null) {
		return this._oninputmouseup;
	}
	ValueExpression ve = getValueExpression("oninputmouseup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOninputmouseup(String _oninputmouseup){
this._oninputmouseup = _oninputmouseup;
}

public String getOnkeydown(){
	if (this._onkeydown != null) {
		return this._onkeydown;
	}
	ValueExpression ve = getValueExpression("onkeydown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeydown(String _onkeydown){
this._onkeydown = _onkeydown;
}

public String getOnkeypress(){
	if (this._onkeypress != null) {
		return this._onkeypress;
	}
	ValueExpression ve = getValueExpression("onkeypress");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeypress(String _onkeypress){
this._onkeypress = _onkeypress;
}

public String getOnkeyup(){
	if (this._onkeyup != null) {
		return this._onkeyup;
	}
	ValueExpression ve = getValueExpression("onkeyup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeyup(String _onkeyup){
this._onkeyup = _onkeyup;
}

public String getOnmousedown(){
	if (this._onmousedown != null) {
		return this._onmousedown;
	}
	ValueExpression ve = getValueExpression("onmousedown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousedown(String _onmousedown){
this._onmousedown = _onmousedown;
}

public String getOnmousemove(){
	if (this._onmousemove != null) {
		return this._onmousemove;
	}
	ValueExpression ve = getValueExpression("onmousemove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousemove(String _onmousemove){
this._onmousemove = _onmousemove;
}

public String getOnmouseout(){
	if (this._onmouseout != null) {
		return this._onmouseout;
	}
	ValueExpression ve = getValueExpression("onmouseout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseout(String _onmouseout){
this._onmouseout = _onmouseout;
}

public String getOnmouseover(){
	if (this._onmouseover != null) {
		return this._onmouseover;
	}
	ValueExpression ve = getValueExpression("onmouseover");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseover(String _onmouseover){
this._onmouseover = _onmouseover;
}

public String getOnmouseup(){
	if (this._onmouseup != null) {
		return this._onmouseup;
	}
	ValueExpression ve = getValueExpression("onmouseup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseup(String _onmouseup){
this._onmouseup = _onmouseup;
}

public String getOnselect(){
	if (this._onselect != null) {
		return this._onselect;
	}
	ValueExpression ve = getValueExpression("onselect");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnselect(String _onselect){
this._onselect = _onselect;
}

public String getOnviewactivated(){
	if (this._onviewactivated != null) {
		return this._onviewactivated;
	}
	ValueExpression ve = getValueExpression("onviewactivated");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnviewactivated(String _onviewactivated){
this._onviewactivated = _onviewactivated;
}

public String getOnviewactivation(){
	if (this._onviewactivation != null) {
		return this._onviewactivation;
	}
	ValueExpression ve = getValueExpression("onviewactivation");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnviewactivation(String _onviewactivation){
this._onviewactivation = _onviewactivation;
}

public String getSaveControlIcon(){
	if (this._saveControlIcon != null) {
		return this._saveControlIcon;
	}
	ValueExpression ve = getValueExpression("saveControlIcon");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSaveControlIcon(String _saveControlIcon){
this._saveControlIcon = _saveControlIcon;
}

public boolean isSelectOnEdit(){
	if (this._selectOnEditSet) {
	    return (this._selectOnEdit);
	}
	ValueExpression ve = getValueExpression("selectOnEdit");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._selectOnEdit);
	    }
	    
	    return value;
	} else {
	    return (this._selectOnEdit);
	}

}

public void setSelectOnEdit(boolean _selectOnEdit){
this._selectOnEdit = _selectOnEdit;
this._selectOnEditSet = true;
}

public boolean isShowControls(){
	if (this._showControlsSet) {
	    return (this._showControls);
	}
	ValueExpression ve = getValueExpression("showControls");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._showControls);
	    }
	    
	    return value;
	} else {
	    return (this._showControls);
	}

}

public void setShowControls(boolean _showControls){
this._showControls = _showControls;
this._showControlsSet = true;
}

public String getStyleClass(){
	if (this._styleClass != null) {
		return this._styleClass;
	}
	ValueExpression ve = getValueExpression("styleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyleClass(String _styleClass){
this._styleClass = _styleClass;
}

public int getTabindex(){
	if (this._tabindexSet) {
	    return (this._tabindex);
	}
	ValueExpression ve = getValueExpression("tabindex");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._tabindex);
	    }
	    
	    return value;
	} else {
	    return (this._tabindex);
	}

}

public void setTabindex(int _tabindex){
this._tabindex = _tabindex;
this._tabindexSet = true;
}

public String getViewClass(){
	if (this._viewClass != null) {
		return this._viewClass;
	}
	ValueExpression ve = getValueExpression("viewClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setViewClass(String _viewClass){
this._viewClass = _viewClass;
}

public String getViewHoverClass(){
	if (this._viewHoverClass != null) {
		return this._viewHoverClass;
	}
	ValueExpression ve = getValueExpression("viewHoverClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setViewHoverClass(String _viewHoverClass){
this._viewHoverClass = _viewHoverClass;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[57];
state[0] = super.saveState(context);
state[1] = _cancelControlIcon;
state[2] = _changedClass;
state[3] = _changedHoverClass;
state[4] = _controlClass;
state[5] = _controlHoverClass;
state[6] = _controlPressedClass;
state[7] = _controlsHorizontalPosition;
state[8] = _controlsVerticalPosition;
state[9] = _defaultLabel;
state[10] = _editClass;
state[11] = _editEvent;
state[12] = _inputWidth;
state[13] = _label;
state[14] = _layout;
state[15] = _maxInputWidth;
state[16] = Integer.valueOf(_maxlength);
state[17] = Boolean.valueOf(_maxlengthSet);
state[18] = _minInputWidth;
state[19] = _onblur;
state[20] = _onchange;
state[21] = _onclick;
state[22] = _ondblclick;
state[23] = _oneditactivated;
state[24] = _oneditactivation;
state[25] = _onfocus;
state[26] = _oninputclick;
state[27] = _oninputdblclick;
state[28] = _oninputkeydown;
state[29] = _oninputkeypress;
state[30] = _oninputkeyup;
state[31] = _oninputmousedown;
state[32] = _oninputmousemove;
state[33] = _oninputmouseout;
state[34] = _oninputmouseover;
state[35] = _oninputmouseup;
state[36] = _onkeydown;
state[37] = _onkeypress;
state[38] = _onkeyup;
state[39] = _onmousedown;
state[40] = _onmousemove;
state[41] = _onmouseout;
state[42] = _onmouseover;
state[43] = _onmouseup;
state[44] = _onselect;
state[45] = _onviewactivated;
state[46] = _onviewactivation;
state[47] = _saveControlIcon;
state[48] = Boolean.valueOf(_selectOnEdit);
state[49] = Boolean.valueOf(_selectOnEditSet);
state[50] = Boolean.valueOf(_showControls);
state[51] = Boolean.valueOf(_showControlsSet);
state[52] = _styleClass;
state[53] = Integer.valueOf(_tabindex);
state[54] = Boolean.valueOf(_tabindexSet);
state[55] = _viewClass;
state[56] = _viewHoverClass;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_cancelControlIcon = (String)states[1];;
		_changedClass = (String)states[2];;
		_changedHoverClass = (String)states[3];;
		_controlClass = (String)states[4];;
		_controlHoverClass = (String)states[5];;
		_controlPressedClass = (String)states[6];;
		_controlsHorizontalPosition = (String)states[7];;
		_controlsVerticalPosition = (String)states[8];;
		_defaultLabel = (String)states[9];;
		_editClass = (String)states[10];;
		_editEvent = (String)states[11];;
		_inputWidth = (String)states[12];;
		_label = (String)states[13];;
		_layout = (String)states[14];;
		_maxInputWidth = (String)states[15];;
		_maxlength = ((Integer)states[16]).intValue();
		_maxlengthSet = ((Boolean)states[17]).booleanValue();
		_minInputWidth = (String)states[18];;
		_onblur = (String)states[19];;
		_onchange = (String)states[20];;
		_onclick = (String)states[21];;
		_ondblclick = (String)states[22];;
		_oneditactivated = (String)states[23];;
		_oneditactivation = (String)states[24];;
		_onfocus = (String)states[25];;
		_oninputclick = (String)states[26];;
		_oninputdblclick = (String)states[27];;
		_oninputkeydown = (String)states[28];;
		_oninputkeypress = (String)states[29];;
		_oninputkeyup = (String)states[30];;
		_oninputmousedown = (String)states[31];;
		_oninputmousemove = (String)states[32];;
		_oninputmouseout = (String)states[33];;
		_oninputmouseover = (String)states[34];;
		_oninputmouseup = (String)states[35];;
		_onkeydown = (String)states[36];;
		_onkeypress = (String)states[37];;
		_onkeyup = (String)states[38];;
		_onmousedown = (String)states[39];;
		_onmousemove = (String)states[40];;
		_onmouseout = (String)states[41];;
		_onmouseover = (String)states[42];;
		_onmouseup = (String)states[43];;
		_onselect = (String)states[44];;
		_onviewactivated = (String)states[45];;
		_onviewactivation = (String)states[46];;
		_saveControlIcon = (String)states[47];;
		_selectOnEdit = ((Boolean)states[48]).booleanValue();
		_selectOnEditSet = ((Boolean)states[49]).booleanValue();
		_showControls = ((Boolean)states[50]).booleanValue();
		_showControlsSet = ((Boolean)states[51]).booleanValue();
		_styleClass = (String)states[52];;
		_tabindex = ((Integer)states[53]).intValue();
		_tabindexSet = ((Boolean)states[54]).booleanValue();
		_viewClass = (String)states[55];;
		_viewHoverClass = (String)states[56];;
	
}

}
