/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.util.Set ;
import java.lang.Object ;
import java.lang.String ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlSubTable;

public class SubTableTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * ajaxKeys
		 * This attribute defines row keys that are updated after an AJAX request
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * This attribute defines row keys that are updated after an AJAX request
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding  for a component state for saving or redefinition
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding  for a component state for saving or redefinition
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * first
		 * A zero-relative row number of the first row to display
		 */
		private ValueExpression _first;
		/**
		 * A zero-relative row number of the first row to display
		 * Setter for first
		 * @param first - new value
		 */
		 public void setFirst( ValueExpression  __first ){
			this._first = __first;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * footerClass
		 * Assigns one or more space-separated CSS class names to any footer generated for this component
		 */
		private ValueExpression _footerClass;
		/**
		 * Assigns one or more space-separated CSS class names to any footer generated for this component
		 * Setter for footerClass
		 * @param footerClass - new value
		 */
		 public void setFooterClass( ValueExpression  __footerClass ){
			this._footerClass = __footerClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to any header generated for this component
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to any header generated for this component
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onRowClick
		 * The client-side script method to be called when the row is clicked
		 */
		private ValueExpression _onRowClick;
		/**
		 * The client-side script method to be called when the row is clicked
		 * Setter for onRowClick
		 * @param onRowClick - new value
		 */
		 public void setOnRowClick( ValueExpression  __onRowClick ){
			this._onRowClick = __onRowClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowDblClick
		 * The client-side script method to be called when the row is double-clicked
		 */
		private ValueExpression _onRowDblClick;
		/**
		 * The client-side script method to be called when the row is double-clicked
		 * Setter for onRowDblClick
		 * @param onRowDblClick - new value
		 */
		 public void setOnRowDblClick( ValueExpression  __onRowDblClick ){
			this._onRowDblClick = __onRowDblClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseDown
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 */
		private ValueExpression _onRowMouseDown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 * Setter for onRowMouseDown
		 * @param onRowMouseDown - new value
		 */
		 public void setOnRowMouseDown( ValueExpression  __onRowMouseDown ){
			this._onRowMouseDown = __onRowMouseDown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseMove
		 * The client-side script method to be called when a pointer is moved within the row
		 */
		private ValueExpression _onRowMouseMove;
		/**
		 * The client-side script method to be called when a pointer is moved within the row
		 * Setter for onRowMouseMove
		 * @param onRowMouseMove - new value
		 */
		 public void setOnRowMouseMove( ValueExpression  __onRowMouseMove ){
			this._onRowMouseMove = __onRowMouseMove;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseOut
		 * The client-side script method to be called when a pointer is moved away from the row
		 */
		private ValueExpression _onRowMouseOut;
		/**
		 * The client-side script method to be called when a pointer is moved away from the row
		 * Setter for onRowMouseOut
		 * @param onRowMouseOut - new value
		 */
		 public void setOnRowMouseOut( ValueExpression  __onRowMouseOut ){
			this._onRowMouseOut = __onRowMouseOut;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseOver
		 * The client-side script method to be called when a pointer is moved onto the row
		 */
		private ValueExpression _onRowMouseOver;
		/**
		 * The client-side script method to be called when a pointer is moved onto the row
		 * Setter for onRowMouseOver
		 * @param onRowMouseOver - new value
		 */
		 public void setOnRowMouseOver( ValueExpression  __onRowMouseOver ){
			this._onRowMouseOver = __onRowMouseOver;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseUp
		 * The client-side script method to be called when a mouse button is released over the row
		 */
		private ValueExpression _onRowMouseUp;
		/**
		 * The client-side script method to be called when a mouse button is released over the row
		 * Setter for onRowMouseUp
		 * @param onRowMouseUp - new value
		 */
		 public void setOnRowMouseUp( ValueExpression  __onRowMouseUp ){
			this._onRowMouseUp = __onRowMouseUp;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * The attribute provides access to a row key in a Request scope
		 */
		private ValueExpression _rowKeyVar;
		/**
		 * The attribute provides access to a row key in a Request scope
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( ValueExpression  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rows
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 */
		private ValueExpression _rows;
		/**
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 * Setter for rows
		 * @param rows - new value
		 */
		 public void setRows( ValueExpression  __rows ){
			this._rows = __rows;
	     }
	  
	 	 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * stateVar
		 * The attribute  provides access to a component state on the client side
		 */
		private ValueExpression _stateVar;
		/**
		 * The attribute  provides access to a component state on the client side
		 * Setter for stateVar
		 * @param stateVar - new value
		 */
		 public void setStateVar( ValueExpression  __stateVar ){
			this._stateVar = __stateVar;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 */
		private String _var;
		/**
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxKeys = null;
	 		 		 		 		 		    this._columnClasses = null;
	 		 		    this._componentState = null;
	 		 		 		 		 		    this._first = null;
	 		 		 		    this._footerClass = null;
	 		 		 		    this._headerClass = null;
	 		 		 		    this._onRowClick = null;
	 		 		    this._onRowDblClick = null;
	 		 		    this._onRowMouseDown = null;
	 		 		    this._onRowMouseMove = null;
	 		 		    this._onRowMouseOut = null;
	 		 		    this._onRowMouseOver = null;
	 		 		    this._onRowMouseUp = null;
	 		 		 		 		 		 		 		 		 		 		 		 		 		 		    this._rowClasses = null;
	 		 		 		 		 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		    this._rows = null;
	 		 		 		 		 		 		 		 		    this._stateVar = null;
	 		 		 		    this._value = null;
	 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlSubTable comp = (HtmlSubTable) component;
 		 			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					      		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					   		 			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					      		 			 
						if (this._first != null) {
				if (this._first.isLiteralText()) {
					try {
												
						Integer __first = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._first.getExpressionString(), 
											Integer.class);
					
												comp.setFirst(__first.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("first", this._first);
				}
			}
					    		 			 
						if (this._footerClass != null) {
				if (this._footerClass.isLiteralText()) {
					try {
												
						java.lang.String __footerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._footerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFooterClass(__footerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("footerClass", this._footerClass);
				}
			}
					    		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					    		 			 
						if (this._onRowClick != null) {
				if (this._onRowClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowClick(__onRowClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowClick", this._onRowClick);
				}
			}
					   		 			 
						if (this._onRowDblClick != null) {
				if (this._onRowDblClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowDblClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowDblClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowDblClick(__onRowDblClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowDblClick", this._onRowDblClick);
				}
			}
					   		 			 
						if (this._onRowMouseDown != null) {
				if (this._onRowMouseDown.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseDown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseDown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseDown(__onRowMouseDown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseDown", this._onRowMouseDown);
				}
			}
					   		 			 
						if (this._onRowMouseMove != null) {
				if (this._onRowMouseMove.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseMove = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseMove.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseMove(__onRowMouseMove);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseMove", this._onRowMouseMove);
				}
			}
					   		 			 
						if (this._onRowMouseOut != null) {
				if (this._onRowMouseOut.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseOut = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseOut.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseOut(__onRowMouseOut);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseOut", this._onRowMouseOut);
				}
			}
					   		 			 
						if (this._onRowMouseOver != null) {
				if (this._onRowMouseOver.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseOver = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseOver.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseOver(__onRowMouseOver);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseOver", this._onRowMouseOver);
				}
			}
					   		 			 
						if (this._onRowMouseUp != null) {
				if (this._onRowMouseUp.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseUp = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseUp.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseUp(__onRowMouseUp);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseUp", this._onRowMouseUp);
				}
			}
					               		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					       		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
						if (this._rowKeyVar != null) {
				if (this._rowKeyVar.isLiteralText()) {
					try {
												
						java.lang.String __rowKeyVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowKeyVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowKeyVar(__rowKeyVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowKeyVar", this._rowKeyVar);
				}
			}
					   		 			 
						if (this._rows != null) {
				if (this._rows.isLiteralText()) {
					try {
												
						Integer __rows = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rows.getExpressionString(), 
											Integer.class);
					
												comp.setRows(__rows.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rows", this._rows);
				}
			}
					         		 			 
						if (this._stateVar != null) {
				if (this._stateVar.isLiteralText()) {
					try {
												
						java.lang.String __stateVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stateVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStateVar(__stateVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stateVar", this._stateVar);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.SubTable";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.SubTableRenderer";
			}

}
