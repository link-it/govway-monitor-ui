/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import org.richfaces.model.Ordering ;
import java.lang.String ;
import java.util.Comparator ;
import javax.el.MethodExpression ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlColumn;

public class ColumnTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * breakBefore
		 * if "true" next column begins from the first row
		 */
		private ValueExpression _breakBefore;
		/**
		 * if "true" next column begins from the first row
		 * Setter for breakBefore
		 * @param breakBefore - new value
		 */
		 public void setBreakBefore( ValueExpression  __breakBefore ){
			this._breakBefore = __breakBefore;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * colspan
		 * Corresponds to the HTML colspan attribute
		 */
		private ValueExpression _colspan;
		/**
		 * Corresponds to the HTML colspan attribute
		 * Setter for colspan
		 * @param colspan - new value
		 */
		 public void setColspan( ValueExpression  __colspan ){
			this._colspan = __colspan;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * comparator
		 * Defines value binding to the comparator that is used to compare the values
		 */
		private ValueExpression _comparator;
		/**
		 * Defines value binding to the comparator that is used to compare the values
		 * Setter for comparator
		 * @param comparator - new value
		 */
		 public void setComparator( ValueExpression  __comparator ){
			this._comparator = __comparator;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * filterBy
		 * Defines iterable object property which is used when filtering performed.
		 */
		private ValueExpression _filterBy;
		/**
		 * Defines iterable object property which is used when filtering performed.
		 * Setter for filterBy
		 * @param filterBy - new value
		 */
		 public void setFilterBy( ValueExpression  __filterBy ){
			this._filterBy = __filterBy;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * filterEvent
		 * Event for filter input that forces the filtration (default value is "onchange")
		 */
		private ValueExpression _filterEvent;
		/**
		 * Event for filter input that forces the filtration (default value is "onchange")
		 * Setter for filterEvent
		 * @param filterEvent - new value
		 */
		 public void setFilterEvent( ValueExpression  __filterEvent ){
			this._filterEvent = __filterEvent;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * filterExpression
		 * Attribute defines a bean property which is used for filtering of a column
		 */
		private ValueExpression _filterExpression;
		/**
		 * Attribute defines a bean property which is used for filtering of a column
		 * Setter for filterExpression
		 * @param filterExpression - new value
		 */
		 public void setFilterExpression( ValueExpression  __filterExpression ){
			this._filterExpression = __filterExpression;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * filterMethod
		 * This attribute is defined with method binding. This method accepts on Object parameter and return boolean value
		 */
		private MethodExpression _filterMethod;
		/**
		 * This attribute is defined with method binding. This method accepts on Object parameter and return boolean value
		 * Setter for filterMethod
		 * @param filterMethod - new value
		 */
		 public void setFilterMethod( MethodExpression  __filterMethod ){
			this._filterMethod = __filterMethod;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * filterValue
		 * Defines current filtering value
		 */
		private ValueExpression _filterValue;
		/**
		 * Defines current filtering value
		 * Setter for filterValue
		 * @param filterValue - new value
		 */
		 public void setFilterValue( ValueExpression  __filterValue ){
			this._filterValue = __filterValue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * footerClass
		 * Assigns one or more space-separated CSS class names to any footer generated for this component
		 */
		private ValueExpression _footerClass;
		/**
		 * Assigns one or more space-separated CSS class names to any footer generated for this component
		 * Setter for footerClass
		 * @param footerClass - new value
		 */
		 public void setFooterClass( ValueExpression  __footerClass ){
			this._footerClass = __footerClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to any header generated for this component
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to any header generated for this component
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * label
		 * Column label for drag indicator. Usable only for extendedDataTable component
		 */
		private ValueExpression _label;
		/**
		 * Column label for drag indicator. Usable only for extendedDataTable component
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * rowspan
		 * Corresponds to the HTML rowspan attribute
		 */
		private ValueExpression _rowspan;
		/**
		 * Corresponds to the HTML rowspan attribute
		 * Setter for rowspan
		 * @param rowspan - new value
		 */
		 public void setRowspan( ValueExpression  __rowspan ){
			this._rowspan = __rowspan;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selfSorted
		 * Manages if the header of the column is clickable, icons rendered and sorting is fired after click on the header. You need to define this attribute inside &amp;lt;rich:dataTable&amp;gt; component.
	Default value is "true"
		 */
		private ValueExpression _selfSorted;
		/**
		 * Manages if the header of the column is clickable, icons rendered and sorting is fired after click on the header. You need to define this attribute inside &amp;lt;rich:dataTable&amp;gt; component.
	Default value is "true"
		 * Setter for selfSorted
		 * @param selfSorted - new value
		 */
		 public void setSelfSorted( ValueExpression  __selfSorted ){
			this._selfSorted = __selfSorted;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortBy
		 * Defines a bean property which is used for sorting of a column. This attribute used with &amp;lt;rich:dataTable&amp;gt;
		 */
		private ValueExpression _sortBy;
		/**
		 * Defines a bean property which is used for sorting of a column. This attribute used with &amp;lt;rich:dataTable&amp;gt;
		 * Setter for sortBy
		 * @param sortBy - new value
		 */
		 public void setSortBy( ValueExpression  __sortBy ){
			this._sortBy = __sortBy;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortExpression
		 * Defines a bean property which is used for sorting of a column and used only with &amp;lt;rich:scrollableDataTable&amp;gt;.
		 */
		private ValueExpression _sortExpression;
		/**
		 * Defines a bean property which is used for sorting of a column and used only with &amp;lt;rich:scrollableDataTable&amp;gt;.
		 * Setter for sortExpression
		 * @param sortExpression - new value
		 */
		 public void setSortExpression( ValueExpression  __sortExpression ){
			this._sortExpression = __sortExpression;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * sortIcon
		 * Defines sort icon. The value for the attribute is context related.
		 */
		private ValueExpression _sortIcon;
		/**
		 * Defines sort icon. The value for the attribute is context related.
		 * Setter for sortIcon
		 * @param sortIcon - new value
		 */
		 public void setSortIcon( ValueExpression  __sortIcon ){
			this._sortIcon = __sortIcon;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortIconAscending
		 * Defines sort icon for ascending order. The value for the attribute is context related.
		 */
		private ValueExpression _sortIconAscending;
		/**
		 * Defines sort icon for ascending order. The value for the attribute is context related.
		 * Setter for sortIconAscending
		 * @param sortIconAscending - new value
		 */
		 public void setSortIconAscending( ValueExpression  __sortIconAscending ){
			this._sortIconAscending = __sortIconAscending;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortIconDescending
		 * Defines sort icon for descending order. The value for the attribute is context related.
		 */
		private ValueExpression _sortIconDescending;
		/**
		 * Defines sort icon for descending order. The value for the attribute is context related.
		 * Setter for sortIconDescending
		 * @param sortIconDescending - new value
		 */
		 public void setSortIconDescending( ValueExpression  __sortIconDescending ){
			this._sortIconDescending = __sortIconDescending;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortOrder
		 * SortOrder is an enumeration of the possible sort orderings. Default value is "UNSORTED"
		 */
		private ValueExpression _sortOrder;
		/**
		 * SortOrder is an enumeration of the possible sort orderings. Default value is "UNSORTED"
		 * Setter for sortOrder
		 * @param sortOrder - new value
		 */
		 public void setSortOrder( ValueExpression  __sortOrder ){
			this._sortOrder = __sortOrder;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortable
		 * Boolean attribute. If "true" it's possible to sort the column content after click on the header.
	Default value is "true"
		 */
		private ValueExpression _sortable;
		/**
		 * Boolean attribute. If "true" it's possible to sort the column content after click on the header.
	Default value is "true"
		 * Setter for sortable
		 * @param sortable - new value
		 */
		 public void setSortable( ValueExpression  __sortable ){
			this._sortable = __sortable;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * visible
		 * The attribute is used to define whether the component is visible or not. The default value is "true".
		 */
		private ValueExpression _visible;
		/**
		 * The attribute is used to define whether the component is visible or not. The default value is "true".
		 * Setter for visible
		 * @param visible - new value
		 */
		 public void setVisible( ValueExpression  __visible ){
			this._visible = __visible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * Attribute defines width of column.
		 */
		private ValueExpression _width;
		/**
		 * Attribute defines width of column.
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._breakBefore = null;
	 		 		    this._colspan = null;
	 		 		    this._comparator = null;
	 		 		 		 		    this._filterBy = null;
	 		 		    this._filterEvent = null;
	 		 		    this._filterExpression = null;
	 		 		 		    this._filterMethod = null;
	 		 		    this._filterValue = null;
	 		 		 		    this._footerClass = null;
	 		 		 		    this._headerClass = null;
	 		 		 		    this._label = null;
	 		 		 		 		    this._rowspan = null;
	 		 		    this._selfSorted = null;
	 		 		    this._sortBy = null;
	 		 		    this._sortExpression = null;
	 		 		 		    this._sortIcon = null;
	 		 		    this._sortIconAscending = null;
	 		 		    this._sortIconDescending = null;
	 		 		    this._sortOrder = null;
	 		 		    this._sortable = null;
	 		 		 		 		 		    this._visible = null;
	 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlColumn comp = (HtmlColumn) component;
  		 			 
						if (this._breakBefore != null) {
				if (this._breakBefore.isLiteralText()) {
					try {
												
						Boolean __breakBefore = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._breakBefore.getExpressionString(), 
											Boolean.class);
					
												comp.setBreakBefore(__breakBefore.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("breakBefore", this._breakBefore);
				}
			}
					   		 			 
						if (this._colspan != null) {
				if (this._colspan.isLiteralText()) {
					try {
												
						Integer __colspan = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._colspan.getExpressionString(), 
											Integer.class);
					
												comp.setColspan(__colspan.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("colspan", this._colspan);
				}
			}
					   		 			 
						if (this._comparator != null) {
				if (this._comparator.isLiteralText()) {
					try {
												
						java.util.Comparator __comparator = (java.util.Comparator) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._comparator.getExpressionString(), 
											java.util.Comparator.class);
					
												comp.setComparator(__comparator);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("comparator", this._comparator);
				}
			}
					     		 			 				if(null != this._filterBy && this._filterBy.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.Column with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property filterBy");
				}
			 
						if (this._filterBy != null) {
				if (this._filterBy.isLiteralText()) {
					try {
												
						java.lang.Object __filterBy = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._filterBy.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setFilterBy(__filterBy);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("filterBy", this._filterBy);
				}
			}
					   		 			 
						if (this._filterEvent != null) {
				if (this._filterEvent.isLiteralText()) {
					try {
												
						java.lang.String __filterEvent = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._filterEvent.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFilterEvent(__filterEvent);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("filterEvent", this._filterEvent);
				}
			}
					   		 			 				if(null != this._filterExpression && this._filterExpression.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.Column with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property filterExpression");
				}
			 
						if (this._filterExpression != null) {
				if (this._filterExpression.isLiteralText()) {
					try {
												
						Boolean __filterExpression = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._filterExpression.getExpressionString(), 
											Boolean.class);
					
												comp.setFilterExpression(__filterExpression.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("filterExpression", this._filterExpression);
				}
			}
					    		 			if(null != this._filterMethod){
				((HtmlColumn)component).setFilterMethod(this._filterMethod);
			}		
		   		 			 
						if (this._filterValue != null) {
				if (this._filterValue.isLiteralText()) {
					try {
												
						java.lang.String __filterValue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._filterValue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFilterValue(__filterValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("filterValue", this._filterValue);
				}
			}
					    		 			 
						if (this._footerClass != null) {
				if (this._footerClass.isLiteralText()) {
					try {
												
						java.lang.String __footerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._footerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFooterClass(__footerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("footerClass", this._footerClass);
				}
			}
					    		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					    		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					     		 			 
						if (this._rowspan != null) {
				if (this._rowspan.isLiteralText()) {
					try {
												
						Integer __rowspan = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowspan.getExpressionString(), 
											Integer.class);
					
												comp.setRowspan(__rowspan.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowspan", this._rowspan);
				}
			}
					   		 			 
						if (this._selfSorted != null) {
				if (this._selfSorted.isLiteralText()) {
					try {
												
						Boolean __selfSorted = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selfSorted.getExpressionString(), 
											Boolean.class);
					
												comp.setSelfSorted(__selfSorted.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selfSorted", this._selfSorted);
				}
			}
					   		 			 
						if (this._sortBy != null) {
				if (this._sortBy.isLiteralText()) {
					try {
												
						java.lang.Object __sortBy = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortBy.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setSortBy(__sortBy);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortBy", this._sortBy);
				}
			}
					   		 			 
						if (this._sortExpression != null) {
				if (this._sortExpression.isLiteralText()) {
					try {
												
						java.lang.String __sortExpression = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortExpression.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSortExpression(__sortExpression);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortExpression", this._sortExpression);
				}
			}
					    		 			 
						if (this._sortIcon != null) {
				if (this._sortIcon.isLiteralText()) {
					try {
												
						java.lang.String __sortIcon = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortIcon.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSortIcon(__sortIcon);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortIcon", this._sortIcon);
				}
			}
					   		 			 
						if (this._sortIconAscending != null) {
				if (this._sortIconAscending.isLiteralText()) {
					try {
												
						java.lang.String __sortIconAscending = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortIconAscending.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSortIconAscending(__sortIconAscending);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortIconAscending", this._sortIconAscending);
				}
			}
					   		 			 
						if (this._sortIconDescending != null) {
				if (this._sortIconDescending.isLiteralText()) {
					try {
												
						java.lang.String __sortIconDescending = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortIconDescending.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSortIconDescending(__sortIconDescending);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortIconDescending", this._sortIconDescending);
				}
			}
					   		 			 
						if (this._sortOrder != null) {
				if (this._sortOrder.isLiteralText()) {
					try {
												
						org.richfaces.model.Ordering __sortOrder = (org.richfaces.model.Ordering) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortOrder.getExpressionString(), 
											org.richfaces.model.Ordering.class);
					
												comp.setSortOrder(__sortOrder);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortOrder", this._sortOrder);
				}
			}
					   		 			 
						if (this._sortable != null) {
				if (this._sortable.isLiteralText()) {
					try {
												
						Boolean __sortable = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortable.getExpressionString(), 
											Boolean.class);
					
												comp.setSortable(__sortable.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortable", this._sortable);
				}
			}
					      		 			 
						if (this._visible != null) {
				if (this._visible.isLiteralText()) {
					try {
												
						Boolean __visible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._visible.getExpressionString(), 
											Boolean.class);
					
												comp.setVisible(__visible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("visible", this._visible);
				}
			}
					   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.Column";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.renderkit.CellRenderer";
			}

}
