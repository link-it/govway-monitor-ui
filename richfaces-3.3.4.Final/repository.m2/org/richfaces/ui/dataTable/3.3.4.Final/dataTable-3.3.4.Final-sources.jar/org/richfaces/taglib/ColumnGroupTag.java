/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlColumnGroup;

public class ColumnGroupTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
				each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
				the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. 
				If there are more class names than columns, the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
				each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
				the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. 
				If there are more class names than columns, the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
				each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
				the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
				the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
				each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
				the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
				the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 		 		 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		    this._columnClasses = null;
	 		 		 		 		 		 		 		 		 		    this._rowClasses = null;
	 		 		 		 		 		 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlColumnGroup comp = (HtmlColumnGroup) component;
   		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					          		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					            }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ColumnGroup";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.ColumnGroupRenderer";
			}

}
