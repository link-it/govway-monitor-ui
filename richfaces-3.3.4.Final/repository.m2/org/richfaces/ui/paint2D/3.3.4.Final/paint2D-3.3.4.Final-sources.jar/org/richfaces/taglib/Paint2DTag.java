/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPaint2D;

public class Paint2DTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * align
		 * Deprecated. This attribute specifies the position of an IMG, OBJECT, or APPLET with respect to its context.           
           The possible values are "bottom", "middle", "top", "left" and "right". The default value is "middle".
		 */
		private ValueExpression _align;
		/**
		 * Deprecated. This attribute specifies the position of an IMG, OBJECT, or APPLET with respect to its context.           
           The possible values are "bottom", "middle", "top", "left" and "right". The default value is "middle".
		 * Setter for align
		 * @param align - new value
		 */
		 public void setAlign( ValueExpression  __align ){
			this._align = __align;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * alt
		 * For compability with XHTML 1.1 standart
		 */
		private ValueExpression _alt;
		/**
		 * For compability with XHTML 1.1 standart
		 * Setter for alt
		 * @param alt - new value
		 */
		 public void setAlt( ValueExpression  __alt ){
			this._alt = __alt;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * bgcolor
		 * Background color of painted image. Default value is 'transparent' which means no background fill. 
			Hex colors can be used, as well as common color names. 
			Invalid values are treated as transparent.
			Note, that JPEG format doesn't support transparency, and transparent background is painted black.
			Also note, that several browsers (e.g. IE6) do not support PNG transparency. Default value is &amp;quot;transparent&amp;quot;
		 */
		private ValueExpression _bgcolor;
		/**
		 * Background color of painted image. Default value is 'transparent' which means no background fill. 
			Hex colors can be used, as well as common color names. 
			Invalid values are treated as transparent.
			Note, that JPEG format doesn't support transparency, and transparent background is painted black.
			Also note, that several browsers (e.g. IE6) do not support PNG transparency. Default value is &amp;quot;transparent&amp;quot;
		 * Setter for bgcolor
		 * @param bgcolor - new value
		 */
		 public void setBgcolor( ValueExpression  __bgcolor ){
			this._bgcolor = __bgcolor;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * border
		 * Deprecated. This attribute specifies the width of an IMG or OBJECT border, in pixels. The default value for this attribute depends on the user agent
		 */
		private ValueExpression _border;
		/**
		 * Deprecated. This attribute specifies the width of an IMG or OBJECT border, in pixels. The default value for this attribute depends on the user agent
		 * Setter for border
		 * @param border - new value
		 */
		 public void setBorder( ValueExpression  __border ){
			this._border = __border;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cacheable
		 * Supported (or not) client/server caching for generated images.
			Caching on client supported by properly sending and processing of HTTP headers (Last-Modified, Expires, If-Modified-Since, etc.)
			Server-side caching is supported by application-scope object cache.
			For build of cache key use "value" attribute, serialized to URI
		 */
		private ValueExpression _cacheable;
		/**
		 * Supported (or not) client/server caching for generated images.
			Caching on client supported by properly sending and processing of HTTP headers (Last-Modified, Expires, If-Modified-Since, etc.)
			Server-side caching is supported by application-scope object cache.
			For build of cache key use "value" attribute, serialized to URI
		 * Setter for cacheable
		 * @param cacheable - new value
		 */
		 public void setCacheable( ValueExpression  __cacheable ){
			this._cacheable = __cacheable;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * data
		 * Value calculated at render time and stored in Image URI (as part of cache Key), 
			at paint time passed to a paint method. It can be used for updating cache at change of image generating
			conditions, and for creating paint beans as "Lightweight" pattern components (request scope).
			IMPORTANT: Since serialized data stored in URI, avoid using big objects
		 */
		private ValueExpression _data;
		/**
		 * Value calculated at render time and stored in Image URI (as part of cache Key), 
			at paint time passed to a paint method. It can be used for updating cache at change of image generating
			conditions, and for creating paint beans as "Lightweight" pattern components (request scope).
			IMPORTANT: Since serialized data stored in URI, avoid using big objects
		 * Setter for data
		 * @param data - new value
		 */
		 public void setData( ValueExpression  __data ){
			this._data = __data;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * format
		 * format Name of format for sending a generated image. It currently supports "jpeg" (24 bit, default), "gif" (8 bit with transparency), "png" (32 bit with transparency)
		 */
		private ValueExpression _format;
		/**
		 * format Name of format for sending a generated image. It currently supports "jpeg" (24 bit, default), "gif" (8 bit with transparency), "png" (32 bit with transparency)
		 * Setter for format
		 * @param format - new value
		 */
		 public void setFormat( ValueExpression  __format ){
			this._format = __format;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * height
		 * Height in pixels of image (for paint canvas and HTML attribute). Default value is "10".
		 */
		private ValueExpression _height;
		/**
		 * Height in pixels of image (for paint canvas and HTML attribute). Default value is "10".
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hspace
		 * Deprecated. This attribute specifies the amount of white space to be inserted to the left and right of an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 */
		private ValueExpression _hspace;
		/**
		 * Deprecated. This attribute specifies the amount of white space to be inserted to the left and right of an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 * Setter for hspace
		 * @param hspace - new value
		 */
		 public void setHspace( ValueExpression  __hspace ){
			this._hspace = __hspace;
	     }
	  
	 	 		 		 		 	  	  	  
		/*
		 * paint
		 * The method calls expression to paint Image on prepared Buffered image. It must have two parameters with a type of java.awt.Graphics2D (graphics to paint) and Object (restored from URI "data" property).
			For painting used 32-bit RGBA color model (for 8-bit images used Diffusion filtration before sending)
		 */
		private MethodExpression _paint;
		/**
		 * The method calls expression to paint Image on prepared Buffered image. It must have two parameters with a type of java.awt.Graphics2D (graphics to paint) and Object (restored from URI "data" property).
			For painting used 32-bit RGBA color model (for 8-bit images used Diffusion filtration before sending)
		 * Setter for paint
		 * @param paint - new value
		 */
		 public void setPaint( MethodExpression  __paint ){
			this._paint = __paint;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * vspace
		 * Deprecated. This attribute specifies the amount of white space to be inserted above and below an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 */
		private ValueExpression _vspace;
		/**
		 * Deprecated. This attribute specifies the amount of white space to be inserted above and below an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 * Setter for vspace
		 * @param vspace - new value
		 */
		 public void setVspace( ValueExpression  __vspace ){
			this._vspace = __vspace;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * Width in pixels of image (for paint canvas and HTML attribute). Default value is "10".
		 */
		private ValueExpression _width;
		/**
		 * Width in pixels of image (for paint canvas and HTML attribute). Default value is "10".
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._align = null;
	 		 		    this._alt = null;
	 		 		    this._bgcolor = null;
	 		 		 		    this._border = null;
	 		 		    this._cacheable = null;
	 		 		 		    this._data = null;
	 		 		 		 		    this._format = null;
	 		 		    this._height = null;
	 		 		    this._hspace = null;
	 		 		 		 		    this._paint = null;
	 		 		 		 		 		 		    this._value = null;
	 		 		    this._vspace = null;
	 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPaint2D comp = (HtmlPaint2D) component;
 		 			 
						if (this._align != null) {
				if (this._align.isLiteralText()) {
					try {
												
						java.lang.String __align = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._align.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAlign(__align);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("align", this._align);
				}
			}
					   		 			 
						if (this._alt != null) {
				if (this._alt.isLiteralText()) {
					try {
												
						java.lang.String __alt = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._alt.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAlt(__alt);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("alt", this._alt);
				}
			}
					   		 			 
						if (this._bgcolor != null) {
				if (this._bgcolor.isLiteralText()) {
					try {
												
						java.lang.String __bgcolor = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bgcolor.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBgcolor(__bgcolor);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bgcolor", this._bgcolor);
				}
			}
					    		 			 
						if (this._border != null) {
				if (this._border.isLiteralText()) {
					try {
												
						java.lang.String __border = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._border.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBorder(__border);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("border", this._border);
				}
			}
					   		 			 
						if (this._cacheable != null) {
				if (this._cacheable.isLiteralText()) {
					try {
												
						Boolean __cacheable = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cacheable.getExpressionString(), 
											Boolean.class);
					
												comp.setCacheable(__cacheable.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cacheable", this._cacheable);
				}
			}
					    		 			 
						if (this._data != null) {
				if (this._data.isLiteralText()) {
					try {
												
						java.lang.Object __data = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._data.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setData(__data);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("data", this._data);
				}
			}
					     		 			 
						if (this._format != null) {
				if (this._format.isLiteralText()) {
					try {
												
						java.lang.String __format = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._format.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFormat(__format);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("format", this._format);
				}
			}
					   		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						Integer __height = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											Integer.class);
					
												comp.setHeight(__height.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					   		 			 
						if (this._hspace != null) {
				if (this._hspace.isLiteralText()) {
					try {
												
						java.lang.String __hspace = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hspace.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHspace(__hspace);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hspace", this._hspace);
				}
			}
					     		 			if(null != this._paint){
             if (!this._paint.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._paint);
                ((HtmlPaint2D)component).setPaint(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid paint value: " + this._paint);
             }
			}
		       		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
						if (this._vspace != null) {
				if (this._vspace.isLiteralText()) {
					try {
												
						java.lang.String __vspace = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._vspace.getExpressionString(), 
											java.lang.String.class);
					
												comp.setVspace(__vspace);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("vspace", this._vspace);
				}
			}
					   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						Integer __width = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											Integer.class);
					
												comp.setWidth(__width.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.Paint2D";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.Paint2DRenderer";
			}

}
