/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import org.richfaces.taglib.Image2DTagHandler ;
import javax.faces.component.UIComponent ;
import javax.faces.component.UIComponent;
import org.richfaces.component.html.HtmlPaint2D;
import com.sun.facelets.tag.jsf.ComponentHandler;
import com.sun.facelets.tag.jsf.ComponentConfig;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
/**
 * @author shura (latest modification by $Author: alexsmirnov $)
 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
 *
 */
public class Paint2DTagHandler extends org.richfaces.taglib.Image2DTagHandler {


  private static final Paint2DTagHandlerMetaRule metaRule = new Paint2DTagHandlerMetaRule();


  
  public Paint2DTagHandler(ComponentConfig config) 
  {
    super(config);
  }
// Metarule
  protected MetaRuleset createMetaRuleset(Class type)
  {
    MetaRuleset m = super.createMetaRuleset(type);
	m.addRule(metaRule);
	return m;
  }

  	/**
	 * @author shura (latest modification by $Author: alexsmirnov $)
	 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
	 *
	 */
	static class Paint2DTagHandlerMetaRule extends MetaRule{

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.MetaRule#applyRule(java.lang.String, com.sun.facelets.tag.TagAttribute, com.sun.facelets.tag.MetadataTarget)
		 */
		public Metadata applyRule(String name, TagAttribute attribute, MetadataTarget meta) {
	        if (meta.isTargetInstanceOf(HtmlPaint2D.class)) {
				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 				 				 		  	            	            
	            if ("paint".equals(name)) {
	                    return new paintMapper(attribute);
	            }
				
						  		 				 				 				 				 				 		  		 				 		  		 				 		  		 			        }
			return null;
		}

	}


    
    
     
    
    
    
      
    
    
      
  		
	static class paintMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {java.awt.Graphics2D.class,java.lang.Object.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public paintMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlPaint2D) instance)
            .setPaint
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	      
    
    
    }
