/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlProgressBar;

public class ProgressBarTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 	  	  	  
		/*
		 * actionListener
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 */
		private MethodExpression _actionListener;
		/**
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 * Setter for actionListener
		 * @param actionListener - new value
		 */
		 public void setActionListener( MethodExpression  __actionListener ){
			this._actionListener = __actionListener;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * ajaxSingle
		 * Limits JSF tree processing (decoding, conversion, validation and model updating) only to a component that sends the request. Boolean. Default value is "false".
		 */
		private ValueExpression _ajaxSingle;
		/**
		 * Limits JSF tree processing (decoding, conversion, validation and model updating) only to a component that sends the request. Boolean. Default value is "false".
		 * Setter for ajaxSingle
		 * @param ajaxSingle - new value
		 */
		 public void setAjaxSingle( ValueExpression  __ajaxSingle ){
			this._ajaxSingle = __ajaxSingle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * bypassUpdates
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 */
		private ValueExpression _bypassUpdates;
		/**
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 * Setter for bypassUpdates
		 * @param bypassUpdates - new value
		 */
		 public void setBypassUpdates( ValueExpression  __bypassUpdates ){
			this._bypassUpdates = __bypassUpdates;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * completeClass
		 * Assigns one or more space-separated CSS class names to the component progress line rendering
		 */
		private ValueExpression _completeClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component progress line rendering
		 * Setter for completeClass
		 * @param completeClass - new value
		 */
		 public void setCompleteClass( ValueExpression  __completeClass ){
			this._completeClass = __completeClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * data
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 */
		private ValueExpression _data;
		/**
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 * Setter for data
		 * @param data - new value
		 */
		 public void setData( ValueExpression  __data ){
			this._data = __data;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * enabled
		 * Enables/disables polling. Default value is "true".
		 */
		private ValueExpression _enabled;
		/**
		 * Enables/disables polling. Default value is "true".
		 * Setter for enabled
		 * @param enabled - new value
		 */
		 public void setEnabled( ValueExpression  __enabled ){
			this._enabled = __enabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * eventsQueue
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 */
		private ValueExpression _eventsQueue;
		/**
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 * Setter for eventsQueue
		 * @param eventsQueue - new value
		 */
		 public void setEventsQueue( ValueExpression  __eventsQueue ){
			this._eventsQueue = __eventsQueue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * finishClass
		 * Assigns one or more space-separated CSS class names to the progress bar complete state
		 */
		private ValueExpression _finishClass;
		/**
		 * Assigns one or more space-separated CSS class names to the progress bar complete state
		 * Setter for finishClass
		 * @param finishClass - new value
		 */
		 public void setFinishClass( ValueExpression  __finishClass ){
			this._finishClass = __finishClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * focus
		 * ID of an element to set focus after request is completed on client side
		 */
		private ValueExpression _focus;
		/**
		 * ID of an element to set focus after request is completed on client side
		 * Setter for focus
		 * @param focus - new value
		 */
		 public void setFocus( ValueExpression  __focus ){
			this._focus = __focus;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * immediate
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 */
		private ValueExpression _immediate;
		/**
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * initialClass
		 * Assigns one or more space-separated CSS class names to the progress bar initial state
		 */
		private ValueExpression _initialClass;
		/**
		 * Assigns one or more space-separated CSS class names to the progress bar initial state
		 * Setter for initialClass
		 * @param initialClass - new value
		 */
		 public void setInitialClass( ValueExpression  __initialClass ){
			this._initialClass = __initialClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * interval
		 * Interval (in ms) for call poll requests. Default value
				1000 ms (1 sec)
		 */
		private ValueExpression _interval;
		/**
		 * Interval (in ms) for call poll requests. Default value
				1000 ms (1 sec)
		 * Setter for interval
		 * @param interval - new value
		 */
		 public void setInterval( ValueExpression  __interval ){
			this._interval = __interval;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * Attribute defines a simple label instead of rendering children component
		 */
		private ValueExpression _label;
		/**
		 * Attribute defines a simple label instead of rendering children component
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * limitToList
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 */
		private ValueExpression _limitToList;
		/**
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 * Setter for limitToList
		 * @param limitToList - new value
		 */
		 public void setLimitToList( ValueExpression  __limitToList ){
			this._limitToList = __limitToList;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * maxValue
		 * Max value, after which complete state should be rendered. Default value is "100".
		 */
		private ValueExpression _maxValue;
		/**
		 * Max value, after which complete state should be rendered. Default value is "100".
		 * Setter for maxValue
		 * @param maxValue - new value
		 */
		 public void setMaxValue( ValueExpression  __maxValue ){
			this._maxValue = __maxValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * minValue
		 * Min value when initial state should be rendered. Default value is "0".
		 */
		private ValueExpression _minValue;
		/**
		 * Min value when initial state should be rendered. Default value is "0".
		 * Setter for minValue
		 * @param minValue - new value
		 */
		 public void setMinValue( ValueExpression  __minValue ){
			this._minValue = __minValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * mode
		 * Attributes defines AJAX or CLIENT modes for component. Possible values are "ajax", "client". Default value is "ajax".
		 */
		private ValueExpression _mode;
		/**
		 * Attributes defines AJAX or CLIENT modes for component. Possible values are "ajax", "client". Default value is "ajax".
		 * Setter for mode
		 * @param mode - new value
		 */
		 public void setMode( ValueExpression  __mode ){
			this._mode = __mode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onbeforedomupdate
		 * The client-side script method to be called before DOM is updated
		 */
		private ValueExpression _onbeforedomupdate;
		/**
		 * The client-side script method to be called before DOM is updated
		 * Setter for onbeforedomupdate
		 * @param onbeforedomupdate - new value
		 */
		 public void setOnbeforedomupdate( ValueExpression  __onbeforedomupdate ){
			this._onbeforedomupdate = __onbeforedomupdate;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the request is completed
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the request is completed
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onsubmit
		 * The client-side script method to be called before an ajax request is submitted
		 */
		private ValueExpression _onsubmit;
		/**
		 * The client-side script method to be called before an ajax request is submitted
		 * Setter for onsubmit
		 * @param onsubmit - new value
		 */
		 public void setOnsubmit( ValueExpression  __onsubmit ){
			this._onsubmit = __onsubmit;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * parameters
		 * Parameters for macrosubstitution in the label
		 */
		private ValueExpression _parameters;
		/**
		 * Parameters for macrosubstitution in the label
		 * Setter for parameters
		 * @param parameters - new value
		 */
		 public void setParameters( ValueExpression  __parameters ){
			this._parameters = __parameters;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * process
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _process;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for process
		 * @param process - new value
		 */
		 public void setProcess( ValueExpression  __process ){
			this._process = __process;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * progressVar
		 * DEPRECATED. Provides access to value of the component on the client
		 */
		private ValueExpression _progressVar;
		/**
		 * DEPRECATED. Provides access to value of the component on the client
		 * Setter for progressVar
		 * @param progressVar - new value
		 */
		 public void setProgressVar( ValueExpression  __progressVar ){
			this._progressVar = __progressVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * reRenderAfterComplete
		 * Set of componets to rerender after completion
		 */
		private ValueExpression _reRenderAfterComplete;
		/**
		 * Set of componets to rerender after completion
		 * Setter for reRenderAfterComplete
		 * @param reRenderAfterComplete - new value
		 */
		 public void setReRenderAfterComplete( ValueExpression  __reRenderAfterComplete ){
			this._reRenderAfterComplete = __reRenderAfterComplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * remainClass
		 * Assigns one or more space-separated CSS class names to the remained part of the progress bar
		 */
		private ValueExpression _remainClass;
		/**
		 * Assigns one or more space-separated CSS class names to the remained part of the progress bar
		 * Setter for remainClass
		 * @param remainClass - new value
		 */
		 public void setRemainClass( ValueExpression  __remainClass ){
			this._remainClass = __remainClass;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * similarityGroupingId
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 */
		private ValueExpression _similarityGroupingId;
		/**
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 * Setter for similarityGroupingId
		 * @param similarityGroupingId - new value
		 */
		 public void setSimilarityGroupingId( ValueExpression  __similarityGroupingId ){
			this._similarityGroupingId = __similarityGroupingId;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * timeout
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 */
		private ValueExpression _timeout;
		/**
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * Sets the current value of the progress
		 */
		private ValueExpression _value;
		/**
		 * Sets the current value of the progress
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		    this._actionListener = null;
	 		 		 		 		    this._ajaxSingle = null;
	 		 		 		    this._bypassUpdates = null;
	 		 		    this._completeClass = null;
	 		 		    this._data = null;
	 		 		 		    this._enabled = null;
	 		 		    this._eventsQueue = null;
	 		 		 		    this._finishClass = null;
	 		 		    this._focus = null;
	 		 		 		    this._ignoreDupResponses = null;
	 		 		    this._immediate = null;
	 		 		    this._initialClass = null;
	 		 		    this._interval = null;
	 		 		    this._label = null;
	 		 		    this._limitToList = null;
	 		 		    this._maxValue = null;
	 		 		    this._minValue = null;
	 		 		    this._mode = null;
	 		 		    this._onbeforedomupdate = null;
	 		 		 		    this._oncomplete = null;
	 		 		 		 		 		 		 		 		 		 		 		    this._onsubmit = null;
	 		 		    this._parameters = null;
	 		 		    this._process = null;
	 		 		    this._progressVar = null;
	 		 		    this._reRender = null;
	 		 		    this._reRenderAfterComplete = null;
	 		 		    this._remainClass = null;
	 		 		 		 		    this._similarityGroupingId = null;
	 		 		    this._status = null;
	 		 		 		 		 		    this._timeout = null;
	 		 		 		    this._value = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlProgressBar comp = (HtmlProgressBar) component;
   		 			setActionListenerProperty(comp, this._actionListener);
		     		 			 
						if (this._ajaxSingle != null) {
				if (this._ajaxSingle.isLiteralText()) {
					try {
												
						Boolean __ajaxSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxSingle(__ajaxSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSingle", this._ajaxSingle);
				}
			}
					    		 			 
						if (this._bypassUpdates != null) {
				if (this._bypassUpdates.isLiteralText()) {
					try {
												
						Boolean __bypassUpdates = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bypassUpdates.getExpressionString(), 
											Boolean.class);
					
												comp.setBypassUpdates(__bypassUpdates.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bypassUpdates", this._bypassUpdates);
				}
			}
					   		 			 
						if (this._completeClass != null) {
				if (this._completeClass.isLiteralText()) {
					try {
												
						java.lang.String __completeClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._completeClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCompleteClass(__completeClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("completeClass", this._completeClass);
				}
			}
					   		 			 
						if (this._data != null) {
				if (this._data.isLiteralText()) {
					try {
												
						java.lang.Object __data = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._data.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setData(__data);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("data", this._data);
				}
			}
					    		 			 
						if (this._enabled != null) {
				if (this._enabled.isLiteralText()) {
					try {
												
						Boolean __enabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enabled.getExpressionString(), 
											Boolean.class);
					
												comp.setEnabled(__enabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enabled", this._enabled);
				}
			}
					   		 			 
						if (this._eventsQueue != null) {
				if (this._eventsQueue.isLiteralText()) {
					try {
												
						java.lang.String __eventsQueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._eventsQueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEventsQueue(__eventsQueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("eventsQueue", this._eventsQueue);
				}
			}
					    		 			 
						if (this._finishClass != null) {
				if (this._finishClass.isLiteralText()) {
					try {
												
						java.lang.String __finishClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._finishClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFinishClass(__finishClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("finishClass", this._finishClass);
				}
			}
					   		 			 
						if (this._focus != null) {
				if (this._focus.isLiteralText()) {
					try {
												
						java.lang.String __focus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._focus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFocus(__focus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("focus", this._focus);
				}
			}
					    		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					   		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._initialClass != null) {
				if (this._initialClass.isLiteralText()) {
					try {
												
						java.lang.String __initialClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._initialClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInitialClass(__initialClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("initialClass", this._initialClass);
				}
			}
					   		 			 
						if (this._interval != null) {
				if (this._interval.isLiteralText()) {
					try {
												
						Integer __interval = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._interval.getExpressionString(), 
											Integer.class);
					
												comp.setInterval(__interval.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("interval", this._interval);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					   		 			 
						if (this._limitToList != null) {
				if (this._limitToList.isLiteralText()) {
					try {
												
						Boolean __limitToList = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._limitToList.getExpressionString(), 
											Boolean.class);
					
												comp.setLimitToList(__limitToList.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("limitToList", this._limitToList);
				}
			}
					   		 			 
						if (this._maxValue != null) {
				if (this._maxValue.isLiteralText()) {
					try {
												
						java.lang.Object __maxValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._maxValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setMaxValue(__maxValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("maxValue", this._maxValue);
				}
			}
					   		 			 
						if (this._minValue != null) {
				if (this._minValue.isLiteralText()) {
					try {
												
						java.lang.Object __minValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._minValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setMinValue(__minValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("minValue", this._minValue);
				}
			}
					   		 			 
						if (this._mode != null) {
				if (this._mode.isLiteralText()) {
					try {
												
						java.lang.String __mode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._mode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMode(__mode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("mode", this._mode);
				}
			}
					   		 			 
						if (this._onbeforedomupdate != null) {
				if (this._onbeforedomupdate.isLiteralText()) {
					try {
												
						java.lang.String __onbeforedomupdate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbeforedomupdate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbeforedomupdate(__onbeforedomupdate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbeforedomupdate", this._onbeforedomupdate);
				}
			}
					    		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					            		 			 
						if (this._onsubmit != null) {
				if (this._onsubmit.isLiteralText()) {
					try {
												
						java.lang.String __onsubmit = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsubmit.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsubmit(__onsubmit);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsubmit", this._onsubmit);
				}
			}
					   		 			 
						if (this._parameters != null) {
				if (this._parameters.isLiteralText()) {
					try {
												
						java.lang.Object __parameters = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._parameters.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setParameters(__parameters);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("parameters", this._parameters);
				}
			}
					   		 			 
						if (this._process != null) {
				if (this._process.isLiteralText()) {
					try {
												
						java.lang.Object __process = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._process.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setProcess(__process);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("process", this._process);
				}
			}
					   		 			 
						if (this._progressVar != null) {
				if (this._progressVar.isLiteralText()) {
					try {
												
						java.lang.String __progressVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._progressVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setProgressVar(__progressVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("progressVar", this._progressVar);
				}
			}
					   		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					   		 			 
						if (this._reRenderAfterComplete != null) {
				if (this._reRenderAfterComplete.isLiteralText()) {
					try {
												
						java.lang.String __reRenderAfterComplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRenderAfterComplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setReRenderAfterComplete(__reRenderAfterComplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRenderAfterComplete", this._reRenderAfterComplete);
				}
			}
					   		 			 
						if (this._remainClass != null) {
				if (this._remainClass.isLiteralText()) {
					try {
												
						java.lang.String __remainClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._remainClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemainClass(__remainClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("remainClass", this._remainClass);
				}
			}
					     		 			 
						if (this._similarityGroupingId != null) {
				if (this._similarityGroupingId.isLiteralText()) {
					try {
												
						java.lang.String __similarityGroupingId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._similarityGroupingId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSimilarityGroupingId(__similarityGroupingId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("similarityGroupingId", this._similarityGroupingId);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					      		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ProgressBar";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.renderkit.ProgressBarRenderer";
			}

}
