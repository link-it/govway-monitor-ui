/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlVirtualEarth;

public class VirtualEarthTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * dashboardSize
		 * Initial map type. The possible values are "Normal", "Small", "Tiny". Default value is "Normal".
		 */
		private ValueExpression _dashboardSize;
		/**
		 * Initial map type. The possible values are "Normal", "Small", "Tiny". Default value is "Normal".
		 * Setter for dashboardSize
		 * @param dashboardSize - new value
		 */
		 public void setDashboardSize( ValueExpression  __dashboardSize ){
			this._dashboardSize = __dashboardSize;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * lat
		 * Initial latitude coordinate in degrees, as a number between -90 and +90. Default value is "37.9721046".
		 */
		private ValueExpression _lat;
		/**
		 * Initial latitude coordinate in degrees, as a number between -90 and +90. Default value is "37.9721046".
		 * Setter for lat
		 * @param lat - new value
		 */
		 public void setLat( ValueExpression  __lat ){
			this._lat = __lat;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * lng
		 * Initial longitude coordinate in degrees, as a number between -180 and +180. Default value is "-122.04248428346".
		 */
		private ValueExpression _lng;
		/**
		 * Initial longitude coordinate in degrees, as a number between -180 and +180. Default value is "-122.04248428346".
		 * Setter for lng
		 * @param lng - new value
		 */
		 public void setLng( ValueExpression  __lng ){
			this._lng = __lng;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * mapStyle
		 * Navigation control size. Possible values are  "Road", "Aerial", "Hybrid", "Birdseye". Default value is "Road"
		 */
		private ValueExpression _mapStyle;
		/**
		 * Navigation control size. Possible values are  "Road", "Aerial", "Hybrid", "Birdseye". Default value is "Road"
		 * Setter for mapStyle
		 * @param mapStyle - new value
		 */
		 public void setMapStyle( ValueExpression  __mapStyle ){
			this._mapStyle = __mapStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onLoadMap
		 * The client-side script method to be called when the Virtual Earth object is initiated
		 */
		private ValueExpression _onLoadMap;
		/**
		 * The client-side script method to be called when the Virtual Earth object is initiated
		 * Setter for onLoadMap
		 * @param onLoadMap - new value
		 */
		 public void setOnLoadMap( ValueExpression  __onLoadMap ){
			this._onLoadMap = __onLoadMap;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * var
		 * The JavaScript variable that is used to access the Virtual Earth API. If you have
			 more than one Virtual Earth components on the same page, use individual
			 key for each of them. Default value name is "map".
		 */
		private ValueExpression _var;
		/**
		 * The JavaScript variable that is used to access the Virtual Earth API. If you have
			 more than one Virtual Earth components on the same page, use individual
			 key for each of them. Default value name is "map".
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( ValueExpression  __var ){
			this._var = __var;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * version
		 * Virtual earth version, Default value is "6.1".
		 */
		private ValueExpression _version;
		/**
		 * Virtual earth version, Default value is "6.1".
		 * Setter for version
		 * @param version - new value
		 */
		 public void setVersion( ValueExpression  __version ){
			this._version = __version;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * zoom
		 * Initial zoom level as a number between 1 and 18. Default value is "17".
		 */
		private ValueExpression _zoom;
		/**
		 * Initial zoom level as a number between 1 and 18. Default value is "17".
		 * Setter for zoom
		 * @param zoom - new value
		 */
		 public void setZoom( ValueExpression  __zoom ){
			this._zoom = __zoom;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._dashboardSize = null;
	 		 		 		 		    this._lat = null;
	 		 		    this._lng = null;
	 		 		    this._mapStyle = null;
	 		 		    this._onLoadMap = null;
	 		 		 		 		 		 		 		 		 		 		 		 		 		 		 		    this._var = null;
	 		 		    this._version = null;
	 		 		    this._zoom = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlVirtualEarth comp = (HtmlVirtualEarth) component;
  		 			 
						if (this._dashboardSize != null) {
				if (this._dashboardSize.isLiteralText()) {
					try {
												
						java.lang.String __dashboardSize = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dashboardSize.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDashboardSize(__dashboardSize);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dashboardSize", this._dashboardSize);
				}
			}
					     		 			 
						if (this._lat != null) {
				if (this._lat.isLiteralText()) {
					try {
												
						java.lang.String __lat = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lat.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLat(__lat);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lat", this._lat);
				}
			}
					   		 			 
						if (this._lng != null) {
				if (this._lng.isLiteralText()) {
					try {
												
						java.lang.String __lng = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lng.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLng(__lng);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lng", this._lng);
				}
			}
					   		 			 
						if (this._mapStyle != null) {
				if (this._mapStyle.isLiteralText()) {
					try {
												
						java.lang.String __mapStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._mapStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMapStyle(__mapStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("mapStyle", this._mapStyle);
				}
			}
					   		 			 
						if (this._onLoadMap != null) {
				if (this._onLoadMap.isLiteralText()) {
					try {
												
						java.lang.String __onLoadMap = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onLoadMap.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnLoadMap(__onLoadMap);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onLoadMap", this._onLoadMap);
				}
			}
					                		 			 
						if (this._var != null) {
				if (this._var.isLiteralText()) {
					try {
												
						java.lang.String __var = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._var.getExpressionString(), 
											java.lang.String.class);
					
												comp.setVar(__var);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("var", this._var);
				}
			}
					   		 			 
						if (this._version != null) {
				if (this._version.isLiteralText()) {
					try {
												
						java.lang.String __version = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._version.getExpressionString(), 
											java.lang.String.class);
					
												comp.setVersion(__version);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("version", this._version);
				}
			}
					   		 			 
						if (this._zoom != null) {
				if (this._zoom.isLiteralText()) {
					try {
												
						java.lang.String __zoom = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._zoom.getExpressionString(), 
											java.lang.String.class);
					
												comp.setZoom(__zoom);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("zoom", this._zoom);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.VirtualEarth";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.VirtualEarthRenderer";
			}

}
