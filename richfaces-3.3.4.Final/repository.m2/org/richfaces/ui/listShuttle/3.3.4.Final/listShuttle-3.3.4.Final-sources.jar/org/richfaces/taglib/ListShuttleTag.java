/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.util.Set ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlListShuttle;

public class ListShuttleTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * activeItem
		 * Stores active item
		 */
		private ValueExpression _activeItem;
		/**
		 * Stores active item
		 * Setter for activeItem
		 * @param activeItem - new value
		 */
		 public void setActiveItem( ValueExpression  __activeItem ){
			this._activeItem = __activeItem;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxKeys
		 * Defines row keys that are updated after an Ajax request
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * Defines row keys that are updated after an Ajax request
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * bottomControlClass
		 * Assigns one or more space-separated CSS class names to the 'Bottom' button
		 */
		private ValueExpression _bottomControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Bottom' button
		 * Setter for bottomControlClass
		 * @param bottomControlClass - new value
		 */
		 public void setBottomControlClass( ValueExpression  __bottomControlClass ){
			this._bottomControlClass = __bottomControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * bottomControlLabel
		 * Defines a label for a bottom control
		 */
		private ValueExpression _bottomControlLabel;
		/**
		 * Defines a label for a bottom control
		 * Setter for bottomControlLabel
		 * @param bottomControlLabel - new value
		 */
		 public void setBottomControlLabel( ValueExpression  __bottomControlLabel ){
			this._bottomControlLabel = __bottomControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * bottomTitle
		 * HTML: alt for the last button
		 */
		private ValueExpression _bottomTitle;
		/**
		 * HTML: alt for the last button
		 * Setter for bottomTitle
		 * @param bottomTitle - new value
		 */
		 public void setBottomTitle( ValueExpression  __bottomTitle ){
			this._bottomTitle = __bottomTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns. If the CSS class names are comma-separated, 
	        	each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
	        	the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. 
	        	If there are more class names than columns, the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns. If the CSS class names are comma-separated, 
	        	each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
	        	the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. 
	        	If there are more class names than columns, the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding  for a component state for saving or redefinition
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding  for a component state for saving or redefinition
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsType
		 * Defines type of a control: button or none. Default value is "button".
		 */
		private ValueExpression _controlsType;
		/**
		 * Defines type of a control: button or none. Default value is "button".
		 * Setter for controlsType
		 * @param controlsType - new value
		 */
		 public void setControlsType( ValueExpression  __controlsType ){
			this._controlsType = __controlsType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsVerticalAlign
		 * Customizes vertically a position of move/copy and order controls relatively to lists. Default value is "middle"
		 */
		private ValueExpression _controlsVerticalAlign;
		/**
		 * Customizes vertically a position of move/copy and order controls relatively to lists. Default value is "middle"
		 * Setter for controlsVerticalAlign
		 * @param controlsVerticalAlign - new value
		 */
		 public void setControlsVerticalAlign( ValueExpression  __controlsVerticalAlign ){
			this._controlsVerticalAlign = __controlsVerticalAlign;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyAllControlClass
		 * Assigns one or more space-separated CSS class names to the 'Copy all' button
		 */
		private ValueExpression _copyAllControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Copy all' button
		 * Setter for copyAllControlClass
		 * @param copyAllControlClass - new value
		 */
		 public void setCopyAllControlClass( ValueExpression  __copyAllControlClass ){
			this._copyAllControlClass = __copyAllControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyAllControlLabel
		 * Defines a label for a "Copy all" control
		 */
		private ValueExpression _copyAllControlLabel;
		/**
		 * Defines a label for a "Copy all" control
		 * Setter for copyAllControlLabel
		 * @param copyAllControlLabel - new value
		 */
		 public void setCopyAllControlLabel( ValueExpression  __copyAllControlLabel ){
			this._copyAllControlLabel = __copyAllControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyAllTitle
		 * HTML: alt for "Copy all" button
		 */
		private ValueExpression _copyAllTitle;
		/**
		 * HTML: alt for "Copy all" button
		 * Setter for copyAllTitle
		 * @param copyAllTitle - new value
		 */
		 public void setCopyAllTitle( ValueExpression  __copyAllTitle ){
			this._copyAllTitle = __copyAllTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyControlClass
		 * Assigns one or more space-separated CSS class names to the 'Copy' button
		 */
		private ValueExpression _copyControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Copy' button
		 * Setter for copyControlClass
		 * @param copyControlClass - new value
		 */
		 public void setCopyControlClass( ValueExpression  __copyControlClass ){
			this._copyControlClass = __copyControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyControlLabel
		 * Defines a label for a "Copy" control
		 */
		private ValueExpression _copyControlLabel;
		/**
		 * Defines a label for a "Copy" control
		 * Setter for copyControlLabel
		 * @param copyControlLabel - new value
		 */
		 public void setCopyControlLabel( ValueExpression  __copyControlLabel ){
			this._copyControlLabel = __copyControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyTitle
		 * HTML: alt for a "Copy" button
		 */
		private ValueExpression _copyTitle;
		/**
		 * HTML: alt for a "Copy" button
		 * Setter for copyTitle
		 * @param copyTitle - new value
		 */
		 public void setCopyTitle( ValueExpression  __copyTitle ){
			this._copyTitle = __copyTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledControlClass
		 * Assigns one or more space-separated CSS class names to the component disabled controls
		 */
		private ValueExpression _disabledControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component disabled controls
		 * Setter for disabledControlClass
		 * @param disabledControlClass - new value
		 */
		 public void setDisabledControlClass( ValueExpression  __disabledControlClass ){
			this._disabledControlClass = __disabledControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * downControlClass
		 * Assigns one or more space-separated CSS class names to the 'Down' button
		 */
		private ValueExpression _downControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Down' button
		 * Setter for downControlClass
		 * @param downControlClass - new value
		 */
		 public void setDownControlClass( ValueExpression  __downControlClass ){
			this._downControlClass = __downControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * downControlLabel
		 * Defines a label for a down control
		 */
		private ValueExpression _downControlLabel;
		/**
		 * Defines a label for a down control
		 * Setter for downControlLabel
		 * @param downControlLabel - new value
		 */
		 public void setDownControlLabel( ValueExpression  __downControlLabel ){
			this._downControlLabel = __downControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * downTitle
		 * HTML: alt for bottom button
		 */
		private ValueExpression _downTitle;
		/**
		 * HTML: alt for bottom button
		 * Setter for downTitle
		 * @param downTitle - new value
		 */
		 public void setDownTitle( ValueExpression  __downTitle ){
			this._downTitle = __downTitle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fastMoveControlsVisible
		 * If "false", 'Copy All' and 'Remove All' controls aren't displayed. Default value is "true".
		 */
		private ValueExpression _fastMoveControlsVisible;
		/**
		 * If "false", 'Copy All' and 'Remove All' controls aren't displayed. Default value is "true".
		 * Setter for fastMoveControlsVisible
		 * @param fastMoveControlsVisible - new value
		 */
		 public void setFastMoveControlsVisible( ValueExpression  __fastMoveControlsVisible ){
			this._fastMoveControlsVisible = __fastMoveControlsVisible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * fastOrderControlsVisible
		 * If "false", 'Top' and 'Bottom' controls aren't displayed. Default value is "true".
		 */
		private ValueExpression _fastOrderControlsVisible;
		/**
		 * If "false", 'Top' and 'Bottom' controls aren't displayed. Default value is "true".
		 * Setter for fastOrderControlsVisible
		 * @param fastOrderControlsVisible - new value
		 */
		 public void setFastOrderControlsVisible( ValueExpression  __fastOrderControlsVisible ){
			this._fastOrderControlsVisible = __fastOrderControlsVisible;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listClass
		 * Assigns one or more space-separated CSS class names to the component lists
		 */
		private ValueExpression _listClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component lists
		 * Setter for listClass
		 * @param listClass - new value
		 */
		 public void setListClass( ValueExpression  __listClass ){
			this._listClass = __listClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listsHeight
		 * Defines height of the list. Default value is "140".
		 */
		private ValueExpression _listsHeight;
		/**
		 * Defines height of the list. Default value is "140".
		 * Setter for listsHeight
		 * @param listsHeight - new value
		 */
		 public void setListsHeight( ValueExpression  __listsHeight ){
			this._listsHeight = __listsHeight;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * moveControlsVisible
		 * If "false", 'Copy' and 'Remove' controls aren't displayed. Default value is "true".
		 */
		private ValueExpression _moveControlsVisible;
		/**
		 * If "false", 'Copy' and 'Remove' controls aren't displayed. Default value is "true".
		 * Setter for moveControlsVisible
		 * @param moveControlsVisible - new value
		 */
		 public void setMoveControlsVisible( ValueExpression  __moveControlsVisible ){
			this._moveControlsVisible = __moveControlsVisible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onblur
		 * The client-side script method to be called when the component loses the focus
		 */
		private ValueExpression _onblur;
		/**
		 * The client-side script method to be called when the component loses the focus
		 * Setter for onblur
		 * @param onblur - new value
		 */
		 public void setOnblur( ValueExpression  __onblur ){
			this._onblur = __onblur;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onbottomclick
		 * The client-side script method to be called when the 'Bottom' button  is clicked
		 */
		private ValueExpression _onbottomclick;
		/**
		 * The client-side script method to be called when the 'Bottom' button  is clicked
		 * Setter for onbottomclick
		 * @param onbottomclick - new value
		 */
		 public void setOnbottomclick( ValueExpression  __onbottomclick ){
			this._onbottomclick = __onbottomclick;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * oncopyallclick
		 * The client-side script method to be called when the 'Copy All' button is clicked
		 */
		private ValueExpression _oncopyallclick;
		/**
		 * The client-side script method to be called when the 'Copy All' button is clicked
		 * Setter for oncopyallclick
		 * @param oncopyallclick - new value
		 */
		 public void setOncopyallclick( ValueExpression  __oncopyallclick ){
			this._oncopyallclick = __oncopyallclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncopyclick
		 * The client-side script method to be called when the 'Copy' button is clicked
		 */
		private ValueExpression _oncopyclick;
		/**
		 * The client-side script method to be called when the 'Copy' button is clicked
		 * Setter for oncopyclick
		 * @param oncopyclick - new value
		 */
		 public void setOncopyclick( ValueExpression  __oncopyclick ){
			this._oncopyclick = __oncopyclick;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ondownclick
		 * The client-side script method to be called when the 'Down' button is clicked
		 */
		private ValueExpression _ondownclick;
		/**
		 * The client-side script method to be called when the 'Down' button is clicked
		 * Setter for ondownclick
		 * @param ondownclick - new value
		 */
		 public void setOndownclick( ValueExpression  __ondownclick ){
			this._ondownclick = __ondownclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onfocus
		 * The client-side script method to be called when the component gets the focus
		 */
		private ValueExpression _onfocus;
		/**
		 * The client-side script method to be called when the component gets the focus
		 * Setter for onfocus
		 * @param onfocus - new value
		 */
		 public void setOnfocus( ValueExpression  __onfocus ){
			this._onfocus = __onfocus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onlistchange
		 * The client-side script method to be called before the list is changed
		 */
		private ValueExpression _onlistchange;
		/**
		 * The client-side script method to be called before the list is changed
		 * Setter for onlistchange
		 * @param onlistchange - new value
		 */
		 public void setOnlistchange( ValueExpression  __onlistchange ){
			this._onlistchange = __onlistchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onlistchanged
		 * The client-side script method to be called when the list is changed
		 */
		private ValueExpression _onlistchanged;
		/**
		 * The client-side script method to be called when the list is changed
		 * Setter for onlistchanged
		 * @param onlistchanged - new value
		 */
		 public void setOnlistchanged( ValueExpression  __onlistchanged ){
			this._onlistchanged = __onlistchanged;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * onorderchange
		 * The client-side script method to be called before the list order is changed
		 */
		private ValueExpression _onorderchange;
		/**
		 * The client-side script method to be called before the list order is changed
		 * Setter for onorderchange
		 * @param onorderchange - new value
		 */
		 public void setOnorderchange( ValueExpression  __onorderchange ){
			this._onorderchange = __onorderchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onorderchanged
		 * The client-side script method to be called when the list order is changed
		 */
		private ValueExpression _onorderchanged;
		/**
		 * The client-side script method to be called when the list order is changed
		 * Setter for onorderchanged
		 * @param onorderchanged - new value
		 */
		 public void setOnorderchanged( ValueExpression  __onorderchanged ){
			this._onorderchanged = __onorderchanged;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onremoveallclick
		 * The client-side script method to be called when the 'Remove All' button is clicked
		 */
		private ValueExpression _onremoveallclick;
		/**
		 * The client-side script method to be called when the 'Remove All' button is clicked
		 * Setter for onremoveallclick
		 * @param onremoveallclick - new value
		 */
		 public void setOnremoveallclick( ValueExpression  __onremoveallclick ){
			this._onremoveallclick = __onremoveallclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onremoveclick
		 * The client-side script method to be called when the 'Remove' button is clicked
		 */
		private ValueExpression _onremoveclick;
		/**
		 * The client-side script method to be called when the 'Remove' button is clicked
		 * Setter for onremoveclick
		 * @param onremoveclick - new value
		 */
		 public void setOnremoveclick( ValueExpression  __onremoveclick ){
			this._onremoveclick = __onremoveclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ontopclick
		 * The client-side script method to be called when the 'Top' button is clicked
		 */
		private ValueExpression _ontopclick;
		/**
		 * The client-side script method to be called when the 'Top' button is clicked
		 * Setter for ontopclick
		 * @param ontopclick - new value
		 */
		 public void setOntopclick( ValueExpression  __ontopclick ){
			this._ontopclick = __ontopclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onupclick
		 * The client-side script method to be called when the 'Up' button is clicked
		 */
		private ValueExpression _onupclick;
		/**
		 * The client-side script method to be called when the 'Up' button is clicked
		 * Setter for onupclick
		 * @param onupclick - new value
		 */
		 public void setOnupclick( ValueExpression  __onupclick ){
			this._onupclick = __onupclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * orderControlsVisible
		 * If "false", 'Up' and 'Down' controls aren't displayed. Default value is "true".
		 */
		private ValueExpression _orderControlsVisible;
		/**
		 * If "false", 'Up' and 'Down' controls aren't displayed. Default value is "true".
		 * Setter for orderControlsVisible
		 * @param orderControlsVisible - new value
		 */
		 public void setOrderControlsVisible( ValueExpression  __orderControlsVisible ){
			this._orderControlsVisible = __orderControlsVisible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeAllControlClass
		 * Assigns one or more space-separated CSS class names to the 'Remove all' button
		 */
		private ValueExpression _removeAllControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Remove all' button
		 * Setter for removeAllControlClass
		 * @param removeAllControlClass - new value
		 */
		 public void setRemoveAllControlClass( ValueExpression  __removeAllControlClass ){
			this._removeAllControlClass = __removeAllControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeAllControlLabel
		 * Defines a label for a "Remove all" control
		 */
		private ValueExpression _removeAllControlLabel;
		/**
		 * Defines a label for a "Remove all" control
		 * Setter for removeAllControlLabel
		 * @param removeAllControlLabel - new value
		 */
		 public void setRemoveAllControlLabel( ValueExpression  __removeAllControlLabel ){
			this._removeAllControlLabel = __removeAllControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeAllTitle
		 * HTML: alt for "Remove all" button
		 */
		private ValueExpression _removeAllTitle;
		/**
		 * HTML: alt for "Remove all" button
		 * Setter for removeAllTitle
		 * @param removeAllTitle - new value
		 */
		 public void setRemoveAllTitle( ValueExpression  __removeAllTitle ){
			this._removeAllTitle = __removeAllTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeControlClass
		 * Assigns one or more space-separated CSS class names to the 'Remove' button
		 */
		private ValueExpression _removeControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Remove' button
		 * Setter for removeControlClass
		 * @param removeControlClass - new value
		 */
		 public void setRemoveControlClass( ValueExpression  __removeControlClass ){
			this._removeControlClass = __removeControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeControlLabel
		 * Defines a label for a "Remove" control
		 */
		private ValueExpression _removeControlLabel;
		/**
		 * Defines a label for a "Remove" control
		 * Setter for removeControlLabel
		 * @param removeControlLabel - new value
		 */
		 public void setRemoveControlLabel( ValueExpression  __removeControlLabel ){
			this._removeControlLabel = __removeControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeTitle
		 * HTML: alt for a "Remove" button
		 */
		private ValueExpression _removeTitle;
		/**
		 * HTML: alt for a "Remove" button
		 * Setter for removeTitle
		 * @param removeTitle - new value
		 */
		 public void setRemoveTitle( ValueExpression  __removeTitle ){
			this._removeTitle = __removeTitle;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows. If the CSS class names are comma-separated, 
	        	each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
	        	the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. 
	        	If there are more class names than rows, the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows. If the CSS class names are comma-separated, 
	        	each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
	        	the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. 
	        	If there are more class names than rows, the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * The attribute provides access to a row key in a Request scope
		 */
		private String _rowKeyVar;
		/**
		 * The attribute provides access to a row key in a Request scope
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( String  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * showButtonLabels
		 * Shows a label for a button. Default value is "true".
		 */
		private ValueExpression _showButtonLabels;
		/**
		 * Shows a label for a button. Default value is "true".
		 * Setter for showButtonLabels
		 * @param showButtonLabels - new value
		 */
		 public void setShowButtonLabels( ValueExpression  __showButtonLabels ){
			this._showButtonLabels = __showButtonLabels;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sourceCaptionLabel
		 * Defines source list caption representation text
		 */
		private ValueExpression _sourceCaptionLabel;
		/**
		 * Defines source list caption representation text
		 * Setter for sourceCaptionLabel
		 * @param sourceCaptionLabel - new value
		 */
		 public void setSourceCaptionLabel( ValueExpression  __sourceCaptionLabel ){
			this._sourceCaptionLabel = __sourceCaptionLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sourceListWidth
		 * Defines width of a source list. Default value is "140".
		 */
		private ValueExpression _sourceListWidth;
		/**
		 * Defines width of a source list. Default value is "140".
		 * Setter for sourceListWidth
		 * @param sourceListWidth - new value
		 */
		 public void setSourceListWidth( ValueExpression  __sourceListWidth ){
			this._sourceListWidth = __sourceListWidth;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sourceRequired
		 * Defines the case when source value is being validated.
				If the value is "true", there should be at least one item in the source list
		 */
		private ValueExpression _sourceRequired;
		/**
		 * Defines the case when source value is being validated.
				If the value is "true", there should be at least one item in the source list
		 * Setter for sourceRequired
		 * @param sourceRequired - new value
		 */
		 public void setSourceRequired( ValueExpression  __sourceRequired ){
			this._sourceRequired = __sourceRequired;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sourceSelection
		 * Manages selection in a source list from the server side
		 */
		private ValueExpression _sourceSelection;
		/**
		 * Manages selection in a source list from the server side
		 * Setter for sourceSelection
		 * @param sourceSelection - new value
		 */
		 public void setSourceSelection( ValueExpression  __sourceSelection ){
			this._sourceSelection = __sourceSelection;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sourceValue
		 * Defines a List or Array of items to be shown in a source list
		 */
		private ValueExpression _sourceValue;
		/**
		 * Defines a List or Array of items to be shown in a source list
		 * Setter for sourceValue
		 * @param sourceValue - new value
		 */
		 public void setSourceValue( ValueExpression  __sourceValue ){
			this._sourceValue = __sourceValue;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * switchByClick
		 * If "true", dragging between lists realized by click
		 */
		private ValueExpression _switchByClick;
		/**
		 * If "true", dragging between lists realized by click
		 * Setter for switchByClick
		 * @param switchByClick - new value
		 */
		 public void setSwitchByClick( ValueExpression  __switchByClick ){
			this._switchByClick = __switchByClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * switchByDblClick
		 * If "true", items can be moved between the lists by double-clicking on them. Default value is "true".
		 */
		private ValueExpression _switchByDblClick;
		/**
		 * If "true", items can be moved between the lists by double-clicking on them. Default value is "true".
		 * Setter for switchByDblClick
		 * @param switchByDblClick - new value
		 */
		 public void setSwitchByDblClick( ValueExpression  __switchByDblClick ){
			this._switchByDblClick = __switchByDblClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * targetCaptionLabel
		 * Defines target list caption representation text
		 */
		private ValueExpression _targetCaptionLabel;
		/**
		 * Defines target list caption representation text
		 * Setter for targetCaptionLabel
		 * @param targetCaptionLabel - new value
		 */
		 public void setTargetCaptionLabel( ValueExpression  __targetCaptionLabel ){
			this._targetCaptionLabel = __targetCaptionLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * targetListWidth
		 * Defines width of a target list. Default value is "140".
		 */
		private ValueExpression _targetListWidth;
		/**
		 * Defines width of a target list. Default value is "140".
		 * Setter for targetListWidth
		 * @param targetListWidth - new value
		 */
		 public void setTargetListWidth( ValueExpression  __targetListWidth ){
			this._targetListWidth = __targetListWidth;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * targetRequired
		 * Defines the case when target value is being validated.
				If the value is "true", there should be at least one item in the target list
		 */
		private ValueExpression _targetRequired;
		/**
		 * Defines the case when target value is being validated.
				If the value is "true", there should be at least one item in the target list
		 * Setter for targetRequired
		 * @param targetRequired - new value
		 */
		 public void setTargetRequired( ValueExpression  __targetRequired ){
			this._targetRequired = __targetRequired;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * targetSelection
		 * Manages selection in a target list from the server side
		 */
		private ValueExpression _targetSelection;
		/**
		 * Manages selection in a target list from the server side
		 * Setter for targetSelection
		 * @param targetSelection - new value
		 */
		 public void setTargetSelection( ValueExpression  __targetSelection ){
			this._targetSelection = __targetSelection;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * targetValue
		 * Defines a List or Array of items to be shown in a target list
		 */
		private ValueExpression _targetValue;
		/**
		 * Defines a List or Array of items to be shown in a target list
		 * Setter for targetValue
		 * @param targetValue - new value
		 */
		 public void setTargetValue( ValueExpression  __targetValue ){
			this._targetValue = __targetValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topControlClass
		 * Assigns one or more space-separated CSS class names to the 'Top' button
		 */
		private ValueExpression _topControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Top' button
		 * Setter for topControlClass
		 * @param topControlClass - new value
		 */
		 public void setTopControlClass( ValueExpression  __topControlClass ){
			this._topControlClass = __topControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topControlLabel
		 * Defines a label for a "Top" control
		 */
		private ValueExpression _topControlLabel;
		/**
		 * Defines a label for a "Top" control
		 * Setter for topControlLabel
		 * @param topControlLabel - new value
		 */
		 public void setTopControlLabel( ValueExpression  __topControlLabel ){
			this._topControlLabel = __topControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topTitle
		 * HTML: alt for the first button
		 */
		private ValueExpression _topTitle;
		/**
		 * HTML: alt for the first button
		 * Setter for topTitle
		 * @param topTitle - new value
		 */
		 public void setTopTitle( ValueExpression  __topTitle ){
			this._topTitle = __topTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * upControlClass
		 * Assigns one or more space-separated CSS class names to the 'Up' button
		 */
		private ValueExpression _upControlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the 'Up' button
		 * Setter for upControlClass
		 * @param upControlClass - new value
		 */
		 public void setUpControlClass( ValueExpression  __upControlClass ){
			this._upControlClass = __upControlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * upControlLabel
		 * Defines a label for an "Up" control
		 */
		private ValueExpression _upControlLabel;
		/**
		 * Defines a label for an "Up" control
		 * Setter for upControlLabel
		 * @param upControlLabel - new value
		 */
		 public void setUpControlLabel( ValueExpression  __upControlLabel ){
			this._upControlLabel = __upControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * upTitle
		 * HTML: alt for top button
		 */
		private ValueExpression _upTitle;
		/**
		 * HTML: alt for top button
		 * Setter for upTitle
		 * @param upTitle - new value
		 */
		 public void setUpTitle( ValueExpression  __upTitle ){
			this._upTitle = __upTitle;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * var
		 * Defines a list on the page
		 */
		private String _var;
		/**
		 * Defines a list on the page
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._activeItem = null;
	 		 		    this._ajaxKeys = null;
	 		 		 		 		    this._bottomControlClass = null;
	 		 		    this._bottomControlLabel = null;
	 		 		    this._bottomTitle = null;
	 		 		    this._columnClasses = null;
	 		 		    this._componentState = null;
	 		 		    this._controlsType = null;
	 		 		    this._controlsVerticalAlign = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._copyAllControlClass = null;
	 		 		    this._copyAllControlLabel = null;
	 		 		    this._copyAllTitle = null;
	 		 		    this._copyControlClass = null;
	 		 		    this._copyControlLabel = null;
	 		 		    this._copyTitle = null;
	 		 		    this._disabledControlClass = null;
	 		 		    this._downControlClass = null;
	 		 		    this._downControlLabel = null;
	 		 		    this._downTitle = null;
	 		 		 		    this._fastMoveControlsVisible = null;
	 		 		    this._fastOrderControlsVisible = null;
	 		 		 		 		 		 		    this._immediate = null;
	 		 		 		    this._label = null;
	 		 		    this._listClass = null;
	 		 		    this._listsHeight = null;
	 		 		 		 		    this._moveControlsVisible = null;
	 		 		    this._onblur = null;
	 		 		    this._onbottomclick = null;
	 		 		 		 		    this._oncopyallclick = null;
	 		 		    this._oncopyclick = null;
	 		 		 		    this._ondownclick = null;
	 		 		    this._onfocus = null;
	 		 		    this._onlistchange = null;
	 		 		    this._onlistchanged = null;
	 		 		 		 		 		    this._onorderchange = null;
	 		 		    this._onorderchanged = null;
	 		 		    this._onremoveallclick = null;
	 		 		    this._onremoveclick = null;
	 		 		    this._ontopclick = null;
	 		 		    this._onupclick = null;
	 		 		    this._orderControlsVisible = null;
	 		 		    this._removeAllControlClass = null;
	 		 		    this._removeAllControlLabel = null;
	 		 		    this._removeAllTitle = null;
	 		 		    this._removeControlClass = null;
	 		 		    this._removeControlLabel = null;
	 		 		    this._removeTitle = null;
	 		 		 		 		    this._requiredMessage = null;
	 		 		 		    this._rowClasses = null;
	 		 		 		 		 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		 		    this._showButtonLabels = null;
	 		 		    this._sourceCaptionLabel = null;
	 		 		    this._sourceListWidth = null;
	 		 		    this._sourceRequired = null;
	 		 		    this._sourceSelection = null;
	 		 		    this._sourceValue = null;
	 		 		 		 		 		 		    this._switchByClick = null;
	 		 		    this._switchByDblClick = null;
	 		 		    this._targetCaptionLabel = null;
	 		 		    this._targetListWidth = null;
	 		 		    this._targetRequired = null;
	 		 		    this._targetSelection = null;
	 		 		    this._targetValue = null;
	 		 		    this._topControlClass = null;
	 		 		    this._topControlLabel = null;
	 		 		    this._topTitle = null;
	 		 		    this._upControlClass = null;
	 		 		    this._upControlLabel = null;
	 		 		    this._upTitle = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		 		    this._valueChangeListener = null;
	 		 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlListShuttle comp = (HtmlListShuttle) component;
 		 			 
						if (this._activeItem != null) {
				if (this._activeItem.isLiteralText()) {
					try {
												
						java.lang.Object __activeItem = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeItem.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setActiveItem(__activeItem);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeItem", this._activeItem);
				}
			}
					   		 			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					     		 			 
						if (this._bottomControlClass != null) {
				if (this._bottomControlClass.isLiteralText()) {
					try {
												
						java.lang.String __bottomControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bottomControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBottomControlClass(__bottomControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bottomControlClass", this._bottomControlClass);
				}
			}
					   		 			 
						if (this._bottomControlLabel != null) {
				if (this._bottomControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __bottomControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bottomControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBottomControlLabel(__bottomControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bottomControlLabel", this._bottomControlLabel);
				}
			}
					   		 			 
						if (this._bottomTitle != null) {
				if (this._bottomTitle.isLiteralText()) {
					try {
												
						java.lang.String __bottomTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bottomTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBottomTitle(__bottomTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bottomTitle", this._bottomTitle);
				}
			}
					   		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					   		 			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					   		 			 
						if (this._controlsType != null) {
				if (this._controlsType.isLiteralText()) {
					try {
												
						java.lang.String __controlsType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsType(__controlsType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsType", this._controlsType);
				}
			}
					   		 			 
						if (this._controlsVerticalAlign != null) {
				if (this._controlsVerticalAlign.isLiteralText()) {
					try {
												
						java.lang.String __controlsVerticalAlign = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsVerticalAlign.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsVerticalAlign(__controlsVerticalAlign);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsVerticalAlign", this._controlsVerticalAlign);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._copyAllControlClass != null) {
				if (this._copyAllControlClass.isLiteralText()) {
					try {
												
						java.lang.String __copyAllControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyAllControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyAllControlClass(__copyAllControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyAllControlClass", this._copyAllControlClass);
				}
			}
					   		 			 
						if (this._copyAllControlLabel != null) {
				if (this._copyAllControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __copyAllControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyAllControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyAllControlLabel(__copyAllControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyAllControlLabel", this._copyAllControlLabel);
				}
			}
					   		 			 
						if (this._copyAllTitle != null) {
				if (this._copyAllTitle.isLiteralText()) {
					try {
												
						java.lang.String __copyAllTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyAllTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyAllTitle(__copyAllTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyAllTitle", this._copyAllTitle);
				}
			}
					   		 			 
						if (this._copyControlClass != null) {
				if (this._copyControlClass.isLiteralText()) {
					try {
												
						java.lang.String __copyControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyControlClass(__copyControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyControlClass", this._copyControlClass);
				}
			}
					   		 			 
						if (this._copyControlLabel != null) {
				if (this._copyControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __copyControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyControlLabel(__copyControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyControlLabel", this._copyControlLabel);
				}
			}
					   		 			 
						if (this._copyTitle != null) {
				if (this._copyTitle.isLiteralText()) {
					try {
												
						java.lang.String __copyTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyTitle(__copyTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyTitle", this._copyTitle);
				}
			}
					   		 			 
						if (this._disabledControlClass != null) {
				if (this._disabledControlClass.isLiteralText()) {
					try {
												
						java.lang.String __disabledControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledControlClass(__disabledControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledControlClass", this._disabledControlClass);
				}
			}
					   		 			 
						if (this._downControlClass != null) {
				if (this._downControlClass.isLiteralText()) {
					try {
												
						java.lang.String __downControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._downControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDownControlClass(__downControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("downControlClass", this._downControlClass);
				}
			}
					   		 			 
						if (this._downControlLabel != null) {
				if (this._downControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __downControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._downControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDownControlLabel(__downControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("downControlLabel", this._downControlLabel);
				}
			}
					   		 			 
						if (this._downTitle != null) {
				if (this._downTitle.isLiteralText()) {
					try {
												
						java.lang.String __downTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._downTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDownTitle(__downTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("downTitle", this._downTitle);
				}
			}
					    		 			 
						if (this._fastMoveControlsVisible != null) {
				if (this._fastMoveControlsVisible.isLiteralText()) {
					try {
												
						Boolean __fastMoveControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fastMoveControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setFastMoveControlsVisible(__fastMoveControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fastMoveControlsVisible", this._fastMoveControlsVisible);
				}
			}
					   		 			 
						if (this._fastOrderControlsVisible != null) {
				if (this._fastOrderControlsVisible.isLiteralText()) {
					try {
												
						Boolean __fastOrderControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fastOrderControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setFastOrderControlsVisible(__fastOrderControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fastOrderControlsVisible", this._fastOrderControlsVisible);
				}
			}
					       		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					    		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					   		 			 
						if (this._listClass != null) {
				if (this._listClass.isLiteralText()) {
					try {
												
						java.lang.String __listClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListClass(__listClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listClass", this._listClass);
				}
			}
					   		 			 
						if (this._listsHeight != null) {
				if (this._listsHeight.isLiteralText()) {
					try {
												
						java.lang.String __listsHeight = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listsHeight.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListsHeight(__listsHeight);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listsHeight", this._listsHeight);
				}
			}
					     		 			 
						if (this._moveControlsVisible != null) {
				if (this._moveControlsVisible.isLiteralText()) {
					try {
												
						Boolean __moveControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._moveControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setMoveControlsVisible(__moveControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("moveControlsVisible", this._moveControlsVisible);
				}
			}
					   		 			 
						if (this._onblur != null) {
				if (this._onblur.isLiteralText()) {
					try {
												
						java.lang.String __onblur = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onblur.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnblur(__onblur);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onblur", this._onblur);
				}
			}
					   		 			 
						if (this._onbottomclick != null) {
				if (this._onbottomclick.isLiteralText()) {
					try {
												
						java.lang.String __onbottomclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbottomclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbottomclick(__onbottomclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbottomclick", this._onbottomclick);
				}
			}
					     		 			 
						if (this._oncopyallclick != null) {
				if (this._oncopyallclick.isLiteralText()) {
					try {
												
						java.lang.String __oncopyallclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncopyallclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncopyallclick(__oncopyallclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncopyallclick", this._oncopyallclick);
				}
			}
					   		 			 
						if (this._oncopyclick != null) {
				if (this._oncopyclick.isLiteralText()) {
					try {
												
						java.lang.String __oncopyclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncopyclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncopyclick(__oncopyclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncopyclick", this._oncopyclick);
				}
			}
					    		 			 
						if (this._ondownclick != null) {
				if (this._ondownclick.isLiteralText()) {
					try {
												
						java.lang.String __ondownclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondownclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndownclick(__ondownclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondownclick", this._ondownclick);
				}
			}
					   		 			 
						if (this._onfocus != null) {
				if (this._onfocus.isLiteralText()) {
					try {
												
						java.lang.String __onfocus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfocus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfocus(__onfocus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfocus", this._onfocus);
				}
			}
					   		 			 
						if (this._onlistchange != null) {
				if (this._onlistchange.isLiteralText()) {
					try {
												
						java.lang.String __onlistchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onlistchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnlistchange(__onlistchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onlistchange", this._onlistchange);
				}
			}
					   		 			 
						if (this._onlistchanged != null) {
				if (this._onlistchanged.isLiteralText()) {
					try {
												
						java.lang.String __onlistchanged = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onlistchanged.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnlistchanged(__onlistchanged);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onlistchanged", this._onlistchanged);
				}
			}
					      		 			 
						if (this._onorderchange != null) {
				if (this._onorderchange.isLiteralText()) {
					try {
												
						java.lang.String __onorderchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onorderchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnorderchange(__onorderchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onorderchange", this._onorderchange);
				}
			}
					   		 			 
						if (this._onorderchanged != null) {
				if (this._onorderchanged.isLiteralText()) {
					try {
												
						java.lang.String __onorderchanged = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onorderchanged.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnorderchanged(__onorderchanged);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onorderchanged", this._onorderchanged);
				}
			}
					   		 			 
						if (this._onremoveallclick != null) {
				if (this._onremoveallclick.isLiteralText()) {
					try {
												
						java.lang.String __onremoveallclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onremoveallclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnremoveallclick(__onremoveallclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onremoveallclick", this._onremoveallclick);
				}
			}
					   		 			 
						if (this._onremoveclick != null) {
				if (this._onremoveclick.isLiteralText()) {
					try {
												
						java.lang.String __onremoveclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onremoveclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnremoveclick(__onremoveclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onremoveclick", this._onremoveclick);
				}
			}
					   		 			 
						if (this._ontopclick != null) {
				if (this._ontopclick.isLiteralText()) {
					try {
												
						java.lang.String __ontopclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ontopclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOntopclick(__ontopclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ontopclick", this._ontopclick);
				}
			}
					   		 			 
						if (this._onupclick != null) {
				if (this._onupclick.isLiteralText()) {
					try {
												
						java.lang.String __onupclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onupclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnupclick(__onupclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onupclick", this._onupclick);
				}
			}
					   		 			 
						if (this._orderControlsVisible != null) {
				if (this._orderControlsVisible.isLiteralText()) {
					try {
												
						Boolean __orderControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._orderControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setOrderControlsVisible(__orderControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("orderControlsVisible", this._orderControlsVisible);
				}
			}
					   		 			 
						if (this._removeAllControlClass != null) {
				if (this._removeAllControlClass.isLiteralText()) {
					try {
												
						java.lang.String __removeAllControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeAllControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveAllControlClass(__removeAllControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeAllControlClass", this._removeAllControlClass);
				}
			}
					   		 			 
						if (this._removeAllControlLabel != null) {
				if (this._removeAllControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __removeAllControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeAllControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveAllControlLabel(__removeAllControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeAllControlLabel", this._removeAllControlLabel);
				}
			}
					   		 			 
						if (this._removeAllTitle != null) {
				if (this._removeAllTitle.isLiteralText()) {
					try {
												
						java.lang.String __removeAllTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeAllTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveAllTitle(__removeAllTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeAllTitle", this._removeAllTitle);
				}
			}
					   		 			 
						if (this._removeControlClass != null) {
				if (this._removeControlClass.isLiteralText()) {
					try {
												
						java.lang.String __removeControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveControlClass(__removeControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeControlClass", this._removeControlClass);
				}
			}
					   		 			 
						if (this._removeControlLabel != null) {
				if (this._removeControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __removeControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveControlLabel(__removeControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeControlLabel", this._removeControlLabel);
				}
			}
					   		 			 
						if (this._removeTitle != null) {
				if (this._removeTitle.isLiteralText()) {
					try {
												
						java.lang.String __removeTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveTitle(__removeTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeTitle", this._removeTitle);
				}
			}
					     		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					    		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					       		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
											if (this._rowKeyVar != null) {
					comp.setRowKeyVar(this._rowKeyVar);
				}
									    		 			 
						if (this._showButtonLabels != null) {
				if (this._showButtonLabels.isLiteralText()) {
					try {
												
						Boolean __showButtonLabels = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showButtonLabels.getExpressionString(), 
											Boolean.class);
					
												comp.setShowButtonLabels(__showButtonLabels.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showButtonLabels", this._showButtonLabels);
				}
			}
					   		 			 
						if (this._sourceCaptionLabel != null) {
				if (this._sourceCaptionLabel.isLiteralText()) {
					try {
												
						java.lang.String __sourceCaptionLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sourceCaptionLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSourceCaptionLabel(__sourceCaptionLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sourceCaptionLabel", this._sourceCaptionLabel);
				}
			}
					   		 			 
						if (this._sourceListWidth != null) {
				if (this._sourceListWidth.isLiteralText()) {
					try {
												
						java.lang.String __sourceListWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sourceListWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSourceListWidth(__sourceListWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sourceListWidth", this._sourceListWidth);
				}
			}
					   		 			 
						if (this._sourceRequired != null) {
				if (this._sourceRequired.isLiteralText()) {
					try {
												
						Boolean __sourceRequired = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sourceRequired.getExpressionString(), 
											Boolean.class);
					
												comp.setSourceRequired(__sourceRequired.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sourceRequired", this._sourceRequired);
				}
			}
					   		 			 				if(null != this._sourceSelection && this._sourceSelection.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.ListShuttle with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property sourceSelection");
				}
			 
						if (this._sourceSelection != null) {
				if (this._sourceSelection.isLiteralText()) {
					try {
												
						java.util.Set __sourceSelection = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sourceSelection.getExpressionString(), 
											java.util.Set.class);
					
												comp.setSourceSelection(__sourceSelection);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sourceSelection", this._sourceSelection);
				}
			}
					   		 			 
						if (this._sourceValue != null) {
				if (this._sourceValue.isLiteralText()) {
					try {
												
						java.lang.Object __sourceValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sourceValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setSourceValue(__sourceValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sourceValue", this._sourceValue);
				}
			}
					       		 			 
						if (this._switchByClick != null) {
				if (this._switchByClick.isLiteralText()) {
					try {
												
						Boolean __switchByClick = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._switchByClick.getExpressionString(), 
											Boolean.class);
					
												comp.setSwitchByClick(__switchByClick.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("switchByClick", this._switchByClick);
				}
			}
					   		 			 
						if (this._switchByDblClick != null) {
				if (this._switchByDblClick.isLiteralText()) {
					try {
												
						Boolean __switchByDblClick = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._switchByDblClick.getExpressionString(), 
											Boolean.class);
					
												comp.setSwitchByDblClick(__switchByDblClick.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("switchByDblClick", this._switchByDblClick);
				}
			}
					   		 			 
						if (this._targetCaptionLabel != null) {
				if (this._targetCaptionLabel.isLiteralText()) {
					try {
												
						java.lang.String __targetCaptionLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetCaptionLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTargetCaptionLabel(__targetCaptionLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetCaptionLabel", this._targetCaptionLabel);
				}
			}
					   		 			 
						if (this._targetListWidth != null) {
				if (this._targetListWidth.isLiteralText()) {
					try {
												
						java.lang.String __targetListWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetListWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTargetListWidth(__targetListWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetListWidth", this._targetListWidth);
				}
			}
					   		 			 
						if (this._targetRequired != null) {
				if (this._targetRequired.isLiteralText()) {
					try {
												
						Boolean __targetRequired = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetRequired.getExpressionString(), 
											Boolean.class);
					
												comp.setTargetRequired(__targetRequired.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetRequired", this._targetRequired);
				}
			}
					   		 			 				if(null != this._targetSelection && this._targetSelection.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.ListShuttle with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property targetSelection");
				}
			 
						if (this._targetSelection != null) {
				if (this._targetSelection.isLiteralText()) {
					try {
												
						java.util.Set __targetSelection = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetSelection.getExpressionString(), 
											java.util.Set.class);
					
												comp.setTargetSelection(__targetSelection);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetSelection", this._targetSelection);
				}
			}
					   		 			 
						if (this._targetValue != null) {
				if (this._targetValue.isLiteralText()) {
					try {
												
						java.lang.Object __targetValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setTargetValue(__targetValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetValue", this._targetValue);
				}
			}
					   		 			 
						if (this._topControlClass != null) {
				if (this._topControlClass.isLiteralText()) {
					try {
												
						java.lang.String __topControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopControlClass(__topControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topControlClass", this._topControlClass);
				}
			}
					   		 			 
						if (this._topControlLabel != null) {
				if (this._topControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __topControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopControlLabel(__topControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topControlLabel", this._topControlLabel);
				}
			}
					   		 			 
						if (this._topTitle != null) {
				if (this._topTitle.isLiteralText()) {
					try {
												
						java.lang.String __topTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopTitle(__topTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topTitle", this._topTitle);
				}
			}
					   		 			 
						if (this._upControlClass != null) {
				if (this._upControlClass.isLiteralText()) {
					try {
												
						java.lang.String __upControlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._upControlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUpControlClass(__upControlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("upControlClass", this._upControlClass);
				}
			}
					   		 			 
						if (this._upControlLabel != null) {
				if (this._upControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __upControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._upControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUpControlLabel(__upControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("upControlLabel", this._upControlLabel);
				}
			}
					   		 			 
						if (this._upTitle != null) {
				if (this._upTitle.isLiteralText()) {
					try {
												
						java.lang.String __upTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._upTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUpTitle(__upTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("upTitle", this._upTitle);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					     		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ListShuttle";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.ListShuttleRenderer";
			}

}
