/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlRecursiveTreeNodesAdaptor;

public class RecursiveTreeNodesAdaptorTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 		 		 	  			  		  	  
		/*
		 * included
		 * This boolean expression is used to define which elements of both collections are processed. Default value is "true".
		 */
		private ValueExpression _included;
		/**
		 * This boolean expression is used to define which elements of both collections are processed. Default value is "true".
		 * Setter for included
		 * @param included - new value
		 */
		 public void setIncluded( ValueExpression  __included ){
			this._included = __included;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * includedNode
		 * This boolean expression is used to define which elements are processed. Default value is "true".
		 */
		private ValueExpression _includedNode;
		/**
		 * This boolean expression is used to define which elements are processed. Default value is "true".
		 * Setter for includedNode
		 * @param includedNode - new value
		 */
		 public void setIncludedNode( ValueExpression  __includedNode ){
			this._includedNode = __includedNode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * includedRoot
		 * This boolean expression is used to define which elements are processed applying to "roots" collection. Default value is "true".
		 */
		private ValueExpression _includedRoot;
		/**
		 * This boolean expression is used to define which elements are processed applying to "roots" collection. Default value is "true".
		 * Setter for includedRoot
		 * @param includedRoot - new value
		 */
		 public void setIncludedRoot( ValueExpression  __includedRoot ){
			this._includedRoot = __includedRoot;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * nodes
		 * Defines collection to use at the other (non-top) levels of iteration
		 */
		private ValueExpression _nodes;
		/**
		 * Defines collection to use at the other (non-top) levels of iteration
		 * Setter for nodes
		 * @param nodes - new value
		 */
		 public void setNodes( ValueExpression  __nodes ){
			this._nodes = __nodes;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * recursionOrder
		 * The attribute is used to control a recursion order. Possible values are "first", "last", "[id of adaptor]" ("first" and "last" are reserved values). When "[id of the adaptor]" is set it means that recursion occurs after these adaptor component nodes are processed. The default value is "last"
		 */
		private ValueExpression _recursionOrder;
		/**
		 * The attribute is used to control a recursion order. Possible values are "first", "last", "[id of adaptor]" ("first" and "last" are reserved values). When "[id of the adaptor]" is set it means that recursion occurs after these adaptor component nodes are processed. The default value is "last"
		 * Setter for recursionOrder
		 * @param recursionOrder - new value
		 */
		 public void setRecursionOrder( ValueExpression  __recursionOrder ){
			this._recursionOrder = __recursionOrder;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * roots
		 * Defines collection to use at the top of iteration
		 */
		private ValueExpression _roots;
		/**
		 * Defines collection to use at the top of iteration
		 * Setter for roots
		 * @param roots - new value
		 */
		 public void setRoots( ValueExpression  __roots ){
			this._roots = __roots;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the current collection element will be used when iterating
		 */
		private ValueExpression _var;
		/**
		 * A request-scope attribute via which the data object for the current collection element will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( ValueExpression  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		 		    this._included = null;
	 		 		    this._includedNode = null;
	 		 		    this._includedRoot = null;
	 		 		    this._nodes = null;
	 		 		    this._recursionOrder = null;
	 		 		 		    this._roots = null;
	 		 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlRecursiveTreeNodesAdaptor comp = (HtmlRecursiveTreeNodesAdaptor) component;
     		 			 
						if (this._included != null) {
				if (this._included.isLiteralText()) {
					try {
												
						Boolean __included = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._included.getExpressionString(), 
											Boolean.class);
					
												comp.setIncluded(__included.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("included", this._included);
				}
			}
					   		 			 
						if (this._includedNode != null) {
				if (this._includedNode.isLiteralText()) {
					try {
												
						Boolean __includedNode = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._includedNode.getExpressionString(), 
											Boolean.class);
					
												comp.setIncludedNode(__includedNode.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("includedNode", this._includedNode);
				}
			}
					   		 			 
						if (this._includedRoot != null) {
				if (this._includedRoot.isLiteralText()) {
					try {
												
						Boolean __includedRoot = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._includedRoot.getExpressionString(), 
											Boolean.class);
					
												comp.setIncludedRoot(__includedRoot.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("includedRoot", this._includedRoot);
				}
			}
					   		 			 				if(null != this._nodes && this._nodes.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.RecursiveTreeNodesAdaptor with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property nodes");
				}
			 
						if (this._nodes != null) {
				if (this._nodes.isLiteralText()) {
					try {
												
						java.lang.Object __nodes = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._nodes.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setNodes(__nodes);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("nodes", this._nodes);
				}
			}
					   		 			 
						if (this._recursionOrder != null) {
				if (this._recursionOrder.isLiteralText()) {
					try {
												
						java.lang.String __recursionOrder = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._recursionOrder.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRecursionOrder(__recursionOrder);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("recursionOrder", this._recursionOrder);
				}
			}
					    		 			 				if(null != this._roots && this._roots.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.RecursiveTreeNodesAdaptor with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property roots");
				}
			 
						if (this._roots != null) {
				if (this._roots.isLiteralText()) {
					try {
												
						java.lang.Object __roots = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._roots.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setRoots(__roots);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("roots", this._roots);
				}
			}
					    		 			 
						if (this._var != null) {
				if (this._var.isLiteralText()) {
					try {
												
						java.lang.String __var = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._var.getExpressionString(), 
											java.lang.String.class);
					
												comp.setVar(__var);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("var", this._var);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.RecursiveTreeNodesAdaptor";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return null;
			}

}
