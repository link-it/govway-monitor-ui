/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlTreeNodesAdaptor;

public class TreeNodesAdaptorTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 		 		 	  			  		  	  
		/*
		 * includedNode
		 * This boolean expression is used to define which elements are processed. Default value is "true".
		 */
		private ValueExpression _includedNode;
		/**
		 * This boolean expression is used to define which elements are processed. Default value is "true".
		 * Setter for includedNode
		 * @param includedNode - new value
		 */
		 public void setIncludedNode( ValueExpression  __includedNode ){
			this._includedNode = __includedNode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * nodes
		 * Defines collection to use at the other (non-top) levels of iteration
		 */
		private ValueExpression _nodes;
		/**
		 * Defines collection to use at the other (non-top) levels of iteration
		 * Setter for nodes
		 * @param nodes - new value
		 */
		 public void setNodes( ValueExpression  __nodes ){
			this._nodes = __nodes;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the current collection element will be used when iterating
		 */
		private ValueExpression _var;
		/**
		 * A request-scope attribute via which the data object for the current collection element will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( ValueExpression  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		 		    this._includedNode = null;
	 		 		    this._nodes = null;
	 		 		 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlTreeNodesAdaptor comp = (HtmlTreeNodesAdaptor) component;
     		 			 
						if (this._includedNode != null) {
				if (this._includedNode.isLiteralText()) {
					try {
												
						Boolean __includedNode = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._includedNode.getExpressionString(), 
											Boolean.class);
					
												comp.setIncludedNode(__includedNode.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("includedNode", this._includedNode);
				}
			}
					   		 			 				if(null != this._nodes && this._nodes.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.TreeNodesAdaptor with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property nodes");
				}
			 
						if (this._nodes != null) {
				if (this._nodes.isLiteralText()) {
					try {
												
						java.lang.Object __nodes = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._nodes.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setNodes(__nodes);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("nodes", this._nodes);
				}
			}
					     		 			 
						if (this._var != null) {
				if (this._var.isLiteralText()) {
					try {
												
						java.lang.String __var = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._var.getExpressionString(), 
											java.lang.String.class);
					
												comp.setVar(__var);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("var", this._var);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.TreeNodesAdaptor";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return null;
			}

}
