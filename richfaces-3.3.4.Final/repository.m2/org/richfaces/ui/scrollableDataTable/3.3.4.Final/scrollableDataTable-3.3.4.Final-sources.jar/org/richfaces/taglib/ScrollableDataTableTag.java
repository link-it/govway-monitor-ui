/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.richfaces.model.selection.Selection ;
import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import org.richfaces.model.SortOrder ;
import org.richfaces.model.SelectionMode ;
import java.util.Set ;
import java.lang.Object ;
import java.lang.String ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlScrollableDataTable;

public class ScrollableDataTableTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * activeClass
		 * Assigns one or more space-separated CSS class names to the component active row
		 */
		private ValueExpression _activeClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component active row
		 * Setter for activeClass
		 * @param activeClass - new value
		 */
		 public void setActiveClass( ValueExpression  __activeClass ){
			this._activeClass = __activeClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * activeRowKey
		 * Request scope attribute under which the activeRowKey will be accessible
		 */
		private ValueExpression _activeRowKey;
		/**
		 * Request scope attribute under which the activeRowKey will be accessible
		 * Setter for activeRowKey
		 * @param activeRowKey - new value
		 */
		 public void setActiveRowKey( ValueExpression  __activeRowKey ){
			this._activeRowKey = __activeRowKey;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxKeys
		 * This attribute defines row keys that are updated after an AJAX request
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * This attribute defines row keys that are updated after an AJAX request
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * bypassUpdates
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 */
		private ValueExpression _bypassUpdates;
		/**
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 * Setter for bypassUpdates
		 * @param bypassUpdates - new value
		 */
		 public void setBypassUpdates( ValueExpression  __bypassUpdates ){
			this._bypassUpdates = __bypassUpdates;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding  for a component state for saving or redefinition
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding  for a component state for saving or redefinition
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * data
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 */
		private ValueExpression _data;
		/**
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 * Setter for data
		 * @param data - new value
		 */
		 public void setData( ValueExpression  __data ){
			this._data = __data;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * eventsQueue
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 */
		private ValueExpression _eventsQueue;
		/**
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 * Setter for eventsQueue
		 * @param eventsQueue - new value
		 */
		 public void setEventsQueue( ValueExpression  __eventsQueue ){
			this._eventsQueue = __eventsQueue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * first
		 * A zero-relative row number of the first row to display
		 */
		private ValueExpression _first;
		/**
		 * A zero-relative row number of the first row to display
		 * Setter for first
		 * @param first - new value
		 */
		 public void setFirst( ValueExpression  __first ){
			this._first = __first;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * footerClass
		 * Assigns one or more space-separated CSS class names to any footer generated for this component
		 */
		private ValueExpression _footerClass;
		/**
		 * Assigns one or more space-separated CSS class names to any footer generated for this component
		 * Setter for footerClass
		 * @param footerClass - new value
		 */
		 public void setFooterClass( ValueExpression  __footerClass ){
			this._footerClass = __footerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * frozenColCount
		 * Defines the number of the fixed columns from the left side that will not be scrolled via horizontal scroll.
			Default value is "0".
		 */
		private ValueExpression _frozenColCount;
		/**
		 * Defines the number of the fixed columns from the left side that will not be scrolled via horizontal scroll.
			Default value is "0".
		 * Setter for frozenColCount
		 * @param frozenColCount - new value
		 */
		 public void setFrozenColCount( ValueExpression  __frozenColCount ){
			this._frozenColCount = __frozenColCount;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to any header generated for this component
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to any header generated for this component
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * height
		 * Defines a height of the component. Default value is "500px".
		 */
		private ValueExpression _height;
		/**
		 * Defines a height of the component. Default value is "500px".
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hideWhenScrolling
		 * If "true" data will be hidden during scrolling. Can be used for increase performance.
			Default value is "false".
		 */
		private ValueExpression _hideWhenScrolling;
		/**
		 * If "true" data will be hidden during scrolling. Can be used for increase performance.
			Default value is "false".
		 * Setter for hideWhenScrolling
		 * @param hideWhenScrolling - new value
		 */
		 public void setHideWhenScrolling( ValueExpression  __hideWhenScrolling ){
			this._hideWhenScrolling = __hideWhenScrolling;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onRowClick
		 * The client-side script method to be called when the row is clicked
		 */
		private ValueExpression _onRowClick;
		/**
		 * The client-side script method to be called when the row is clicked
		 * Setter for onRowClick
		 * @param onRowClick - new value
		 */
		 public void setOnRowClick( ValueExpression  __onRowClick ){
			this._onRowClick = __onRowClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowDblClick
		 * The client-side script method to be called when the row is double-clicked
		 */
		private ValueExpression _onRowDblClick;
		/**
		 * The client-side script method to be called when the row is double-clicked
		 * Setter for onRowDblClick
		 * @param onRowDblClick - new value
		 */
		 public void setOnRowDblClick( ValueExpression  __onRowDblClick ){
			this._onRowDblClick = __onRowDblClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseDown
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 */
		private ValueExpression _onRowMouseDown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 * Setter for onRowMouseDown
		 * @param onRowMouseDown - new value
		 */
		 public void setOnRowMouseDown( ValueExpression  __onRowMouseDown ){
			this._onRowMouseDown = __onRowMouseDown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseUp
		 * The client-side script method to be called when a mouse button is released over the row
		 */
		private ValueExpression _onRowMouseUp;
		/**
		 * The client-side script method to be called when a mouse button is released over the row
		 * Setter for onRowMouseUp
		 * @param onRowMouseUp - new value
		 */
		 public void setOnRowMouseUp( ValueExpression  __onRowMouseUp ){
			this._onRowMouseUp = __onRowMouseUp;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * onselectionchange
		 * The client side script method to be called when a selected row is changed
		 */
		private ValueExpression _onselectionchange;
		/**
		 * The client side script method to be called when a selected row is changed
		 * Setter for onselectionchange
		 * @param onselectionchange - new value
		 */
		 public void setOnselectionchange( ValueExpression  __onselectionchange ){
			this._onselectionchange = __onselectionchange;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * requestDelay
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 */
		private ValueExpression _requestDelay;
		/**
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 * Setter for requestDelay
		 * @param requestDelay - new value
		 */
		 public void setRequestDelay( ValueExpression  __requestDelay ){
			this._requestDelay = __requestDelay;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * The attribute provides access to a row key in a Request scope
		 */
		private String _rowKeyVar;
		/**
		 * The attribute provides access to a row key in a Request scope
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( String  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rows
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 */
		private ValueExpression _rows;
		/**
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 * Setter for rows
		 * @param rows - new value
		 */
		 public void setRows( ValueExpression  __rows ){
			this._rows = __rows;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * scriptVar
		 * Name of JavaScript variable corresponding to component
		 */
		private String _scriptVar;
		/**
		 * Name of JavaScript variable corresponding to component
		 * Setter for scriptVar
		 * @param scriptVar - new value
		 */
		 public void setScriptVar( String  __scriptVar ){
			this._scriptVar = __scriptVar;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * selectedClass
		 * Assigns one or more space-separated CSS class names to the component rows selected
		 */
		private ValueExpression _selectedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component rows selected
		 * Setter for selectedClass
		 * @param selectedClass - new value
		 */
		 public void setSelectedClass( ValueExpression  __selectedClass ){
			this._selectedClass = __selectedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selection
		 * Value binding representing selected rows
		 */
		private ValueExpression _selection;
		/**
		 * Value binding representing selected rows
		 * Setter for selection
		 * @param selection - new value
		 */
		 public void setSelection( ValueExpression  __selection ){
			this._selection = __selection;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * selectionMode
		 * Defines selection behaviour, provides an enumeration of the possible selection modes. Default value is "multi"
		 */
		private ValueExpression _selectionMode;
		/**
		 * Defines selection behaviour, provides an enumeration of the possible selection modes. Default value is "multi"
		 * Setter for selectionMode
		 * @param selectionMode - new value
		 */
		 public void setSelectionMode( ValueExpression  __selectionMode ){
			this._selectionMode = __selectionMode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * similarityGroupingId
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 */
		private ValueExpression _similarityGroupingId;
		/**
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 * Setter for similarityGroupingId
		 * @param similarityGroupingId - new value
		 */
		 public void setSimilarityGroupingId( ValueExpression  __similarityGroupingId ){
			this._similarityGroupingId = __similarityGroupingId;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * sortMode
		 * Defines mode of sorting. Possible values are 'single' for sorting of one column and 'multi' for some.
		 */
		private ValueExpression _sortMode;
		/**
		 * Defines mode of sorting. Possible values are 'single' for sorting of one column and 'multi' for some.
		 * Setter for sortMode
		 * @param sortMode - new value
		 */
		 public void setSortMode( ValueExpression  __sortMode ){
			this._sortMode = __sortMode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortOrder
		 * ValueBinding pointing at a property of a class to manage rows sorting
		 */
		private ValueExpression _sortOrder;
		/**
		 * ValueBinding pointing at a property of a class to manage rows sorting
		 * Setter for sortOrder
		 * @param sortOrder - new value
		 */
		 public void setSortOrder( ValueExpression  __sortOrder ){
			this._sortOrder = __sortOrder;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stateVar
		 * The attribute  provides access to a component state on the client side
		 */
		private String _stateVar;
		/**
		 * The attribute  provides access to a component state on the client side
		 * Setter for stateVar
		 * @param stateVar - new value
		 */
		 public void setStateVar( String  __stateVar ){
			this._stateVar = __stateVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * timeout
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 */
		private ValueExpression _timeout;
		/**
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 */
		private String _var;
		/**
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * Defines a width of the component. Default value is "700px".
		 */
		private ValueExpression _width;
		/**
		 * Defines a width of the component. Default value is "700px".
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._activeClass = null;
	 		 		    this._activeRowKey = null;
	 		 		    this._ajaxKeys = null;
	 		 		 		 		 		    this._bypassUpdates = null;
	 		 		 		    this._columnClasses = null;
	 		 		    this._componentState = null;
	 		 		    this._data = null;
	 		 		    this._eventsQueue = null;
	 		 		 		    this._first = null;
	 		 		 		 		    this._footerClass = null;
	 		 		    this._frozenColCount = null;
	 		 		 		    this._headerClass = null;
	 		 		    this._height = null;
	 		 		    this._hideWhenScrolling = null;
	 		 		 		    this._ignoreDupResponses = null;
	 		 		 		    this._onRowClick = null;
	 		 		    this._onRowDblClick = null;
	 		 		    this._onRowMouseDown = null;
	 		 		    this._onRowMouseUp = null;
	 		 		 		 		    this._onselectionchange = null;
	 		 		 		    this._reRender = null;
	 		 		 		    this._requestDelay = null;
	 		 		 		 		    this._rowClasses = null;
	 		 		 		 		 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		    this._rows = null;
	 		 		    this._scriptVar = null;
	 		 		 		    this._selectedClass = null;
	 		 		    this._selection = null;
	 		 		 		    this._selectionMode = null;
	 		 		    this._similarityGroupingId = null;
	 		 		 		    this._sortMode = null;
	 		 		    this._sortOrder = null;
	 		 		    this._stateVar = null;
	 		 		    this._status = null;
	 		 		 		 		    this._timeout = null;
	 		 		    this._value = null;
	 		 		    this._var = null;
	 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlScrollableDataTable comp = (HtmlScrollableDataTable) component;
 		 			 
						if (this._activeClass != null) {
				if (this._activeClass.isLiteralText()) {
					try {
												
						java.lang.String __activeClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setActiveClass(__activeClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeClass", this._activeClass);
				}
			}
					   		 			 
						if (this._activeRowKey != null) {
				if (this._activeRowKey.isLiteralText()) {
					try {
												
						java.lang.Object __activeRowKey = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeRowKey.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setActiveRowKey(__activeRowKey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeRowKey", this._activeRowKey);
				}
			}
					   		 			 				if(null != this._ajaxKeys && this._ajaxKeys.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.component.ScrollableDataTable with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property ajaxKeys");
				}
			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					      		 			 
						if (this._bypassUpdates != null) {
				if (this._bypassUpdates.isLiteralText()) {
					try {
												
						Boolean __bypassUpdates = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bypassUpdates.getExpressionString(), 
											Boolean.class);
					
												comp.setBypassUpdates(__bypassUpdates.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bypassUpdates", this._bypassUpdates);
				}
			}
					    		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					   		 			 				if(null != this._componentState && this._componentState.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.component.ScrollableDataTable with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property componentState");
				}
			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					   		 			 
						if (this._data != null) {
				if (this._data.isLiteralText()) {
					try {
												
						java.lang.Object __data = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._data.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setData(__data);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("data", this._data);
				}
			}
					   		 			 
						if (this._eventsQueue != null) {
				if (this._eventsQueue.isLiteralText()) {
					try {
												
						java.lang.String __eventsQueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._eventsQueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEventsQueue(__eventsQueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("eventsQueue", this._eventsQueue);
				}
			}
					    		 			 
						if (this._first != null) {
				if (this._first.isLiteralText()) {
					try {
												
						Integer __first = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._first.getExpressionString(), 
											Integer.class);
					
												comp.setFirst(__first.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("first", this._first);
				}
			}
					     		 			 
						if (this._footerClass != null) {
				if (this._footerClass.isLiteralText()) {
					try {
												
						java.lang.String __footerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._footerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFooterClass(__footerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("footerClass", this._footerClass);
				}
			}
					   		 			 
						if (this._frozenColCount != null) {
				if (this._frozenColCount.isLiteralText()) {
					try {
												
						Integer __frozenColCount = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._frozenColCount.getExpressionString(), 
											Integer.class);
					
												comp.setFrozenColCount(__frozenColCount.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("frozenColCount", this._frozenColCount);
				}
			}
					    		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					   		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						java.lang.String __height = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeight(__height);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					   		 			 
						if (this._hideWhenScrolling != null) {
				if (this._hideWhenScrolling.isLiteralText()) {
					try {
												
						Boolean __hideWhenScrolling = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hideWhenScrolling.getExpressionString(), 
											Boolean.class);
					
												comp.setHideWhenScrolling(__hideWhenScrolling.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hideWhenScrolling", this._hideWhenScrolling);
				}
			}
					    		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					    		 			 
						if (this._onRowClick != null) {
				if (this._onRowClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowClick(__onRowClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowClick", this._onRowClick);
				}
			}
					   		 			 
						if (this._onRowDblClick != null) {
				if (this._onRowDblClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowDblClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowDblClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowDblClick(__onRowDblClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowDblClick", this._onRowDblClick);
				}
			}
					   		 			 
						if (this._onRowMouseDown != null) {
				if (this._onRowMouseDown.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseDown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseDown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseDown(__onRowMouseDown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseDown", this._onRowMouseDown);
				}
			}
					   		 			 
						if (this._onRowMouseUp != null) {
				if (this._onRowMouseUp.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseUp = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseUp.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseUp(__onRowMouseUp);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseUp", this._onRowMouseUp);
				}
			}
					     		 			 
						if (this._onselectionchange != null) {
				if (this._onselectionchange.isLiteralText()) {
					try {
												
						java.lang.String __onselectionchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselectionchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselectionchange(__onselectionchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselectionchange", this._onselectionchange);
				}
			}
					    		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					    		 			 
						if (this._requestDelay != null) {
				if (this._requestDelay.isLiteralText()) {
					try {
												
						Integer __requestDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requestDelay.getExpressionString(), 
											Integer.class);
					
												comp.setRequestDelay(__requestDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requestDelay", this._requestDelay);
				}
			}
					     		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					       		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
											if (this._rowKeyVar != null) {
					comp.setRowKeyVar(this._rowKeyVar);
				}
									   		 			 
						if (this._rows != null) {
				if (this._rows.isLiteralText()) {
					try {
												
						Integer __rows = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rows.getExpressionString(), 
											Integer.class);
					
												comp.setRows(__rows.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rows", this._rows);
				}
			}
					   		 			 
											if (this._scriptVar != null) {
					comp.setScriptVar(this._scriptVar);
				}
									    		 			 
						if (this._selectedClass != null) {
				if (this._selectedClass.isLiteralText()) {
					try {
												
						java.lang.String __selectedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectedClass(__selectedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectedClass", this._selectedClass);
				}
			}
					   		 			 				if(null != this._selection && this._selection.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.component.ScrollableDataTable with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property selection");
				}
			 
						if (this._selection != null) {
				if (this._selection.isLiteralText()) {
					try {
												
						org.richfaces.model.selection.Selection __selection = (org.richfaces.model.selection.Selection) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selection.getExpressionString(), 
											org.richfaces.model.selection.Selection.class);
					
												comp.setSelection(__selection);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selection", this._selection);
				}
			}
					    		 			 
						if (this._selectionMode != null) {
				if (this._selectionMode.isLiteralText()) {
					try {
												
						org.richfaces.model.SelectionMode __selectionMode = (org.richfaces.model.SelectionMode) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectionMode.getExpressionString(), 
											org.richfaces.model.SelectionMode.class);
					
												comp.setSelectionMode(__selectionMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectionMode", this._selectionMode);
				}
			}
					   		 			 
						if (this._similarityGroupingId != null) {
				if (this._similarityGroupingId.isLiteralText()) {
					try {
												
						java.lang.String __similarityGroupingId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._similarityGroupingId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSimilarityGroupingId(__similarityGroupingId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("similarityGroupingId", this._similarityGroupingId);
				}
			}
					    		 			 
						if (this._sortMode != null) {
				if (this._sortMode.isLiteralText()) {
					try {
												
						java.lang.String __sortMode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortMode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSortMode(__sortMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortMode", this._sortMode);
				}
			}
					   		 			 				if(null != this._sortOrder && this._sortOrder.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.component.ScrollableDataTable with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property sortOrder");
				}
			 
						if (this._sortOrder != null) {
				if (this._sortOrder.isLiteralText()) {
					try {
												
						org.richfaces.model.SortOrder __sortOrder = (org.richfaces.model.SortOrder) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortOrder.getExpressionString(), 
											org.richfaces.model.SortOrder.class);
					
												comp.setSortOrder(__sortOrder);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortOrder", this._sortOrder);
				}
			}
					   		 			 
											if (this._stateVar != null) {
					comp.setStateVar(this._stateVar);
				}
									   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					     		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					   		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.component.ScrollableDataTable";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.renderkit.html.ScrollableDataTableRenderer";
			}

}
