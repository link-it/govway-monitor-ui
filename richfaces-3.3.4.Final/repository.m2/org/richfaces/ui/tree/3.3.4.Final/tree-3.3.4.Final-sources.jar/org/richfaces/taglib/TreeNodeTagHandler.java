/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;
import org.richfaces.taglib.TreeListenersTagHandler ;
import javax.faces.component.UIComponent;
import org.richfaces.component.html.HtmlTreeNode;
import com.sun.facelets.tag.jsf.ComponentHandler;
import com.sun.facelets.tag.jsf.ComponentConfig;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
/**
 * @author shura (latest modification by $Author: alexsmirnov $)
 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
 *
 */
public class TreeNodeTagHandler extends org.richfaces.taglib.TreeListenersTagHandler {


  private static final TreeNodeTagHandlerMetaRule metaRule = new TreeNodeTagHandlerMetaRule();


  
  public TreeNodeTagHandler(ComponentConfig config) 
  {
    super(config);
  }
// Metarule
  protected MetaRuleset createMetaRuleset(Class type)
  {
    MetaRuleset m = super.createMetaRuleset(type);
	m.addRule(metaRule);
	return m;
  }

  	/**
	 * @author shura (latest modification by $Author: alexsmirnov $)
	 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
	 *
	 */
	static class TreeNodeTagHandlerMetaRule extends MetaRule{

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.MetaRule#applyRule(java.lang.String, com.sun.facelets.tag.TagAttribute, com.sun.facelets.tag.MetadataTarget)
		 */
		public Metadata applyRule(String name, TagAttribute attribute, MetadataTarget meta) {
	        if (meta.isTargetInstanceOf(HtmlTreeNode.class)) {
				 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  	            	            
	            if ("changeExpandListener".equals(name)) {
	                    return new changeExpandListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 		  		 				 		  	            	            
	            if ("dragListener".equals(name)) {
	                    return new dragListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 		  	            	            
	            if ("dropListener".equals(name)) {
	                    return new dropListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 				 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 		  	            	            
	            if ("nodeSelectListener".equals(name)) {
	                    return new nodeSelectListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 				 				 				 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 			        }
			return null;
		}

	}

 
    
    
    
     
    
  		
	static class changeExpandListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.NodeExpandedEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public changeExpandListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTreeNode) instance)
            .setChangeExpandListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
    
    
  		
	static class dragListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.DragEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public dragListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTreeNode) instance)
            .setDragListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
    
  		
	static class dropListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.DropEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public dropListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTreeNode) instance)
            .setDropListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
     
    
    
    
    
    
     
      
      
    
    
    
  		
	static class nodeSelectListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.NodeSelectedEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public nodeSelectListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTreeNode) instance)
            .setNodeSelectListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
     
    
    
     
    
    
    
    
    
    
    
    
            
    
    
    
     
    
    
    
    
    
    
    }
