/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import javax.faces.convert.Converter ;
import java.util.Set ;
import java.lang.Object ;
import org.richfaces.taglib.TreeTagHandlerBase ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;
import javax.faces.component.UIComponent;
import org.richfaces.component.html.HtmlTree;
import com.sun.facelets.tag.jsf.ComponentHandler;
import com.sun.facelets.tag.jsf.ComponentConfig;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
/**
 * @author shura (latest modification by $Author: alexsmirnov $)
 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
 *
 */
public class TreeTagHandler extends org.richfaces.taglib.TreeTagHandlerBase {


  private static final TreeTagHandlerMetaRule metaRule = new TreeTagHandlerMetaRule();


  
  public TreeTagHandler(ComponentConfig config) 
  {
    super(config);
  }
// Metarule
  protected MetaRuleset createMetaRuleset(Class type)
  {
    MetaRuleset m = super.createMetaRuleset(type);
	m.addRule(metaRule);
	return m;
  }

  	/**
	 * @author shura (latest modification by $Author: alexsmirnov $)
	 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
	 *
	 */
	static class TreeTagHandlerMetaRule extends MetaRule{

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.MetaRule#applyRule(java.lang.String, com.sun.facelets.tag.TagAttribute, com.sun.facelets.tag.MetadataTarget)
		 */
		public Metadata applyRule(String name, TagAttribute attribute, MetadataTarget meta) {
	        if (meta.isTargetInstanceOf(HtmlTree.class)) {
				 		  		 				 		  		 				 		  	            	            
	            if ("adviseNodeOpened".equals(name)) {
	                    return new adviseNodeOpenedMapper(attribute);
	            }
				
						  		 				 		  	            	            
	            if ("adviseNodeSelected".equals(name)) {
	                    return new adviseNodeSelectedMapper(attribute);
	            }
				
						  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 				 		  		 				 		  	            	            
	            if ("changeExpandListener".equals(name)) {
	                    return new changeExpandListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  	            	            
	            if ("dragListener".equals(name)) {
	                    return new dragListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 		  	            	            
	            if ("dropListener".equals(name)) {
	                    return new dropListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 				 		  		 				 				 		  		 				 				 				 		  	            	            
	            if ("nodeSelectListener".equals(name)) {
	                    return new nodeSelectListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 				 				 				 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 			        }
			return null;
		}

	}


    
    
  		
	static class adviseNodeOpenedMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.component.UITree.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public adviseNodeOpenedMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTree) instance)
            .setAdviseNodeOpened
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	  
  		
	static class adviseNodeSelectedMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.component.UITree.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public adviseNodeSelectedMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTree) instance)
            .setAdviseNodeSelected
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	  
    
    
    
    
    
       
    
  		
	static class changeExpandListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.NodeExpandedEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public changeExpandListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTree) instance)
            .setChangeExpandListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
    
    
    
    
  		
	static class dragListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.DragEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public dragListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTree) instance)
            .setDragListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
    
  		
	static class dropListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.DropEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public dropListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTree) instance)
            .setDropListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
      
    
    
    
    
    
    
    
    
    
    
     
    
     
     
      
  		
	static class nodeSelectListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {org.richfaces.event.NodeSelectedEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public nodeSelectListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlTree) instance)
            .setNodeSelectListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
     
    
    
     
    
    
    
    
    
    
    
    
            
    
    
    
    
    
     
    
       
    
    
    
    
     
    
    
    
    
    
      
    
    
     
    
    
    
    
    
    }
