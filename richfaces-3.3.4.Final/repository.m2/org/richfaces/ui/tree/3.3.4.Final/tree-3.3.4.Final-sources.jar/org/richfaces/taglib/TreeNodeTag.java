/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlTreeNode;

public class TreeNodeTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * acceptCursors
		 * List of comma separated cursors that indicates when acceptable draggable over dropzone
		 */
		private ValueExpression _acceptCursors;
		/**
		 * List of comma separated cursors that indicates when acceptable draggable over dropzone
		 * Setter for acceptCursors
		 * @param acceptCursors - new value
		 */
		 public void setAcceptCursors( ValueExpression  __acceptCursors ){
			this._acceptCursors = __acceptCursors;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * acceptedTypes
		 * A list of drag zones types, which elements are accepted by a drop zone
		 */
		private ValueExpression _acceptedTypes;
		/**
		 * A list of drag zones types, which elements are accepted by a drop zone
		 * Setter for acceptedTypes
		 * @param acceptedTypes - new value
		 */
		 public void setAcceptedTypes( ValueExpression  __acceptedTypes ){
			this._acceptedTypes = __acceptedTypes;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxSingle
		 * Limits JSF tree processing (decoding, conversion, validation and model updating) only to a component that sends the request. Boolean. Default value is "false".
		 */
		private ValueExpression _ajaxSingle;
		/**
		 * Limits JSF tree processing (decoding, conversion, validation and model updating) only to a component that sends the request. Boolean. Default value is "false".
		 * Setter for ajaxSingle
		 * @param ajaxSingle - new value
		 */
		 public void setAjaxSingle( ValueExpression  __ajaxSingle ){
			this._ajaxSingle = __ajaxSingle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxSubmitSelection
		 * An algorithm of AJAX request submission. Possible values are "inherit", "true", "false". Default value is "inherit".
		 */
		private ValueExpression _ajaxSubmitSelection;
		/**
		 * An algorithm of AJAX request submission. Possible values are "inherit", "true", "false". Default value is "inherit".
		 * Setter for ajaxSubmitSelection
		 * @param ajaxSubmitSelection - new value
		 */
		 public void setAjaxSubmitSelection( ValueExpression  __ajaxSubmitSelection ){
			this._ajaxSubmitSelection = __ajaxSubmitSelection;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * bypassUpdates
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 */
		private ValueExpression _bypassUpdates;
		/**
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 * Setter for bypassUpdates
		 * @param bypassUpdates - new value
		 */
		 public void setBypassUpdates( ValueExpression  __bypassUpdates ){
			this._bypassUpdates = __bypassUpdates;
	     }
	  
	 	 		 	  	  	  
		/*
		 * changeExpandListener
		 * Listener called on expand/collapse event on the node
		 */
		private MethodExpression _changeExpandListener;
		/**
		 * Listener called on expand/collapse event on the node
		 * Setter for changeExpandListener
		 * @param changeExpandListener - new value
		 */
		 public void setChangeExpandListener( MethodExpression  __changeExpandListener ){
			this._changeExpandListener = __changeExpandListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * cursorTypeMapping
		 * Mapping between drop types and acceptable cursors
		 */
		private ValueExpression _cursorTypeMapping;
		/**
		 * Mapping between drop types and acceptable cursors
		 * Setter for cursorTypeMapping
		 * @param cursorTypeMapping - new value
		 */
		 public void setCursorTypeMapping( ValueExpression  __cursorTypeMapping ){
			this._cursorTypeMapping = __cursorTypeMapping;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * data
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 */
		private ValueExpression _data;
		/**
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 * Setter for data
		 * @param data - new value
		 */
		 public void setData( ValueExpression  __data ){
			this._data = __data;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * dragIndicator
		 * Id of a component that is used as drag pointer during the drag operation
		 */
		private ValueExpression _dragIndicator;
		/**
		 * Id of a component that is used as drag pointer during the drag operation
		 * Setter for dragIndicator
		 * @param dragIndicator - new value
		 */
		 public void setDragIndicator( ValueExpression  __dragIndicator ){
			this._dragIndicator = __dragIndicator;
	     }
	  
	 	 		 	  	  	  
		/*
		 * dragListener
		 * MethodBinding representing an action listener method that will be notified after drag operation
		 */
		private MethodExpression _dragListener;
		/**
		 * MethodBinding representing an action listener method that will be notified after drag operation
		 * Setter for dragListener
		 * @param dragListener - new value
		 */
		 public void setDragListener( MethodExpression  __dragListener ){
			this._dragListener = __dragListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * dragType
		 * A drag zone type that is used for zone definition, which elements can be accepted by a drop zone
		 */
		private ValueExpression _dragType;
		/**
		 * A drag zone type that is used for zone definition, which elements can be accepted by a drop zone
		 * Setter for dragType
		 * @param dragType - new value
		 */
		 public void setDragType( ValueExpression  __dragType ){
			this._dragType = __dragType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * dragValue
		 * Data to be sent to the drop zone after a drop event. Default value is "getUITree().getDragValue()".
		 */
		private ValueExpression _dragValue;
		/**
		 * Data to be sent to the drop zone after a drop event. Default value is "getUITree().getDragValue()".
		 * Setter for dragValue
		 * @param dragValue - new value
		 */
		 public void setDragValue( ValueExpression  __dragValue ){
			this._dragValue = __dragValue;
	     }
	  
	 	 		 	  	  	  
		/*
		 * dropListener
		 * MethodBinding representing an action listener method that will be notified after drop operation
		 */
		private MethodExpression _dropListener;
		/**
		 * MethodBinding representing an action listener method that will be notified after drop operation
		 * Setter for dropListener
		 * @param dropListener - new value
		 */
		 public void setDropListener( MethodExpression  __dropListener ){
			this._dropListener = __dropListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * dropValue
		 * Data to be processed after a drop event. Default value is "getUITree().getDropValue()".
		 */
		private ValueExpression _dropValue;
		/**
		 * Data to be processed after a drop event. Default value is "getUITree().getDropValue()".
		 * Setter for dropValue
		 * @param dropValue - new value
		 */
		 public void setDropValue( ValueExpression  __dropValue ){
			this._dropValue = __dropValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * eventsQueue
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 */
		private ValueExpression _eventsQueue;
		/**
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 * Setter for eventsQueue
		 * @param eventsQueue - new value
		 */
		 public void setEventsQueue( ValueExpression  __eventsQueue ){
			this._eventsQueue = __eventsQueue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * focus
		 * ID of an element to set focus after request is completed on client side
		 */
		private ValueExpression _focus;
		/**
		 * ID of an element to set focus after request is completed on client side
		 * Setter for focus
		 * @param focus - new value
		 */
		 public void setFocus( ValueExpression  __focus ){
			this._focus = __focus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * grabCursors
		 * List of comma separated cursors that indicates when you can grab and drag an object
		 */
		private ValueExpression _grabCursors;
		/**
		 * List of comma separated cursors that indicates when you can grab and drag an object
		 * Setter for grabCursors
		 * @param grabCursors - new value
		 */
		 public void setGrabCursors( ValueExpression  __grabCursors ){
			this._grabCursors = __grabCursors;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * grabbingCursors
		 * List of comma separated cursors that indicates when you has grabbed something
		 */
		private ValueExpression _grabbingCursors;
		/**
		 * List of comma separated cursors that indicates when you has grabbed something
		 * Setter for grabbingCursors
		 * @param grabbingCursors - new value
		 */
		 public void setGrabbingCursors( ValueExpression  __grabbingCursors ){
			this._grabbingCursors = __grabbingCursors;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * highlightedClass
		 * Assigns one or more space-separated CSS class names to the component highlighted node
		 */
		private ValueExpression _highlightedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component highlighted node
		 * Setter for highlightedClass
		 * @param highlightedClass - new value
		 */
		 public void setHighlightedClass( ValueExpression  __highlightedClass ){
			this._highlightedClass = __highlightedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * icon
		 * The icon for node
		 */
		private ValueExpression _icon;
		/**
		 * The icon for node
		 * Setter for icon
		 * @param icon - new value
		 */
		 public void setIcon( ValueExpression  __icon ){
			this._icon = __icon;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconCollapsed
		 * The icon for collapsed node
		 */
		private ValueExpression _iconCollapsed;
		/**
		 * The icon for collapsed node
		 * Setter for iconCollapsed
		 * @param iconCollapsed - new value
		 */
		 public void setIconCollapsed( ValueExpression  __iconCollapsed ){
			this._iconCollapsed = __iconCollapsed;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * iconExpanded
		 * The icon for expanded node
		 */
		private ValueExpression _iconExpanded;
		/**
		 * The icon for expanded node
		 * Setter for iconExpanded
		 * @param iconExpanded - new value
		 */
		 public void setIconExpanded( ValueExpression  __iconExpanded ){
			this._iconExpanded = __iconExpanded;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * iconLeaf
		 * An icon for component leaves
		 */
		private ValueExpression _iconLeaf;
		/**
		 * An icon for component leaves
		 * Setter for iconLeaf
		 * @param iconLeaf - new value
		 */
		 public void setIconLeaf( ValueExpression  __iconLeaf ){
			this._iconLeaf = __iconLeaf;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * limitToList
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 */
		private ValueExpression _limitToList;
		/**
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 * Setter for limitToList
		 * @param limitToList - new value
		 */
		 public void setLimitToList( ValueExpression  __limitToList ){
			this._limitToList = __limitToList;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * nodeClass
		 * Assigns one or more space-separated CSS class names to the component node
		 */
		private ValueExpression _nodeClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component node
		 * Setter for nodeClass
		 * @param nodeClass - new value
		 */
		 public void setNodeClass( ValueExpression  __nodeClass ){
			this._nodeClass = __nodeClass;
	     }
	  
	 	 		 	  	  	  
		/*
		 * nodeSelectListener
		 * MethodBinding representing an action listener method that will be notified after selection of node.
		 */
		private MethodExpression _nodeSelectListener;
		/**
		 * MethodBinding representing an action listener method that will be notified after selection of node.
		 * Setter for nodeSelectListener
		 * @param nodeSelectListener - new value
		 */
		 public void setNodeSelectListener( MethodExpression  __nodeSelectListener ){
			this._nodeSelectListener = __nodeSelectListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onbeforedomupdate
		 * The client-side script method to be called before DOM is updated
		 */
		private ValueExpression _onbeforedomupdate;
		/**
		 * The client-side script method to be called before DOM is updated
		 * Setter for onbeforedomupdate
		 * @param onbeforedomupdate - new value
		 */
		 public void setOnbeforedomupdate( ValueExpression  __onbeforedomupdate ){
			this._onbeforedomupdate = __onbeforedomupdate;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * oncollapse
		 * The client-side script method to be called when a node is collapsed
		 */
		private ValueExpression _oncollapse;
		/**
		 * The client-side script method to be called when a node is collapsed
		 * Setter for oncollapse
		 * @param oncollapse - new value
		 */
		 public void setOncollapse( ValueExpression  __oncollapse ){
			this._oncollapse = __oncollapse;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the request is completed
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the request is completed
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncontextmenu
		 * The client-side script method to be called when the right mouse button is clicked over the component.
		   Returning false prevents a default browser context menu from being displayed.
		 */
		private ValueExpression _oncontextmenu;
		/**
		 * The client-side script method to be called when the right mouse button is clicked over the component.
		   Returning false prevents a default browser context menu from being displayed.
		 * Setter for oncontextmenu
		 * @param oncontextmenu - new value
		 */
		 public void setOncontextmenu( ValueExpression  __oncontextmenu ){
			this._oncontextmenu = __oncontextmenu;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ondragend
		 * The client-side script method to be called when the dragging operation is finished. The default attribute value is "getDefaultOndragend()".
		 */
		private ValueExpression _ondragend;
		/**
		 * The client-side script method to be called when the dragging operation is finished. The default attribute value is "getDefaultOndragend()".
		 * Setter for ondragend
		 * @param ondragend - new value
		 */
		 public void setOndragend( ValueExpression  __ondragend ){
			this._ondragend = __ondragend;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondragenter
		 * The client-side script method to be called when a draggable object enters the zone. The default attribute value is "getDefaultOndragenter()".
		 */
		private ValueExpression _ondragenter;
		/**
		 * The client-side script method to be called when a draggable object enters the zone. The default attribute value is "getDefaultOndragenter()".
		 * Setter for ondragenter
		 * @param ondragenter - new value
		 */
		 public void setOndragenter( ValueExpression  __ondragenter ){
			this._ondragenter = __ondragenter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondragexit
		 * The client-side script method to be called after a draggable object leaves the zone. The default attribute value is "getDefaultOndragexit()".
		 */
		private ValueExpression _ondragexit;
		/**
		 * The client-side script method to be called after a draggable object leaves the zone. The default attribute value is "getDefaultOndragexit()".
		 * Setter for ondragexit
		 * @param ondragexit - new value
		 */
		 public void setOndragexit( ValueExpression  __ondragexit ){
			this._ondragexit = __ondragexit;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondragstart
		 * The client-side script method to be called when the dragging operation is started. The default attribute value is "getDefaultOndragstart()".
		 */
		private ValueExpression _ondragstart;
		/**
		 * The client-side script method to be called when the dragging operation is started. The default attribute value is "getDefaultOndragstart()".
		 * Setter for ondragstart
		 * @param ondragstart - new value
		 */
		 public void setOndragstart( ValueExpression  __ondragstart ){
			this._ondragstart = __ondragstart;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondrop
		 * The client-side script method to be called when something is dropped into the drop zone. The default attribute value is "getDefaultOndrop()".
		 */
		private ValueExpression _ondrop;
		/**
		 * The client-side script method to be called when something is dropped into the drop zone. The default attribute value is "getDefaultOndrop()".
		 * Setter for ondrop
		 * @param ondrop - new value
		 */
		 public void setOndrop( ValueExpression  __ondrop ){
			this._ondrop = __ondrop;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondropend
		 * The client-side script method to be called when a draggable object is dropped into any zone. The default attribute value is "getDefaultOndropend()".
		 */
		private ValueExpression _ondropend;
		/**
		 * The client-side script method to be called when a draggable object is dropped into any zone. The default attribute value is "getDefaultOndropend()".
		 * Setter for ondropend
		 * @param ondropend - new value
		 */
		 public void setOndropend( ValueExpression  __ondropend ){
			this._ondropend = __ondropend;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondropout
		 * The client-side script method to be called when the draggable object is moved away from the drop zone
		 */
		private ValueExpression _ondropout;
		/**
		 * The client-side script method to be called when the draggable object is moved away from the drop zone
		 * Setter for ondropout
		 * @param ondropout - new value
		 */
		 public void setOndropout( ValueExpression  __ondropout ){
			this._ondropout = __ondropout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondropover
		 * The client-side script method to be called when the draggable object is over the drop zone
		 */
		private ValueExpression _ondropover;
		/**
		 * The client-side script method to be called when the draggable object is over the drop zone
		 * Setter for ondropover
		 * @param ondropover - new value
		 */
		 public void setOndropover( ValueExpression  __ondropover ){
			this._ondropover = __ondropover;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onexpand
		 * The client-side script method to be called when a node is expanded
		 */
		private ValueExpression _onexpand;
		/**
		 * The client-side script method to be called when a node is expanded
		 * Setter for onexpand
		 * @param onexpand - new value
		 */
		 public void setOnexpand( ValueExpression  __onexpand ){
			this._onexpand = __onexpand;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onselected
		 * The client-side script method to be called when a node is selected
		 */
		private ValueExpression _onselected;
		/**
		 * The client-side script method to be called when a node is selected
		 * Setter for onselected
		 * @param onselected - new value
		 */
		 public void setOnselected( ValueExpression  __onselected ){
			this._onselected = __onselected;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * process
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _process;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for process
		 * @param process - new value
		 */
		 public void setProcess( ValueExpression  __process ){
			this._process = __process;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, 
		   	rendered in case of AjaxRequest  caused by this component. 
		   	Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection. Default value is "getDefaultReRender()".
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, 
		   	rendered in case of AjaxRequest  caused by this component. 
		   	Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection. Default value is "getDefaultReRender()".
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rejectCursors
		 * List of comma separated cursors that indicates when rejectable draggable over dropzone
		 */
		private ValueExpression _rejectCursors;
		/**
		 * List of comma separated cursors that indicates when rejectable draggable over dropzone
		 * Setter for rejectCursors
		 * @param rejectCursors - new value
		 */
		 public void setRejectCursors( ValueExpression  __rejectCursors ){
			this._rejectCursors = __rejectCursors;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * requestDelay
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 */
		private ValueExpression _requestDelay;
		/**
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 * Setter for requestDelay
		 * @param requestDelay - new value
		 */
		 public void setRequestDelay( ValueExpression  __requestDelay ){
			this._requestDelay = __requestDelay;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectedClass
		 * Assigns one or more space-separated CSS class names to the component selected node
		 */
		private ValueExpression _selectedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component selected node
		 * Setter for selectedClass
		 * @param selectedClass - new value
		 */
		 public void setSelectedClass( ValueExpression  __selectedClass ){
			this._selectedClass = __selectedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * similarityGroupingId
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 */
		private ValueExpression _similarityGroupingId;
		/**
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 * Setter for similarityGroupingId
		 * @param similarityGroupingId - new value
		 */
		 public void setSimilarityGroupingId( ValueExpression  __similarityGroupingId ){
			this._similarityGroupingId = __similarityGroupingId;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * timeout
		 * Gets timeout in ms. Default value is "getDefaultTimeout()".
		 */
		private ValueExpression _timeout;
		/**
		 * Gets timeout in ms. Default value is "getDefaultTimeout()".
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * type
		 * A node type
		 */
		private ValueExpression _type;
		/**
		 * A node type
		 * Setter for type
		 * @param type - new value
		 */
		 public void setType( ValueExpression  __type ){
			this._type = __type;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * typeMapping
		 * The attribute associates a type of dragable zone (dragType) with &amp;lt;rich:dndParam&amp;gt; defined for &amp;lt;rich:dropSupport&amp;gt; for passing parameter value to &amp;lt;rich:dragIndicator&amp;gt;. It uses JSON format: (drag_type: parameter_name).
		 */
		private ValueExpression _typeMapping;
		/**
		 * The attribute associates a type of dragable zone (dragType) with &amp;lt;rich:dndParam&amp;gt; defined for &amp;lt;rich:dropSupport&amp;gt; for passing parameter value to &amp;lt;rich:dragIndicator&amp;gt;. It uses JSON format: (drag_type: parameter_name).
		 * Setter for typeMapping
		 * @param typeMapping - new value
		 */
		 public void setTypeMapping( ValueExpression  __typeMapping ){
			this._typeMapping = __typeMapping;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._acceptCursors = null;
	 		 		    this._acceptedTypes = null;
	 		 		    this._ajaxSingle = null;
	 		 		    this._ajaxSubmitSelection = null;
	 		 		 		    this._bypassUpdates = null;
	 		 		    this._changeExpandListener = null;
	 		 		 		    this._cursorTypeMapping = null;
	 		 		    this._data = null;
	 		 		    this._dragIndicator = null;
	 		 		    this._dragListener = null;
	 		 		 		    this._dragType = null;
	 		 		    this._dragValue = null;
	 		 		    this._dropListener = null;
	 		 		 		    this._dropValue = null;
	 		 		    this._eventsQueue = null;
	 		 		 		    this._focus = null;
	 		 		    this._grabCursors = null;
	 		 		    this._grabbingCursors = null;
	 		 		    this._highlightedClass = null;
	 		 		    this._icon = null;
	 		 		    this._iconCollapsed = null;
	 		 		 		    this._iconExpanded = null;
	 		 		 		 		    this._iconLeaf = null;
	 		 		 		 		    this._ignoreDupResponses = null;
	 		 		    this._limitToList = null;
	 		 		    this._nodeClass = null;
	 		 		    this._nodeSelectListener = null;
	 		 		 		    this._onbeforedomupdate = null;
	 		 		 		    this._oncollapse = null;
	 		 		    this._oncomplete = null;
	 		 		    this._oncontextmenu = null;
	 		 		 		    this._ondragend = null;
	 		 		    this._ondragenter = null;
	 		 		    this._ondragexit = null;
	 		 		    this._ondragstart = null;
	 		 		    this._ondrop = null;
	 		 		    this._ondropend = null;
	 		 		    this._ondropout = null;
	 		 		    this._ondropover = null;
	 		 		    this._onexpand = null;
	 		 		 		 		 		 		 		 		 		 		    this._onselected = null;
	 		 		    this._process = null;
	 		 		    this._reRender = null;
	 		 		    this._rejectCursors = null;
	 		 		 		    this._requestDelay = null;
	 		 		    this._selectedClass = null;
	 		 		    this._similarityGroupingId = null;
	 		 		    this._status = null;
	 		 		    this._timeout = null;
	 		 		    this._type = null;
	 		 		    this._typeMapping = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlTreeNode comp = (HtmlTreeNode) component;
  		 			 
						if (this._acceptCursors != null) {
				if (this._acceptCursors.isLiteralText()) {
					try {
												
						java.lang.String __acceptCursors = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._acceptCursors.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAcceptCursors(__acceptCursors);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("acceptCursors", this._acceptCursors);
				}
			}
					   		 			 
						if (this._acceptedTypes != null) {
				if (this._acceptedTypes.isLiteralText()) {
					try {
												
						java.lang.Object __acceptedTypes = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._acceptedTypes.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setAcceptedTypes(__acceptedTypes);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("acceptedTypes", this._acceptedTypes);
				}
			}
					   		 			 
						if (this._ajaxSingle != null) {
				if (this._ajaxSingle.isLiteralText()) {
					try {
												
						Boolean __ajaxSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxSingle(__ajaxSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSingle", this._ajaxSingle);
				}
			}
					   		 			 
						if (this._ajaxSubmitSelection != null) {
				if (this._ajaxSubmitSelection.isLiteralText()) {
					try {
												
						java.lang.String __ajaxSubmitSelection = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSubmitSelection.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAjaxSubmitSelection(__ajaxSubmitSelection);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSubmitSelection", this._ajaxSubmitSelection);
				}
			}
					    		 			 
						if (this._bypassUpdates != null) {
				if (this._bypassUpdates.isLiteralText()) {
					try {
												
						Boolean __bypassUpdates = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bypassUpdates.getExpressionString(), 
											Boolean.class);
					
												comp.setBypassUpdates(__bypassUpdates.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bypassUpdates", this._bypassUpdates);
				}
			}
					   		 			if(null != this._changeExpandListener){
             if (!this._changeExpandListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._changeExpandListener);
                ((HtmlTreeNode)component).setChangeExpandListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid changeExpandListener value: " + this._changeExpandListener);
             }
			}
		    		 			 
						if (this._cursorTypeMapping != null) {
				if (this._cursorTypeMapping.isLiteralText()) {
					try {
												
						java.lang.Object __cursorTypeMapping = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cursorTypeMapping.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setCursorTypeMapping(__cursorTypeMapping);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cursorTypeMapping", this._cursorTypeMapping);
				}
			}
					   		 			 
						if (this._data != null) {
				if (this._data.isLiteralText()) {
					try {
												
						java.lang.Object __data = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._data.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setData(__data);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("data", this._data);
				}
			}
					   		 			 
						if (this._dragIndicator != null) {
				if (this._dragIndicator.isLiteralText()) {
					try {
												
						java.lang.String __dragIndicator = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dragIndicator.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDragIndicator(__dragIndicator);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dragIndicator", this._dragIndicator);
				}
			}
					   		 			if(null != this._dragListener){
             if (!this._dragListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._dragListener);
                ((HtmlTreeNode)component).setDragListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid dragListener value: " + this._dragListener);
             }
			}
		    		 			 
						if (this._dragType != null) {
				if (this._dragType.isLiteralText()) {
					try {
												
						java.lang.String __dragType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dragType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDragType(__dragType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dragType", this._dragType);
				}
			}
					   		 			 
						if (this._dragValue != null) {
				if (this._dragValue.isLiteralText()) {
					try {
												
						java.lang.Object __dragValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dragValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setDragValue(__dragValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dragValue", this._dragValue);
				}
			}
					   		 			if(null != this._dropListener){
             if (!this._dropListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._dropListener);
                ((HtmlTreeNode)component).setDropListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid dropListener value: " + this._dropListener);
             }
			}
		    		 			 
						if (this._dropValue != null) {
				if (this._dropValue.isLiteralText()) {
					try {
												
						java.lang.Object __dropValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dropValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setDropValue(__dropValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dropValue", this._dropValue);
				}
			}
					   		 			 
						if (this._eventsQueue != null) {
				if (this._eventsQueue.isLiteralText()) {
					try {
												
						java.lang.String __eventsQueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._eventsQueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEventsQueue(__eventsQueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("eventsQueue", this._eventsQueue);
				}
			}
					    		 			 
						if (this._focus != null) {
				if (this._focus.isLiteralText()) {
					try {
												
						java.lang.String __focus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._focus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFocus(__focus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("focus", this._focus);
				}
			}
					   		 			 
						if (this._grabCursors != null) {
				if (this._grabCursors.isLiteralText()) {
					try {
												
						java.lang.String __grabCursors = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._grabCursors.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGrabCursors(__grabCursors);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("grabCursors", this._grabCursors);
				}
			}
					   		 			 
						if (this._grabbingCursors != null) {
				if (this._grabbingCursors.isLiteralText()) {
					try {
												
						java.lang.String __grabbingCursors = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._grabbingCursors.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGrabbingCursors(__grabbingCursors);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("grabbingCursors", this._grabbingCursors);
				}
			}
					   		 			 
						if (this._highlightedClass != null) {
				if (this._highlightedClass.isLiteralText()) {
					try {
												
						java.lang.String __highlightedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._highlightedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHighlightedClass(__highlightedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("highlightedClass", this._highlightedClass);
				}
			}
					   		 			 
						if (this._icon != null) {
				if (this._icon.isLiteralText()) {
					try {
												
						java.lang.String __icon = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._icon.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIcon(__icon);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("icon", this._icon);
				}
			}
					   		 			 
						if (this._iconCollapsed != null) {
				if (this._iconCollapsed.isLiteralText()) {
					try {
												
						java.lang.String __iconCollapsed = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconCollapsed.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconCollapsed(__iconCollapsed);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconCollapsed", this._iconCollapsed);
				}
			}
					    		 			 
						if (this._iconExpanded != null) {
				if (this._iconExpanded.isLiteralText()) {
					try {
												
						java.lang.String __iconExpanded = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconExpanded.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconExpanded(__iconExpanded);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconExpanded", this._iconExpanded);
				}
			}
					     		 			 
						if (this._iconLeaf != null) {
				if (this._iconLeaf.isLiteralText()) {
					try {
												
						java.lang.String __iconLeaf = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconLeaf.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconLeaf(__iconLeaf);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconLeaf", this._iconLeaf);
				}
			}
					     		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					   		 			 
						if (this._limitToList != null) {
				if (this._limitToList.isLiteralText()) {
					try {
												
						Boolean __limitToList = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._limitToList.getExpressionString(), 
											Boolean.class);
					
												comp.setLimitToList(__limitToList.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("limitToList", this._limitToList);
				}
			}
					   		 			 
						if (this._nodeClass != null) {
				if (this._nodeClass.isLiteralText()) {
					try {
												
						java.lang.String __nodeClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._nodeClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setNodeClass(__nodeClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("nodeClass", this._nodeClass);
				}
			}
					   		 			if(null != this._nodeSelectListener){
             if (!this._nodeSelectListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._nodeSelectListener);
                ((HtmlTreeNode)component).setNodeSelectListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid nodeSelectListener value: " + this._nodeSelectListener);
             }
			}
		    		 			 
						if (this._onbeforedomupdate != null) {
				if (this._onbeforedomupdate.isLiteralText()) {
					try {
												
						java.lang.String __onbeforedomupdate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbeforedomupdate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbeforedomupdate(__onbeforedomupdate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbeforedomupdate", this._onbeforedomupdate);
				}
			}
					    		 			 
						if (this._oncollapse != null) {
				if (this._oncollapse.isLiteralText()) {
					try {
												
						java.lang.String __oncollapse = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncollapse.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncollapse(__oncollapse);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncollapse", this._oncollapse);
				}
			}
					   		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					   		 			 
						if (this._oncontextmenu != null) {
				if (this._oncontextmenu.isLiteralText()) {
					try {
												
						java.lang.String __oncontextmenu = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncontextmenu.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncontextmenu(__oncontextmenu);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncontextmenu", this._oncontextmenu);
				}
			}
					    		 			 
						if (this._ondragend != null) {
				if (this._ondragend.isLiteralText()) {
					try {
												
						java.lang.String __ondragend = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondragend.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndragend(__ondragend);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondragend", this._ondragend);
				}
			}
					   		 			 
						if (this._ondragenter != null) {
				if (this._ondragenter.isLiteralText()) {
					try {
												
						java.lang.String __ondragenter = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondragenter.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndragenter(__ondragenter);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondragenter", this._ondragenter);
				}
			}
					   		 			 
						if (this._ondragexit != null) {
				if (this._ondragexit.isLiteralText()) {
					try {
												
						java.lang.String __ondragexit = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondragexit.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndragexit(__ondragexit);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondragexit", this._ondragexit);
				}
			}
					   		 			 
						if (this._ondragstart != null) {
				if (this._ondragstart.isLiteralText()) {
					try {
												
						java.lang.String __ondragstart = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondragstart.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndragstart(__ondragstart);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondragstart", this._ondragstart);
				}
			}
					   		 			 
						if (this._ondrop != null) {
				if (this._ondrop.isLiteralText()) {
					try {
												
						java.lang.String __ondrop = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondrop.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndrop(__ondrop);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondrop", this._ondrop);
				}
			}
					   		 			 
						if (this._ondropend != null) {
				if (this._ondropend.isLiteralText()) {
					try {
												
						java.lang.String __ondropend = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondropend.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndropend(__ondropend);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondropend", this._ondropend);
				}
			}
					   		 			 
						if (this._ondropout != null) {
				if (this._ondropout.isLiteralText()) {
					try {
												
						java.lang.String __ondropout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondropout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndropout(__ondropout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondropout", this._ondropout);
				}
			}
					   		 			 
						if (this._ondropover != null) {
				if (this._ondropover.isLiteralText()) {
					try {
												
						java.lang.String __ondropover = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondropover.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndropover(__ondropover);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondropover", this._ondropover);
				}
			}
					   		 			 
						if (this._onexpand != null) {
				if (this._onexpand.isLiteralText()) {
					try {
												
						java.lang.String __onexpand = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onexpand.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnexpand(__onexpand);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onexpand", this._onexpand);
				}
			}
					           		 			 
						if (this._onselected != null) {
				if (this._onselected.isLiteralText()) {
					try {
												
						java.lang.String __onselected = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselected.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselected(__onselected);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselected", this._onselected);
				}
			}
					   		 			 
						if (this._process != null) {
				if (this._process.isLiteralText()) {
					try {
												
						java.lang.Object __process = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._process.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setProcess(__process);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("process", this._process);
				}
			}
					   		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					   		 			 
						if (this._rejectCursors != null) {
				if (this._rejectCursors.isLiteralText()) {
					try {
												
						java.lang.String __rejectCursors = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rejectCursors.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRejectCursors(__rejectCursors);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rejectCursors", this._rejectCursors);
				}
			}
					    		 			 
						if (this._requestDelay != null) {
				if (this._requestDelay.isLiteralText()) {
					try {
												
						Integer __requestDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requestDelay.getExpressionString(), 
											Integer.class);
					
												comp.setRequestDelay(__requestDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requestDelay", this._requestDelay);
				}
			}
					   		 			 
						if (this._selectedClass != null) {
				if (this._selectedClass.isLiteralText()) {
					try {
												
						java.lang.String __selectedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectedClass(__selectedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectedClass", this._selectedClass);
				}
			}
					   		 			 
						if (this._similarityGroupingId != null) {
				if (this._similarityGroupingId.isLiteralText()) {
					try {
												
						java.lang.String __similarityGroupingId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._similarityGroupingId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSimilarityGroupingId(__similarityGroupingId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("similarityGroupingId", this._similarityGroupingId);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					   		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					   		 			 
						if (this._type != null) {
				if (this._type.isLiteralText()) {
					try {
												
						java.lang.String __type = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._type.getExpressionString(), 
											java.lang.String.class);
					
												comp.setType(__type);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("type", this._type);
				}
			}
					   		 			 
						if (this._typeMapping != null) {
				if (this._typeMapping.isLiteralText()) {
					try {
												
						java.lang.Object __typeMapping = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._typeMapping.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setTypeMapping(__typeMapping);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("typeMapping", this._typeMapping);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.TreeNode";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.TreeNodeRenderer";
			}

}
