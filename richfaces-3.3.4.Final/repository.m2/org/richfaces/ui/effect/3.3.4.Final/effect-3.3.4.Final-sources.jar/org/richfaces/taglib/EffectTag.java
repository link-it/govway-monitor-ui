/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlEffect;

public class EffectTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * disableDefault
		 * Disable default action for target event ( append "return false;" to JavaScript ). Default value is "false".
		 */
		private ValueExpression _disableDefault;
		/**
		 * Disable default action for target event ( append "return false;" to JavaScript ). Default value is "false".
		 * Setter for disableDefault
		 * @param disableDefault - new value
		 */
		 public void setDisableDefault( ValueExpression  __disableDefault ){
			this._disableDefault = __disableDefault;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * event
		 * Event on the component or html tag the effect is attached to
		 */
		private String _event;
		/**
		 * Event on the component or html tag the effect is attached to
		 * Setter for event
		 * @param event - new value
		 */
		 public void setEvent( String  __event ){
			this._event = __event;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * for
		 * Id of the target component.
		 */
		private ValueExpression _for;
		/**
		 * Id of the target component.
		 * Setter for for
		 * @param for - new value
		 */
		 public void setFor( ValueExpression  __for ){
			this._for = __for;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * name
		 * Generated JavaScript name.
		 */
		private ValueExpression _name;
		/**
		 * Generated JavaScript name.
		 * Setter for name
		 * @param name - new value
		 */
		 public void setName( ValueExpression  __name ){
			this._name = __name;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * params
		 * Parameters passed to the effect function.
			  Example params="{duration:0.2,from:1.0,to:0.1}"
		 */
		private ValueExpression _params;
		/**
		 * Parameters passed to the effect function.
			  Example params="{duration:0.2,from:1.0,to:0.1}"
		 * Setter for params
		 * @param params - new value
		 */
		 public void setParams( ValueExpression  __params ){
			this._params = __params;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * targetId
		 * The id of the element the effect apply to. Might be component id
			  or client id of jsf component or html tag. If targetId is not defined
			  the value of the attribute 'for' or the 'targetId' option effect
			  play its role
		 */
		private ValueExpression _targetId;
		/**
		 * The id of the element the effect apply to. Might be component id
			  or client id of jsf component or html tag. If targetId is not defined
			  the value of the attribute 'for' or the 'targetId' option effect
			  play its role
		 * Setter for targetId
		 * @param targetId - new value
		 */
		 public void setTargetId( ValueExpression  __targetId ){
			this._targetId = __targetId;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * type
		 * Defines the type of effect. Possible values: "Fade", "Blind", "Opacity".
		 */
		private ValueExpression _type;
		/**
		 * Defines the type of effect. Possible values: "Fade", "Blind", "Opacity".
		 * Setter for type
		 * @param type - new value
		 */
		 public void setType( ValueExpression  __type ){
			this._type = __type;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._disableDefault = null;
	 		 		    this._event = null;
	 		 		 		 		    this._for = null;
	 		 		 		    this._name = null;
	 		 		 		    this._params = null;
	 		 		 		 		    this._targetId = null;
	 		 		    this._type = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlEffect comp = (HtmlEffect) component;
  		 			 
						if (this._disableDefault != null) {
				if (this._disableDefault.isLiteralText()) {
					try {
												
						Boolean __disableDefault = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disableDefault.getExpressionString(), 
											Boolean.class);
					
												comp.setDisableDefault(__disableDefault.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disableDefault", this._disableDefault);
				}
			}
					   		 			 
											if (this._event != null) {
					comp.setEvent(this._event);
				}
									     		 			 
						if (this._for != null) {
				if (this._for.isLiteralText()) {
					try {
												
						java.lang.String __for = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._for.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFor(__for);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("for", this._for);
				}
			}
					    		 			 
						if (this._name != null) {
				if (this._name.isLiteralText()) {
					try {
												
						java.lang.String __name = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._name.getExpressionString(), 
											java.lang.String.class);
					
												comp.setName(__name);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("name", this._name);
				}
			}
					    		 			 
						if (this._params != null) {
				if (this._params.isLiteralText()) {
					try {
												
						java.lang.String __params = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._params.getExpressionString(), 
											java.lang.String.class);
					
												comp.setParams(__params);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("params", this._params);
				}
			}
					     		 			 
						if (this._targetId != null) {
				if (this._targetId.isLiteralText()) {
					try {
												
						java.lang.String __targetId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTargetId(__targetId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetId", this._targetId);
				}
			}
					   		 			 
						if (this._type != null) {
				if (this._type.isLiteralText()) {
					try {
												
						java.lang.String __type = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._type.getExpressionString(), 
											java.lang.String.class);
					
												comp.setType(__type);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("type", this._type);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.Effect";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.EffectRenderer";
			}

}
