/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.richfaces.taglib.DataFilterSliderTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import java.lang.Integer ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlDataFilterSlider;

public class DataFilterSliderTag extends org.richfaces.taglib.DataFilterSliderTagBase {

		// Fields
		 		 	  	  	  
		/*
		 * action
		 * MethodBinding pointing at the application action to be invoked,
            if this UIComponent is activated by you, during the Apply
            Request Values or Invoke Application phase of the request
            processing lifecycle, depending on the value of the immediate
            property
		 */
		private MethodExpression _action;
		/**
		 * MethodBinding pointing at the application action to be invoked,
            if this UIComponent is activated by you, during the Apply
            Request Values or Invoke Application phase of the request
            processing lifecycle, depending on the value of the immediate
            property
		 * Setter for action
		 * @param action - new value
		 */
		 public void setAction( MethodExpression  __action ){
			this._action = __action;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * actionListener
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 */
		private MethodExpression _actionListener;
		/**
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 * Setter for actionListener
		 * @param actionListener - new value
		 */
		 public void setActionListener( MethodExpression  __actionListener ){
			this._actionListener = __actionListener;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * ajaxSingle
		 * Limits JSF tree processing (decoding, conversion, validation and model updating) only to a component that sends the request. Boolean. Default value is "false".
		 */
		private ValueExpression _ajaxSingle;
		/**
		 * Limits JSF tree processing (decoding, conversion, validation and model updating) only to a component that sends the request. Boolean. Default value is "false".
		 * Setter for ajaxSingle
		 * @param ajaxSingle - new value
		 */
		 public void setAjaxSingle( ValueExpression  __ajaxSingle ){
			this._ajaxSingle = __ajaxSingle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * bypassUpdates
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 */
		private ValueExpression _bypassUpdates;
		/**
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 * Setter for bypassUpdates
		 * @param bypassUpdates - new value
		 */
		 public void setBypassUpdates( ValueExpression  __bypassUpdates ){
			this._bypassUpdates = __bypassUpdates;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * clientErrorMessage
		 * An error message to use in client-side validation events
		 */
		private ValueExpression _clientErrorMessage;
		/**
		 * An error message to use in client-side validation events
		 * Setter for clientErrorMessage
		 * @param clientErrorMessage - new value
		 */
		 public void setClientErrorMessage( ValueExpression  __clientErrorMessage ){
			this._clientErrorMessage = __clientErrorMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * data
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 */
		private ValueExpression _data;
		/**
		 * Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
		 * Setter for data
		 * @param data - new value
		 */
		 public void setData( ValueExpression  __data ){
			this._data = __data;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * endRange
		 * A slider end point
		 */
		private ValueExpression _endRange;
		/**
		 * A slider end point
		 * Setter for endRange
		 * @param endRange - new value
		 */
		 public void setEndRange( ValueExpression  __endRange ){
			this._endRange = __endRange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * eventsQueue
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 */
		private ValueExpression _eventsQueue;
		/**
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 * Setter for eventsQueue
		 * @param eventsQueue - new value
		 */
		 public void setEventsQueue( ValueExpression  __eventsQueue ){
			this._eventsQueue = __eventsQueue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fieldStyleClass
		 * Assigns one or more space-separated CSS class names to the component input field. The value of the "manualInput" attribute must
            	be "true".
		 */
		private ValueExpression _fieldStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component input field. The value of the "manualInput" attribute must
            	be "true".
		 * Setter for fieldStyleClass
		 * @param fieldStyleClass - new value
		 */
		 public void setFieldStyleClass( ValueExpression  __fieldStyleClass ){
			this._fieldStyleClass = __fieldStyleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * filterBy
		 * A getter of an object member required to compare a slider value to. This is a
                value that is used in results filtering
		 */
		private ValueExpression _filterBy;
		/**
		 * A getter of an object member required to compare a slider value to. This is a
                value that is used in results filtering
		 * Setter for filterBy
		 * @param filterBy - new value
		 */
		 public void setFilterBy( ValueExpression  __filterBy ){
			this._filterBy = __filterBy;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * focus
		 * ID of an element to set focus after request is completed on client side
		 */
		private ValueExpression _focus;
		/**
		 * ID of an element to set focus after request is completed on client side
		 * Setter for focus
		 * @param focus - new value
		 */
		 public void setFocus( ValueExpression  __focus ){
			this._focus = __focus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * for
		 * The component using UIData (datatable id)
		 */
		private ValueExpression _for;
		/**
		 * The component using UIData (datatable id)
		 * Setter for for
		 * @param for - new value
		 */
		 public void setFor( ValueExpression  __for ){
			this._for = __for;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * forValRef
		 * This is a string which is used in a value attribute of the datatable. It is used for resetting
                the datatable back to the original list provided by a backing bean
		 */
		private ValueExpression _forValRef;
		/**
		 * This is a string which is used in a value attribute of the datatable. It is used for resetting
                the datatable back to the original list provided by a backing bean
		 * Setter for forValRef
		 * @param forValRef - new value
		 */
		 public void setForValRef( ValueExpression  __forValRef ){
			this._forValRef = __forValRef;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * handleStyleClass
		 * Assigns one or more space-separated CSS class names to the component handle
		 */
		private ValueExpression _handleStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component handle
		 * Setter for handleStyleClass
		 * @param handleStyleClass - new value
		 */
		 public void setHandleStyleClass( ValueExpression  __handleStyleClass ){
			this._handleStyleClass = __handleStyleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * handleValue
		 * Current handle value
		 */
		private ValueExpression _handleValue;
		/**
		 * Current handle value
		 * Setter for handleValue
		 * @param handleValue - new value
		 */
		 public void setHandleValue( ValueExpression  __handleValue ){
			this._handleValue = __handleValue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * immediate
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 */
		private ValueExpression _immediate;
		/**
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * increment
		 * Amount to which a handle on each slide/move should be incremented
		 */
		private ValueExpression _increment;
		/**
		 * Amount to which a handle on each slide/move should be incremented
		 * Setter for increment
		 * @param increment - new value
		 */
		 public void setIncrement( ValueExpression  __increment ){
			this._increment = __increment;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * limitToList
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 */
		private ValueExpression _limitToList;
		/**
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 * Setter for limitToList
		 * @param limitToList - new value
		 */
		 public void setLimitToList( ValueExpression  __limitToList ){
			this._limitToList = __limitToList;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * manualInput
		 * False value for this attribute makes text field "read-only" and "hidden".
                Hence, the value can be changed only from a handle.
                Default value is "true"
		 */
		private ValueExpression _manualInput;
		/**
		 * False value for this attribute makes text field "read-only" and "hidden".
                Hence, the value can be changed only from a handle.
                Default value is "true"
		 * Setter for manualInput
		 * @param manualInput - new value
		 */
		 public void setManualInput( ValueExpression  __manualInput ){
			this._manualInput = __manualInput;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onbeforedomupdate
		 * The client-side script method to be called before DOM is updated
		 */
		private ValueExpression _onbeforedomupdate;
		/**
		 * The client-side script method to be called before DOM is updated
		 * Setter for onbeforedomupdate
		 * @param onbeforedomupdate - new value
		 */
		 public void setOnbeforedomupdate( ValueExpression  __onbeforedomupdate ){
			this._onbeforedomupdate = __onbeforedomupdate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onchange
		 * The client-side script method to be called when the component input field value is changed
		 */
		private ValueExpression _onchange;
		/**
		 * The client-side script method to be called when the component input field value is changed
		 * Setter for onchange
		 * @param onchange - new value
		 */
		 public void setOnchange( ValueExpression  __onchange ){
			this._onchange = __onchange;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the request is completed
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the request is completed
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onerror
		 * The client-side script method to be called whenever a
        		JavaScript error occurs
		 */
		private ValueExpression _onerror;
		/**
		 * The client-side script method to be called whenever a
        		JavaScript error occurs
		 * Setter for onerror
		 * @param onerror - new value
		 */
		 public void setOnerror( ValueExpression  __onerror ){
			this._onerror = __onerror;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeydown
		 * The client-side script method to be called when a key is pressed down in the component input field
		 */
		private ValueExpression _oninputkeydown;
		/**
		 * The client-side script method to be called when a key is pressed down in the component input field
		 * Setter for oninputkeydown
		 * @param oninputkeydown - new value
		 */
		 public void setOninputkeydown( ValueExpression  __oninputkeydown ){
			this._oninputkeydown = __oninputkeydown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeypress
		 * The client-side script method to be called when a key is pressed and released in the component input field
		 */
		private ValueExpression _oninputkeypress;
		/**
		 * The client-side script method to be called when a key is pressed and released in the component input field
		 * Setter for oninputkeypress
		 * @param oninputkeypress - new value
		 */
		 public void setOninputkeypress( ValueExpression  __oninputkeypress ){
			this._oninputkeypress = __oninputkeypress;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeyup
		 * The client-side script method to be called when a key is released in the component input field
		 */
		private ValueExpression _oninputkeyup;
		/**
		 * The client-side script method to be called when a key is released in the component input field
		 * Setter for oninputkeyup
		 * @param oninputkeyup - new value
		 */
		 public void setOninputkeyup( ValueExpression  __oninputkeyup ){
			this._oninputkeyup = __oninputkeyup;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onslide
		 * The client-side script method to be called when a slider handle is moved
		 */
		private ValueExpression _onslide;
		/**
		 * The client-side script method to be called when a slider handle is moved
		 * Setter for onslide
		 * @param onslide - new value
		 */
		 public void setOnslide( ValueExpression  __onslide ){
			this._onslide = __onslide;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * process
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _process;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for process
		 * @param process - new value
		 */
		 public void setProcess( ValueExpression  __process ){
			this._process = __process;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rangeStyleClass
		 * Assigns one or more space-separated CSS class names to the background div element wrapping a full range
		 */
		private ValueExpression _rangeStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the background div element wrapping a full range
		 * Setter for rangeStyleClass
		 * @param rangeStyleClass - new value
		 */
		 public void setRangeStyleClass( ValueExpression  __rangeStyleClass ){
			this._rangeStyleClass = __rangeStyleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * requestDelay
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 */
		private ValueExpression _requestDelay;
		/**
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 * Setter for requestDelay
		 * @param requestDelay - new value
		 */
		 public void setRequestDelay( ValueExpression  __requestDelay ){
			this._requestDelay = __requestDelay;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * similarityGroupingId
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 */
		private ValueExpression _similarityGroupingId;
		/**
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 * Setter for similarityGroupingId
		 * @param similarityGroupingId - new value
		 */
		 public void setSimilarityGroupingId( ValueExpression  __similarityGroupingId ){
			this._similarityGroupingId = __similarityGroupingId;
	     }
	  
	 	 		 	  	  	  
		/*
		 * sliderListener
		 * MethodBinding representing an action listener method that will be notified after changing of slider control position
		 */
		private MethodExpression _sliderListener;
		/**
		 * MethodBinding representing an action listener method that will be notified after changing of slider control position
		 * Setter for sliderListener
		 * @param sliderListener - new value
		 */
		 public void setSliderListener( MethodExpression  __sliderListener ){
			this._sliderListener = __sliderListener;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * startRange
		 * A slider begin point
		 */
		private ValueExpression _startRange;
		/**
		 * A slider begin point
		 * Setter for startRange
		 * @param startRange - new value
		 */
		 public void setStartRange( ValueExpression  __startRange ){
			this._startRange = __startRange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * storeResults
		 * Specifies if the component will store a UIData object (your table rows) in session
		 */
		private ValueExpression _storeResults;
		/**
		 * Specifies if the component will store a UIData object (your table rows) in session
		 * Setter for storeResults
		 * @param storeResults - new value
		 */
		 public void setStoreResults( ValueExpression  __storeResults ){
			this._storeResults = __storeResults;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * timeout
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 */
		private ValueExpression _timeout;
		/**
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * trackStyleClass
		 * Assigns one or more space-separated CSS class names to the component track
		 */
		private ValueExpression _trackStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component track
		 * Setter for trackStyleClass
		 * @param trackStyleClass - new value
		 */
		 public void setTrackStyleClass( ValueExpression  __trackStyleClass ){
			this._trackStyleClass = __trackStyleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * trailer
		 * It shows or hides a trailer following a handle
		 */
		private ValueExpression _trailer;
		/**
		 * It shows or hides a trailer following a handle
		 * Setter for trailer
		 * @param trailer - new value
		 */
		 public void setTrailer( ValueExpression  __trailer ){
			this._trailer = __trailer;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * trailerStyleClass
		 * Assigns one or more space-separated CSS class names to the trailer following the component handle
		 */
		private ValueExpression _trailerStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the trailer following the component handle
		 * Setter for trailerStyleClass
		 * @param trailerStyleClass - new value
		 */
		 public void setTrailerStyleClass( ValueExpression  __trailerStyleClass ){
			this._trailerStyleClass = __trailerStyleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * Width of the slider control. Default value is "200px".
		 */
		private ValueExpression _width;
		/**
		 * Width of the slider control. Default value is "200px".
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._action = null;
	 		 		 		    this._actionListener = null;
	 		 		 		 		 		    this._ajaxSingle = null;
	 		 		 		    this._bypassUpdates = null;
	 		 		    this._clientErrorMessage = null;
	 		 		    this._data = null;
	 		 		    this._endRange = null;
	 		 		    this._eventsQueue = null;
	 		 		 		    this._fieldStyleClass = null;
	 		 		    this._filterBy = null;
	 		 		    this._focus = null;
	 		 		    this._for = null;
	 		 		    this._forValRef = null;
	 		 		    this._handleStyleClass = null;
	 		 		    this._handleValue = null;
	 		 		 		    this._ignoreDupResponses = null;
	 		 		    this._immediate = null;
	 		 		    this._increment = null;
	 		 		    this._limitToList = null;
	 		 		    this._manualInput = null;
	 		 		 		    this._onbeforedomupdate = null;
	 		 		    this._onchange = null;
	 		 		 		    this._oncomplete = null;
	 		 		 		    this._onerror = null;
	 		 		    this._oninputkeydown = null;
	 		 		    this._oninputkeypress = null;
	 		 		    this._oninputkeyup = null;
	 		 		 		 		 		 		 		 		 		 		    this._onslide = null;
	 		 		    this._process = null;
	 		 		    this._rangeStyleClass = null;
	 		 		    this._reRender = null;
	 		 		 		    this._requestDelay = null;
	 		 		    this._similarityGroupingId = null;
	 		 		    this._sliderListener = null;
	 		 		 		 		    this._startRange = null;
	 		 		    this._status = null;
	 		 		    this._storeResults = null;
	 		 		 		 		 		    this._timeout = null;
	 		 		    this._trackStyleClass = null;
	 		 		    this._trailer = null;
	 		 		    this._trailerStyleClass = null;
	 		 		    this._value = null;
	 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlDataFilterSlider comp = (HtmlDataFilterSlider) component;
  		 			setActionProperty(comp, this._action);
		    		 			setActionListenerProperty(comp, this._actionListener);
		      		 			 
						if (this._ajaxSingle != null) {
				if (this._ajaxSingle.isLiteralText()) {
					try {
												
						Boolean __ajaxSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxSingle(__ajaxSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSingle", this._ajaxSingle);
				}
			}
					    		 			 
						if (this._bypassUpdates != null) {
				if (this._bypassUpdates.isLiteralText()) {
					try {
												
						Boolean __bypassUpdates = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bypassUpdates.getExpressionString(), 
											Boolean.class);
					
												comp.setBypassUpdates(__bypassUpdates.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bypassUpdates", this._bypassUpdates);
				}
			}
					   		 			 
						if (this._clientErrorMessage != null) {
				if (this._clientErrorMessage.isLiteralText()) {
					try {
												
						java.lang.String __clientErrorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._clientErrorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setClientErrorMessage(__clientErrorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("clientErrorMessage", this._clientErrorMessage);
				}
			}
					   		 			 
						if (this._data != null) {
				if (this._data.isLiteralText()) {
					try {
												
						java.lang.Object __data = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._data.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setData(__data);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("data", this._data);
				}
			}
					   		 			 
						if (this._endRange != null) {
				if (this._endRange.isLiteralText()) {
					try {
												
						java.lang.Integer __endRange = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._endRange.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setEndRange(__endRange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("endRange", this._endRange);
				}
			}
					   		 			 
						if (this._eventsQueue != null) {
				if (this._eventsQueue.isLiteralText()) {
					try {
												
						java.lang.String __eventsQueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._eventsQueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEventsQueue(__eventsQueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("eventsQueue", this._eventsQueue);
				}
			}
					    		 			 
						if (this._fieldStyleClass != null) {
				if (this._fieldStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __fieldStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fieldStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFieldStyleClass(__fieldStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fieldStyleClass", this._fieldStyleClass);
				}
			}
					   		 			 
						if (this._filterBy != null) {
				if (this._filterBy.isLiteralText()) {
					try {
												
						java.lang.String __filterBy = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._filterBy.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFilterBy(__filterBy);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("filterBy", this._filterBy);
				}
			}
					   		 			 
						if (this._focus != null) {
				if (this._focus.isLiteralText()) {
					try {
												
						java.lang.String __focus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._focus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFocus(__focus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("focus", this._focus);
				}
			}
					   		 			 
						if (this._for != null) {
				if (this._for.isLiteralText()) {
					try {
												
						java.lang.String __for = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._for.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFor(__for);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("for", this._for);
				}
			}
					   		 			 
						if (this._forValRef != null) {
				if (this._forValRef.isLiteralText()) {
					try {
												
						java.lang.String __forValRef = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._forValRef.getExpressionString(), 
											java.lang.String.class);
					
												comp.setForValRef(__forValRef);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("forValRef", this._forValRef);
				}
			}
					   		 			 
						if (this._handleStyleClass != null) {
				if (this._handleStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __handleStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._handleStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHandleStyleClass(__handleStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("handleStyleClass", this._handleStyleClass);
				}
			}
					   		 			 
						if (this._handleValue != null) {
				if (this._handleValue.isLiteralText()) {
					try {
												
						java.lang.Integer __handleValue = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._handleValue.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setHandleValue(__handleValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("handleValue", this._handleValue);
				}
			}
					    		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					   		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._increment != null) {
				if (this._increment.isLiteralText()) {
					try {
												
						java.lang.Integer __increment = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._increment.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setIncrement(__increment);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("increment", this._increment);
				}
			}
					   		 			 
						if (this._limitToList != null) {
				if (this._limitToList.isLiteralText()) {
					try {
												
						Boolean __limitToList = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._limitToList.getExpressionString(), 
											Boolean.class);
					
												comp.setLimitToList(__limitToList.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("limitToList", this._limitToList);
				}
			}
					   		 			 
						if (this._manualInput != null) {
				if (this._manualInput.isLiteralText()) {
					try {
												
						Boolean __manualInput = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._manualInput.getExpressionString(), 
											Boolean.class);
					
												comp.setManualInput(__manualInput.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("manualInput", this._manualInput);
				}
			}
					    		 			 
						if (this._onbeforedomupdate != null) {
				if (this._onbeforedomupdate.isLiteralText()) {
					try {
												
						java.lang.String __onbeforedomupdate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbeforedomupdate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbeforedomupdate(__onbeforedomupdate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbeforedomupdate", this._onbeforedomupdate);
				}
			}
					   		 			 
						if (this._onchange != null) {
				if (this._onchange.isLiteralText()) {
					try {
												
						java.lang.String __onchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnchange(__onchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onchange", this._onchange);
				}
			}
					    		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					    		 			 
						if (this._onerror != null) {
				if (this._onerror.isLiteralText()) {
					try {
												
						java.lang.String __onerror = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onerror.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnerror(__onerror);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onerror", this._onerror);
				}
			}
					   		 			 
						if (this._oninputkeydown != null) {
				if (this._oninputkeydown.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeydown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeydown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeydown(__oninputkeydown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeydown", this._oninputkeydown);
				}
			}
					   		 			 
						if (this._oninputkeypress != null) {
				if (this._oninputkeypress.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeypress = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeypress.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeypress(__oninputkeypress);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeypress", this._oninputkeypress);
				}
			}
					   		 			 
						if (this._oninputkeyup != null) {
				if (this._oninputkeyup.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeyup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeyup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeyup(__oninputkeyup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeyup", this._oninputkeyup);
				}
			}
					           		 			 
						if (this._onslide != null) {
				if (this._onslide.isLiteralText()) {
					try {
												
						java.lang.String __onslide = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onslide.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnslide(__onslide);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onslide", this._onslide);
				}
			}
					   		 			 
						if (this._process != null) {
				if (this._process.isLiteralText()) {
					try {
												
						java.lang.Object __process = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._process.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setProcess(__process);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("process", this._process);
				}
			}
					   		 			 
						if (this._rangeStyleClass != null) {
				if (this._rangeStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __rangeStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rangeStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRangeStyleClass(__rangeStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rangeStyleClass", this._rangeStyleClass);
				}
			}
					   		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					    		 			 
						if (this._requestDelay != null) {
				if (this._requestDelay.isLiteralText()) {
					try {
												
						Integer __requestDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requestDelay.getExpressionString(), 
											Integer.class);
					
												comp.setRequestDelay(__requestDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requestDelay", this._requestDelay);
				}
			}
					   		 			 
						if (this._similarityGroupingId != null) {
				if (this._similarityGroupingId.isLiteralText()) {
					try {
												
						java.lang.String __similarityGroupingId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._similarityGroupingId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSimilarityGroupingId(__similarityGroupingId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("similarityGroupingId", this._similarityGroupingId);
				}
			}
					   		 			if(null != this._sliderListener){
             if (!this._sliderListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._sliderListener);
                ((HtmlDataFilterSlider)component).setSliderListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid sliderListener value: " + this._sliderListener);
             }
			}
		     		 			 
						if (this._startRange != null) {
				if (this._startRange.isLiteralText()) {
					try {
												
						java.lang.Integer __startRange = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._startRange.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setStartRange(__startRange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("startRange", this._startRange);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					   		 			 
						if (this._storeResults != null) {
				if (this._storeResults.isLiteralText()) {
					try {
												
						Boolean __storeResults = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._storeResults.getExpressionString(), 
											Boolean.class);
					
												comp.setStoreResults(__storeResults.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("storeResults", this._storeResults);
				}
			}
					      		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					   		 			 
						if (this._trackStyleClass != null) {
				if (this._trackStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __trackStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._trackStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTrackStyleClass(__trackStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("trackStyleClass", this._trackStyleClass);
				}
			}
					   		 			 
						if (this._trailer != null) {
				if (this._trailer.isLiteralText()) {
					try {
												
						Boolean __trailer = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._trailer.getExpressionString(), 
											Boolean.class);
					
												comp.setTrailer(__trailer.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("trailer", this._trailer);
				}
			}
					   		 			 
						if (this._trailerStyleClass != null) {
				if (this._trailerStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __trailerStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._trailerStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTrailerStyleClass(__trailerStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("trailerStyleClass", this._trailerStyleClass);
				}
			}
					   		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.DataFilterSlider";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.DataFilterSliderRenderer";
			}

}
