/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlInplaceInput;

public class InplaceInputTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * cancelControlIcon
		 * Defines custom cancel icon
		 */
		private ValueExpression _cancelControlIcon;
		/**
		 * Defines custom cancel icon
		 * Setter for cancelControlIcon
		 * @param cancelControlIcon - new value
		 */
		 public void setCancelControlIcon( ValueExpression  __cancelControlIcon ){
			this._cancelControlIcon = __cancelControlIcon;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * changedClass
		 * Assigns one or more space-separated CSS class names to the component in the changed state
		 */
		private ValueExpression _changedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component in the changed state
		 * Setter for changedClass
		 * @param changedClass - new value
		 */
		 public void setChangedClass( ValueExpression  __changedClass ){
			this._changedClass = __changedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * changedHoverClass
		 * Assigns one or more space-separated CSS class names to the component hovered in the changed state
		 */
		private ValueExpression _changedHoverClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component hovered in the changed state
		 * Setter for changedHoverClass
		 * @param changedHoverClass - new value
		 */
		 public void setChangedHoverClass( ValueExpression  __changedHoverClass ){
			this._changedHoverClass = __changedHoverClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlClass
		 * Assigns one or more space-separated CSS class names to the component controls
		 */
		private ValueExpression _controlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component controls
		 * Setter for controlClass
		 * @param controlClass - new value
		 */
		 public void setControlClass( ValueExpression  __controlClass ){
			this._controlClass = __controlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlHoverClass
		 * Assigns one or more space-separated CSS class names to the component control hovered
		 */
		private ValueExpression _controlHoverClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component control hovered
		 * Setter for controlHoverClass
		 * @param controlHoverClass - new value
		 */
		 public void setControlHoverClass( ValueExpression  __controlHoverClass ){
			this._controlHoverClass = __controlHoverClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlPressedClass
		 * Assigns one or more space-separated CSS class names to the component control pressed
		 */
		private ValueExpression _controlPressedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component control pressed
		 * Setter for controlPressedClass
		 * @param controlPressedClass - new value
		 */
		 public void setControlPressedClass( ValueExpression  __controlPressedClass ){
			this._controlPressedClass = __controlPressedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsHorizontalPosition
		 * Positions the controls horizontally. Possible values are "left", "center", "right". Default value is "right".
		 */
		private ValueExpression _controlsHorizontalPosition;
		/**
		 * Positions the controls horizontally. Possible values are "left", "center", "right". Default value is "right".
		 * Setter for controlsHorizontalPosition
		 * @param controlsHorizontalPosition - new value
		 */
		 public void setControlsHorizontalPosition( ValueExpression  __controlsHorizontalPosition ){
			this._controlsHorizontalPosition = __controlsHorizontalPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * controlsVerticalPosition
		 * Positions the controls vertically. Possible values are "bottom","center" and "top". Default value is "center"
		 */
		private ValueExpression _controlsVerticalPosition;
		/**
		 * Positions the controls vertically. Possible values are "bottom","center" and "top". Default value is "center"
		 * Setter for controlsVerticalPosition
		 * @param controlsVerticalPosition - new value
		 */
		 public void setControlsVerticalPosition( ValueExpression  __controlsVerticalPosition ){
			this._controlsVerticalPosition = __controlsVerticalPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * defaultLabel
		 * The attribute is used to display text while value is undefined
		 */
		private ValueExpression _defaultLabel;
		/**
		 * The attribute is used to display text while value is undefined
		 * Setter for defaultLabel
		 * @param defaultLabel - new value
		 */
		 public void setDefaultLabel( ValueExpression  __defaultLabel ){
			this._defaultLabel = __defaultLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * editClass
		 * Assigns one or more space-separated CSS class names to the component in the edit state
		 */
		private ValueExpression _editClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component in the edit state
		 * Setter for editClass
		 * @param editClass - new value
		 */
		 public void setEditClass( ValueExpression  __editClass ){
			this._editClass = __editClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * editEvent
		 * Provides an option to assign an JavaScript action that initiates the change of the state. Default value is "onclick".
		 */
		private ValueExpression _editEvent;
		/**
		 * Provides an option to assign an JavaScript action that initiates the change of the state. Default value is "onclick".
		 * Setter for editEvent
		 * @param editEvent - new value
		 */
		 public void setEditEvent( ValueExpression  __editEvent ){
			this._editEvent = __editEvent;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * inputWidth
		 * Sets width of the input field
		 */
		private ValueExpression _inputWidth;
		/**
		 * Sets width of the input field
		 * Setter for inputWidth
		 * @param inputWidth - new value
		 */
		 public void setInputWidth( ValueExpression  __inputWidth ){
			this._inputWidth = __inputWidth;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * layout
		 * Defines how the component is displayed in the layout. Possible values are "block", "inline". Default value is "inline".
		 */
		private ValueExpression _layout;
		/**
		 * Defines how the component is displayed in the layout. Possible values are "block", "inline". Default value is "inline".
		 * Setter for layout
		 * @param layout - new value
		 */
		 public void setLayout( ValueExpression  __layout ){
			this._layout = __layout;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * maxInputWidth
		 * Sets the maximum width of the input field. Default value is "500px".
		 */
		private ValueExpression _maxInputWidth;
		/**
		 * Sets the maximum width of the input field. Default value is "500px".
		 * Setter for maxInputWidth
		 * @param maxInputWidth - new value
		 */
		 public void setMaxInputWidth( ValueExpression  __maxInputWidth ){
			this._maxInputWidth = __maxInputWidth;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * maxlength
		 * Specifies the maximum number of digits that could be entered into the input field. 
				The maximum number is unlimited by default.
		 */
		private ValueExpression _maxlength;
		/**
		 * Specifies the maximum number of digits that could be entered into the input field. 
				The maximum number is unlimited by default.
		 * Setter for maxlength
		 * @param maxlength - new value
		 */
		 public void setMaxlength( ValueExpression  __maxlength ){
			this._maxlength = __maxlength;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * minInputWidth
		 * Sets the minimum width of the input field. Default value is "40px".
		 */
		private ValueExpression _minInputWidth;
		/**
		 * Sets the minimum width of the input field. Default value is "40px".
		 * Setter for minInputWidth
		 * @param minInputWidth - new value
		 */
		 public void setMinInputWidth( ValueExpression  __minInputWidth ){
			this._minInputWidth = __minInputWidth;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onblur
		 * The client-side script method to be called when the component loses the focus
		 */
		private ValueExpression _onblur;
		/**
		 * The client-side script method to be called when the component loses the focus
		 * Setter for onblur
		 * @param onblur - new value
		 */
		 public void setOnblur( ValueExpression  __onblur ){
			this._onblur = __onblur;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onchange
		 * The client-side script method to be called when the component value is changed
		 */
		private ValueExpression _onchange;
		/**
		 * The client-side script method to be called when the component value is changed
		 * Setter for onchange
		 * @param onchange - new value
		 */
		 public void setOnchange( ValueExpression  __onchange ){
			this._onchange = __onchange;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * oneditactivated
		 * The client-side script method to be called when the component edit state is activated
		 */
		private ValueExpression _oneditactivated;
		/**
		 * The client-side script method to be called when the component edit state is activated
		 * Setter for oneditactivated
		 * @param oneditactivated - new value
		 */
		 public void setOneditactivated( ValueExpression  __oneditactivated ){
			this._oneditactivated = __oneditactivated;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oneditactivation
		 * The client-side script method to be called before the component edit state is activated
		 */
		private ValueExpression _oneditactivation;
		/**
		 * The client-side script method to be called before the component edit state is activated
		 * Setter for oneditactivation
		 * @param oneditactivation - new value
		 */
		 public void setOneditactivation( ValueExpression  __oneditactivation ){
			this._oneditactivation = __oneditactivation;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onfocus
		 * The client-side script method to be called when the component gets the focus
		 */
		private ValueExpression _onfocus;
		/**
		 * The client-side script method to be called when the component gets the focus
		 * Setter for onfocus
		 * @param onfocus - new value
		 */
		 public void setOnfocus( ValueExpression  __onfocus ){
			this._onfocus = __onfocus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputclick
		 * The client-side script method to be called when the input field is clicked
		 */
		private ValueExpression _oninputclick;
		/**
		 * The client-side script method to be called when the input field is clicked
		 * Setter for oninputclick
		 * @param oninputclick - new value
		 */
		 public void setOninputclick( ValueExpression  __oninputclick ){
			this._oninputclick = __oninputclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputdblclick
		 * The client-side script method to be called when the input field is double-clicked
		 */
		private ValueExpression _oninputdblclick;
		/**
		 * The client-side script method to be called when the input field is double-clicked
		 * Setter for oninputdblclick
		 * @param oninputdblclick - new value
		 */
		 public void setOninputdblclick( ValueExpression  __oninputdblclick ){
			this._oninputdblclick = __oninputdblclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeydown
		 * The client-side script method to be called when a key is pressed down in the input field
		 */
		private ValueExpression _oninputkeydown;
		/**
		 * The client-side script method to be called when a key is pressed down in the input field
		 * Setter for oninputkeydown
		 * @param oninputkeydown - new value
		 */
		 public void setOninputkeydown( ValueExpression  __oninputkeydown ){
			this._oninputkeydown = __oninputkeydown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeypress
		 * The client-side script method to be called when a key is pressed and released in the input field
		 */
		private ValueExpression _oninputkeypress;
		/**
		 * The client-side script method to be called when a key is pressed and released in the input field
		 * Setter for oninputkeypress
		 * @param oninputkeypress - new value
		 */
		 public void setOninputkeypress( ValueExpression  __oninputkeypress ){
			this._oninputkeypress = __oninputkeypress;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeyup
		 * The client-side script method to be called when a key is released in the input field
		 */
		private ValueExpression _oninputkeyup;
		/**
		 * The client-side script method to be called when a key is released in the input field
		 * Setter for oninputkeyup
		 * @param oninputkeyup - new value
		 */
		 public void setOninputkeyup( ValueExpression  __oninputkeyup ){
			this._oninputkeyup = __oninputkeyup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmousedown
		 * The client-side script method to be called when a mouse button is pressed down in the input field
		 */
		private ValueExpression _oninputmousedown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down in the input field
		 * Setter for oninputmousedown
		 * @param oninputmousedown - new value
		 */
		 public void setOninputmousedown( ValueExpression  __oninputmousedown ){
			this._oninputmousedown = __oninputmousedown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmousemove
		 * The client-side script method to be called when a pointer is moved within the input field
		 */
		private ValueExpression _oninputmousemove;
		/**
		 * The client-side script method to be called when a pointer is moved within the input field
		 * Setter for oninputmousemove
		 * @param oninputmousemove - new value
		 */
		 public void setOninputmousemove( ValueExpression  __oninputmousemove ){
			this._oninputmousemove = __oninputmousemove;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmouseout
		 * The client-side script method to be called when a pointer is moved away from the input field
		 */
		private ValueExpression _oninputmouseout;
		/**
		 * The client-side script method to be called when a pointer is moved away from the input field
		 * Setter for oninputmouseout
		 * @param oninputmouseout - new value
		 */
		 public void setOninputmouseout( ValueExpression  __oninputmouseout ){
			this._oninputmouseout = __oninputmouseout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmouseover
		 * The client-side script method to be called when a pointer is moved onto the input field
		 */
		private ValueExpression _oninputmouseover;
		/**
		 * The client-side script method to be called when a pointer is moved onto the input field
		 * Setter for oninputmouseover
		 * @param oninputmouseover - new value
		 */
		 public void setOninputmouseover( ValueExpression  __oninputmouseover ){
			this._oninputmouseover = __oninputmouseover;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmouseup
		 * The client-side script method to be called when a mouse button is released in the input field
		 */
		private ValueExpression _oninputmouseup;
		/**
		 * The client-side script method to be called when a mouse button is released in the input field
		 * Setter for oninputmouseup
		 * @param oninputmouseup - new value
		 */
		 public void setOninputmouseup( ValueExpression  __oninputmouseup ){
			this._oninputmouseup = __oninputmouseup;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onselect
		 * The client-side script method to be called when some text is selected in the input field
		 */
		private ValueExpression _onselect;
		/**
		 * The client-side script method to be called when some text is selected in the input field
		 * Setter for onselect
		 * @param onselect - new value
		 */
		 public void setOnselect( ValueExpression  __onselect ){
			this._onselect = __onselect;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onviewactivated
		 * The client-side script method to be called when the component view state is activated
		 */
		private ValueExpression _onviewactivated;
		/**
		 * The client-side script method to be called when the component view state is activated
		 * Setter for onviewactivated
		 * @param onviewactivated - new value
		 */
		 public void setOnviewactivated( ValueExpression  __onviewactivated ){
			this._onviewactivated = __onviewactivated;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onviewactivation
		 * The client-side script method to be called before the component view state is activated
		 */
		private ValueExpression _onviewactivation;
		/**
		 * The client-side script method to be called before the component view state is activated
		 * Setter for onviewactivation
		 * @param onviewactivation - new value
		 */
		 public void setOnviewactivation( ValueExpression  __onviewactivation ){
			this._onviewactivation = __onviewactivation;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * saveControlIcon
		 * Defines custom save icon
		 */
		private ValueExpression _saveControlIcon;
		/**
		 * Defines custom save icon
		 * Setter for saveControlIcon
		 * @param saveControlIcon - new value
		 */
		 public void setSaveControlIcon( ValueExpression  __saveControlIcon ){
			this._saveControlIcon = __saveControlIcon;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectOnEdit
		 * Makes the input field select when switched to edit state. Default value is "false"
		 */
		private ValueExpression _selectOnEdit;
		/**
		 * Makes the input field select when switched to edit state. Default value is "false"
		 * Setter for selectOnEdit
		 * @param selectOnEdit - new value
		 */
		 public void setSelectOnEdit( ValueExpression  __selectOnEdit ){
			this._selectOnEdit = __selectOnEdit;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showControls
		 * Serves to display "save" and "cancel" controls. Default value is "false".
		 */
		private ValueExpression _showControls;
		/**
		 * Serves to display "save" and "cancel" controls. Default value is "false".
		 * Setter for showControls
		 * @param showControls - new value
		 */
		 public void setShowControls( ValueExpression  __showControls ){
			this._showControls = __showControls;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * tabindex
		 * Serves to define the tabbing order
		 */
		private ValueExpression _tabindex;
		/**
		 * Serves to define the tabbing order
		 * Setter for tabindex
		 * @param tabindex - new value
		 */
		 public void setTabindex( ValueExpression  __tabindex ){
			this._tabindex = __tabindex;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * viewClass
		 * Assigns one or more space-separated CSS class names to the component in the view state
		 */
		private ValueExpression _viewClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component in the view state
		 * Setter for viewClass
		 * @param viewClass - new value
		 */
		 public void setViewClass( ValueExpression  __viewClass ){
			this._viewClass = __viewClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * viewHoverClass
		 * Assigns one or more space-separated CSS class names to the component hovered in the view state
		 */
		private ValueExpression _viewHoverClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component hovered in the view state
		 * Setter for viewHoverClass
		 * @param viewHoverClass - new value
		 */
		 public void setViewHoverClass( ValueExpression  __viewHoverClass ){
			this._viewHoverClass = __viewHoverClass;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._cancelControlIcon = null;
	 		 		    this._changedClass = null;
	 		 		    this._changedHoverClass = null;
	 		 		    this._controlClass = null;
	 		 		    this._controlHoverClass = null;
	 		 		    this._controlPressedClass = null;
	 		 		    this._controlsHorizontalPosition = null;
	 		 		    this._controlsVerticalPosition = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._defaultLabel = null;
	 		 		    this._editClass = null;
	 		 		    this._editEvent = null;
	 		 		 		 		    this._immediate = null;
	 		 		    this._inputWidth = null;
	 		 		    this._label = null;
	 		 		    this._layout = null;
	 		 		 		 		    this._maxInputWidth = null;
	 		 		    this._maxlength = null;
	 		 		    this._minInputWidth = null;
	 		 		    this._onblur = null;
	 		 		    this._onchange = null;
	 		 		 		 		    this._oneditactivated = null;
	 		 		    this._oneditactivation = null;
	 		 		    this._onfocus = null;
	 		 		    this._oninputclick = null;
	 		 		    this._oninputdblclick = null;
	 		 		    this._oninputkeydown = null;
	 		 		    this._oninputkeypress = null;
	 		 		    this._oninputkeyup = null;
	 		 		    this._oninputmousedown = null;
	 		 		    this._oninputmousemove = null;
	 		 		    this._oninputmouseout = null;
	 		 		    this._oninputmouseover = null;
	 		 		    this._oninputmouseup = null;
	 		 		 		 		 		 		 		 		 		 		    this._onselect = null;
	 		 		    this._onviewactivated = null;
	 		 		    this._onviewactivation = null;
	 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		    this._saveControlIcon = null;
	 		 		    this._selectOnEdit = null;
	 		 		    this._showControls = null;
	 		 		 		    this._tabindex = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		 		    this._viewClass = null;
	 		 		    this._viewHoverClass = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlInplaceInput comp = (HtmlInplaceInput) component;
  		 			 
						if (this._cancelControlIcon != null) {
				if (this._cancelControlIcon.isLiteralText()) {
					try {
												
						java.lang.String __cancelControlIcon = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cancelControlIcon.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCancelControlIcon(__cancelControlIcon);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cancelControlIcon", this._cancelControlIcon);
				}
			}
					   		 			 
						if (this._changedClass != null) {
				if (this._changedClass.isLiteralText()) {
					try {
												
						java.lang.String __changedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._changedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setChangedClass(__changedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("changedClass", this._changedClass);
				}
			}
					   		 			 
						if (this._changedHoverClass != null) {
				if (this._changedHoverClass.isLiteralText()) {
					try {
												
						java.lang.String __changedHoverClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._changedHoverClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setChangedHoverClass(__changedHoverClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("changedHoverClass", this._changedHoverClass);
				}
			}
					   		 			 
						if (this._controlClass != null) {
				if (this._controlClass.isLiteralText()) {
					try {
												
						java.lang.String __controlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlClass(__controlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlClass", this._controlClass);
				}
			}
					   		 			 
						if (this._controlHoverClass != null) {
				if (this._controlHoverClass.isLiteralText()) {
					try {
												
						java.lang.String __controlHoverClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlHoverClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlHoverClass(__controlHoverClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlHoverClass", this._controlHoverClass);
				}
			}
					   		 			 
						if (this._controlPressedClass != null) {
				if (this._controlPressedClass.isLiteralText()) {
					try {
												
						java.lang.String __controlPressedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlPressedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlPressedClass(__controlPressedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlPressedClass", this._controlPressedClass);
				}
			}
					   		 			 
						if (this._controlsHorizontalPosition != null) {
				if (this._controlsHorizontalPosition.isLiteralText()) {
					try {
												
						java.lang.String __controlsHorizontalPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsHorizontalPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsHorizontalPosition(__controlsHorizontalPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsHorizontalPosition", this._controlsHorizontalPosition);
				}
			}
					   		 			 
						if (this._controlsVerticalPosition != null) {
				if (this._controlsVerticalPosition.isLiteralText()) {
					try {
												
						java.lang.String __controlsVerticalPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlsVerticalPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlsVerticalPosition(__controlsVerticalPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlsVerticalPosition", this._controlsVerticalPosition);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._defaultLabel != null) {
				if (this._defaultLabel.isLiteralText()) {
					try {
												
						java.lang.String __defaultLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._defaultLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDefaultLabel(__defaultLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("defaultLabel", this._defaultLabel);
				}
			}
					   		 			 
						if (this._editClass != null) {
				if (this._editClass.isLiteralText()) {
					try {
												
						java.lang.String __editClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._editClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEditClass(__editClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("editClass", this._editClass);
				}
			}
					   		 			 
						if (this._editEvent != null) {
				if (this._editEvent.isLiteralText()) {
					try {
												
						java.lang.String __editEvent = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._editEvent.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEditEvent(__editEvent);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("editEvent", this._editEvent);
				}
			}
					     		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._inputWidth != null) {
				if (this._inputWidth.isLiteralText()) {
					try {
												
						java.lang.String __inputWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._inputWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInputWidth(__inputWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("inputWidth", this._inputWidth);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					   		 			 
						if (this._layout != null) {
				if (this._layout.isLiteralText()) {
					try {
												
						java.lang.String __layout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._layout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLayout(__layout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("layout", this._layout);
				}
			}
					     		 			 
						if (this._maxInputWidth != null) {
				if (this._maxInputWidth.isLiteralText()) {
					try {
												
						java.lang.String __maxInputWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._maxInputWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMaxInputWidth(__maxInputWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("maxInputWidth", this._maxInputWidth);
				}
			}
					   		 			 
						if (this._maxlength != null) {
				if (this._maxlength.isLiteralText()) {
					try {
												
						Integer __maxlength = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._maxlength.getExpressionString(), 
											Integer.class);
					
												comp.setMaxlength(__maxlength.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("maxlength", this._maxlength);
				}
			}
					   		 			 
						if (this._minInputWidth != null) {
				if (this._minInputWidth.isLiteralText()) {
					try {
												
						java.lang.String __minInputWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._minInputWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMinInputWidth(__minInputWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("minInputWidth", this._minInputWidth);
				}
			}
					   		 			 
						if (this._onblur != null) {
				if (this._onblur.isLiteralText()) {
					try {
												
						java.lang.String __onblur = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onblur.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnblur(__onblur);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onblur", this._onblur);
				}
			}
					   		 			 
						if (this._onchange != null) {
				if (this._onchange.isLiteralText()) {
					try {
												
						java.lang.String __onchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnchange(__onchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onchange", this._onchange);
				}
			}
					     		 			 
						if (this._oneditactivated != null) {
				if (this._oneditactivated.isLiteralText()) {
					try {
												
						java.lang.String __oneditactivated = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oneditactivated.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOneditactivated(__oneditactivated);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oneditactivated", this._oneditactivated);
				}
			}
					   		 			 
						if (this._oneditactivation != null) {
				if (this._oneditactivation.isLiteralText()) {
					try {
												
						java.lang.String __oneditactivation = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oneditactivation.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOneditactivation(__oneditactivation);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oneditactivation", this._oneditactivation);
				}
			}
					   		 			 
						if (this._onfocus != null) {
				if (this._onfocus.isLiteralText()) {
					try {
												
						java.lang.String __onfocus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfocus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfocus(__onfocus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfocus", this._onfocus);
				}
			}
					   		 			 
						if (this._oninputclick != null) {
				if (this._oninputclick.isLiteralText()) {
					try {
												
						java.lang.String __oninputclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputclick(__oninputclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputclick", this._oninputclick);
				}
			}
					   		 			 
						if (this._oninputdblclick != null) {
				if (this._oninputdblclick.isLiteralText()) {
					try {
												
						java.lang.String __oninputdblclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputdblclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputdblclick(__oninputdblclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputdblclick", this._oninputdblclick);
				}
			}
					   		 			 
						if (this._oninputkeydown != null) {
				if (this._oninputkeydown.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeydown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeydown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeydown(__oninputkeydown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeydown", this._oninputkeydown);
				}
			}
					   		 			 
						if (this._oninputkeypress != null) {
				if (this._oninputkeypress.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeypress = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeypress.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeypress(__oninputkeypress);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeypress", this._oninputkeypress);
				}
			}
					   		 			 
						if (this._oninputkeyup != null) {
				if (this._oninputkeyup.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeyup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeyup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeyup(__oninputkeyup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeyup", this._oninputkeyup);
				}
			}
					   		 			 
						if (this._oninputmousedown != null) {
				if (this._oninputmousedown.isLiteralText()) {
					try {
												
						java.lang.String __oninputmousedown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmousedown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmousedown(__oninputmousedown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmousedown", this._oninputmousedown);
				}
			}
					   		 			 
						if (this._oninputmousemove != null) {
				if (this._oninputmousemove.isLiteralText()) {
					try {
												
						java.lang.String __oninputmousemove = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmousemove.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmousemove(__oninputmousemove);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmousemove", this._oninputmousemove);
				}
			}
					   		 			 
						if (this._oninputmouseout != null) {
				if (this._oninputmouseout.isLiteralText()) {
					try {
												
						java.lang.String __oninputmouseout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmouseout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmouseout(__oninputmouseout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmouseout", this._oninputmouseout);
				}
			}
					   		 			 
						if (this._oninputmouseover != null) {
				if (this._oninputmouseover.isLiteralText()) {
					try {
												
						java.lang.String __oninputmouseover = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmouseover.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmouseover(__oninputmouseover);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmouseover", this._oninputmouseover);
				}
			}
					   		 			 
						if (this._oninputmouseup != null) {
				if (this._oninputmouseup.isLiteralText()) {
					try {
												
						java.lang.String __oninputmouseup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmouseup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmouseup(__oninputmouseup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmouseup", this._oninputmouseup);
				}
			}
					           		 			 
						if (this._onselect != null) {
				if (this._onselect.isLiteralText()) {
					try {
												
						java.lang.String __onselect = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselect.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselect(__onselect);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselect", this._onselect);
				}
			}
					   		 			 
						if (this._onviewactivated != null) {
				if (this._onviewactivated.isLiteralText()) {
					try {
												
						java.lang.String __onviewactivated = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onviewactivated.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnviewactivated(__onviewactivated);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onviewactivated", this._onviewactivated);
				}
			}
					   		 			 
						if (this._onviewactivation != null) {
				if (this._onviewactivation.isLiteralText()) {
					try {
												
						java.lang.String __onviewactivation = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onviewactivation.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnviewactivation(__onviewactivation);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onviewactivation", this._onviewactivation);
				}
			}
					    		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					   		 			 
						if (this._saveControlIcon != null) {
				if (this._saveControlIcon.isLiteralText()) {
					try {
												
						java.lang.String __saveControlIcon = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._saveControlIcon.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSaveControlIcon(__saveControlIcon);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("saveControlIcon", this._saveControlIcon);
				}
			}
					   		 			 
						if (this._selectOnEdit != null) {
				if (this._selectOnEdit.isLiteralText()) {
					try {
												
						Boolean __selectOnEdit = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectOnEdit.getExpressionString(), 
											Boolean.class);
					
												comp.setSelectOnEdit(__selectOnEdit.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectOnEdit", this._selectOnEdit);
				}
			}
					   		 			 
						if (this._showControls != null) {
				if (this._showControls.isLiteralText()) {
					try {
												
						Boolean __showControls = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showControls.getExpressionString(), 
											Boolean.class);
					
												comp.setShowControls(__showControls.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showControls", this._showControls);
				}
			}
					    		 			 
						if (this._tabindex != null) {
				if (this._tabindex.isLiteralText()) {
					try {
												
						Integer __tabindex = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tabindex.getExpressionString(), 
											Integer.class);
					
												comp.setTabindex(__tabindex.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tabindex", this._tabindex);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
						if (this._viewClass != null) {
				if (this._viewClass.isLiteralText()) {
					try {
												
						java.lang.String __viewClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._viewClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setViewClass(__viewClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("viewClass", this._viewClass);
				}
			}
					   		 			 
						if (this._viewHoverClass != null) {
				if (this._viewHoverClass.isLiteralText()) {
					try {
												
						java.lang.String __viewHoverClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._viewHoverClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setViewHoverClass(__viewHoverClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("viewHoverClass", this._viewHoverClass);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.InplaceInput";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.renderkit.InplaceInputRenderer";
			}

}
