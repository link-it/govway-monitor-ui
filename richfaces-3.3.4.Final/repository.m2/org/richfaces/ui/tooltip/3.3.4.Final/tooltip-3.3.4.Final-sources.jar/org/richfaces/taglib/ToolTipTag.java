/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import org.richfaces.taglib.ToolTipTagBase ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlToolTip;

public class ToolTipTag extends org.richfaces.taglib.ToolTipTagBase {

		// Fields
		 	  	  	  
		/*
		 * action
		 * MethodBinding pointing at the application action to be invoked,
            if this UIComponent is activated by you, during the Apply
            Request Values or Invoke Application phase of the request
            processing lifecycle, depending on the value of the immediate
            property
		 */
		private MethodExpression _action;
		/**
		 * MethodBinding pointing at the application action to be invoked,
            if this UIComponent is activated by you, during the Apply
            Request Values or Invoke Application phase of the request
            processing lifecycle, depending on the value of the immediate
            property
		 * Setter for action
		 * @param action - new value
		 */
		 public void setAction( MethodExpression  __action ){
			this._action = __action;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * actionListener
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 */
		private MethodExpression _actionListener;
		/**
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 * Setter for actionListener
		 * @param actionListener - new value
		 */
		 public void setActionListener( MethodExpression  __actionListener ){
			this._actionListener = __actionListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ajaxSingle
		 * boolean attribute which provides possibility to limit JSF tree processing(decoding, conversion/validation, value applying) to the component which sends the request only.
				Default value is "true"
		 */
		private ValueExpression _ajaxSingle;
		/**
		 * boolean attribute which provides possibility to limit JSF tree processing(decoding, conversion/validation, value applying) to the component which sends the request only.
				Default value is "true"
		 * Setter for ajaxSingle
		 * @param ajaxSingle - new value
		 */
		 public void setAjaxSingle( ValueExpression  __ajaxSingle ){
			this._ajaxSingle = __ajaxSingle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * attached
		 * If the value of the "attached" attribute is "true", a component is attached to the parent component;
            	if "false", component does not listen to activating browser events, but could be activated externally.  Default value is "true"
		 */
		private ValueExpression _attached;
		/**
		 * If the value of the "attached" attribute is "true", a component is attached to the parent component;
            	if "false", component does not listen to activating browser events, but could be activated externally.  Default value is "true"
		 * Setter for attached
		 * @param attached - new value
		 */
		 public void setAttached( ValueExpression  __attached ){
			this._attached = __attached;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * direction
		 * Defines direction of the popup list to appear. 
	    		Possible values are "top-right", "top-left", "bottom-right", "bottom-left", "auto".
	    		Default value is "bottom-right"
		 */
		private ValueExpression _direction;
		/**
		 * Defines direction of the popup list to appear. 
	    		Possible values are "top-right", "top-left", "bottom-right", "bottom-left", "auto".
	    		Default value is "bottom-right"
		 * Setter for direction
		 * @param direction - new value
		 */
		 public void setDirection( ValueExpression  __direction ){
			this._direction = __direction;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabled
		 * If false the components is rendered on the client but JavaScript for calling disabled. Default value is "false"
		 */
		private ValueExpression _disabled;
		/**
		 * If false the components is rendered on the client but JavaScript for calling disabled. Default value is "false"
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * followMouse
		 * If "true" tooltip should follow the mouse while it moves over the parent element. Default value is "false"
		 */
		private ValueExpression _followMouse;
		/**
		 * If "true" tooltip should follow the mouse while it moves over the parent element. Default value is "false"
		 * Setter for followMouse
		 * @param followMouse - new value
		 */
		 public void setFollowMouse( ValueExpression  __followMouse ){
			this._followMouse = __followMouse;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * for
		 * Id of the target component
		 */
		private ValueExpression _for;
		/**
		 * Id of the target component
		 * Setter for for
		 * @param for - new value
		 */
		 public void setFor( ValueExpression  __for ){
			this._for = __for;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hideDelay
		 * Delay in milliseconds before tooltip will be hidden. Default value is "0"
		 */
		private ValueExpression _hideDelay;
		/**
		 * Delay in milliseconds before tooltip will be hidden. Default value is "0"
		 * Setter for hideDelay
		 * @param hideDelay - new value
		 */
		 public void setHideDelay( ValueExpression  __hideDelay ){
			this._hideDelay = __hideDelay;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hideEvent
		 * Event that triggers the tooltip disappearance.
	    		Default value is "none" (so, the component does not disappears)
		 */
		private ValueExpression _hideEvent;
		/**
		 * Event that triggers the tooltip disappearance.
	    		Default value is "none" (so, the component does not disappears)
		 * Setter for hideEvent
		 * @param hideEvent - new value
		 */
		 public void setHideEvent( ValueExpression  __hideEvent ){
			this._hideEvent = __hideEvent;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * horizontalOffset
		 * Sets the horizontal offset between pop-up list and mouse pointer. Default value is "10"
		 */
		private ValueExpression _horizontalOffset;
		/**
		 * Sets the horizontal offset between pop-up list and mouse pointer. Default value is "10"
		 * Setter for horizontalOffset
		 * @param horizontalOffset - new value
		 */
		 public void setHorizontalOffset( ValueExpression  __horizontalOffset ){
			this._horizontalOffset = __horizontalOffset;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 */
		private ValueExpression _immediate;
		/**
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * layout
		 * Block/inline mode flag. Possible value are: "inline" or "block".  Default value is "inline". Tooltip will contain div/span elements respectively
		 */
		private ValueExpression _layout;
		/**
		 * Block/inline mode flag. Possible value are: "inline" or "block".  Default value is "inline". Tooltip will contain div/span elements respectively
		 * Setter for layout
		 * @param layout - new value
		 */
		 public void setLayout( ValueExpression  __layout ){
			this._layout = __layout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * mode
		 * Controls the way of data loading to a tooltip. May have following values: "client" (default) and "ajax"
		 */
		private ValueExpression _mode;
		/**
		 * Controls the way of data loading to a tooltip. May have following values: "client" (default) and "ajax"
		 * Setter for mode
		 * @param mode - new value
		 */
		 public void setMode( ValueExpression  __mode ){
			this._mode = __mode;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the tooltip is shown
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the tooltip is shown
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onhide
		 * The client-side script method to be called after the tooltip is hidden
		 */
		private ValueExpression _onhide;
		/**
		 * The client-side script method to be called after the tooltip is hidden
		 * Setter for onhide
		 * @param onhide - new value
		 */
		 public void setOnhide( ValueExpression  __onhide ){
			this._onhide = __onhide;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onshow
		 * The client-side script method to be called before the tooltip is shown
		 */
		private ValueExpression _onshow;
		/**
		 * The client-side script method to be called before the tooltip is shown
		 * Setter for onshow
		 * @param onshow - new value
		 */
		 public void setOnshow( ValueExpression  __onshow ){
			this._onshow = __onshow;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * showDelay
		 * Delay in milliseconds before tooltip will be displayed. Default value is "0"
		 */
		private ValueExpression _showDelay;
		/**
		 * Delay in milliseconds before tooltip will be displayed. Default value is "0"
		 * Setter for showDelay
		 * @param showDelay - new value
		 */
		 public void setShowDelay( ValueExpression  __showDelay ){
			this._showDelay = __showDelay;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * verticalOffset
		 * Sets the vertical offset between pop-up list and mouse pointer. Default value is "10"
		 */
		private ValueExpression _verticalOffset;
		/**
		 * Sets the vertical offset between pop-up list and mouse pointer. Default value is "10"
		 * Setter for verticalOffset
		 * @param verticalOffset - new value
		 */
		 public void setVerticalOffset( ValueExpression  __verticalOffset ){
			this._verticalOffset = __verticalOffset;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * zorder
		 * The same as CSS z-index for toolTip. Default value is "99"
		 */
		private ValueExpression _zorder;
		/**
		 * The same as CSS z-index for toolTip. Default value is "99"
		 * Setter for zorder
		 * @param zorder - new value
		 */
		 public void setZorder( ValueExpression  __zorder ){
			this._zorder = __zorder;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._action = null;
	 		 		 		    this._actionListener = null;
	 		 		 		    this._ajaxSingle = null;
	 		 		    this._attached = null;
	 		 		 		    this._direction = null;
	 		 		    this._disabled = null;
	 		 		 		 		    this._followMouse = null;
	 		 		    this._for = null;
	 		 		    this._hideDelay = null;
	 		 		    this._hideEvent = null;
	 		 		    this._horizontalOffset = null;
	 		 		 		    this._immediate = null;
	 		 		    this._layout = null;
	 		 		    this._mode = null;
	 		 		 		    this._oncomplete = null;
	 		 		 		    this._onhide = null;
	 		 		 		 		 		 		 		 		 		 		    this._onshow = null;
	 		 		 		    this._showDelay = null;
	 		 		 		 		 		 		    this._value = null;
	 		 		    this._verticalOffset = null;
	 		 		    this._zorder = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlToolTip comp = (HtmlToolTip) component;
 		 			setActionProperty(comp, this._action);
		    		 			setActionListenerProperty(comp, this._actionListener);
		    		 			 
						if (this._ajaxSingle != null) {
				if (this._ajaxSingle.isLiteralText()) {
					try {
												
						Boolean __ajaxSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxSingle(__ajaxSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSingle", this._ajaxSingle);
				}
			}
					   		 			 
						if (this._attached != null) {
				if (this._attached.isLiteralText()) {
					try {
												
						Boolean __attached = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._attached.getExpressionString(), 
											Boolean.class);
					
												comp.setAttached(__attached.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("attached", this._attached);
				}
			}
					    		 			 
						if (this._direction != null) {
				if (this._direction.isLiteralText()) {
					try {
												
						java.lang.String __direction = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._direction.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDirection(__direction);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("direction", this._direction);
				}
			}
					   		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					     		 			 
						if (this._followMouse != null) {
				if (this._followMouse.isLiteralText()) {
					try {
												
						Boolean __followMouse = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._followMouse.getExpressionString(), 
											Boolean.class);
					
												comp.setFollowMouse(__followMouse.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("followMouse", this._followMouse);
				}
			}
					   		 			 
						if (this._for != null) {
				if (this._for.isLiteralText()) {
					try {
												
						java.lang.String __for = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._for.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFor(__for);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("for", this._for);
				}
			}
					   		 			 
						if (this._hideDelay != null) {
				if (this._hideDelay.isLiteralText()) {
					try {
												
						Integer __hideDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hideDelay.getExpressionString(), 
											Integer.class);
					
												comp.setHideDelay(__hideDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hideDelay", this._hideDelay);
				}
			}
					   		 			 
						if (this._hideEvent != null) {
				if (this._hideEvent.isLiteralText()) {
					try {
												
						java.lang.String __hideEvent = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hideEvent.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHideEvent(__hideEvent);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hideEvent", this._hideEvent);
				}
			}
					   		 			 
						if (this._horizontalOffset != null) {
				if (this._horizontalOffset.isLiteralText()) {
					try {
												
						Integer __horizontalOffset = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._horizontalOffset.getExpressionString(), 
											Integer.class);
					
												comp.setHorizontalOffset(__horizontalOffset.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("horizontalOffset", this._horizontalOffset);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._layout != null) {
				if (this._layout.isLiteralText()) {
					try {
												
						java.lang.String __layout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._layout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLayout(__layout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("layout", this._layout);
				}
			}
					   		 			 
						if (this._mode != null) {
				if (this._mode.isLiteralText()) {
					try {
												
						java.lang.String __mode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._mode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMode(__mode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("mode", this._mode);
				}
			}
					    		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					    		 			 
						if (this._onhide != null) {
				if (this._onhide.isLiteralText()) {
					try {
												
						java.lang.String __onhide = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onhide.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnhide(__onhide);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onhide", this._onhide);
				}
			}
					           		 			 
						if (this._onshow != null) {
				if (this._onshow.isLiteralText()) {
					try {
												
						java.lang.String __onshow = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onshow.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnshow(__onshow);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onshow", this._onshow);
				}
			}
					    		 			 
						if (this._showDelay != null) {
				if (this._showDelay.isLiteralText()) {
					try {
												
						Integer __showDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showDelay.getExpressionString(), 
											Integer.class);
					
												comp.setShowDelay(__showDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showDelay", this._showDelay);
				}
			}
					       		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
						if (this._verticalOffset != null) {
				if (this._verticalOffset.isLiteralText()) {
					try {
												
						Integer __verticalOffset = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._verticalOffset.getExpressionString(), 
											Integer.class);
					
												comp.setVerticalOffset(__verticalOffset.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("verticalOffset", this._verticalOffset);
				}
			}
					   		 			 
						if (this._zorder != null) {
				if (this._zorder.isLiteralText()) {
					try {
												
						Integer __zorder = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._zorder.getExpressionString(), 
											Integer.class);
					
												comp.setZorder(__zorder.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("zorder", this._zorder);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.component.ToolTip";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.renderkit.html.ToolTipRenderer";
			}

}
