package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIScrollableDataTable;
import org.richfaces.model.SelectionMode;
import org.richfaces.model.SortOrder;
import org.richfaces.model.selection.Selection;

public class HtmlScrollableDataTable extends UIScrollableDataTable{

static public final  String COMPONENT_FAMILY = "org.richfaces.component.ScrollableDataTable";

static public final  String COMPONENT_TYPE = "org.richfaces.component.ScrollableDataTable";

/*
* Assigns one or more space-separated CSS class names to the component active row
*/
private  String _activeClass = null;

/*
* Request scope attribute under which the activeRowKey will be accessible
*/
private  Object _activeRowKey = null;

/*
* If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
*/
private  boolean _bypassUpdates = false;

private  boolean _bypassUpdatesSet = false;

/*
* Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
*/
private  String _columnClasses = null;

/*
* Serialized (on default with JSON) data passed on the client by a developer on AJAX request. It's accessible via "data.foo" syntax
*/
private  Object _data = null;

/*
* Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
*/
private  String _eventsQueue = null;

/*
* id of the element to set focus after request completed on client side
*/
private  String _focus = null;

/*
* Assigns one or more space-separated CSS class names to any footer generated for this component
*/
private  String _footerClass = null;

/*
* Defines the number of the fixed columns from the left side that will not be scrolled via horizontal scroll.
			Default value is "0".
*/
private  int _frozenColCount = 0;

private  boolean _frozenColCountSet = false;

/*
* Assigns one or more space-separated CSS class names to any header generated for this component
*/
private  String _headerClass = null;

/*
* Defines a height of the component. Default value is "500px".
*/
private  String _height = null;

/*
* If "true" data will be hidden during scrolling. Can be used for increase performance.
			Default value is "false".
*/
private  boolean _hideWhenScrolling = false;

private  boolean _hideWhenScrollingSet = false;

/*
* Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
*/
private  boolean _ignoreDupResponses = false;

private  boolean _ignoreDupResponsesSet = false;

/*
* The client-side script method to be called when the row is clicked
*/
private  String _onRowClick = null;

/*
* The client-side script method to be called when the row is double-clicked
*/
private  String _onRowDblClick = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the row
*/
private  String _onRowMouseDown = null;

/*
* The client-side script method to be called when a mouse button is released over the row
*/
private  String _onRowMouseUp = null;

/*
* onbeforedomupdate
*/
private  String _onbeforedomupdate = null;

/*
* oncomplete
*/
private  String _oncomplete = null;

/*
* The client side script method to be called when a selected row is changed
*/
private  String _onselectionchange = null;

/*
* process
*/
private  Object _process = null;

/*
* Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
*/
private  Object _reRender = null;

/*
* Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
*/
private  int _requestDelay = Integer.MIN_VALUE;

private  boolean _requestDelaySet = false;

/*
* Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
*/
private  String _rowClasses = null;

/*
* Name of JavaScript variable corresponding to component
*/
private  String _scriptVar = null;

/*
* Assigns one or more space-separated CSS class names to the component rows selected
*/
private  String _selectedClass = null;

/*
* Value binding representing selected rows
*/
private  Selection _selection = null;

/*
* Defines selection behaviour, provides an enumeration of the possible selection modes. Default value is "multi"
*/
private  SelectionMode _selectionMode = null;

/*
* If there are any component requests with identical IDs then these requests will be grouped.
*/
private  String _similarityGroupingId = null;

/*
* Defines mode of sorting. Possible values are 'single' for sorting of one column and 'multi' for some.
*/
private  String _sortMode = null;

/*
* ValueBinding pointing at a property of a class to manage rows sorting
*/
private  SortOrder _sortOrder = null;

/*
* ID (in format of call UIComponent.findComponent()) of Request status component
*/
private  String _status = null;

/*
* CSS style rules to be applied to the component
*/
private  String _style = null;

/*
* Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
*/
private  String _styleClass = null;

/*
* Response waiting time on a particular request. If a response is not received during this time, the request is aborted
*/
private  int _timeout = Integer.MIN_VALUE;

private  boolean _timeoutSet = false;

/*
* Defines a width of the component. Default value is "700px".
*/
private  String _width = null;


public HtmlScrollableDataTable(){
setRendererType("org.richfaces.renderkit.html.ScrollableDataTableRenderer");
}

public String getActiveClass(){
	if (this._activeClass != null) {
		return this._activeClass;
	}
	ValueExpression ve = getValueExpression("activeClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setActiveClass(String _activeClass){
this._activeClass = _activeClass;
}

public Object getActiveRowKey(){
	if (this._activeRowKey != null) {
		return this._activeRowKey;
	}
	ValueExpression ve = getValueExpression("activeRowKey");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setActiveRowKey(Object _activeRowKey){
this._activeRowKey = _activeRowKey;
}

public boolean isBypassUpdates(){
	if (this._bypassUpdatesSet) {
	    return (this._bypassUpdates);
	}
	ValueExpression ve = getValueExpression("bypassUpdates");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._bypassUpdates);
	    }
	    
	    return value;
	} else {
	    return (this._bypassUpdates);
	}

}

public void setBypassUpdates(boolean _bypassUpdates){
this._bypassUpdates = _bypassUpdates;
this._bypassUpdatesSet = true;
}

public String getColumnClasses(){
	if (this._columnClasses != null) {
		return this._columnClasses;
	}
	ValueExpression ve = getValueExpression("columnClasses");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setColumnClasses(String _columnClasses){
this._columnClasses = _columnClasses;
}

public Object getData(){
	if (this._data != null) {
		return this._data;
	}
	ValueExpression ve = getValueExpression("data");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setData(Object _data){
this._data = _data;
}

public String getEventsQueue(){
	if (this._eventsQueue != null) {
		return this._eventsQueue;
	}
	ValueExpression ve = getValueExpression("eventsQueue");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setEventsQueue(String _eventsQueue){
this._eventsQueue = _eventsQueue;
}

public String getFocus(){
	if (this._focus != null) {
		return this._focus;
	}
	ValueExpression ve = getValueExpression("focus");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFocus(String _focus){
this._focus = _focus;
}

public String getFooterClass(){
	if (this._footerClass != null) {
		return this._footerClass;
	}
	ValueExpression ve = getValueExpression("footerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFooterClass(String _footerClass){
this._footerClass = _footerClass;
}

public int getFrozenColCount(){
	if (this._frozenColCountSet) {
	    return (this._frozenColCount);
	}
	ValueExpression ve = getValueExpression("frozenColCount");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._frozenColCount);
	    }
	    
	    return value;
	} else {
	    return (this._frozenColCount);
	}

}

public void setFrozenColCount(int _frozenColCount){
this._frozenColCount = _frozenColCount;
this._frozenColCountSet = true;
}

public String getHeaderClass(){
	if (this._headerClass != null) {
		return this._headerClass;
	}
	ValueExpression ve = getValueExpression("headerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setHeaderClass(String _headerClass){
this._headerClass = _headerClass;
}

public String getHeight(){
	if (this._height != null) {
		return this._height;
	}
	ValueExpression ve = getValueExpression("height");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "500px";
	

}

public void setHeight(String _height){
this._height = _height;
}

public boolean isHideWhenScrolling(){
	if (this._hideWhenScrollingSet) {
	    return (this._hideWhenScrolling);
	}
	ValueExpression ve = getValueExpression("hideWhenScrolling");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._hideWhenScrolling);
	    }
	    
	    return value;
	} else {
	    return (this._hideWhenScrolling);
	}

}

public void setHideWhenScrolling(boolean _hideWhenScrolling){
this._hideWhenScrolling = _hideWhenScrolling;
this._hideWhenScrollingSet = true;
}

public boolean isIgnoreDupResponses(){
	if (this._ignoreDupResponsesSet) {
	    return (this._ignoreDupResponses);
	}
	ValueExpression ve = getValueExpression("ignoreDupResponses");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._ignoreDupResponses);
	    }
	    
	    return value;
	} else {
	    return (this._ignoreDupResponses);
	}

}

public void setIgnoreDupResponses(boolean _ignoreDupResponses){
this._ignoreDupResponses = _ignoreDupResponses;
this._ignoreDupResponsesSet = true;
}

public String getOnRowClick(){
	if (this._onRowClick != null) {
		return this._onRowClick;
	}
	ValueExpression ve = getValueExpression("onRowClick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowClick(String _onRowClick){
this._onRowClick = _onRowClick;
}

public String getOnRowDblClick(){
	if (this._onRowDblClick != null) {
		return this._onRowDblClick;
	}
	ValueExpression ve = getValueExpression("onRowDblClick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowDblClick(String _onRowDblClick){
this._onRowDblClick = _onRowDblClick;
}

public String getOnRowMouseDown(){
	if (this._onRowMouseDown != null) {
		return this._onRowMouseDown;
	}
	ValueExpression ve = getValueExpression("onRowMouseDown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseDown(String _onRowMouseDown){
this._onRowMouseDown = _onRowMouseDown;
}

public String getOnRowMouseUp(){
	if (this._onRowMouseUp != null) {
		return this._onRowMouseUp;
	}
	ValueExpression ve = getValueExpression("onRowMouseUp");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseUp(String _onRowMouseUp){
this._onRowMouseUp = _onRowMouseUp;
}

public String getOnbeforedomupdate(){
	if (this._onbeforedomupdate != null) {
		return this._onbeforedomupdate;
	}
	ValueExpression ve = getValueExpression("onbeforedomupdate");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnbeforedomupdate(String _onbeforedomupdate){
this._onbeforedomupdate = _onbeforedomupdate;
}

public String getOncomplete(){
	if (this._oncomplete != null) {
		return this._oncomplete;
	}
	ValueExpression ve = getValueExpression("oncomplete");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOncomplete(String _oncomplete){
this._oncomplete = _oncomplete;
}

public String getOnselectionchange(){
	if (this._onselectionchange != null) {
		return this._onselectionchange;
	}
	ValueExpression ve = getValueExpression("onselectionchange");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnselectionchange(String _onselectionchange){
this._onselectionchange = _onselectionchange;
}

public Object getProcess(){
	if (this._process != null) {
		return this._process;
	}
	ValueExpression ve = getValueExpression("process");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setProcess(Object _process){
this._process = _process;
}

public Object getReRender(){
	if (this._reRender != null) {
		return this._reRender;
	}
	ValueExpression ve = getValueExpression("reRender");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setReRender(Object _reRender){
this._reRender = _reRender;
}

public int getRequestDelay(){
	if (this._requestDelaySet) {
	    return (this._requestDelay);
	}
	ValueExpression ve = getValueExpression("requestDelay");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._requestDelay);
	    }
	    
	    return value;
	} else {
	    return (this._requestDelay);
	}

}

public void setRequestDelay(int _requestDelay){
this._requestDelay = _requestDelay;
this._requestDelaySet = true;
}

public String getRowClasses(){
	if (this._rowClasses != null) {
		return this._rowClasses;
	}
	ValueExpression ve = getValueExpression("rowClasses");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setRowClasses(String _rowClasses){
this._rowClasses = _rowClasses;
}

public String getScriptVar(){
return _scriptVar;
}

public void setScriptVar(String _scriptVar){
this._scriptVar = _scriptVar;
}

public String getSelectedClass(){
	if (this._selectedClass != null) {
		return this._selectedClass;
	}
	ValueExpression ve = getValueExpression("selectedClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSelectedClass(String _selectedClass){
this._selectedClass = _selectedClass;
}

public Selection getSelection(){
	if (this._selection != null) {
		return this._selection;
	}
	ValueExpression ve = getValueExpression("selection");
	if (ve != null) {
	    Selection value = null;
	    
	    try {
			value = (Selection) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSelection(Selection _selection){
this._selection = _selection;
}

public SelectionMode getSelectionMode(){
	if (this._selectionMode != null) {
		return this._selectionMode;
	}
	ValueExpression ve = getValueExpression("selectionMode");
	if (ve != null) {
	    SelectionMode value = null;
	    
	    try {
			value = (SelectionMode) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return SelectionMode.multi;
	

}

public void setSelectionMode(SelectionMode _selectionMode){
this._selectionMode = _selectionMode;
}

public String getSimilarityGroupingId(){
	if (this._similarityGroupingId != null) {
		return this._similarityGroupingId;
	}
	ValueExpression ve = getValueExpression("similarityGroupingId");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSimilarityGroupingId(String _similarityGroupingId){
this._similarityGroupingId = _similarityGroupingId;
}

public String getSortMode(){
	if (this._sortMode != null) {
		return this._sortMode;
	}
	ValueExpression ve = getValueExpression("sortMode");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSortMode(String _sortMode){
this._sortMode = _sortMode;
}

public SortOrder getSortOrder(){
	if (this._sortOrder != null) {
		return this._sortOrder;
	}
	ValueExpression ve = getValueExpression("sortOrder");
	if (ve != null) {
	    SortOrder value = null;
	    
	    try {
			value = (SortOrder) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSortOrder(SortOrder _sortOrder){
this._sortOrder = _sortOrder;
}

public String getStatus(){
	if (this._status != null) {
		return this._status;
	}
	ValueExpression ve = getValueExpression("status");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStatus(String _status){
this._status = _status;
}

public String getStyle(){
	if (this._style != null) {
		return this._style;
	}
	ValueExpression ve = getValueExpression("style");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyle(String _style){
this._style = _style;
}

public String getStyleClass(){
	if (this._styleClass != null) {
		return this._styleClass;
	}
	ValueExpression ve = getValueExpression("styleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyleClass(String _styleClass){
this._styleClass = _styleClass;
}

public int getTimeout(){
	if (this._timeoutSet) {
	    return (this._timeout);
	}
	ValueExpression ve = getValueExpression("timeout");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._timeout);
	    }
	    
	    return value;
	} else {
	    return (this._timeout);
	}

}

public void setTimeout(int _timeout){
this._timeout = _timeout;
this._timeoutSet = true;
}

public String getWidth(){
	if (this._width != null) {
		return this._width;
	}
	ValueExpression ve = getValueExpression("width");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "700px";
	

}

public void setWidth(String _width){
this._width = _width;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[43];
state[0] = super.saveState(context);
state[1] = _activeClass;
state[2] = saveAttachedState(context, _activeRowKey);
state[3] = Boolean.valueOf(_bypassUpdates);
state[4] = Boolean.valueOf(_bypassUpdatesSet);
state[5] = _columnClasses;
state[6] = saveAttachedState(context, _data);
state[7] = _eventsQueue;
state[8] = _focus;
state[9] = _footerClass;
state[10] = Integer.valueOf(_frozenColCount);
state[11] = Boolean.valueOf(_frozenColCountSet);
state[12] = _headerClass;
state[13] = _height;
state[14] = Boolean.valueOf(_hideWhenScrolling);
state[15] = Boolean.valueOf(_hideWhenScrollingSet);
state[16] = Boolean.valueOf(_ignoreDupResponses);
state[17] = Boolean.valueOf(_ignoreDupResponsesSet);
state[18] = _onRowClick;
state[19] = _onRowDblClick;
state[20] = _onRowMouseDown;
state[21] = _onRowMouseUp;
state[22] = _onbeforedomupdate;
state[23] = _oncomplete;
state[24] = _onselectionchange;
state[25] = saveAttachedState(context, _process);
state[26] = saveAttachedState(context, _reRender);
state[27] = Integer.valueOf(_requestDelay);
state[28] = Boolean.valueOf(_requestDelaySet);
state[29] = _rowClasses;
state[30] = _scriptVar;
state[31] = _selectedClass;
state[32] = saveAttachedState(context, _selection);
state[33] = saveAttachedState(context, _selectionMode);
state[34] = _similarityGroupingId;
state[35] = _sortMode;
state[36] = saveAttachedState(context, _sortOrder);
state[37] = _status;
state[38] = _style;
state[39] = _styleClass;
state[40] = Integer.valueOf(_timeout);
state[41] = Boolean.valueOf(_timeoutSet);
state[42] = _width;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_activeClass = (String)states[1];;
		_activeRowKey = (Object)restoreAttachedState(context, states[2]);
		_bypassUpdates = ((Boolean)states[3]).booleanValue();
		_bypassUpdatesSet = ((Boolean)states[4]).booleanValue();
		_columnClasses = (String)states[5];;
		_data = (Object)restoreAttachedState(context, states[6]);
		_eventsQueue = (String)states[7];;
		_focus = (String)states[8];;
		_footerClass = (String)states[9];;
		_frozenColCount = ((Integer)states[10]).intValue();
		_frozenColCountSet = ((Boolean)states[11]).booleanValue();
		_headerClass = (String)states[12];;
		_height = (String)states[13];;
		_hideWhenScrolling = ((Boolean)states[14]).booleanValue();
		_hideWhenScrollingSet = ((Boolean)states[15]).booleanValue();
		_ignoreDupResponses = ((Boolean)states[16]).booleanValue();
		_ignoreDupResponsesSet = ((Boolean)states[17]).booleanValue();
		_onRowClick = (String)states[18];;
		_onRowDblClick = (String)states[19];;
		_onRowMouseDown = (String)states[20];;
		_onRowMouseUp = (String)states[21];;
		_onbeforedomupdate = (String)states[22];;
		_oncomplete = (String)states[23];;
		_onselectionchange = (String)states[24];;
		_process = (Object)restoreAttachedState(context, states[25]);
		_reRender = (Object)restoreAttachedState(context, states[26]);
		_requestDelay = ((Integer)states[27]).intValue();
		_requestDelaySet = ((Boolean)states[28]).booleanValue();
		_rowClasses = (String)states[29];;
		_scriptVar = (String)states[30];;
		_selectedClass = (String)states[31];;
		_selection = (Selection)restoreAttachedState(context, states[32]);
		_selectionMode = (SelectionMode)restoreAttachedState(context, states[33]);
		_similarityGroupingId = (String)states[34];;
		_sortMode = (String)states[35];;
		_sortOrder = (SortOrder)restoreAttachedState(context, states[36]);
		_status = (String)states[37];;
		_style = (String)states[38];;
		_styleClass = (String)states[39];;
		_timeout = ((Integer)states[40]).intValue();
		_timeoutSet = ((Boolean)states[41]).booleanValue();
		_width = (String)states[42];;
	
}

}
