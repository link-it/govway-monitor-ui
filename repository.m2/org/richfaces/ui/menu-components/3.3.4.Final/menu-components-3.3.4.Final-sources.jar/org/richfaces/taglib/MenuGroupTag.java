/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import java.lang.Integer ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlMenuGroup;

public class MenuGroupTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * direction
		 * Defines direction of the popup sublist to appear
                ("right", "left", "auto"(Default), "left-down", "left-up", "right-down", "right-up")
		 */
		private ValueExpression _direction;
		/**
		 * Defines direction of the popup sublist to appear
                ("right", "left", "auto"(Default), "left-down", "left-up", "right-down", "right-up")
		 * Setter for direction
		 * @param direction - new value
		 */
		 public void setDirection( ValueExpression  __direction ){
			this._direction = __direction;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabled
		 * If "true" sets state of the item to disabled state. Default value is "false".
		 */
		private ValueExpression _disabled;
		/**
		 * If "true" sets state of the item to disabled state. Default value is "false".
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * event
		 * Defines the event on the representation element that
                triggers the menu's appearance. Default value is "onmouseover".
		 */
		private ValueExpression _event;
		/**
		 * Defines the event on the representation element that
                triggers the menu's appearance. Default value is "onmouseover".
		 * Setter for event
		 * @param event - new value
		 */
		 public void setEvent( ValueExpression  __event ){
			this._event = __event;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * icon
		 * Path to the icon to be displayed for the enabled item
                state
		 */
		private ValueExpression _icon;
		/**
		 * Path to the icon to be displayed for the enabled item
                state
		 * Setter for icon
		 * @param icon - new value
		 */
		 public void setIcon( ValueExpression  __icon ){
			this._icon = __icon;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconClass
		 * Assigns one or more space-separated CSS class names to the component icon element
		 */
		private ValueExpression _iconClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component icon element
		 * Setter for iconClass
		 * @param iconClass - new value
		 */
		 public void setIconClass( ValueExpression  __iconClass ){
			this._iconClass = __iconClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconDisabled
		 * Path to the icon to be displayed for the disabled item
                state
		 */
		private ValueExpression _iconDisabled;
		/**
		 * Path to the icon to be displayed for the disabled item
                state
		 * Setter for iconDisabled
		 * @param iconDisabled - new value
		 */
		 public void setIconDisabled( ValueExpression  __iconDisabled ){
			this._iconDisabled = __iconDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconFolder
		 * Path to the folder icon to be displayed for the enabled
                item state
		 */
		private ValueExpression _iconFolder;
		/**
		 * Path to the folder icon to be displayed for the enabled
                item state
		 * Setter for iconFolder
		 * @param iconFolder - new value
		 */
		 public void setIconFolder( ValueExpression  __iconFolder ){
			this._iconFolder = __iconFolder;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconFolderDisabled
		 * Path to the folder icon to be displayed for the enabled
                item state
		 */
		private ValueExpression _iconFolderDisabled;
		/**
		 * Path to the folder icon to be displayed for the enabled
                item state
		 * Setter for iconFolderDisabled
		 * @param iconFolderDisabled - new value
		 */
		 public void setIconFolderDisabled( ValueExpression  __iconFolderDisabled ){
			this._iconFolderDisabled = __iconFolderDisabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconStyle
		 * CSS style rules to be applied to the component icon element
		 */
		private ValueExpression _iconStyle;
		/**
		 * CSS style rules to be applied to the component icon element
		 * Setter for iconStyle
		 * @param iconStyle - new value
		 */
		 public void setIconStyle( ValueExpression  __iconStyle ){
			this._iconStyle = __iconStyle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * labelClass
		 * Assigns one or more space-separated CSS class names to the component label element
		 */
		private ValueExpression _labelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component label element
		 * Setter for labelClass
		 * @param labelClass - new value
		 */
		 public void setLabelClass( ValueExpression  __labelClass ){
			this._labelClass = __labelClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * onclose
		 * The client-side script method to be called when a group is
                closed
		 */
		private ValueExpression _onclose;
		/**
		 * The client-side script method to be called when a group is
                closed
		 * Setter for onclose
		 * @param onclose - new value
		 */
		 public void setOnclose( ValueExpression  __onclose ){
			this._onclose = __onclose;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * onopen
		 * The client-side script method to be called when a group is
                opened
		 */
		private ValueExpression _onopen;
		/**
		 * The client-side script method to be called when a group is
                opened
		 * Setter for onopen
		 * @param onopen - new value
		 */
		 public void setOnopen( ValueExpression  __onopen ){
			this._onopen = __onopen;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * selectClass
		 * Assigns one or more space-separated CSS class names to the component selected items
		 */
		private ValueExpression _selectClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component selected items
		 * Setter for selectClass
		 * @param selectClass - new value
		 */
		 public void setSelectClass( ValueExpression  __selectClass ){
			this._selectClass = __selectClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectStyle
		 * CSS style rules to be applied to the component selected items
		 */
		private ValueExpression _selectStyle;
		/**
		 * CSS style rules to be applied to the component selected items
		 * Setter for selectStyle
		 * @param selectStyle - new value
		 */
		 public void setSelectStyle( ValueExpression  __selectStyle ){
			this._selectStyle = __selectStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showDelay
		 * Delay between event and menu showing. Default value is "300".
		 */
		private ValueExpression _showDelay;
		/**
		 * Delay between event and menu showing. Default value is "300".
		 * Setter for showDelay
		 * @param showDelay - new value
		 */
		 public void setShowDelay( ValueExpression  __showDelay ){
			this._showDelay = __showDelay;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * value
		 * Defines representation text for menuItem
		 */
		private ValueExpression _value;
		/**
		 * Defines representation text for menuItem
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._converter = null;
	 		 		    this._direction = null;
	 		 		    this._disabled = null;
	 		 		    this._event = null;
	 		 		 		    this._icon = null;
	 		 		    this._iconClass = null;
	 		 		    this._iconDisabled = null;
	 		 		    this._iconFolder = null;
	 		 		    this._iconFolderDisabled = null;
	 		 		    this._iconStyle = null;
	 		 		 		    this._labelClass = null;
	 		 		 		    this._onclose = null;
	 		 		 		 		 		    this._onopen = null;
	 		 		 		    this._selectClass = null;
	 		 		    this._selectStyle = null;
	 		 		    this._showDelay = null;
	 		 		 		 		    this._value = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlMenuGroup comp = (HtmlMenuGroup) component;
  		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._direction != null) {
				if (this._direction.isLiteralText()) {
					try {
												
						java.lang.String __direction = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._direction.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDirection(__direction);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("direction", this._direction);
				}
			}
					   		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					   		 			 
						if (this._event != null) {
				if (this._event.isLiteralText()) {
					try {
												
						java.lang.String __event = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._event.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEvent(__event);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("event", this._event);
				}
			}
					    		 			 
						if (this._icon != null) {
				if (this._icon.isLiteralText()) {
					try {
												
						java.lang.String __icon = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._icon.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIcon(__icon);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("icon", this._icon);
				}
			}
					   		 			 
						if (this._iconClass != null) {
				if (this._iconClass.isLiteralText()) {
					try {
												
						java.lang.String __iconClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconClass(__iconClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconClass", this._iconClass);
				}
			}
					   		 			 
						if (this._iconDisabled != null) {
				if (this._iconDisabled.isLiteralText()) {
					try {
												
						java.lang.String __iconDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconDisabled(__iconDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconDisabled", this._iconDisabled);
				}
			}
					   		 			 
						if (this._iconFolder != null) {
				if (this._iconFolder.isLiteralText()) {
					try {
												
						java.lang.String __iconFolder = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconFolder.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconFolder(__iconFolder);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconFolder", this._iconFolder);
				}
			}
					   		 			 
						if (this._iconFolderDisabled != null) {
				if (this._iconFolderDisabled.isLiteralText()) {
					try {
												
						java.lang.String __iconFolderDisabled = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconFolderDisabled.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconFolderDisabled(__iconFolderDisabled);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconFolderDisabled", this._iconFolderDisabled);
				}
			}
					   		 			 
						if (this._iconStyle != null) {
				if (this._iconStyle.isLiteralText()) {
					try {
												
						java.lang.String __iconStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconStyle(__iconStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconStyle", this._iconStyle);
				}
			}
					    		 			 
						if (this._labelClass != null) {
				if (this._labelClass.isLiteralText()) {
					try {
												
						java.lang.String __labelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._labelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabelClass(__labelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("labelClass", this._labelClass);
				}
			}
					    		 			 
						if (this._onclose != null) {
				if (this._onclose.isLiteralText()) {
					try {
												
						java.lang.String __onclose = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onclose.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnclose(__onclose);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onclose", this._onclose);
				}
			}
					      		 			 
						if (this._onopen != null) {
				if (this._onopen.isLiteralText()) {
					try {
												
						java.lang.String __onopen = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onopen.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnopen(__onopen);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onopen", this._onopen);
				}
			}
					    		 			 
						if (this._selectClass != null) {
				if (this._selectClass.isLiteralText()) {
					try {
												
						java.lang.String __selectClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectClass(__selectClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectClass", this._selectClass);
				}
			}
					   		 			 
						if (this._selectStyle != null) {
				if (this._selectStyle.isLiteralText()) {
					try {
												
						java.lang.String __selectStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectStyle(__selectStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectStyle", this._selectStyle);
				}
			}
					   		 			 
						if (this._showDelay != null) {
				if (this._showDelay.isLiteralText()) {
					try {
												
						java.lang.Integer __showDelay = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showDelay.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setShowDelay(__showDelay);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showDelay", this._showDelay);
				}
			}
					     		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.MenuGroup";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.MenuGroupRenderer";
			}

}
