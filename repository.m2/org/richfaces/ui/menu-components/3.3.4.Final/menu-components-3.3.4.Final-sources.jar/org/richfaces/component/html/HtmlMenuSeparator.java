package org.richfaces.component.html;

import javax.faces.context.FacesContext;
import org.richfaces.component.UIMenuSeparator;

public class HtmlMenuSeparator extends UIMenuSeparator{

final static public  String COMPONENT_FAMILY = "org.richfaces.DropDownMenu";

final static public  String COMPONENT_TYPE = "org.richfaces.MenuSeparator";


public HtmlMenuSeparator(){
setRendererType("org.richfaces.MenuSeparatorRenderer");
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[1];
state[0] = super.saveState(context);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);

}

}
