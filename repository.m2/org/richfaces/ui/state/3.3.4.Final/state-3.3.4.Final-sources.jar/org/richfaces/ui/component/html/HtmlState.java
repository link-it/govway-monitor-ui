package org.richfaces.ui.component.html;

import javax.faces.context.FacesContext;
import org.richfaces.ui.component.UIState;

public class HtmlState extends UIState{

static public final  String COMPONENT_FAMILY = "org.richfaces.ui.State";

static public final  String COMPONENT_TYPE = "org.richfaces.ui.State";


public HtmlState(){
setRendererType("org.richfaces.ui.StateRenderer");
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[1];
state[0] = super.saveState(context);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);

}

}
