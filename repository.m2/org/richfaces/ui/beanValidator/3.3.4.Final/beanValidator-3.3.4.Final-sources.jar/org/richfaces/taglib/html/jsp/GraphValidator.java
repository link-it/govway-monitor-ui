/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib.html.jsp;

import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;
import org.ajax4jsf.webapp.taglib.UIComponentTagBase ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlGraphValidator;

public class GraphValidator extends org.ajax4jsf.webapp.taglib.UIComponentTagBase {

		// Fields
		 		 		 		 	  			  		  	  
		/*
		 * profiles
		 * This attribute defines JavaBean Validation 'groups' feature (JSR-303). It is ignored if Hibernate Validator is used.
		 */
		private ValueExpression _profiles;
		/**
		 * This attribute defines JavaBean Validation 'groups' feature (JSR-303). It is ignored if Hibernate Validator is used.
		 * Setter for profiles
		 * @param profiles - new value
		 */
		 public void setProfiles( ValueExpression  __profiles ){
			this._profiles = __profiles;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * summary
		 * Summary message for a validation errors.
		 */
		private ValueExpression _summary;
		/**
		 * Summary message for a validation errors.
		 * Setter for summary
		 * @param summary - new value
		 */
		 public void setSummary( ValueExpression  __summary ){
			this._summary = __summary;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * type
		 * JSF Validator type, that implements GraphValidator interface.This validator is used for the Graph and input fields validation.
		 */
		private ValueExpression _type;
		/**
		 * JSF Validator type, that implements GraphValidator interface.This validator is used for the Graph and input fields validation.
		 * Setter for type
		 * @param type - new value
		 */
		 public void setType( ValueExpression  __type ){
			this._type = __type;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component.
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component.
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		    this._profiles = null;
	 		 		 		    this._summary = null;
	 		 		    this._type = null;
	 		 		    this._value = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlGraphValidator comp = (HtmlGraphValidator) component;
    		 			 
						if (this._profiles != null) {
				if (this._profiles.isLiteralText()) {
					try {
												
						java.lang.Object __profiles = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._profiles.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setProfiles(__profiles);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("profiles", this._profiles);
				}
			}
					    		 			 
						if (this._summary != null) {
				if (this._summary.isLiteralText()) {
					try {
												
						java.lang.String __summary = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._summary.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSummary(__summary);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("summary", this._summary);
				}
			}
					   		 			 
						if (this._type != null) {
				if (this._type.isLiteralText()) {
					try {
												
						java.lang.String __type = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._type.getExpressionString(), 
											java.lang.String.class);
					
												comp.setType(__type);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("type", this._type);
				}
			}
					   		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.GraphValidator";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return null;
			}

}
