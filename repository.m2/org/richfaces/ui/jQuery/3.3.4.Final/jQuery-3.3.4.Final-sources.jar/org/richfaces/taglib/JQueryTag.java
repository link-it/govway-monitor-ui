/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlJQuery;

public class JQueryTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 		 	  			  		  	  
		/*
		 * name
		 * The name of a function that will be generated to execute a query. The "name" attribute is required 
			    if "timing" attribute equals to "onJScall"
		 */
		private ValueExpression _name;
		/**
		 * The name of a function that will be generated to execute a query. The "name" attribute is required 
			    if "timing" attribute equals to "onJScall"
		 * Setter for name
		 * @param name - new value
		 */
		 public void setName( ValueExpression  __name ){
			this._name = __name;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * query
		 * The query string that is executed for a given selector.
		 */
		private ValueExpression _query;
		/**
		 * The query string that is executed for a given selector.
		 * Setter for query
		 * @param query - new value
		 */
		 public void setQuery( ValueExpression  __query ){
			this._query = __query;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * selector
		 * Selector for query. The "selector" attribute uses defined by w3c
			    consortium syntax for CSS rule selector with some jQuery extensions.
		 */
		private ValueExpression _selector;
		/**
		 * Selector for query. The "selector" attribute uses defined by w3c
			    consortium syntax for CSS rule selector with some jQuery extensions.
		 * Setter for selector
		 * @param selector - new value
		 */
		 public void setSelector( ValueExpression  __selector ){
			this._selector = __selector;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * timing
		 * The attribute that defines when to perform the query. The possible values are "immediate","onload" and "onJScall". 
			 "immediate" performs the query right away. "onload" adds the task to the
			 time when a document is loaded (the DOM tree is created). "onJScall" allows to invoke the 
			 query by Javascipt function name defined with "name" attribute. The default value is 
			 "immediate".
		 */
		private ValueExpression _timing;
		/**
		 * The attribute that defines when to perform the query. The possible values are "immediate","onload" and "onJScall". 
			 "immediate" performs the query right away. "onload" adds the task to the
			 time when a document is loaded (the DOM tree is created). "onJScall" allows to invoke the 
			 query by Javascipt function name defined with "name" attribute. The default value is 
			 "immediate".
		 * Setter for timing
		 * @param timing - new value
		 */
		 public void setTiming( ValueExpression  __timing ){
			this._timing = __timing;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		    this._name = null;
	 		 		    this._query = null;
	 		 		 		    this._selector = null;
	 		 		    this._timing = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlJQuery comp = (HtmlJQuery) component;
    		 			 
						if (this._name != null) {
				if (this._name.isLiteralText()) {
					try {
												
						java.lang.String __name = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._name.getExpressionString(), 
											java.lang.String.class);
					
												comp.setName(__name);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("name", this._name);
				}
			}
					   		 			 
						if (this._query != null) {
				if (this._query.isLiteralText()) {
					try {
												
						java.lang.String __query = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._query.getExpressionString(), 
											java.lang.String.class);
					
												comp.setQuery(__query);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("query", this._query);
				}
			}
					    		 			 
						if (this._selector != null) {
				if (this._selector.isLiteralText()) {
					try {
												
						java.lang.String __selector = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selector.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelector(__selector);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selector", this._selector);
				}
			}
					   		 			 
						if (this._timing != null) {
				if (this._timing.isLiteralText()) {
					try {
												
						java.lang.String __timing = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timing.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTiming(__timing);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timing", this._timing);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.JQuery";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.JQueryRenderer";
			}

}
