/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPanelMenu;

public class PanelMenuTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabled
		 * If true sets state of the item to disabled state. Default value is "false".
		 */
		private ValueExpression _disabled;
		/**
		 * If true sets state of the item to disabled state. Default value is "false".
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledGroupClass
		 * Assigns one or more space-separated CSS class names to the component disabled groups
		 */
		private ValueExpression _disabledGroupClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component disabled groups
		 * Setter for disabledGroupClass
		 * @param disabledGroupClass - new value
		 */
		 public void setDisabledGroupClass( ValueExpression  __disabledGroupClass ){
			this._disabledGroupClass = __disabledGroupClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledGroupStyle
		 * CSS style rules to be applied to the component disabled groups
		 */
		private ValueExpression _disabledGroupStyle;
		/**
		 * CSS style rules to be applied to the component disabled groups
		 * Setter for disabledGroupStyle
		 * @param disabledGroupStyle - new value
		 */
		 public void setDisabledGroupStyle( ValueExpression  __disabledGroupStyle ){
			this._disabledGroupStyle = __disabledGroupStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledItemClass
		 * Assigns one or more space-separated CSS class names to the component disabled items
		 */
		private ValueExpression _disabledItemClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component disabled items
		 * Setter for disabledItemClass
		 * @param disabledItemClass - new value
		 */
		 public void setDisabledItemClass( ValueExpression  __disabledItemClass ){
			this._disabledItemClass = __disabledItemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledItemStyle
		 * CSS style rules to be applied to the component disabled items
		 */
		private ValueExpression _disabledItemStyle;
		/**
		 * CSS style rules to be applied to the component disabled items
		 * Setter for disabledItemStyle
		 * @param disabledItemStyle - new value
		 */
		 public void setDisabledItemStyle( ValueExpression  __disabledItemStyle ){
			this._disabledItemStyle = __disabledItemStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * event
		 * Defines the event on the representation element that triggers the
				submenu's expand/collapse. Default value is "onclick".
		 */
		private ValueExpression _event;
		/**
		 * Defines the event on the representation element that triggers the
				submenu's expand/collapse. Default value is "onclick".
		 * Setter for event
		 * @param event - new value
		 */
		 public void setEvent( ValueExpression  __event ){
			this._event = __event;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * expandMode
		 * Set the submission mode for all panel menu groups after expand/collapse
				except ones where this attribute redefined. Possible values are "ajax", "server", "none". 
				Default value is "none".
		 */
		private ValueExpression _expandMode;
		/**
		 * Set the submission mode for all panel menu groups after expand/collapse
				except ones where this attribute redefined. Possible values are "ajax", "server", "none". 
				Default value is "none".
		 * Setter for expandMode
		 * @param expandMode - new value
		 */
		 public void setExpandMode( ValueExpression  __expandMode ){
			this._expandMode = __expandMode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * expandSingle
		 * Whether only one panel menu node on top level can be opened at a time. If
				the value of this attribute is true, the previously opened node on the top level is
				closed. If the value is false, the node is left opened. Default value is "false".
		 */
		private ValueExpression _expandSingle;
		/**
		 * Whether only one panel menu node on top level can be opened at a time. If
				the value of this attribute is true, the previously opened node on the top level is
				closed. If the value is false, the node is left opened. Default value is "false".
		 * Setter for expandSingle
		 * @param expandSingle - new value
		 */
		 public void setExpandSingle( ValueExpression  __expandSingle ){
			this._expandSingle = __expandSingle;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * groupClass
		 * Assigns one or more space-separated CSS class names to any component group except top groups
		 */
		private ValueExpression _groupClass;
		/**
		 * Assigns one or more space-separated CSS class names to any component group except top groups
		 * Setter for groupClass
		 * @param groupClass - new value
		 */
		 public void setGroupClass( ValueExpression  __groupClass ){
			this._groupClass = __groupClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * groupStyle
		 * CSS style rules to be applied to any component group except top groups
		 */
		private ValueExpression _groupStyle;
		/**
		 * CSS style rules to be applied to any component group except top groups
		 * Setter for groupStyle
		 * @param groupStyle - new value
		 */
		 public void setGroupStyle( ValueExpression  __groupStyle ){
			this._groupStyle = __groupStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hoveredGroupClass
		 * Assigns one or more space-separated CSS class names to the component hovered group
		 */
		private ValueExpression _hoveredGroupClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component hovered group
		 * Setter for hoveredGroupClass
		 * @param hoveredGroupClass - new value
		 */
		 public void setHoveredGroupClass( ValueExpression  __hoveredGroupClass ){
			this._hoveredGroupClass = __hoveredGroupClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hoveredGroupStyle
		 * CSS style rules to be applied to the component hovered group
		 */
		private ValueExpression _hoveredGroupStyle;
		/**
		 * CSS style rules to be applied to the component hovered group
		 * Setter for hoveredGroupStyle
		 * @param hoveredGroupStyle - new value
		 */
		 public void setHoveredGroupStyle( ValueExpression  __hoveredGroupStyle ){
			this._hoveredGroupStyle = __hoveredGroupStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hoveredItemClass
		 * Assigns one or more space-separated CSS class names to the component hovered item
		 */
		private ValueExpression _hoveredItemClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component hovered item
		 * Setter for hoveredItemClass
		 * @param hoveredItemClass - new value
		 */
		 public void setHoveredItemClass( ValueExpression  __hoveredItemClass ){
			this._hoveredItemClass = __hoveredItemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hoveredItemStyle
		 * CSS style rules to be applied to the component hovered item
		 */
		private ValueExpression _hoveredItemStyle;
		/**
		 * CSS style rules to be applied to the component hovered item
		 * Setter for hoveredItemStyle
		 * @param hoveredItemStyle - new value
		 */
		 public void setHoveredItemStyle( ValueExpression  __hoveredItemStyle ){
			this._hoveredItemStyle = __hoveredItemStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconCollapsedGroup
		 * Path to the icon to be displayed for the collapsed Group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconCollapsedGroup;
		/**
		 * Path to the icon to be displayed for the collapsed Group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconCollapsedGroup
		 * @param iconCollapsedGroup - new value
		 */
		 public void setIconCollapsedGroup( ValueExpression  __iconCollapsedGroup ){
			this._iconCollapsedGroup = __iconCollapsedGroup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconCollapsedTopGroup
		 * Path to the icon to be displayed for the collapsed top group state.\
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconCollapsedTopGroup;
		/**
		 * Path to the icon to be displayed for the collapsed top group state.\
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconCollapsedTopGroup
		 * @param iconCollapsedTopGroup - new value
		 */
		 public void setIconCollapsedTopGroup( ValueExpression  __iconCollapsedTopGroup ){
			this._iconCollapsedTopGroup = __iconCollapsedTopGroup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconDisabledGroup
		 * Path to the icon to be displayed for the disabled group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconDisabledGroup;
		/**
		 * Path to the icon to be displayed for the disabled group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconDisabledGroup
		 * @param iconDisabledGroup - new value
		 */
		 public void setIconDisabledGroup( ValueExpression  __iconDisabledGroup ){
			this._iconDisabledGroup = __iconDisabledGroup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconDisabledItem
		 * Path to the icon to be displayed for the disabled item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconDisabledItem;
		/**
		 * Path to the icon to be displayed for the disabled item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconDisabledItem
		 * @param iconDisabledItem - new value
		 */
		 public void setIconDisabledItem( ValueExpression  __iconDisabledItem ){
			this._iconDisabledItem = __iconDisabledItem;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconExpandedGroup
		 * Path to the icon to be displayed for the expanded Group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconExpandedGroup;
		/**
		 * Path to the icon to be displayed for the expanded Group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconExpandedGroup
		 * @param iconExpandedGroup - new value
		 */
		 public void setIconExpandedGroup( ValueExpression  __iconExpandedGroup ){
			this._iconExpandedGroup = __iconExpandedGroup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconExpandedTopGroup
		 * Path to the icon to be displayed for the expanded top group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconExpandedTopGroup;
		/**
		 * Path to the icon to be displayed for the expanded top group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconExpandedTopGroup
		 * @param iconExpandedTopGroup - new value
		 */
		 public void setIconExpandedTopGroup( ValueExpression  __iconExpandedTopGroup ){
			this._iconExpandedTopGroup = __iconExpandedTopGroup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconGroupPosition
		 * Position of the icon for the group icon. Possible values are "left","right","none". Default value is "left".
		 */
		private ValueExpression _iconGroupPosition;
		/**
		 * Position of the icon for the group icon. Possible values are "left","right","none". Default value is "left".
		 * Setter for iconGroupPosition
		 * @param iconGroupPosition - new value
		 */
		 public void setIconGroupPosition( ValueExpression  __iconGroupPosition ){
			this._iconGroupPosition = __iconGroupPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconGroupTopPosition
		 * Position of the icon for the top group icon. Possible values are "left","right","none". Default value is "left".
		 */
		private ValueExpression _iconGroupTopPosition;
		/**
		 * Position of the icon for the top group icon. Possible values are "left","right","none". Default value is "left".
		 * Setter for iconGroupTopPosition
		 * @param iconGroupTopPosition - new value
		 */
		 public void setIconGroupTopPosition( ValueExpression  __iconGroupTopPosition ){
			this._iconGroupTopPosition = __iconGroupTopPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconItem
		 * Path to the icon to be displayed for the enabled item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconItem;
		/**
		 * Path to the icon to be displayed for the enabled item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconItem
		 * @param iconItem - new value
		 */
		 public void setIconItem( ValueExpression  __iconItem ){
			this._iconItem = __iconItem;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconItemPosition
		 * Position of the icon for the item icon. Possible values are "left","right","none". Default value is "left".
		 */
		private ValueExpression _iconItemPosition;
		/**
		 * Position of the icon for the item icon. Possible values are "left","right","none". Default value is "left".
		 * Setter for iconItemPosition
		 * @param iconItemPosition - new value
		 */
		 public void setIconItemPosition( ValueExpression  __iconItemPosition ){
			this._iconItemPosition = __iconItemPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconItemTopPosition
		 * Position of the icon for the top item icon.
				Possible values are "left","right","none". Default value is "left".
		 */
		private ValueExpression _iconItemTopPosition;
		/**
		 * Position of the icon for the top item icon.
				Possible values are "left","right","none". Default value is "left".
		 * Setter for iconItemTopPosition
		 * @param iconItemTopPosition - new value
		 */
		 public void setIconItemTopPosition( ValueExpression  __iconItemTopPosition ){
			this._iconItemTopPosition = __iconItemTopPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconTopDisableGroup
		 * Path to the icon to be displayed for the disabled top Group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconTopDisableGroup;
		/**
		 * Path to the icon to be displayed for the disabled top Group state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconTopDisableGroup
		 * @param iconTopDisableGroup - new value
		 */
		 public void setIconTopDisableGroup( ValueExpression  __iconTopDisableGroup ){
			this._iconTopDisableGroup = __iconTopDisableGroup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconTopDisabledItem
		 * Path to the icon to be displayed for the disabled top item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconTopDisabledItem;
		/**
		 * Path to the icon to be displayed for the disabled top item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconTopDisabledItem
		 * @param iconTopDisabledItem - new value
		 */
		 public void setIconTopDisabledItem( ValueExpression  __iconTopDisabledItem ){
			this._iconTopDisabledItem = __iconTopDisabledItem;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * iconTopItem
		 * Path to the icon to be displayed for the enabled top item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 */
		private ValueExpression _iconTopItem;
		/**
		 * Path to the icon to be displayed for the enabled top item state.
				You can also use predefined icons, setting the attribute to one of these possible values: "triangle", "triangleUp", "triangleDown", "disc", "chevron", "chevronUp", "chevronDown", "grid".
				Default value is "grid".
		 * Setter for iconTopItem
		 * @param iconTopItem - new value
		 */
		 public void setIconTopItem( ValueExpression  __iconTopItem ){
			this._iconTopItem = __iconTopItem;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * itemClass
		 * Assigns one or more space-separated CSS class names to any component item except top items
		 */
		private ValueExpression _itemClass;
		/**
		 * Assigns one or more space-separated CSS class names to any component item except top items
		 * Setter for itemClass
		 * @param itemClass - new value
		 */
		 public void setItemClass( ValueExpression  __itemClass ){
			this._itemClass = __itemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * itemStyle
		 * CSS style rules to be applied to the component item except top items
		 */
		private ValueExpression _itemStyle;
		/**
		 * CSS style rules to be applied to the component item except top items
		 * Setter for itemStyle
		 * @param itemStyle - new value
		 */
		 public void setItemStyle( ValueExpression  __itemStyle ){
			this._itemStyle = __itemStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * mode
		 * Set the submission mode for all panel menu items on the panel menu except
				ones where this attribute redefined. Possible values are "ajax", "server", "server". Default value is "server".
		 */
		private ValueExpression _mode;
		/**
		 * Set the submission mode for all panel menu items on the panel menu except
				ones where this attribute redefined. Possible values are "ajax", "server", "server". Default value is "server".
		 * Setter for mode
		 * @param mode - new value
		 */
		 public void setMode( ValueExpression  __mode ){
			this._mode = __mode;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * ongroupcollapse
		 * The client-side script method to be called when some group is closed
		 */
		private ValueExpression _ongroupcollapse;
		/**
		 * The client-side script method to be called when some group is closed
		 * Setter for ongroupcollapse
		 * @param ongroupcollapse - new value
		 */
		 public void setOngroupcollapse( ValueExpression  __ongroupcollapse ){
			this._ongroupcollapse = __ongroupcollapse;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ongroupexpand
		 * The client-side script method to be called when some group is activated
		 */
		private ValueExpression _ongroupexpand;
		/**
		 * The client-side script method to be called when some group is activated
		 * Setter for ongroupexpand
		 * @param ongroupexpand - new value
		 */
		 public void setOngroupexpand( ValueExpression  __ongroupexpand ){
			this._ongroupexpand = __ongroupexpand;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onitemhover
		 * The client-side script method to be called when a panel menu item is hovered
		 */
		private ValueExpression _onitemhover;
		/**
		 * The client-side script method to be called when a panel menu item is hovered
		 * Setter for onitemhover
		 * @param onitemhover - new value
		 */
		 public void setOnitemhover( ValueExpression  __onitemhover ){
			this._onitemhover = __onitemhover;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectedChild
		 * contain the name or the clientId of any of the item or group, the child
				defined in this attribute should be highlighted on PanelMenu rendering
		 */
		private ValueExpression _selectedChild;
		/**
		 * contain the name or the clientId of any of the item or group, the child
				defined in this attribute should be highlighted on PanelMenu rendering
		 * Setter for selectedChild
		 * @param selectedChild - new value
		 */
		 public void setSelectedChild( ValueExpression  __selectedChild ){
			this._selectedChild = __selectedChild;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * topGroupClass
		 * Assigns one or more space-separated CSS class names to the component top groups
		 */
		private ValueExpression _topGroupClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component top groups
		 * Setter for topGroupClass
		 * @param topGroupClass - new value
		 */
		 public void setTopGroupClass( ValueExpression  __topGroupClass ){
			this._topGroupClass = __topGroupClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topGroupStyle
		 * CSS style rules to be applied to the component top groups
		 */
		private ValueExpression _topGroupStyle;
		/**
		 * CSS style rules to be applied to the component top groups
		 * Setter for topGroupStyle
		 * @param topGroupStyle - new value
		 */
		 public void setTopGroupStyle( ValueExpression  __topGroupStyle ){
			this._topGroupStyle = __topGroupStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topItemClass
		 * Assigns one or more space-separated CSS class names to the component top items
		 */
		private ValueExpression _topItemClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component top items
		 * Setter for topItemClass
		 * @param topItemClass - new value
		 */
		 public void setTopItemClass( ValueExpression  __topItemClass ){
			this._topItemClass = __topItemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * topItemStyle
		 * CSS style rules to be applied to the component top items
		 */
		private ValueExpression _topItemStyle;
		/**
		 * CSS style rules to be applied to the component top items
		 * Setter for topItemStyle
		 * @param topItemStyle - new value
		 */
		 public void setTopItemStyle( ValueExpression  __topItemStyle ){
			this._topItemStyle = __topItemStyle;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * width
		 * Set minimal width for the menu. Default value is "100%".
		 */
		private ValueExpression _width;
		/**
		 * Set minimal width for the menu. Default value is "100%".
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._disabled = null;
	 		 		    this._disabledGroupClass = null;
	 		 		    this._disabledGroupStyle = null;
	 		 		    this._disabledItemClass = null;
	 		 		    this._disabledItemStyle = null;
	 		 		    this._event = null;
	 		 		    this._expandMode = null;
	 		 		    this._expandSingle = null;
	 		 		 		 		    this._groupClass = null;
	 		 		    this._groupStyle = null;
	 		 		    this._hoveredGroupClass = null;
	 		 		    this._hoveredGroupStyle = null;
	 		 		    this._hoveredItemClass = null;
	 		 		    this._hoveredItemStyle = null;
	 		 		    this._iconCollapsedGroup = null;
	 		 		    this._iconCollapsedTopGroup = null;
	 		 		    this._iconDisabledGroup = null;
	 		 		    this._iconDisabledItem = null;
	 		 		    this._iconExpandedGroup = null;
	 		 		    this._iconExpandedTopGroup = null;
	 		 		    this._iconGroupPosition = null;
	 		 		    this._iconGroupTopPosition = null;
	 		 		    this._iconItem = null;
	 		 		    this._iconItemPosition = null;
	 		 		    this._iconItemTopPosition = null;
	 		 		    this._iconTopDisableGroup = null;
	 		 		    this._iconTopDisabledItem = null;
	 		 		    this._iconTopItem = null;
	 		 		 		    this._immediate = null;
	 		 		    this._itemClass = null;
	 		 		    this._itemStyle = null;
	 		 		    this._label = null;
	 		 		 		 		    this._mode = null;
	 		 		 		 		    this._ongroupcollapse = null;
	 		 		    this._ongroupexpand = null;
	 		 		    this._onitemhover = null;
	 		 		 		 		 		 		 		 		 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		    this._selectedChild = null;
	 		 		 		 		 		    this._topGroupClass = null;
	 		 		    this._topGroupStyle = null;
	 		 		    this._topItemClass = null;
	 		 		    this._topItemStyle = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPanelMenu comp = (HtmlPanelMenu) component;
  		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					   		 			 
						if (this._disabledGroupClass != null) {
				if (this._disabledGroupClass.isLiteralText()) {
					try {
												
						java.lang.String __disabledGroupClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledGroupClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledGroupClass(__disabledGroupClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledGroupClass", this._disabledGroupClass);
				}
			}
					   		 			 
						if (this._disabledGroupStyle != null) {
				if (this._disabledGroupStyle.isLiteralText()) {
					try {
												
						java.lang.String __disabledGroupStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledGroupStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledGroupStyle(__disabledGroupStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledGroupStyle", this._disabledGroupStyle);
				}
			}
					   		 			 
						if (this._disabledItemClass != null) {
				if (this._disabledItemClass.isLiteralText()) {
					try {
												
						java.lang.String __disabledItemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledItemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledItemClass(__disabledItemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledItemClass", this._disabledItemClass);
				}
			}
					   		 			 
						if (this._disabledItemStyle != null) {
				if (this._disabledItemStyle.isLiteralText()) {
					try {
												
						java.lang.String __disabledItemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledItemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledItemStyle(__disabledItemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledItemStyle", this._disabledItemStyle);
				}
			}
					   		 			 
						if (this._event != null) {
				if (this._event.isLiteralText()) {
					try {
												
						java.lang.String __event = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._event.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEvent(__event);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("event", this._event);
				}
			}
					   		 			 
						if (this._expandMode != null) {
				if (this._expandMode.isLiteralText()) {
					try {
												
						java.lang.String __expandMode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._expandMode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setExpandMode(__expandMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("expandMode", this._expandMode);
				}
			}
					   		 			 
						if (this._expandSingle != null) {
				if (this._expandSingle.isLiteralText()) {
					try {
												
						Boolean __expandSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._expandSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setExpandSingle(__expandSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("expandSingle", this._expandSingle);
				}
			}
					     		 			 
						if (this._groupClass != null) {
				if (this._groupClass.isLiteralText()) {
					try {
												
						java.lang.String __groupClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._groupClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGroupClass(__groupClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("groupClass", this._groupClass);
				}
			}
					   		 			 
						if (this._groupStyle != null) {
				if (this._groupStyle.isLiteralText()) {
					try {
												
						java.lang.String __groupStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._groupStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGroupStyle(__groupStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("groupStyle", this._groupStyle);
				}
			}
					   		 			 
						if (this._hoveredGroupClass != null) {
				if (this._hoveredGroupClass.isLiteralText()) {
					try {
												
						java.lang.String __hoveredGroupClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hoveredGroupClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHoveredGroupClass(__hoveredGroupClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hoveredGroupClass", this._hoveredGroupClass);
				}
			}
					   		 			 
						if (this._hoveredGroupStyle != null) {
				if (this._hoveredGroupStyle.isLiteralText()) {
					try {
												
						java.lang.String __hoveredGroupStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hoveredGroupStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHoveredGroupStyle(__hoveredGroupStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hoveredGroupStyle", this._hoveredGroupStyle);
				}
			}
					   		 			 
						if (this._hoveredItemClass != null) {
				if (this._hoveredItemClass.isLiteralText()) {
					try {
												
						java.lang.String __hoveredItemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hoveredItemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHoveredItemClass(__hoveredItemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hoveredItemClass", this._hoveredItemClass);
				}
			}
					   		 			 
						if (this._hoveredItemStyle != null) {
				if (this._hoveredItemStyle.isLiteralText()) {
					try {
												
						java.lang.String __hoveredItemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hoveredItemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHoveredItemStyle(__hoveredItemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hoveredItemStyle", this._hoveredItemStyle);
				}
			}
					   		 			 
						if (this._iconCollapsedGroup != null) {
				if (this._iconCollapsedGroup.isLiteralText()) {
					try {
												
						java.lang.String __iconCollapsedGroup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconCollapsedGroup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconCollapsedGroup(__iconCollapsedGroup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconCollapsedGroup", this._iconCollapsedGroup);
				}
			}
					   		 			 
						if (this._iconCollapsedTopGroup != null) {
				if (this._iconCollapsedTopGroup.isLiteralText()) {
					try {
												
						java.lang.String __iconCollapsedTopGroup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconCollapsedTopGroup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconCollapsedTopGroup(__iconCollapsedTopGroup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconCollapsedTopGroup", this._iconCollapsedTopGroup);
				}
			}
					   		 			 
						if (this._iconDisabledGroup != null) {
				if (this._iconDisabledGroup.isLiteralText()) {
					try {
												
						java.lang.String __iconDisabledGroup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconDisabledGroup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconDisabledGroup(__iconDisabledGroup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconDisabledGroup", this._iconDisabledGroup);
				}
			}
					   		 			 
						if (this._iconDisabledItem != null) {
				if (this._iconDisabledItem.isLiteralText()) {
					try {
												
						java.lang.String __iconDisabledItem = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconDisabledItem.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconDisabledItem(__iconDisabledItem);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconDisabledItem", this._iconDisabledItem);
				}
			}
					   		 			 
						if (this._iconExpandedGroup != null) {
				if (this._iconExpandedGroup.isLiteralText()) {
					try {
												
						java.lang.String __iconExpandedGroup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconExpandedGroup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconExpandedGroup(__iconExpandedGroup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconExpandedGroup", this._iconExpandedGroup);
				}
			}
					   		 			 
						if (this._iconExpandedTopGroup != null) {
				if (this._iconExpandedTopGroup.isLiteralText()) {
					try {
												
						java.lang.String __iconExpandedTopGroup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconExpandedTopGroup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconExpandedTopGroup(__iconExpandedTopGroup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconExpandedTopGroup", this._iconExpandedTopGroup);
				}
			}
					   		 			 
						if (this._iconGroupPosition != null) {
				if (this._iconGroupPosition.isLiteralText()) {
					try {
												
						java.lang.String __iconGroupPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconGroupPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconGroupPosition(__iconGroupPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconGroupPosition", this._iconGroupPosition);
				}
			}
					   		 			 
						if (this._iconGroupTopPosition != null) {
				if (this._iconGroupTopPosition.isLiteralText()) {
					try {
												
						java.lang.String __iconGroupTopPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconGroupTopPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconGroupTopPosition(__iconGroupTopPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconGroupTopPosition", this._iconGroupTopPosition);
				}
			}
					   		 			 
						if (this._iconItem != null) {
				if (this._iconItem.isLiteralText()) {
					try {
												
						java.lang.String __iconItem = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconItem.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconItem(__iconItem);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconItem", this._iconItem);
				}
			}
					   		 			 
						if (this._iconItemPosition != null) {
				if (this._iconItemPosition.isLiteralText()) {
					try {
												
						java.lang.String __iconItemPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconItemPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconItemPosition(__iconItemPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconItemPosition", this._iconItemPosition);
				}
			}
					   		 			 
						if (this._iconItemTopPosition != null) {
				if (this._iconItemTopPosition.isLiteralText()) {
					try {
												
						java.lang.String __iconItemTopPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconItemTopPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconItemTopPosition(__iconItemTopPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconItemTopPosition", this._iconItemTopPosition);
				}
			}
					   		 			 
						if (this._iconTopDisableGroup != null) {
				if (this._iconTopDisableGroup.isLiteralText()) {
					try {
												
						java.lang.String __iconTopDisableGroup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconTopDisableGroup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconTopDisableGroup(__iconTopDisableGroup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconTopDisableGroup", this._iconTopDisableGroup);
				}
			}
					   		 			 
						if (this._iconTopDisabledItem != null) {
				if (this._iconTopDisabledItem.isLiteralText()) {
					try {
												
						java.lang.String __iconTopDisabledItem = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconTopDisabledItem.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconTopDisabledItem(__iconTopDisabledItem);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconTopDisabledItem", this._iconTopDisabledItem);
				}
			}
					   		 			 
						if (this._iconTopItem != null) {
				if (this._iconTopItem.isLiteralText()) {
					try {
												
						java.lang.String __iconTopItem = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._iconTopItem.getExpressionString(), 
											java.lang.String.class);
					
												comp.setIconTopItem(__iconTopItem);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("iconTopItem", this._iconTopItem);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._itemClass != null) {
				if (this._itemClass.isLiteralText()) {
					try {
												
						java.lang.String __itemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._itemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setItemClass(__itemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("itemClass", this._itemClass);
				}
			}
					   		 			 
						if (this._itemStyle != null) {
				if (this._itemStyle.isLiteralText()) {
					try {
												
						java.lang.String __itemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._itemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setItemStyle(__itemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("itemStyle", this._itemStyle);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					     		 			 
						if (this._mode != null) {
				if (this._mode.isLiteralText()) {
					try {
												
						java.lang.String __mode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._mode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMode(__mode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("mode", this._mode);
				}
			}
					     		 			 
						if (this._ongroupcollapse != null) {
				if (this._ongroupcollapse.isLiteralText()) {
					try {
												
						java.lang.String __ongroupcollapse = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ongroupcollapse.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOngroupcollapse(__ongroupcollapse);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ongroupcollapse", this._ongroupcollapse);
				}
			}
					   		 			 
						if (this._ongroupexpand != null) {
				if (this._ongroupexpand.isLiteralText()) {
					try {
												
						java.lang.String __ongroupexpand = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ongroupexpand.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOngroupexpand(__ongroupexpand);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ongroupexpand", this._ongroupexpand);
				}
			}
					   		 			 
						if (this._onitemhover != null) {
				if (this._onitemhover.isLiteralText()) {
					try {
												
						java.lang.String __onitemhover = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onitemhover.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnitemhover(__onitemhover);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onitemhover", this._onitemhover);
				}
			}
					            		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					   		 			 
						if (this._selectedChild != null) {
				if (this._selectedChild.isLiteralText()) {
					try {
												
						java.lang.String __selectedChild = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectedChild.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectedChild(__selectedChild);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectedChild", this._selectedChild);
				}
			}
					      		 			 
						if (this._topGroupClass != null) {
				if (this._topGroupClass.isLiteralText()) {
					try {
												
						java.lang.String __topGroupClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topGroupClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopGroupClass(__topGroupClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topGroupClass", this._topGroupClass);
				}
			}
					   		 			 
						if (this._topGroupStyle != null) {
				if (this._topGroupStyle.isLiteralText()) {
					try {
												
						java.lang.String __topGroupStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topGroupStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopGroupStyle(__topGroupStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topGroupStyle", this._topGroupStyle);
				}
			}
					   		 			 
						if (this._topItemClass != null) {
				if (this._topItemClass.isLiteralText()) {
					try {
												
						java.lang.String __topItemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topItemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopItemClass(__topItemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topItemClass", this._topItemClass);
				}
			}
					   		 			 
						if (this._topItemStyle != null) {
				if (this._topItemStyle.isLiteralText()) {
					try {
												
						java.lang.String __topItemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._topItemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTopItemStyle(__topItemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("topItemStyle", this._topItemStyle);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.PanelMenu";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.PanelMenuRenderer";
			}

}
