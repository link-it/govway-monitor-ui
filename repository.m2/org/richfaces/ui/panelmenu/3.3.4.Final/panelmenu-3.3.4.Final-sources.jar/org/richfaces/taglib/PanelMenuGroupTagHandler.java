/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import javax.faces.convert.Converter ;
import java.lang.Object ;
import org.richfaces.taglib.PanelMenuGroupTagHandlerBase ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;
import javax.faces.component.UIComponent;
import org.richfaces.component.html.HtmlPanelMenuGroup;
import com.sun.facelets.tag.jsf.ComponentHandler;
import com.sun.facelets.tag.jsf.ComponentConfig;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
/**
 * @author shura (latest modification by $Author: alexsmirnov $)
 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
 *
 */
public class PanelMenuGroupTagHandler extends org.richfaces.taglib.PanelMenuGroupTagHandlerBase {


  private static final PanelMenuGroupTagHandlerMetaRule metaRule = new PanelMenuGroupTagHandlerMetaRule();


  
  public PanelMenuGroupTagHandler(ComponentConfig config) 
  {
    super(config);
  }
// Metarule
  protected MetaRuleset createMetaRuleset(Class type)
  {
    MetaRuleset m = super.createMetaRuleset(type);
	m.addRule(metaRule);
	return m;
  }

  	/**
	 * @author shura (latest modification by $Author: alexsmirnov $)
	 * @version $Revision: 1.1.2.1 $ $Date: 2007/02/26 20:48:51 $
	 *
	 */
	static class PanelMenuGroupTagHandlerMetaRule extends MetaRule{

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.MetaRule#applyRule(java.lang.String, com.sun.facelets.tag.TagAttribute, com.sun.facelets.tag.MetadataTarget)
		 */
		public Metadata applyRule(String name, TagAttribute attribute, MetadataTarget meta) {
	        if (meta.isTargetInstanceOf(HtmlPanelMenuGroup.class)) {
				 		  		 				 		  	            	            
	            if ("action".equals(name)) {
	                    return new actionMapper(attribute);
	            }
				
						  		 				 		  	            		
				//skip actionExpression
	
						  		 				 		  	            	            
	            if ("actionListener".equals(name)) {
	                    return new actionListenerMapper(attribute);
	            }
				
						  		 				 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 				 		  		 				 		  		 				 				 				 				 				 				 				 				 				 		  		 				 		  		 				 		  		 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 		  		 				 				 				 		  		 				 		  		 				 		  		 				 		  		 				 		  	            	            
	            if ("validator".equals(name)) {
	                    return new validatorMapper(attribute);
	            }
				
						  		 				 		  		 				 				 				 		  	            	            
	            if ("valueChangeListener".equals(name)) {
	                    return new valueChangeListenerMapper(attribute);
	            }
				
						  		 				 			        }
			return null;
		}

	}


    
  		
	static class actionMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public actionMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlPanelMenuGroup) instance)
            .setAction
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	  
  		
	  
  		
	static class actionListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {javax.faces.event.ActionEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public actionListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlPanelMenuGroup) instance)
            .setActionListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   
    
    
     
    
    
    
    
    
    
    
    
      
    
    
    
    
    
    
    
     
    
    
    
     
    
    
    
    
    
     
    
     
    
            
    
    
     
    
    
    
    
    
      
    
    
    
    
  		
	static class validatorMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {javax.faces.context.FacesContext.class,javax.faces.component.UIComponent.class,java.lang.Object.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public validatorMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlPanelMenuGroup) instance)
            .setValidator
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	  
      
  		
	static class valueChangeListenerMapper extends Metadata {

		private static final Class[] SIGNATURE = new Class[] {javax.faces.event.ValueChangeEvent.class};

		private final TagAttribute _action;
		/**
		 * @param attribute
		 */
		public valueChangeListenerMapper(TagAttribute attribute) {
			_action = attribute;
		}

		/* (non-Javadoc)
		 * @see com.sun.facelets.tag.Metadata#applyMetadata(com.sun.facelets.FaceletContext, java.lang.Object)
		 */
		public void applyMetadata(FaceletContext ctx, Object instance) {
            ((HtmlPanelMenuGroup) instance)
            .setValueChangeListener
            	            		(new LegacyMethodBinding(this._action.getMethodExpression(ctx, null,
                            SIGNATURE)));
            			}

	}
	
		
	   }
