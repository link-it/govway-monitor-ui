/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import org.richfaces.component.LayoutPosition ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlLayoutPanel;

public class LayoutPanelTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 		 	  			  		  	  
		/*
		 * position
		 * Positions the component relative to the &amp;lt;rich:layout/&amp;gt; component. Possible values are top, left, right, center, bottom.
		 */
		private ValueExpression _position;
		/**
		 * Positions the component relative to the &amp;lt;rich:layout/&amp;gt; component. Possible values are top, left, right, center, bottom.
		 * Setter for position
		 * @param position - new value
		 */
		 public void setPosition( ValueExpression  __position ){
			this._position = __position;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * width
		 * Sets the width of the layout area
		 */
		private ValueExpression _width;
		/**
		 * Sets the width of the layout area
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		    this._position = null;
	 		 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlLayoutPanel comp = (HtmlLayoutPanel) component;
    		 			 
						if (this._position != null) {
				if (this._position.isLiteralText()) {
					try {
												
						org.richfaces.component.LayoutPosition __position = (org.richfaces.component.LayoutPosition) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._position.getExpressionString(), 
											org.richfaces.component.LayoutPosition.class);
					
												comp.setPosition(__position);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("position", this._position);
				}
			}
					    		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.LayoutPanel";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.LayoutPanelRenderer";
			}

}
