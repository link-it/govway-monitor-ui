/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPage;

public class PageTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * bodyClass
		 * Assigns one or more space-separated CSS class names to the body part of the page
		 */
		private ValueExpression _bodyClass;
		/**
		 * Assigns one or more space-separated CSS class names to the body part of the page
		 * Setter for bodyClass
		 * @param bodyClass - new value
		 */
		 public void setBodyClass( ValueExpression  __bodyClass ){
			this._bodyClass = __bodyClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * contentType
		 * Set custom mime content type to response
		 */
		private ValueExpression _contentType;
		/**
		 * Set custom mime content type to response
		 * Setter for contentType
		 * @param contentType - new value
		 */
		 public void setContentType( ValueExpression  __contentType ){
			this._contentType = __contentType;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * footerClass
		 * Assigns one or more space-separated CSS class names to the component footer
		 */
		private ValueExpression _footerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component footer
		 * Setter for footerClass
		 * @param footerClass - new value
		 */
		 public void setFooterClass( ValueExpression  __footerClass ){
			this._footerClass = __footerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the component header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * markupType
		 * Page layout format ( html, xhtml, html-transitional, html-3.2 ) for encoding DOCTYPE, namespace and Content-Type definitions
		 */
		private ValueExpression _markupType;
		/**
		 * Page layout format ( html, xhtml, html-transitional, html-3.2 ) for encoding DOCTYPE, namespace and Content-Type definitions
		 * Setter for markupType
		 * @param markupType - new value
		 */
		 public void setMarkupType( ValueExpression  __markupType ){
			this._markupType = __markupType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * namespace
		 * Set html element default namespace
		 */
		private ValueExpression _namespace;
		/**
		 * Set html element default namespace
		 * Setter for namespace
		 * @param namespace - new value
		 */
		 public void setNamespace( ValueExpression  __namespace ){
			this._namespace = __namespace;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncontextmenu
		 * The client-side script method to be called when the right mouse button is clicked over the component
		 */
		private ValueExpression _oncontextmenu;
		/**
		 * The client-side script method to be called when the right mouse button is clicked over the component
		 * Setter for oncontextmenu
		 * @param oncontextmenu - new value
		 */
		 public void setOncontextmenu( ValueExpression  __oncontextmenu ){
			this._oncontextmenu = __oncontextmenu;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onload
		 * The client-side script method to be called before a page is loaded
		 */
		private ValueExpression _onload;
		/**
		 * The client-side script method to be called before a page is loaded
		 * Setter for onload
		 * @param onload - new value
		 */
		 public void setOnload( ValueExpression  __onload ){
			this._onload = __onload;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onunload
		 * The client-side script method to be called when a page is unloaded
		 */
		private ValueExpression _onunload;
		/**
		 * The client-side script method to be called when a page is unloaded
		 * Setter for onunload
		 * @param onunload - new value
		 */
		 public void setOnunload( ValueExpression  __onunload ){
			this._onunload = __onunload;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * pageTitle
		 * String for output as a page title.
		 */
		private ValueExpression _pageTitle;
		/**
		 * String for output as a page title.
		 * Setter for pageTitle
		 * @param pageTitle - new value
		 */
		 public void setPageTitle( ValueExpression  __pageTitle ){
			this._pageTitle = __pageTitle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * sidebarClass
		 * Assigns one or more space-separated CSS class names to the component side panel
		 */
		private ValueExpression _sidebarClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component side panel
		 * Setter for sidebarClass
		 * @param sidebarClass - new value
		 */
		 public void setSidebarClass( ValueExpression  __sidebarClass ){
			this._sidebarClass = __sidebarClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sidebarPosition
		 * Defines the position of the side panel. Possible values are "left", "right". Default value is "left".
		 */
		private ValueExpression _sidebarPosition;
		/**
		 * Defines the position of the side panel. Possible values are "left", "right". Default value is "left".
		 * Setter for sidebarPosition
		 * @param sidebarPosition - new value
		 */
		 public void setSidebarPosition( ValueExpression  __sidebarPosition ){
			this._sidebarPosition = __sidebarPosition;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sidebarWidth
		 * Defines width for the side panel. Default value is "160".
		 */
		private ValueExpression _sidebarWidth;
		/**
		 * Defines width for the side panel. Default value is "160".
		 * Setter for sidebarWidth
		 * @param sidebarWidth - new value
		 */
		 public void setSidebarWidth( ValueExpression  __sidebarWidth ){
			this._sidebarWidth = __sidebarWidth;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * theme
		 * Specifies the way of the component rendering
		 */
		private ValueExpression _theme;
		/**
		 * Specifies the way of the component rendering
		 * Setter for theme
		 * @param theme - new value
		 */
		 public void setTheme( ValueExpression  __theme ){
			this._theme = __theme;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * width
		 * Sets the width of the page
		 */
		private ValueExpression _width;
		/**
		 * Sets the width of the page
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._bodyClass = null;
	 		 		    this._contentType = null;
	 		 		 		 		    this._footerClass = null;
	 		 		    this._headerClass = null;
	 		 		 		 		    this._markupType = null;
	 		 		    this._namespace = null;
	 		 		    this._oncontextmenu = null;
	 		 		    this._onload = null;
	 		 		    this._onunload = null;
	 		 		    this._pageTitle = null;
	 		 		 		    this._sidebarClass = null;
	 		 		    this._sidebarPosition = null;
	 		 		    this._sidebarWidth = null;
	 		 		 		 		    this._theme = null;
	 		 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPage comp = (HtmlPage) component;
  		 			 
						if (this._bodyClass != null) {
				if (this._bodyClass.isLiteralText()) {
					try {
												
						java.lang.String __bodyClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bodyClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBodyClass(__bodyClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bodyClass", this._bodyClass);
				}
			}
					   		 			 
						if (this._contentType != null) {
				if (this._contentType.isLiteralText()) {
					try {
												
						java.lang.String __contentType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentType(__contentType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentType", this._contentType);
				}
			}
					     		 			 
						if (this._footerClass != null) {
				if (this._footerClass.isLiteralText()) {
					try {
												
						java.lang.String __footerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._footerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFooterClass(__footerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("footerClass", this._footerClass);
				}
			}
					   		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					     		 			 
						if (this._markupType != null) {
				if (this._markupType.isLiteralText()) {
					try {
												
						java.lang.String __markupType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._markupType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMarkupType(__markupType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("markupType", this._markupType);
				}
			}
					   		 			 
						if (this._namespace != null) {
				if (this._namespace.isLiteralText()) {
					try {
												
						java.lang.String __namespace = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._namespace.getExpressionString(), 
											java.lang.String.class);
					
												comp.setNamespace(__namespace);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("namespace", this._namespace);
				}
			}
					   		 			 
						if (this._oncontextmenu != null) {
				if (this._oncontextmenu.isLiteralText()) {
					try {
												
						java.lang.String __oncontextmenu = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncontextmenu.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncontextmenu(__oncontextmenu);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncontextmenu", this._oncontextmenu);
				}
			}
					   		 			 
						if (this._onload != null) {
				if (this._onload.isLiteralText()) {
					try {
												
						java.lang.String __onload = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onload.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnload(__onload);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onload", this._onload);
				}
			}
					   		 			 
						if (this._onunload != null) {
				if (this._onunload.isLiteralText()) {
					try {
												
						java.lang.String __onunload = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onunload.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnunload(__onunload);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onunload", this._onunload);
				}
			}
					   		 			 
						if (this._pageTitle != null) {
				if (this._pageTitle.isLiteralText()) {
					try {
												
						java.lang.String __pageTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._pageTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setPageTitle(__pageTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("pageTitle", this._pageTitle);
				}
			}
					    		 			 
						if (this._sidebarClass != null) {
				if (this._sidebarClass.isLiteralText()) {
					try {
												
						java.lang.String __sidebarClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sidebarClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSidebarClass(__sidebarClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sidebarClass", this._sidebarClass);
				}
			}
					   		 			 
						if (this._sidebarPosition != null) {
				if (this._sidebarPosition.isLiteralText()) {
					try {
												
						java.lang.String __sidebarPosition = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sidebarPosition.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSidebarPosition(__sidebarPosition);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sidebarPosition", this._sidebarPosition);
				}
			}
					   		 			 
						if (this._sidebarWidth != null) {
				if (this._sidebarWidth.isLiteralText()) {
					try {
												
						Integer __sidebarWidth = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sidebarWidth.getExpressionString(), 
											Integer.class);
					
												comp.setSidebarWidth(__sidebarWidth.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sidebarWidth", this._sidebarWidth);
				}
			}
					     		 			 
						if (this._theme != null) {
				if (this._theme.isLiteralText()) {
					try {
												
						java.lang.String __theme = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._theme.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTheme(__theme);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("theme", this._theme);
				}
			}
					    		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						Integer __width = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											Integer.class);
					
												comp.setWidth(__width.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.Page";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.PageRenderer";
			}

}
