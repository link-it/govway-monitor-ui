package org.richfaces.component.html;

import javax.faces.context.FacesContext;
import org.richfaces.component.UILayout;

public class HtmlLayout extends UILayout{

static public final  String COMPONENT_FAMILY = "org.richfaces.Layout";

static public final  String COMPONENT_TYPE = "org.richfaces.Layout";


public HtmlLayout(){
setRendererType("org.richfaces.LayoutRenderer");
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[1];
state[0] = super.saveState(context);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);

}

}
