/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.richfaces.taglib.TabPanelTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlTabPanel;

public class TabPanelTag extends org.richfaces.taglib.TabPanelTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * activeTabClass
		 * Assigns one or more space-separated CSS class names to the component active tab
		 */
		private ValueExpression _activeTabClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component active tab
		 * Setter for activeTabClass
		 * @param activeTabClass - new value
		 */
		 public void setActiveTabClass( ValueExpression  __activeTabClass ){
			this._activeTabClass = __activeTabClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * contentClass
		 * CSS style rules to be applied to the panel content
		 */
		private ValueExpression _contentClass;
		/**
		 * CSS style rules to be applied to the panel content
		 * Setter for contentClass
		 * @param contentClass - new value
		 */
		 public void setContentClass( ValueExpression  __contentClass ){
			this._contentClass = __contentClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * contentStyle
		 * Assigns one or more space-separated CSS class names to the panel content
		 */
		private ValueExpression _contentStyle;
		/**
		 * Assigns one or more space-separated CSS class names to the panel content
		 * Setter for contentStyle
		 * @param contentStyle - new value
		 */
		 public void setContentStyle( ValueExpression  __contentStyle ){
			this._contentStyle = __contentStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * disabledTabClass
		 * Assigns one or more space-separated CSS class names to the component disabled tab
		 */
		private ValueExpression _disabledTabClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component disabled tab
		 * Setter for disabledTabClass
		 * @param disabledTabClass - new value
		 */
		 public void setDisabledTabClass( ValueExpression  __disabledTabClass ){
			this._disabledTabClass = __disabledTabClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * headerAlignment
		 * Sets tab headers alignment. It can be "left" or "right".
	    		 Default value is "left".
		 */
		private ValueExpression _headerAlignment;
		/**
		 * Sets tab headers alignment. It can be "left" or "right".
	    		 Default value is "left".
		 * Setter for headerAlignment
		 * @param headerAlignment - new value
		 */
		 public void setHeaderAlignment( ValueExpression  __headerAlignment ){
			this._headerAlignment = __headerAlignment;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the panel header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the panel header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerSpacing
		 * Sets tab headers spacing. It should be a valid size unit expression. Default value is "1px".
		 */
		private ValueExpression _headerSpacing;
		/**
		 * Sets tab headers spacing. It should be a valid size unit expression. Default value is "1px".
		 * Setter for headerSpacing
		 * @param headerSpacing - new value
		 */
		 public void setHeaderSpacing( ValueExpression  __headerSpacing ){
			this._headerSpacing = __headerSpacing;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * height
		 * Height of a tab panel defined in pixels or in percents
		 */
		private ValueExpression _height;
		/**
		 * Height of a tab panel defined in pixels or in percents
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * inactiveTabClass
		 * Assigns one or more space-separated CSS class names to the component inactive (but not disabled) tabs
		 */
		private ValueExpression _inactiveTabClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component inactive (but not disabled) tabs
		 * Setter for inactiveTabClass
		 * @param inactiveTabClass - new value
		 */
		 public void setInactiveTabClass( ValueExpression  __inactiveTabClass ){
			this._inactiveTabClass = __inactiveTabClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * ontabchange
		 * The client-side script method to be called before a tab is changed
		 */
		private ValueExpression _ontabchange;
		/**
		 * The client-side script method to be called before a tab is changed
		 * Setter for ontabchange
		 * @param ontabchange - new value
		 */
		 public void setOntabchange( ValueExpression  __ontabchange ){
			this._ontabchange = __ontabchange;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * switchType
		 * Tabs switch mode: "client", "server"(default), "ajax"
		 */
		private ValueExpression _switchType;
		/**
		 * Tabs switch mode: "client", "server"(default), "ajax"
		 * Setter for switchType
		 * @param switchType - new value
		 */
		 public void setSwitchType( ValueExpression  __switchType ){
			this._switchType = __switchType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * tabClass
		 * Assigns one or more space-separated CSS class names to the component tabs
		 */
		private ValueExpression _tabClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component tabs
		 * Setter for tabClass
		 * @param tabClass - new value
		 */
		 public void setTabClass( ValueExpression  __tabClass ){
			this._tabClass = __tabClass;
	     }
	  
	 	 		 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * width
		 * Width of a tab panel defined in pixels or in percents. 
	    	The default value is 100%
		 */
		private ValueExpression _width;
		/**
		 * Width of a tab panel defined in pixels or in percents. 
	    	The default value is 100%
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._activeTabClass = null;
	 		 		 		    this._contentClass = null;
	 		 		    this._contentStyle = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		 		    this._disabledTabClass = null;
	 		 		 		    this._headerAlignment = null;
	 		 		    this._headerClass = null;
	 		 		    this._headerSpacing = null;
	 		 		    this._height = null;
	 		 		 		    this._immediate = null;
	 		 		    this._inactiveTabClass = null;
	 		 		    this._label = null;
	 		 		 		 		 		 		 		 		 		 		 		 		 		 		 		    this._ontabchange = null;
	 		 		 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		 		 		 		    this._switchType = null;
	 		 		    this._tabClass = null;
	 		 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		 		    this._valueChangeListener = null;
	 		 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlTabPanel comp = (HtmlTabPanel) component;
 		 			 
						if (this._activeTabClass != null) {
				if (this._activeTabClass.isLiteralText()) {
					try {
												
						java.lang.String __activeTabClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeTabClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setActiveTabClass(__activeTabClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeTabClass", this._activeTabClass);
				}
			}
					    		 			 
						if (this._contentClass != null) {
				if (this._contentClass.isLiteralText()) {
					try {
												
						java.lang.String __contentClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentClass(__contentClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentClass", this._contentClass);
				}
			}
					   		 			 
						if (this._contentStyle != null) {
				if (this._contentStyle.isLiteralText()) {
					try {
												
						java.lang.String __contentStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentStyle(__contentStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentStyle", this._contentStyle);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					    		 			 
						if (this._disabledTabClass != null) {
				if (this._disabledTabClass.isLiteralText()) {
					try {
												
						java.lang.String __disabledTabClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledTabClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledTabClass(__disabledTabClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledTabClass", this._disabledTabClass);
				}
			}
					    		 			 
						if (this._headerAlignment != null) {
				if (this._headerAlignment.isLiteralText()) {
					try {
												
						java.lang.String __headerAlignment = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerAlignment.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderAlignment(__headerAlignment);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerAlignment", this._headerAlignment);
				}
			}
					   		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					   		 			 
						if (this._headerSpacing != null) {
				if (this._headerSpacing.isLiteralText()) {
					try {
												
						java.lang.String __headerSpacing = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerSpacing.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderSpacing(__headerSpacing);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerSpacing", this._headerSpacing);
				}
			}
					   		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						java.lang.String __height = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeight(__height);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._inactiveTabClass != null) {
				if (this._inactiveTabClass.isLiteralText()) {
					try {
												
						java.lang.String __inactiveTabClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._inactiveTabClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInactiveTabClass(__inactiveTabClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("inactiveTabClass", this._inactiveTabClass);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					                		 			 
						if (this._ontabchange != null) {
				if (this._ontabchange.isLiteralText()) {
					try {
												
						java.lang.String __ontabchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ontabchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOntabchange(__ontabchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ontabchange", this._ontabchange);
				}
			}
					      		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					      		 			 
						if (this._switchType != null) {
				if (this._switchType.isLiteralText()) {
					try {
												
						java.lang.String __switchType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._switchType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSwitchType(__switchType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("switchType", this._switchType);
				}
			}
					   		 			 
						if (this._tabClass != null) {
				if (this._tabClass.isLiteralText()) {
					try {
												
						java.lang.String __tabClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tabClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTabClass(__tabClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tabClass", this._tabClass);
				}
			}
					     		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					     		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.TabPanel";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.TabPanelRenderer";
			}

}
