/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import java.lang.Integer ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.ContextMenu;

public class ContextMenuTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * attachTiming
		 * Defines the timing when the menu is attached to the target element. Possible values "onload", "immediate", "onavailable" (default). Default value is "onavailable".
		 */
		private ValueExpression _attachTiming;
		/**
		 * Defines the timing when the menu is attached to the target element. Possible values "onload", "immediate", "onavailable" (default). Default value is "onavailable".
		 * Setter for attachTiming
		 * @param attachTiming - new value
		 */
		 public void setAttachTiming( ValueExpression  __attachTiming ){
			this._attachTiming = __attachTiming;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * attachTo
		 * Client identifier of the component or id of the existing DOM element that is a source
				for a given event. If attachTo is defined, the event is attached on the client according
				to the AttachTiming attribute.
				If both attached and attachTo attributes are defined, and attribute attached has value
				'false', it is considered to have higher priority.
		 */
		private ValueExpression _attachTo;
		/**
		 * Client identifier of the component or id of the existing DOM element that is a source
				for a given event. If attachTo is defined, the event is attached on the client according
				to the AttachTiming attribute.
				If both attached and attachTo attributes are defined, and attribute attached has value
				'false', it is considered to have higher priority.
		 * Setter for attachTo
		 * @param attachTo - new value
		 */
		 public void setAttachTo( ValueExpression  __attachTo ){
			this._attachTo = __attachTo;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * attached
		 * If the value of the "attached" attribute is true, the component is attached to the component,
                specified in the "attachTo" attribute or to the parent component,
                if "attachTo" is not defined.  Default value is "true".
		 */
		private ValueExpression _attached;
		/**
		 * If the value of the "attached" attribute is true, the component is attached to the component,
                specified in the "attachTo" attribute or to the parent component,
                if "attachTo" is not defined.  Default value is "true".
		 * Setter for attached
		 * @param attached - new value
		 */
		 public void setAttached( ValueExpression  __attached ){
			this._attached = __attached;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * disableDefaultMenu
		 * Forbids default handling for adjusted event. Default value "false".
		 */
		private ValueExpression _disableDefaultMenu;
		/**
		 * Forbids default handling for adjusted event. Default value "false".
		 * Setter for disableDefaultMenu
		 * @param disableDefaultMenu - new value
		 */
		 public void setDisableDefaultMenu( ValueExpression  __disableDefaultMenu ){
			this._disableDefaultMenu = __disableDefaultMenu;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledItemClass
		 * Assigns one or more space-separated CSS class names to the component disabled item
		 */
		private ValueExpression _disabledItemClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component disabled item
		 * Setter for disabledItemClass
		 * @param disabledItemClass - new value
		 */
		 public void setDisabledItemClass( ValueExpression  __disabledItemClass ){
			this._disabledItemClass = __disabledItemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledItemStyle
		 * CSS style rules to be applied to the component disabled item
		 */
		private ValueExpression _disabledItemStyle;
		/**
		 * CSS style rules to be applied to the component disabled item
		 * Setter for disabledItemStyle
		 * @param disabledItemStyle - new value
		 */
		 public void setDisabledItemStyle( ValueExpression  __disabledItemStyle ){
			this._disabledItemStyle = __disabledItemStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * event
		 * Defines an event on the parent element to display  the menu. Default value is  "oncontextmenu".
		 */
		private ValueExpression _event;
		/**
		 * Defines an event on the parent element to display  the menu. Default value is  "oncontextmenu".
		 * Setter for event
		 * @param event - new value
		 */
		 public void setEvent( ValueExpression  __event ){
			this._event = __event;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * hideDelay
		 * Delay between losing focus and menu closing. Default value is "800".
		 */
		private ValueExpression _hideDelay;
		/**
		 * Delay between losing focus and menu closing. Default value is "800".
		 * Setter for hideDelay
		 * @param hideDelay - new value
		 */
		 public void setHideDelay( ValueExpression  __hideDelay ){
			this._hideDelay = __hideDelay;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * itemClass
		 * Assigns one or more space-separated CSS class names to the component item
		 */
		private ValueExpression _itemClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component item
		 * Setter for itemClass
		 * @param itemClass - new value
		 */
		 public void setItemClass( ValueExpression  __itemClass ){
			this._itemClass = __itemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * itemStyle
		 * CSS style rules to be applied to the component item
		 */
		private ValueExpression _itemStyle;
		/**
		 * CSS style rules to be applied to the component item
		 * Setter for itemStyle
		 * @param itemStyle - new value
		 */
		 public void setItemStyle( ValueExpression  __itemStyle ){
			this._itemStyle = __itemStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncollapse
		 * The client-side script method to be called before the menu is collapsed
		 */
		private ValueExpression _oncollapse;
		/**
		 * The client-side script method to be called before the menu is collapsed
		 * Setter for oncollapse
		 * @param oncollapse - new value
		 */
		 public void setOncollapse( ValueExpression  __oncollapse ){
			this._oncollapse = __oncollapse;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onexpand
		 * The client-side script method to be called before the menu is expanded
		 */
		private ValueExpression _onexpand;
		/**
		 * The client-side script method to be called before the menu is expanded
		 * Setter for onexpand
		 * @param onexpand - new value
		 */
		 public void setOnexpand( ValueExpression  __onexpand ){
			this._onexpand = __onexpand;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ongroupactivate
		 * The client-side script method to be called when some context menu group is activated
		 */
		private ValueExpression _ongroupactivate;
		/**
		 * The client-side script method to be called when some context menu group is activated
		 * Setter for ongroupactivate
		 * @param ongroupactivate - new value
		 */
		 public void setOngroupactivate( ValueExpression  __ongroupactivate ){
			this._ongroupactivate = __ongroupactivate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onitemselect
		 * The client-side script method to be called when some item is selected
		 */
		private ValueExpression _onitemselect;
		/**
		 * The client-side script method to be called when some item is selected
		 * Setter for onitemselect
		 * @param onitemselect - new value
		 */
		 public void setOnitemselect( ValueExpression  __onitemselect ){
			this._onitemselect = __onitemselect;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * popupWidth
		 * Set minimal width for the all of the lists that will appear
		 */
		private ValueExpression _popupWidth;
		/**
		 * Set minimal width for the all of the lists that will appear
		 * Setter for popupWidth
		 * @param popupWidth - new value
		 */
		 public void setPopupWidth( ValueExpression  __popupWidth ){
			this._popupWidth = __popupWidth;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * selectItemClass
		 * Assigns one or more space-separated CSS class names to the component selected item
		 */
		private ValueExpression _selectItemClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component selected item
		 * Setter for selectItemClass
		 * @param selectItemClass - new value
		 */
		 public void setSelectItemClass( ValueExpression  __selectItemClass ){
			this._selectItemClass = __selectItemClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectItemStyle
		 * CSS style rules to be applied to the component selected item
		 */
		private ValueExpression _selectItemStyle;
		/**
		 * CSS style rules to be applied to the component selected item
		 * Setter for selectItemStyle
		 * @param selectItemStyle - new value
		 */
		 public void setSelectItemStyle( ValueExpression  __selectItemStyle ){
			this._selectItemStyle = __selectItemStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showDelay
		 * Delay between event and menu showing. Default value is "50".
		 */
		private ValueExpression _showDelay;
		/**
		 * Delay between event and menu showing. Default value is "50".
		 * Setter for showDelay
		 * @param showDelay - new value
		 */
		 public void setShowDelay( ValueExpression  __showDelay ){
			this._showDelay = __showDelay;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * submitMode
		 * Sets the submission mode for all menu items of the menu except
                those where this attribute redefined. Possible value are "ajax","server", "none". Default value is "server".
		 */
		private ValueExpression _submitMode;
		/**
		 * Sets the submission mode for all menu items of the menu except
                those where this attribute redefined. Possible value are "ajax","server", "none". Default value is "server".
		 * Setter for submitMode
		 * @param submitMode - new value
		 */
		 public void setSubmitMode( ValueExpression  __submitMode ){
			this._submitMode = __submitMode;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._attachTiming = null;
	 		 		    this._attachTo = null;
	 		 		    this._attached = null;
	 		 		 		    this._disableDefaultMenu = null;
	 		 		    this._disabledItemClass = null;
	 		 		    this._disabledItemStyle = null;
	 		 		    this._event = null;
	 		 		 		    this._hideDelay = null;
	 		 		 		    this._itemClass = null;
	 		 		    this._itemStyle = null;
	 		 		    this._oncollapse = null;
	 		 		    this._onexpand = null;
	 		 		    this._ongroupactivate = null;
	 		 		    this._onitemselect = null;
	 		 		 		 		 		    this._popupWidth = null;
	 		 		 		    this._selectItemClass = null;
	 		 		    this._selectItemStyle = null;
	 		 		    this._showDelay = null;
	 		 		 		 		    this._submitMode = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		ContextMenu comp = (ContextMenu) component;
 		 			 
						if (this._attachTiming != null) {
				if (this._attachTiming.isLiteralText()) {
					try {
												
						java.lang.String __attachTiming = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._attachTiming.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAttachTiming(__attachTiming);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("attachTiming", this._attachTiming);
				}
			}
					   		 			 
						if (this._attachTo != null) {
				if (this._attachTo.isLiteralText()) {
					try {
												
						java.lang.String __attachTo = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._attachTo.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAttachTo(__attachTo);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("attachTo", this._attachTo);
				}
			}
					   		 			 
						if (this._attached != null) {
				if (this._attached.isLiteralText()) {
					try {
												
						Boolean __attached = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._attached.getExpressionString(), 
											Boolean.class);
					
												comp.setAttached(__attached.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("attached", this._attached);
				}
			}
					    		 			 
						if (this._disableDefaultMenu != null) {
				if (this._disableDefaultMenu.isLiteralText()) {
					try {
												
						Boolean __disableDefaultMenu = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disableDefaultMenu.getExpressionString(), 
											Boolean.class);
					
												comp.setDisableDefaultMenu(__disableDefaultMenu.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disableDefaultMenu", this._disableDefaultMenu);
				}
			}
					   		 			 
						if (this._disabledItemClass != null) {
				if (this._disabledItemClass.isLiteralText()) {
					try {
												
						java.lang.String __disabledItemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledItemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledItemClass(__disabledItemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledItemClass", this._disabledItemClass);
				}
			}
					   		 			 
						if (this._disabledItemStyle != null) {
				if (this._disabledItemStyle.isLiteralText()) {
					try {
												
						java.lang.String __disabledItemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledItemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledItemStyle(__disabledItemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledItemStyle", this._disabledItemStyle);
				}
			}
					   		 			 
						if (this._event != null) {
				if (this._event.isLiteralText()) {
					try {
												
						java.lang.String __event = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._event.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEvent(__event);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("event", this._event);
				}
			}
					    		 			 
						if (this._hideDelay != null) {
				if (this._hideDelay.isLiteralText()) {
					try {
												
						java.lang.Integer __hideDelay = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hideDelay.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setHideDelay(__hideDelay);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hideDelay", this._hideDelay);
				}
			}
					    		 			 
						if (this._itemClass != null) {
				if (this._itemClass.isLiteralText()) {
					try {
												
						java.lang.String __itemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._itemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setItemClass(__itemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("itemClass", this._itemClass);
				}
			}
					   		 			 
						if (this._itemStyle != null) {
				if (this._itemStyle.isLiteralText()) {
					try {
												
						java.lang.String __itemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._itemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setItemStyle(__itemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("itemStyle", this._itemStyle);
				}
			}
					   		 			 
						if (this._oncollapse != null) {
				if (this._oncollapse.isLiteralText()) {
					try {
												
						java.lang.String __oncollapse = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncollapse.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncollapse(__oncollapse);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncollapse", this._oncollapse);
				}
			}
					   		 			 
						if (this._onexpand != null) {
				if (this._onexpand.isLiteralText()) {
					try {
												
						java.lang.String __onexpand = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onexpand.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnexpand(__onexpand);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onexpand", this._onexpand);
				}
			}
					   		 			 
						if (this._ongroupactivate != null) {
				if (this._ongroupactivate.isLiteralText()) {
					try {
												
						java.lang.String __ongroupactivate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ongroupactivate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOngroupactivate(__ongroupactivate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ongroupactivate", this._ongroupactivate);
				}
			}
					   		 			 
						if (this._onitemselect != null) {
				if (this._onitemselect.isLiteralText()) {
					try {
												
						java.lang.String __onitemselect = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onitemselect.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnitemselect(__onitemselect);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onitemselect", this._onitemselect);
				}
			}
					      		 			 
						if (this._popupWidth != null) {
				if (this._popupWidth.isLiteralText()) {
					try {
												
						java.lang.String __popupWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._popupWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setPopupWidth(__popupWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("popupWidth", this._popupWidth);
				}
			}
					    		 			 
						if (this._selectItemClass != null) {
				if (this._selectItemClass.isLiteralText()) {
					try {
												
						java.lang.String __selectItemClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectItemClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectItemClass(__selectItemClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectItemClass", this._selectItemClass);
				}
			}
					   		 			 
						if (this._selectItemStyle != null) {
				if (this._selectItemStyle.isLiteralText()) {
					try {
												
						java.lang.String __selectItemStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectItemStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectItemStyle(__selectItemStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectItemStyle", this._selectItemStyle);
				}
			}
					   		 			 
						if (this._showDelay != null) {
				if (this._showDelay.isLiteralText()) {
					try {
												
						java.lang.Integer __showDelay = (java.lang.Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showDelay.getExpressionString(), 
											java.lang.Integer.class);
					
												comp.setShowDelay(__showDelay);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showDelay", this._showDelay);
				}
			}
					     		 			 
						if (this._submitMode != null) {
				if (this._submitMode.isLiteralText()) {
					try {
												
						java.lang.String __submitMode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._submitMode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSubmitMode(__submitMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("submitMode", this._submitMode);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ContextMenu";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.DropDownMenuRenderer";
			}

}
