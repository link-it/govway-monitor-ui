/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.util.Set ;
import java.lang.Object ;
import java.lang.String ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlDataGrid;

public class DataGridTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * ajaxKeys
		 * This attribute defines row keys that are updated after an AJAX request
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * This attribute defines row keys that are updated after an AJAX request
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * align
		 * Deprecated. This attribute specifies the position of the table with respect to the document. 
            The possible values are "left", "center" and "right". The default value is "left".
		 */
		private ValueExpression _align;
		/**
		 * Deprecated. This attribute specifies the position of the table with respect to the document. 
            The possible values are "left", "center" and "right". The default value is "left".
		 * Setter for align
		 * @param align - new value
		 */
		 public void setAlign( ValueExpression  __align ){
			this._align = __align;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * bgcolor
		 * Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
		 */
		private ValueExpression _bgcolor;
		/**
		 * Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
		 * Setter for bgcolor
		 * @param bgcolor - new value
		 */
		 public void setBgcolor( ValueExpression  __bgcolor ){
			this._bgcolor = __bgcolor;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * border
		 * This attributes specifies the width of the frame around a component. Default value is "0".
		 */
		private ValueExpression _border;
		/**
		 * This attributes specifies the width of the frame around a component. Default value is "0".
		 * Setter for border
		 * @param border - new value
		 */
		 public void setBorder( ValueExpression  __border ){
			this._border = __border;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * captionClass
		 * Assigns one or more space-separated CSS class names to the component caption
		 */
		private ValueExpression _captionClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component caption
		 * Setter for captionClass
		 * @param captionClass - new value
		 */
		 public void setCaptionClass( ValueExpression  __captionClass ){
			this._captionClass = __captionClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * captionStyle
		 * CSS style rules to be applied to the component caption
		 */
		private ValueExpression _captionStyle;
		/**
		 * CSS style rules to be applied to the component caption
		 * Setter for captionStyle
		 * @param captionStyle - new value
		 */
		 public void setCaptionStyle( ValueExpression  __captionStyle ){
			this._captionStyle = __captionStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cellpadding
		 * This attribute specifies the amount of space between the border of the cell and its contents. Default value is "0".
		 */
		private ValueExpression _cellpadding;
		/**
		 * This attribute specifies the amount of space between the border of the cell and its contents. Default value is "0".
		 * Setter for cellpadding
		 * @param cellpadding - new value
		 */
		 public void setCellpadding( ValueExpression  __cellpadding ){
			this._cellpadding = __cellpadding;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cellspacing
		 * This attribute specifies the amount of space between the border of the cell and its contents.  
				The attribute also specifies the amount of space to leave between cells. Default value is "0".
		 */
		private ValueExpression _cellspacing;
		/**
		 * This attribute specifies the amount of space between the border of the cell and its contents.  
				The attribute also specifies the amount of space to leave between cells. Default value is "0".
		 * Setter for cellspacing
		 * @param cellspacing - new value
		 */
		 public void setCellspacing( ValueExpression  __cellspacing ){
			this._cellspacing = __cellspacing;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * columns
		 * Number of columns
		 */
		private ValueExpression _columns;
		/**
		 * Number of columns
		 * Setter for columns
		 * @param columns - new value
		 */
		 public void setColumns( ValueExpression  __columns ){
			this._columns = __columns;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding  for a component state for saving or redefinition
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding  for a component state for saving or redefinition
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * elements
		 * Number of elements in grid
		 */
		private ValueExpression _elements;
		/**
		 * Number of elements in grid
		 * Setter for elements
		 * @param elements - new value
		 */
		 public void setElements( ValueExpression  __elements ){
			this._elements = __elements;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * first
		 * A zero-relative row number of the first row to display
		 */
		private ValueExpression _first;
		/**
		 * A zero-relative row number of the first row to display
		 * Setter for first
		 * @param first - new value
		 */
		 public void setFirst( ValueExpression  __first ){
			this._first = __first;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * footerClass
		 * Assigns one or more space-separated CSS class names to the component footer
		 */
		private ValueExpression _footerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component footer
		 * Setter for footerClass
		 * @param footerClass - new value
		 */
		 public void setFooterClass( ValueExpression  __footerClass ){
			this._footerClass = __footerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * frame
		 * This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
		 */
		private ValueExpression _frame;
		/**
		 * This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
		 * Setter for frame
		 * @param frame - new value
		 */
		 public void setFrame( ValueExpression  __frame ){
			this._frame = __frame;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the component header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * onRowClick
		 * The client-side script method to be called when the row is clicked
		 */
		private ValueExpression _onRowClick;
		/**
		 * The client-side script method to be called when the row is clicked
		 * Setter for onRowClick
		 * @param onRowClick - new value
		 */
		 public void setOnRowClick( ValueExpression  __onRowClick ){
			this._onRowClick = __onRowClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowDblClick
		 * The client-side script method to be called when the row is double-clicked
		 */
		private ValueExpression _onRowDblClick;
		/**
		 * The client-side script method to be called when the row is double-clicked
		 * Setter for onRowDblClick
		 * @param onRowDblClick - new value
		 */
		 public void setOnRowDblClick( ValueExpression  __onRowDblClick ){
			this._onRowDblClick = __onRowDblClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseDown
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 */
		private ValueExpression _onRowMouseDown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 * Setter for onRowMouseDown
		 * @param onRowMouseDown - new value
		 */
		 public void setOnRowMouseDown( ValueExpression  __onRowMouseDown ){
			this._onRowMouseDown = __onRowMouseDown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseMove
		 * The client-side script method to be called when a pointer is moved within the row
		 */
		private ValueExpression _onRowMouseMove;
		/**
		 * The client-side script method to be called when a pointer is moved within the row
		 * Setter for onRowMouseMove
		 * @param onRowMouseMove - new value
		 */
		 public void setOnRowMouseMove( ValueExpression  __onRowMouseMove ){
			this._onRowMouseMove = __onRowMouseMove;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseOut
		 * The client-side script method to be called when a pointer is moved away from the row
		 */
		private ValueExpression _onRowMouseOut;
		/**
		 * The client-side script method to be called when a pointer is moved away from the row
		 * Setter for onRowMouseOut
		 * @param onRowMouseOut - new value
		 */
		 public void setOnRowMouseOut( ValueExpression  __onRowMouseOut ){
			this._onRowMouseOut = __onRowMouseOut;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseOver
		 * The client-side script method to be called when a pointer is moved onto the row
		 */
		private ValueExpression _onRowMouseOver;
		/**
		 * The client-side script method to be called when a pointer is moved onto the row
		 * Setter for onRowMouseOver
		 * @param onRowMouseOver - new value
		 */
		 public void setOnRowMouseOver( ValueExpression  __onRowMouseOver ){
			this._onRowMouseOver = __onRowMouseOver;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseUp
		 * The client-side script method to be called when a mouse button is released over the row
		 */
		private ValueExpression _onRowMouseUp;
		/**
		 * The client-side script method to be called when a mouse button is released over the row
		 * Setter for onRowMouseUp
		 * @param onRowMouseUp - new value
		 */
		 public void setOnRowMouseUp( ValueExpression  __onRowMouseUp ){
			this._onRowMouseUp = __onRowMouseUp;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * rowEventHandlers
		 * rowEventHandlers
		 */
		private ValueExpression _rowEventHandlers;
		/**
		 * rowEventHandlers
		 * Setter for rowEventHandlers
		 * @param rowEventHandlers - new value
		 */
		 public void setRowEventHandlers( ValueExpression  __rowEventHandlers ){
			this._rowEventHandlers = __rowEventHandlers;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * rowKey
		 * RowKey is a representation of an identifier for a specific data row
		 */
		private ValueExpression _rowKey;
		/**
		 * RowKey is a representation of an identifier for a specific data row
		 * Setter for rowKey
		 * @param rowKey - new value
		 */
		 public void setRowKey( ValueExpression  __rowKey ){
			this._rowKey = __rowKey;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * Request scoped variable for client access to rowKey
		 */
		private ValueExpression _rowKeyVar;
		/**
		 * Request scoped variable for client access to rowKey
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( ValueExpression  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * rules
		 * This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
		 */
		private ValueExpression _rules;
		/**
		 * This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
		 * Setter for rules
		 * @param rules - new value
		 */
		 public void setRules( ValueExpression  __rules ){
			this._rules = __rules;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * stateVar
		 * The attribute  provides access to a component state on the client side
		 */
		private ValueExpression _stateVar;
		/**
		 * The attribute  provides access to a component state on the client side
		 * Setter for stateVar
		 * @param stateVar - new value
		 */
		 public void setStateVar( ValueExpression  __stateVar ){
			this._stateVar = __stateVar;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * summary
		 * This attribute provides a summary of the table's purpose and structure for user agents rendering to non-visual media such as speech and Braille
		 */
		private ValueExpression _summary;
		/**
		 * This attribute provides a summary of the table's purpose and structure for user agents rendering to non-visual media such as speech and Braille
		 * Setter for summary
		 * @param summary - new value
		 */
		 public void setSummary( ValueExpression  __summary ){
			this._summary = __summary;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 */
		private String _var;
		/**
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * This attribute specifies the desired width of the entire table and is intended for visual user agents. When the value is percentage value, the value is relative to the user agent's available horizontal space. In the absence of any width specification, table width is determined by the user agent
		 */
		private ValueExpression _width;
		/**
		 * This attribute specifies the desired width of the entire table and is intended for visual user agents. When the value is percentage value, the value is relative to the user agent's available horizontal space. In the absence of any width specification, table width is determined by the user agent
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxKeys = null;
	 		 		    this._align = null;
	 		 		 		    this._bgcolor = null;
	 		 		 		    this._border = null;
	 		 		    this._captionClass = null;
	 		 		    this._captionStyle = null;
	 		 		    this._cellpadding = null;
	 		 		    this._cellspacing = null;
	 		 		    this._columnClasses = null;
	 		 		    this._columns = null;
	 		 		    this._componentState = null;
	 		 		 		    this._elements = null;
	 		 		 		    this._first = null;
	 		 		 		    this._footerClass = null;
	 		 		    this._frame = null;
	 		 		 		    this._headerClass = null;
	 		 		 		 		    this._onRowClick = null;
	 		 		    this._onRowDblClick = null;
	 		 		    this._onRowMouseDown = null;
	 		 		    this._onRowMouseMove = null;
	 		 		    this._onRowMouseOut = null;
	 		 		    this._onRowMouseOver = null;
	 		 		    this._onRowMouseUp = null;
	 		 		 		 		 		 		 		 		 		 		 		 		 		 		    this._rowClasses = null;
	 		 		 		 		    this._rowEventHandlers = null;
	 		 		 		    this._rowKey = null;
	 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		 		    this._rules = null;
	 		 		    this._stateVar = null;
	 		 		 		 		    this._summary = null;
	 		 		 		    this._value = null;
	 		 		    this._var = null;
	 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlDataGrid comp = (HtmlDataGrid) component;
 		 			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					   		 			 
						if (this._align != null) {
				if (this._align.isLiteralText()) {
					try {
												
						java.lang.String __align = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._align.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAlign(__align);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("align", this._align);
				}
			}
					    		 			 
						if (this._bgcolor != null) {
				if (this._bgcolor.isLiteralText()) {
					try {
												
						java.lang.String __bgcolor = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bgcolor.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBgcolor(__bgcolor);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bgcolor", this._bgcolor);
				}
			}
					    		 			 
						if (this._border != null) {
				if (this._border.isLiteralText()) {
					try {
												
						java.lang.String __border = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._border.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBorder(__border);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("border", this._border);
				}
			}
					   		 			 
						if (this._captionClass != null) {
				if (this._captionClass.isLiteralText()) {
					try {
												
						java.lang.String __captionClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._captionClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCaptionClass(__captionClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("captionClass", this._captionClass);
				}
			}
					   		 			 
						if (this._captionStyle != null) {
				if (this._captionStyle.isLiteralText()) {
					try {
												
						java.lang.String __captionStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._captionStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCaptionStyle(__captionStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("captionStyle", this._captionStyle);
				}
			}
					   		 			 
						if (this._cellpadding != null) {
				if (this._cellpadding.isLiteralText()) {
					try {
												
						java.lang.String __cellpadding = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cellpadding.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCellpadding(__cellpadding);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cellpadding", this._cellpadding);
				}
			}
					   		 			 
						if (this._cellspacing != null) {
				if (this._cellspacing.isLiteralText()) {
					try {
												
						java.lang.String __cellspacing = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cellspacing.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCellspacing(__cellspacing);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cellspacing", this._cellspacing);
				}
			}
					   		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					   		 			 
						if (this._columns != null) {
				if (this._columns.isLiteralText()) {
					try {
												
						Integer __columns = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columns.getExpressionString(), 
											Integer.class);
					
												comp.setColumns(__columns.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columns", this._columns);
				}
			}
					   		 			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					    		 			 
						if (this._elements != null) {
				if (this._elements.isLiteralText()) {
					try {
												
						Integer __elements = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._elements.getExpressionString(), 
											Integer.class);
					
												comp.setElements(__elements.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("elements", this._elements);
				}
			}
					    		 			 
						if (this._first != null) {
				if (this._first.isLiteralText()) {
					try {
												
						Integer __first = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._first.getExpressionString(), 
											Integer.class);
					
												comp.setFirst(__first.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("first", this._first);
				}
			}
					    		 			 
						if (this._footerClass != null) {
				if (this._footerClass.isLiteralText()) {
					try {
												
						java.lang.String __footerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._footerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFooterClass(__footerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("footerClass", this._footerClass);
				}
			}
					   		 			 
						if (this._frame != null) {
				if (this._frame.isLiteralText()) {
					try {
												
						java.lang.String __frame = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._frame.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFrame(__frame);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("frame", this._frame);
				}
			}
					    		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					     		 			 
						if (this._onRowClick != null) {
				if (this._onRowClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowClick(__onRowClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowClick", this._onRowClick);
				}
			}
					   		 			 
						if (this._onRowDblClick != null) {
				if (this._onRowDblClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowDblClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowDblClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowDblClick(__onRowDblClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowDblClick", this._onRowDblClick);
				}
			}
					   		 			 
						if (this._onRowMouseDown != null) {
				if (this._onRowMouseDown.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseDown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseDown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseDown(__onRowMouseDown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseDown", this._onRowMouseDown);
				}
			}
					   		 			 
						if (this._onRowMouseMove != null) {
				if (this._onRowMouseMove.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseMove = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseMove.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseMove(__onRowMouseMove);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseMove", this._onRowMouseMove);
				}
			}
					   		 			 
						if (this._onRowMouseOut != null) {
				if (this._onRowMouseOut.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseOut = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseOut.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseOut(__onRowMouseOut);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseOut", this._onRowMouseOut);
				}
			}
					   		 			 
						if (this._onRowMouseOver != null) {
				if (this._onRowMouseOver.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseOver = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseOver.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseOver(__onRowMouseOver);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseOver", this._onRowMouseOver);
				}
			}
					   		 			 
						if (this._onRowMouseUp != null) {
				if (this._onRowMouseUp.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseUp = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseUp.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseUp(__onRowMouseUp);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseUp", this._onRowMouseUp);
				}
			}
					               		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					     		 			 
						if (this._rowEventHandlers != null) {
				if (this._rowEventHandlers.isLiteralText()) {
					try {
												
						java.util.Set __rowEventHandlers = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowEventHandlers.getExpressionString(), 
											java.util.Set.class);
					
												comp.setRowEventHandlers(__rowEventHandlers);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowEventHandlers", this._rowEventHandlers);
				}
			}
					    		 			 
						if (this._rowKey != null) {
				if (this._rowKey.isLiteralText()) {
					try {
												
						java.lang.Object __rowKey = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowKey.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setRowKey(__rowKey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowKey", this._rowKey);
				}
			}
					   		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
						if (this._rowKeyVar != null) {
				if (this._rowKeyVar.isLiteralText()) {
					try {
												
						java.lang.String __rowKeyVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowKeyVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowKeyVar(__rowKeyVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowKeyVar", this._rowKeyVar);
				}
			}
					    		 			 
						if (this._rules != null) {
				if (this._rules.isLiteralText()) {
					try {
												
						java.lang.String __rules = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rules.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRules(__rules);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rules", this._rules);
				}
			}
					   		 			 
						if (this._stateVar != null) {
				if (this._stateVar.isLiteralText()) {
					try {
												
						java.lang.String __stateVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stateVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStateVar(__stateVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stateVar", this._stateVar);
				}
			}
					     		 			 
						if (this._summary != null) {
				if (this._summary.isLiteralText()) {
					try {
												
						java.lang.String __summary = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._summary.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSummary(__summary);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("summary", this._summary);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.DataGrid";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.DataGridRenderer";
			}

}
