/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.richfaces.model.selection.Selection ;
import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.util.Collection ;
import java.util.Set ;
import java.lang.Boolean ;
import java.lang.Object ;
import java.lang.String ;
import org.ajax4jsf.model.DataComponentState ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlExtendedDataTable;

public class ExtendedDataTableTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * activeClass
		 * Assigns one or more space-separated CSS class names to the component active row
		 */
		private ValueExpression _activeClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component active row
		 * Setter for activeClass
		 * @param activeClass - new value
		 */
		 public void setActiveClass( ValueExpression  __activeClass ){
			this._activeClass = __activeClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * activeRowKey
		 * Request scope attribute under which the activeRowKey will
                                        be accessible
		 */
		private ValueExpression _activeRowKey;
		/**
		 * Request scope attribute under which the activeRowKey will
                                        be accessible
		 * Setter for activeRowKey
		 * @param activeRowKey - new value
		 */
		 public void setActiveRowKey( ValueExpression  __activeRowKey ){
			this._activeRowKey = __activeRowKey;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ajaxKeys
		 * This attribute defines row keys that are updated after an
                                        AJAX request
		 */
		private ValueExpression _ajaxKeys;
		/**
		 * This attribute defines row keys that are updated after an
                                        AJAX request
		 * Setter for ajaxKeys
		 * @param ajaxKeys - new value
		 */
		 public void setAjaxKeys( ValueExpression  __ajaxKeys ){
			this._ajaxKeys = __ajaxKeys;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * align
		 * Deprecated. This attribute specifies the position of the table with respect to the document. 
            The possible values are "left", "center" and "right". The default value is "left".
		 */
		private ValueExpression _align;
		/**
		 * Deprecated. This attribute specifies the position of the table with respect to the document. 
            The possible values are "left", "center" and "right". The default value is "left".
		 * Setter for align
		 * @param align - new value
		 */
		 public void setAlign( ValueExpression  __align ){
			this._align = __align;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * bgcolor
		 * Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
		 */
		private ValueExpression _bgcolor;
		/**
		 * Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
		 * Setter for bgcolor
		 * @param bgcolor - new value
		 */
		 public void setBgcolor( ValueExpression  __bgcolor ){
			this._bgcolor = __bgcolor;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * border
		 * This attributes specifies the width of the frame around a
                                        component. Default value is "0"
		 */
		private ValueExpression _border;
		/**
		 * This attributes specifies the width of the frame around a
                                        component. Default value is "0"
		 * Setter for border
		 * @param border - new value
		 */
		 public void setBorder( ValueExpression  __border ){
			this._border = __border;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * captionClass
		 * Assigns one or more space-separated CSS class names to the component caption
		 */
		private ValueExpression _captionClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component caption
		 * Setter for captionClass
		 * @param captionClass - new value
		 */
		 public void setCaptionClass( ValueExpression  __captionClass ){
			this._captionClass = __captionClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * captionStyle
		 * CSS style rules to be applied to the component caption
		 */
		private ValueExpression _captionStyle;
		/**
		 * CSS style rules to be applied to the component caption
		 * Setter for captionStyle
		 * @param captionStyle - new value
		 */
		 public void setCaptionStyle( ValueExpression  __captionStyle ){
			this._captionStyle = __captionStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cellpadding
		 * This attribute specifies the amount of space between the
                                        border of the cell and its contents. Default value is "0"
		 */
		private ValueExpression _cellpadding;
		/**
		 * This attribute specifies the amount of space between the
                                        border of the cell and its contents. Default value is "0"
		 * Setter for cellpadding
		 * @param cellpadding - new value
		 */
		 public void setCellpadding( ValueExpression  __cellpadding ){
			this._cellpadding = __cellpadding;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cellspacing
		 * The cellspacing attribute specifies the space between cells. Default value is "0"
		 */
		private ValueExpression _cellspacing;
		/**
		 * The cellspacing attribute specifies the space between cells. Default value is "0"
		 * Setter for cellspacing
		 * @param cellspacing - new value
		 */
		 public void setCellspacing( ValueExpression  __cellspacing ){
			this._cellspacing = __cellspacing;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * columnClasses
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 */
		private ValueExpression _columnClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
		 * Setter for columnClasses
		 * @param columnClasses - new value
		 */
		 public void setColumnClasses( ValueExpression  __columnClasses ){
			this._columnClasses = __columnClasses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * componentState
		 * It defines EL-binding for a component state for saving or
                                        redefinition
		 */
		private ValueExpression _componentState;
		/**
		 * It defines EL-binding for a component state for saving or
                                        redefinition
		 * Setter for componentState
		 * @param componentState - new value
		 */
		 public void setComponentState( ValueExpression  __componentState ){
			this._componentState = __componentState;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * enableContextMenu
		 * If set to true, table header context menu will be enabled
		 */
		private ValueExpression _enableContextMenu;
		/**
		 * If set to true, table header context menu will be enabled
		 * Setter for enableContextMenu
		 * @param enableContextMenu - new value
		 */
		 public void setEnableContextMenu( ValueExpression  __enableContextMenu ){
			this._enableContextMenu = __enableContextMenu;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * first
		 * A zero-relative row number of the first row to display
		 */
		private ValueExpression _first;
		/**
		 * A zero-relative row number of the first row to display
		 * Setter for first
		 * @param first - new value
		 */
		 public void setFirst( ValueExpression  __first ){
			this._first = __first;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * footerClass
		 * Assigns one or more space-separated CSS class names to the component footer
		 */
		private ValueExpression _footerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component footer
		 * Setter for footerClass
		 * @param footerClass - new value
		 */
		 public void setFooterClass( ValueExpression  __footerClass ){
			this._footerClass = __footerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * frame
		 * This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
		 */
		private ValueExpression _frame;
		/**
		 * This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
		 * Setter for frame
		 * @param frame - new value
		 */
		 public void setFrame( ValueExpression  __frame ){
			this._frame = __frame;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * groupingColumn
		 * Defines an id of column which the data is grouped by.
		 */
		private ValueExpression _groupingColumn;
		/**
		 * Defines an id of column which the data is grouped by.
		 * Setter for groupingColumn
		 * @param groupingColumn - new value
		 */
		 public void setGroupingColumn( ValueExpression  __groupingColumn ){
			this._groupingColumn = __groupingColumn;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the component header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * height
		 * Defines a height of the component. Default value is "500px"
		 */
		private ValueExpression _height;
		/**
		 * Defines a height of the component. Default value is "500px"
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * noDataLabel
		 * Defines label to be displayed in case there are no data rows.
		 */
		private ValueExpression _noDataLabel;
		/**
		 * Defines label to be displayed in case there are no data rows.
		 * Setter for noDataLabel
		 * @param noDataLabel - new value
		 */
		 public void setNoDataLabel( ValueExpression  __noDataLabel ){
			this._noDataLabel = __noDataLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowClick
		 * The client-side script method to be called when the row is clicked
		 */
		private ValueExpression _onRowClick;
		/**
		 * The client-side script method to be called when the row is clicked
		 * Setter for onRowClick
		 * @param onRowClick - new value
		 */
		 public void setOnRowClick( ValueExpression  __onRowClick ){
			this._onRowClick = __onRowClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowDblClick
		 * The client-side script method to be called when the row is double-clicked
		 */
		private ValueExpression _onRowDblClick;
		/**
		 * The client-side script method to be called when the row is double-clicked
		 * Setter for onRowDblClick
		 * @param onRowDblClick - new value
		 */
		 public void setOnRowDblClick( ValueExpression  __onRowDblClick ){
			this._onRowDblClick = __onRowDblClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseDown
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 */
		private ValueExpression _onRowMouseDown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down over the row
		 * Setter for onRowMouseDown
		 * @param onRowMouseDown - new value
		 */
		 public void setOnRowMouseDown( ValueExpression  __onRowMouseDown ){
			this._onRowMouseDown = __onRowMouseDown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseMove
		 * The client-side script method to be called when a pointer is moved within the row
		 */
		private ValueExpression _onRowMouseMove;
		/**
		 * The client-side script method to be called when a pointer is moved within the row
		 * Setter for onRowMouseMove
		 * @param onRowMouseMove - new value
		 */
		 public void setOnRowMouseMove( ValueExpression  __onRowMouseMove ){
			this._onRowMouseMove = __onRowMouseMove;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseOut
		 * The client-side script method to be called when a pointer is moved away from the row
		 */
		private ValueExpression _onRowMouseOut;
		/**
		 * The client-side script method to be called when a pointer is moved away from the row
		 * Setter for onRowMouseOut
		 * @param onRowMouseOut - new value
		 */
		 public void setOnRowMouseOut( ValueExpression  __onRowMouseOut ){
			this._onRowMouseOut = __onRowMouseOut;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseOver
		 * The client-side script method to be called when a pointer is moved onto the rows
		 */
		private ValueExpression _onRowMouseOver;
		/**
		 * The client-side script method to be called when a pointer is moved onto the rows
		 * Setter for onRowMouseOver
		 * @param onRowMouseOver - new value
		 */
		 public void setOnRowMouseOver( ValueExpression  __onRowMouseOver ){
			this._onRowMouseOver = __onRowMouseOver;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onRowMouseUp
		 * The client-side script method to be called when a pointer is released over the row
		 */
		private ValueExpression _onRowMouseUp;
		/**
		 * The client-side script method to be called when a pointer is released over the row
		 * Setter for onRowMouseUp
		 * @param onRowMouseUp - new value
		 */
		 public void setOnRowMouseUp( ValueExpression  __onRowMouseUp ){
			this._onRowMouseUp = __onRowMouseUp;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onselectionchange
		 * The client-side script method to be called when a selected row is changed
		 */
		private ValueExpression _onselectionchange;
		/**
		 * The client-side script method to be called when a selected row is changed
		 * Setter for onselectionchange
		 * @param onselectionchange - new value
		 */
		 public void setOnselectionchange( ValueExpression  __onselectionchange ){
			this._onselectionchange = __onselectionchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * rowEventHandlers
		 * rowEventHandlers
		 */
		private ValueExpression _rowEventHandlers;
		/**
		 * rowEventHandlers
		 * Setter for rowEventHandlers
		 * @param rowEventHandlers - new value
		 */
		 public void setRowEventHandlers( ValueExpression  __rowEventHandlers ){
			this._rowEventHandlers = __rowEventHandlers;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * rowKeyConverter
		 * Converter for a row key object
		 */
		private ValueExpression _rowKeyConverter;
		/**
		 * Converter for a row key object
		 * Setter for rowKeyConverter
		 * @param rowKeyConverter - new value
		 */
		 public void setRowKeyConverter( ValueExpression  __rowKeyConverter ){
			this._rowKeyConverter = __rowKeyConverter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rowKeyVar
		 * The attribute provides access to a row key in a Request
                                        scope
		 */
		private ValueExpression _rowKeyVar;
		/**
		 * The attribute provides access to a row key in a Request
                                        scope
		 * Setter for rowKeyVar
		 * @param rowKeyVar - new value
		 */
		 public void setRowKeyVar( ValueExpression  __rowKeyVar ){
			this._rowKeyVar = __rowKeyVar;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rows
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 */
		private ValueExpression _rows;
		/**
		 * A number of rows to display, or zero for all remaining
            rows in the table
		 * Setter for rows
		 * @param rows - new value
		 */
		 public void setRows( ValueExpression  __rows ){
			this._rows = __rows;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rules
		 * This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
		 */
		private ValueExpression _rules;
		/**
		 * This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
		 * Setter for rules
		 * @param rules - new value
		 */
		 public void setRules( ValueExpression  __rules ){
			this._rules = __rules;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectedClass
		 * Assigns one or more space-separated CSS class names to the component rows selected
		 */
		private ValueExpression _selectedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component rows selected
		 * Setter for selectedClass
		 * @param selectedClass - new value
		 */
		 public void setSelectedClass( ValueExpression  __selectedClass ){
			this._selectedClass = __selectedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selection
		 * Value binding representing selected rows
		 */
		private ValueExpression _selection;
		/**
		 * Value binding representing selected rows
		 * Setter for selection
		 * @param selection - new value
		 */
		 public void setSelection( ValueExpression  __selection ){
			this._selection = __selection;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectionMode
		 * Single row can be selected. multi:
                                        Multiple rows can be selected. none: no rows can be
                                        selected. Default value is "single"
		 */
		private ValueExpression _selectionMode;
		/**
		 * Single row can be selected. multi:
                                        Multiple rows can be selected. none: no rows can be
                                        selected. Default value is "single"
		 * Setter for selectionMode
		 * @param selectionMode - new value
		 */
		 public void setSelectionMode( ValueExpression  __selectionMode ){
			this._selectionMode = __selectionMode;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * sortMode
		 * Defines mode of sorting. Possible values are 'single'
                                        for sorting of one column and 'multi' for some.
		 */
		private ValueExpression _sortMode;
		/**
		 * Defines mode of sorting. Possible values are 'single'
                                        for sorting of one column and 'multi' for some.
		 * Setter for sortMode
		 * @param sortMode - new value
		 */
		 public void setSortMode( ValueExpression  __sortMode ){
			this._sortMode = __sortMode;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sortPriority
		 * Defines a set of column ids in the order the columns
                                        could be set
		 */
		private ValueExpression _sortPriority;
		/**
		 * Defines a set of column ids in the order the columns
                                        could be set
		 * Setter for sortPriority
		 * @param sortPriority - new value
		 */
		 public void setSortPriority( ValueExpression  __sortPriority ){
			this._sortPriority = __sortPriority;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * stateVar
		 * The attribute provides access to a component state on
                                        the client side
		 */
		private ValueExpression _stateVar;
		/**
		 * The attribute provides access to a component state on
                                        the client side
		 * Setter for stateVar
		 * @param stateVar - new value
		 */
		 public void setStateVar( ValueExpression  __stateVar ){
			this._stateVar = __stateVar;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * tableState
		 * ValueBinding pointing at a property of a String to hold
                                        table state
		 */
		private ValueExpression _tableState;
		/**
		 * ValueBinding pointing at a property of a String to hold
                                        table state
		 * Setter for tableState
		 * @param tableState - new value
		 */
		 public void setTableState( ValueExpression  __tableState ){
			this._tableState = __tableState;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 */
		private String _var;
		/**
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * width
		 * This attribute specifies the desired width of the entire table and is intended for visual user agents. When the value is percentage value, the value is relative to the user agent's available horizontal space. In the absence of any width specification, table width is determined by the user agent
		 */
		private ValueExpression _width;
		/**
		 * This attribute specifies the desired width of the entire table and is intended for visual user agents. When the value is percentage value, the value is relative to the user agent's available horizontal space. In the absence of any width specification, table width is determined by the user agent
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._activeClass = null;
	 		 		    this._activeRowKey = null;
	 		 		    this._ajaxKeys = null;
	 		 		    this._align = null;
	 		 		 		    this._bgcolor = null;
	 		 		 		    this._border = null;
	 		 		    this._captionClass = null;
	 		 		    this._captionStyle = null;
	 		 		    this._cellpadding = null;
	 		 		    this._cellspacing = null;
	 		 		 		    this._columnClasses = null;
	 		 		    this._componentState = null;
	 		 		 		    this._enableContextMenu = null;
	 		 		 		 		    this._first = null;
	 		 		 		    this._footerClass = null;
	 		 		    this._frame = null;
	 		 		 		 		    this._groupingColumn = null;
	 		 		 		 		    this._headerClass = null;
	 		 		    this._height = null;
	 		 		 		 		    this._noDataLabel = null;
	 		 		    this._onRowClick = null;
	 		 		    this._onRowDblClick = null;
	 		 		    this._onRowMouseDown = null;
	 		 		    this._onRowMouseMove = null;
	 		 		    this._onRowMouseOut = null;
	 		 		    this._onRowMouseOver = null;
	 		 		    this._onRowMouseUp = null;
	 		 		 		 		 		 		 		 		 		 		 		 		    this._onselectionchange = null;
	 		 		    this._reRender = null;
	 		 		 		 		    this._rowClasses = null;
	 		 		 		 		    this._rowEventHandlers = null;
	 		 		 		 		    this._rowKeyConverter = null;
	 		 		    this._rowKeyVar = null;
	 		 		    this._rows = null;
	 		 		    this._rules = null;
	 		 		    this._selectedClass = null;
	 		 		    this._selection = null;
	 		 		    this._selectionMode = null;
	 		 		 		    this._sortMode = null;
	 		 		    this._sortPriority = null;
	 		 		 		 		    this._stateVar = null;
	 		 		 		 		 		    this._tableState = null;
	 		 		 		    this._value = null;
	 		 		    this._var = null;
	 		 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlExtendedDataTable comp = (HtmlExtendedDataTable) component;
 		 			 
						if (this._activeClass != null) {
				if (this._activeClass.isLiteralText()) {
					try {
												
						java.lang.String __activeClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setActiveClass(__activeClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeClass", this._activeClass);
				}
			}
					   		 			 
						if (this._activeRowKey != null) {
				if (this._activeRowKey.isLiteralText()) {
					try {
												
						java.lang.Object __activeRowKey = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._activeRowKey.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setActiveRowKey(__activeRowKey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("activeRowKey", this._activeRowKey);
				}
			}
					   		 			 
						if (this._ajaxKeys != null) {
				if (this._ajaxKeys.isLiteralText()) {
					try {
												
						java.util.Set __ajaxKeys = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxKeys.getExpressionString(), 
											java.util.Set.class);
					
												comp.setAjaxKeys(__ajaxKeys);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxKeys", this._ajaxKeys);
				}
			}
					   		 			 
						if (this._align != null) {
				if (this._align.isLiteralText()) {
					try {
												
						java.lang.String __align = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._align.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAlign(__align);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("align", this._align);
				}
			}
					    		 			 
						if (this._bgcolor != null) {
				if (this._bgcolor.isLiteralText()) {
					try {
												
						java.lang.String __bgcolor = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bgcolor.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBgcolor(__bgcolor);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bgcolor", this._bgcolor);
				}
			}
					    		 			 
						if (this._border != null) {
				if (this._border.isLiteralText()) {
					try {
												
						java.lang.String __border = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._border.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBorder(__border);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("border", this._border);
				}
			}
					   		 			 
						if (this._captionClass != null) {
				if (this._captionClass.isLiteralText()) {
					try {
												
						java.lang.String __captionClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._captionClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCaptionClass(__captionClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("captionClass", this._captionClass);
				}
			}
					   		 			 
						if (this._captionStyle != null) {
				if (this._captionStyle.isLiteralText()) {
					try {
												
						java.lang.String __captionStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._captionStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCaptionStyle(__captionStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("captionStyle", this._captionStyle);
				}
			}
					   		 			 
						if (this._cellpadding != null) {
				if (this._cellpadding.isLiteralText()) {
					try {
												
						java.lang.String __cellpadding = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cellpadding.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCellpadding(__cellpadding);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cellpadding", this._cellpadding);
				}
			}
					   		 			 
						if (this._cellspacing != null) {
				if (this._cellspacing.isLiteralText()) {
					try {
												
						java.lang.String __cellspacing = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cellspacing.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCellspacing(__cellspacing);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cellspacing", this._cellspacing);
				}
			}
					    		 			 
						if (this._columnClasses != null) {
				if (this._columnClasses.isLiteralText()) {
					try {
												
						java.lang.String __columnClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._columnClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setColumnClasses(__columnClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("columnClasses", this._columnClasses);
				}
			}
					   		 			 
						if (this._componentState != null) {
				if (this._componentState.isLiteralText()) {
					try {
												
						org.ajax4jsf.model.DataComponentState __componentState = (org.ajax4jsf.model.DataComponentState) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._componentState.getExpressionString(), 
											org.ajax4jsf.model.DataComponentState.class);
					
												comp.setComponentState(__componentState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("componentState", this._componentState);
				}
			}
					    		 			 
						if (this._enableContextMenu != null) {
				if (this._enableContextMenu.isLiteralText()) {
					try {
												
						java.lang.Boolean __enableContextMenu = (java.lang.Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enableContextMenu.getExpressionString(), 
											java.lang.Boolean.class);
					
												comp.setEnableContextMenu(__enableContextMenu);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enableContextMenu", this._enableContextMenu);
				}
			}
					     		 			 
						if (this._first != null) {
				if (this._first.isLiteralText()) {
					try {
												
						Integer __first = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._first.getExpressionString(), 
											Integer.class);
					
												comp.setFirst(__first.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("first", this._first);
				}
			}
					    		 			 
						if (this._footerClass != null) {
				if (this._footerClass.isLiteralText()) {
					try {
												
						java.lang.String __footerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._footerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFooterClass(__footerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("footerClass", this._footerClass);
				}
			}
					   		 			 
						if (this._frame != null) {
				if (this._frame.isLiteralText()) {
					try {
												
						java.lang.String __frame = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._frame.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFrame(__frame);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("frame", this._frame);
				}
			}
					     		 			 
						if (this._groupingColumn != null) {
				if (this._groupingColumn.isLiteralText()) {
					try {
												
						java.lang.String __groupingColumn = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._groupingColumn.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGroupingColumn(__groupingColumn);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("groupingColumn", this._groupingColumn);
				}
			}
					     		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					   		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						java.lang.String __height = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeight(__height);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					     		 			 
						if (this._noDataLabel != null) {
				if (this._noDataLabel.isLiteralText()) {
					try {
												
						java.lang.String __noDataLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._noDataLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setNoDataLabel(__noDataLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("noDataLabel", this._noDataLabel);
				}
			}
					   		 			 
						if (this._onRowClick != null) {
				if (this._onRowClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowClick(__onRowClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowClick", this._onRowClick);
				}
			}
					   		 			 
						if (this._onRowDblClick != null) {
				if (this._onRowDblClick.isLiteralText()) {
					try {
												
						java.lang.String __onRowDblClick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowDblClick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowDblClick(__onRowDblClick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowDblClick", this._onRowDblClick);
				}
			}
					   		 			 
						if (this._onRowMouseDown != null) {
				if (this._onRowMouseDown.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseDown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseDown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseDown(__onRowMouseDown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseDown", this._onRowMouseDown);
				}
			}
					   		 			 
						if (this._onRowMouseMove != null) {
				if (this._onRowMouseMove.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseMove = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseMove.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseMove(__onRowMouseMove);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseMove", this._onRowMouseMove);
				}
			}
					   		 			 
						if (this._onRowMouseOut != null) {
				if (this._onRowMouseOut.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseOut = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseOut.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseOut(__onRowMouseOut);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseOut", this._onRowMouseOut);
				}
			}
					   		 			 
						if (this._onRowMouseOver != null) {
				if (this._onRowMouseOver.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseOver = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseOver.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseOver(__onRowMouseOver);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseOver", this._onRowMouseOver);
				}
			}
					   		 			 
						if (this._onRowMouseUp != null) {
				if (this._onRowMouseUp.isLiteralText()) {
					try {
												
						java.lang.String __onRowMouseUp = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onRowMouseUp.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnRowMouseUp(__onRowMouseUp);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onRowMouseUp", this._onRowMouseUp);
				}
			}
					             		 			 
						if (this._onselectionchange != null) {
				if (this._onselectionchange.isLiteralText()) {
					try {
												
						java.lang.String __onselectionchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselectionchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselectionchange(__onselectionchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselectionchange", this._onselectionchange);
				}
			}
					   		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					     		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					     		 			 
						if (this._rowEventHandlers != null) {
				if (this._rowEventHandlers.isLiteralText()) {
					try {
												
						java.util.Set __rowEventHandlers = (java.util.Set) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowEventHandlers.getExpressionString(), 
											java.util.Set.class);
					
												comp.setRowEventHandlers(__rowEventHandlers);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowEventHandlers", this._rowEventHandlers);
				}
			}
					     		 			setRowKeyConverterProperty(comp, this._rowKeyConverter);
		   		 			 
						if (this._rowKeyVar != null) {
				if (this._rowKeyVar.isLiteralText()) {
					try {
												
						java.lang.String __rowKeyVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowKeyVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowKeyVar(__rowKeyVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowKeyVar", this._rowKeyVar);
				}
			}
					   		 			 
						if (this._rows != null) {
				if (this._rows.isLiteralText()) {
					try {
												
						Integer __rows = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rows.getExpressionString(), 
											Integer.class);
					
												comp.setRows(__rows.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rows", this._rows);
				}
			}
					   		 			 
						if (this._rules != null) {
				if (this._rules.isLiteralText()) {
					try {
												
						java.lang.String __rules = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rules.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRules(__rules);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rules", this._rules);
				}
			}
					   		 			 
						if (this._selectedClass != null) {
				if (this._selectedClass.isLiteralText()) {
					try {
												
						java.lang.String __selectedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectedClass(__selectedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectedClass", this._selectedClass);
				}
			}
					   		 			 				if(null != this._selection && this._selection.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.ExtendedDataTable with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property selection");
				}
			 
						if (this._selection != null) {
				if (this._selection.isLiteralText()) {
					try {
												
						org.richfaces.model.selection.Selection __selection = (org.richfaces.model.selection.Selection) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selection.getExpressionString(), 
											org.richfaces.model.selection.Selection.class);
					
												comp.setSelection(__selection);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selection", this._selection);
				}
			}
					   		 			 
						if (this._selectionMode != null) {
				if (this._selectionMode.isLiteralText()) {
					try {
												
						java.lang.String __selectionMode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectionMode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectionMode(__selectionMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectionMode", this._selectionMode);
				}
			}
					    		 			 
						if (this._sortMode != null) {
				if (this._sortMode.isLiteralText()) {
					try {
												
						java.lang.String __sortMode = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortMode.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSortMode(__sortMode);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortMode", this._sortMode);
				}
			}
					   		 			 
						if (this._sortPriority != null) {
				if (this._sortPriority.isLiteralText()) {
					try {
												
						java.util.Collection __sortPriority = (java.util.Collection) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sortPriority.getExpressionString(), 
											java.util.Collection.class);
					
												comp.setSortPriority(__sortPriority);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sortPriority", this._sortPriority);
				}
			}
					     		 			 
						if (this._stateVar != null) {
				if (this._stateVar.isLiteralText()) {
					try {
												
						java.lang.String __stateVar = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._stateVar.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStateVar(__stateVar);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("stateVar", this._stateVar);
				}
			}
					      		 			 				if(null != this._tableState && this._tableState.isLiteralText()){
					throw new IllegalArgumentException("Component org.richfaces.ExtendedDataTable with Id " + component.getClientId(getFacesContext()) +" allows only EL expressions for property tableState");
				}
			 
						if (this._tableState != null) {
				if (this._tableState.isLiteralText()) {
					try {
												
						java.lang.String __tableState = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tableState.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTableState(__tableState);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tableState", this._tableState);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									    		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ExtendedDataTable";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.ExtendedDataTableRenderer";
			}

}
