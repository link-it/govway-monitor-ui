/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPanel;

public class PanelTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * bodyClass
		 * Assigns one or more space-separated CSS class names to the component content
		 */
		private ValueExpression _bodyClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component content
		 * Setter for bodyClass
		 * @param bodyClass - new value
		 */
		 public void setBodyClass( ValueExpression  __bodyClass ){
			this._bodyClass = __bodyClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * header
		 * Label text appears on a panel header
		 */
		private ValueExpression _header;
		/**
		 * Label text appears on a panel header
		 * Setter for header
		 * @param header - new value
		 */
		 public void setHeader( ValueExpression  __header ){
			this._header = __header;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the component header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 		 		 		 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._bodyClass = null;
	 		 		 		    this._header = null;
	 		 		    this._headerClass = null;
	 		 		 		 		 		 		 		 		 		 		 		 		 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPanel comp = (HtmlPanel) component;
  		 			 
						if (this._bodyClass != null) {
				if (this._bodyClass.isLiteralText()) {
					try {
												
						java.lang.String __bodyClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bodyClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBodyClass(__bodyClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bodyClass", this._bodyClass);
				}
			}
					    		 			 
						if (this._header != null) {
				if (this._header.isLiteralText()) {
					try {
												
						java.lang.String __header = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._header.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeader(__header);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("header", this._header);
				}
			}
					   		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					                   }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.panel";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.PanelRenderer";
			}

}
