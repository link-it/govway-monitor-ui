/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import javax.faces.convert.Converter ;
import java.util.Date ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.el.MethodExpression ;
import javax.faces.component.UIComponent ;
import org.ajax4jsf.webapp.taglib.UIComponentTagBase ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.MediaOutput;

public class MediaOutputTag extends org.ajax4jsf.webapp.taglib.UIComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * accesskey
		 * This attribute assigns an access key to an element. An access key is a single character from the document character set. Note: Authors should consider the input method of the expected reader when specifying an accesskey
		 */
		private ValueExpression _accesskey;
		/**
		 * This attribute assigns an access key to an element. An access key is a single character from the document character set. Note: Authors should consider the input method of the expected reader when specifying an accesskey
		 * Setter for accesskey
		 * @param accesskey - new value
		 */
		 public void setAccesskey( ValueExpression  __accesskey ){
			this._accesskey = __accesskey;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * align
		 * Deprecated. This attribute specifies the position of an IMG, OBJECT, or APPLET with respect to its context.           
           The possible values are "bottom", "middle", "top", "left" and "right". The default value is "middle".
		 */
		private ValueExpression _align;
		/**
		 * Deprecated. This attribute specifies the position of an IMG, OBJECT, or APPLET with respect to its context.           
           The possible values are "bottom", "middle", "top", "left" and "right". The default value is "middle".
		 * Setter for align
		 * @param align - new value
		 */
		 public void setAlign( ValueExpression  __align ){
			this._align = __align;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * archive
		 * Specifies a space-separated list of URIs
		 */
		private ValueExpression _archive;
		/**
		 * Specifies a space-separated list of URIs
		 * Setter for archive
		 * @param archive - new value
		 */
		 public void setArchive( ValueExpression  __archive ){
			this._archive = __archive;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * border
		 * Deprecated. This attribute specifies the width of an IMG or OBJECT border, in pixels. The default value for this attribute depends on the user agent
		 */
		private ValueExpression _border;
		/**
		 * Deprecated. This attribute specifies the width of an IMG or OBJECT border, in pixels. The default value for this attribute depends on the user agent
		 * Setter for border
		 * @param border - new value
		 */
		 public void setBorder( ValueExpression  __border ){
			this._border = __border;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cacheable
		 * Attribute is a flag that defines the caching strategy. If 'cacheable' is set to false, the response will not be cached. If it is set to true, it will be cached and the serialized value of 'value' attribute plays the role of a cache key.
		 */
		private ValueExpression _cacheable;
		/**
		 * Attribute is a flag that defines the caching strategy. If 'cacheable' is set to false, the response will not be cached. If it is set to true, it will be cached and the serialized value of 'value' attribute plays the role of a cache key.
		 * Setter for cacheable
		 * @param cacheable - new value
		 */
		 public void setCacheable( ValueExpression  __cacheable ){
			this._cacheable = __cacheable;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * charset
		 * The character encoding of a resource designated by this hyperlink
		 */
		private ValueExpression _charset;
		/**
		 * The character encoding of a resource designated by this hyperlink
		 * Setter for charset
		 * @param charset - new value
		 */
		 public void setCharset( ValueExpression  __charset ){
			this._charset = __charset;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * classid
		 * identifies an implementation
		 */
		private ValueExpression _classid;
		/**
		 * identifies an implementation
		 * Setter for classid
		 * @param classid - new value
		 */
		 public void setClassid( ValueExpression  __classid ){
			this._classid = __classid;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * codebase
		 * base URI for classid, data, archive
		 */
		private ValueExpression _codebase;
		/**
		 * base URI for classid, data, archive
		 * Setter for codebase
		 * @param codebase - new value
		 */
		 public void setCodebase( ValueExpression  __codebase ){
			this._codebase = __codebase;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * codetype
		 * Defines content type for code
		 */
		private ValueExpression _codetype;
		/**
		 * Defines content type for code
		 * Setter for codetype
		 * @param codetype - new value
		 */
		 public void setCodetype( ValueExpression  __codetype ){
			this._codetype = __codetype;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * ID of a converter to be used or a reference to a
				converter.
		 */
		private ValueExpression _converter;
		/**
		 * ID of a converter to be used or a reference to a
				converter.
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * coords
		 * The attribute specifies shape and it position on the screen. 
        Possible values: "rect: left-x, top-y, right-x, bottom-y", "circle: center-x, center-y, radius", "poly: x1, y1, x2, y2, ..., xN, yN". 
        Notes: 
        a) when giving the radius value in percents, user agents should calculate the final radius value in pixels based on the associated object's width and height; 
        b) the radius value should be smaller than center-x and center-y values; 
        c) for a polygon, the first and last coordinate pairs should have same x and y to close the shape (x1=xN; y1=yN) 
        (when these coordinates are different, user agents should infer an additional pair to close a polygon). 
        Coordinates are relative to the top left corner of an object. All values are lengths. All values are comma separated.
		 */
		private ValueExpression _coords;
		/**
		 * The attribute specifies shape and it position on the screen. 
        Possible values: "rect: left-x, top-y, right-x, bottom-y", "circle: center-x, center-y, radius", "poly: x1, y1, x2, y2, ..., xN, yN". 
        Notes: 
        a) when giving the radius value in percents, user agents should calculate the final radius value in pixels based on the associated object's width and height; 
        b) the radius value should be smaller than center-x and center-y values; 
        c) for a polygon, the first and last coordinate pairs should have same x and y to close the shape (x1=xN; y1=yN) 
        (when these coordinates are different, user agents should infer an additional pair to close a polygon). 
        Coordinates are relative to the top left corner of an object. All values are lengths. All values are comma separated.
		 * Setter for coords
		 * @param coords - new value
		 */
		 public void setCoords( ValueExpression  __coords ){
			this._coords = __coords;
	     }
	  
	 	 		 	  	  	  
		/*
		 * createContent
		 * Method call expression to send generated resource to OutputStream. It must have two parameter with a type of java.io.OutputStream 
        and java.lang.Object ( deserialized value of data attribute )
		 */
		private MethodExpression _createContent;
		/**
		 * Method call expression to send generated resource to OutputStream. It must have two parameter with a type of java.io.OutputStream 
        and java.lang.Object ( deserialized value of data attribute )
		 * Setter for createContent
		 * @param createContent - new value
		 */
		 public void setCreateContent( MethodExpression  __createContent ){
			this._createContent = __createContent;
	     }
	  
	 	 		 	  	  	  
		/*
		 * createContentExpression
		 * Attribute references to the method that will be used for content creating. The method accepts two parameters. The first parameter has an OutputStream type. It is a reference to the steam that should be used for output. The second parameter is a reference to a 'value' attribute of the component.
		 */
		private MethodExpression _createContentExpression;
		/**
		 * Attribute references to the method that will be used for content creating. The method accepts two parameters. The first parameter has an OutputStream type. It is a reference to the steam that should be used for output. The second parameter is a reference to a 'value' attribute of the component.
		 * Setter for createContentExpression
		 * @param createContentExpression - new value
		 */
		 public void setCreateContentExpression( MethodExpression  __createContentExpression ){
			this._createContentExpression = __createContentExpression;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * declare
		 * declare but don't instantiate flag
		 */
		private ValueExpression _declare;
		/**
		 * declare but don't instantiate flag
		 * Setter for declare
		 * @param declare - new value
		 */
		 public void setDeclare( ValueExpression  __declare ){
			this._declare = __declare;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * dir
		 * Direction indication for text that does not inherit
			directionality. Valid values are "LTR" (left-to-right)
			and "RTL" (right-to-left)
		 */
		private ValueExpression _dir;
		/**
		 * Direction indication for text that does not inherit
			directionality. Valid values are "LTR" (left-to-right)
			and "RTL" (right-to-left)
		 * Setter for dir
		 * @param dir - new value
		 */
		 public void setDir( ValueExpression  __dir ){
			this._dir = __dir;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * element
		 * Name of html element for resource link - may be &amp;lt;a&amp;gt; &amp;lt;img&amp;gt; &amp;lt;object&amp;gt; &amp;lt;applet&amp;gt; &amp;lt;script&amp;gt; or &amp;lt;link&amp;gt;
		 */
		private ValueExpression _element;
		/**
		 * Name of html element for resource link - may be &amp;lt;a&amp;gt; &amp;lt;img&amp;gt; &amp;lt;object&amp;gt; &amp;lt;applet&amp;gt; &amp;lt;script&amp;gt; or &amp;lt;link&amp;gt;
		 * Setter for element
		 * @param element - new value
		 */
		 public void setElement( ValueExpression  __element ){
			this._element = __element;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * expires
		 * The attribute allows to manage caching and defines the period after which a resource is reloaded.
		 */
		private ValueExpression _expires;
		/**
		 * The attribute allows to manage caching and defines the period after which a resource is reloaded.
		 * Setter for expires
		 * @param expires - new value
		 */
		 public void setExpires( ValueExpression  __expires ){
			this._expires = __expires;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * hreflang
		 * Base language of a resource specified with the href attribute; hreflang may only be used with href
		 */
		private ValueExpression _hreflang;
		/**
		 * Base language of a resource specified with the href attribute; hreflang may only be used with href
		 * Setter for hreflang
		 * @param hreflang - new value
		 */
		 public void setHreflang( ValueExpression  __hreflang ){
			this._hreflang = __hreflang;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * hspace
		 * Deprecated. This attribute specifies the amount of white space to be inserted to the left and right of an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 */
		private ValueExpression _hspace;
		/**
		 * Deprecated. This attribute specifies the amount of white space to be inserted to the left and right of an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 * Setter for hspace
		 * @param hspace - new value
		 */
		 public void setHspace( ValueExpression  __hspace ){
			this._hspace = __hspace;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ismap
		 * use server-side image map
		 */
		private ValueExpression _ismap;
		/**
		 * use server-side image map
		 * Setter for ismap
		 * @param ismap - new value
		 */
		 public void setIsmap( ValueExpression  __ismap ){
			this._ismap = __ismap;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * lang
		 * Code describing the language used in the generated markup for this component
		 */
		private ValueExpression _lang;
		/**
		 * Code describing the language used in the generated markup for this component
		 * Setter for lang
		 * @param lang - new value
		 */
		 public void setLang( ValueExpression  __lang ){
			this._lang = __lang;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * lastModified
		 * The attribute allows to manage caching. A browser can send request with the header "If-Modified-Since" for necessity of object reloading. If time of modification is earlier, then the framework doesn't call generation and return code 304.
		 */
		private ValueExpression _lastModified;
		/**
		 * The attribute allows to manage caching. A browser can send request with the header "If-Modified-Since" for necessity of object reloading. If time of modification is earlier, then the framework doesn't call generation and return code 304.
		 * Setter for lastModified
		 * @param lastModified - new value
		 */
		 public void setLastModified( ValueExpression  __lastModified ){
			this._lastModified = __lastModified;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * mimeType
		 * Geterated content mime-type for append to response
				header ( 'image/jpeg' etc )
		 */
		private ValueExpression _mimeType;
		/**
		 * Geterated content mime-type for append to response
				header ( 'image/jpeg' etc )
		 * Setter for mimeType
		 * @param mimeType - new value
		 */
		 public void setMimeType( ValueExpression  __mimeType ){
			this._mimeType = __mimeType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onblur
		 * The client-side script method to be called when the element loses the focus either when pointing a device or tabbing navigation. The attribute may be used with the same elements as onfocus
		 */
		private ValueExpression _onblur;
		/**
		 * The client-side script method to be called when the element loses the focus either when pointing a device or tabbing navigation. The attribute may be used with the same elements as onfocus
		 * Setter for onblur
		 * @param onblur - new value
		 */
		 public void setOnblur( ValueExpression  __onblur ){
			this._onblur = __onblur;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onclick
		 * The client-side script method to be called when the element is clicked
		 */
		private ValueExpression _onclick;
		/**
		 * The client-side script method to be called when the element is clicked
		 * Setter for onclick
		 * @param onclick - new value
		 */
		 public void setOnclick( ValueExpression  __onclick ){
			this._onclick = __onclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondblclick
		 * The client-side script method to be called when the element is double-clicked
		 */
		private ValueExpression _ondblclick;
		/**
		 * The client-side script method to be called when the element is double-clicked
		 * Setter for ondblclick
		 * @param ondblclick - new value
		 */
		 public void setOndblclick( ValueExpression  __ondblclick ){
			this._ondblclick = __ondblclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onfocus
		 * The client-side script method to be called when the element gets the focus
		 */
		private ValueExpression _onfocus;
		/**
		 * The client-side script method to be called when the element gets the focus
		 * Setter for onfocus
		 * @param onfocus - new value
		 */
		 public void setOnfocus( ValueExpression  __onfocus ){
			this._onfocus = __onfocus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onkeydown
		 * The client-side script method to be called when a key is pressed down over the element
		 */
		private ValueExpression _onkeydown;
		/**
		 * The client-side script method to be called when a key is pressed down over the element
		 * Setter for onkeydown
		 * @param onkeydown - new value
		 */
		 public void setOnkeydown( ValueExpression  __onkeydown ){
			this._onkeydown = __onkeydown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onkeypress
		 * The client-side script method to be called when a key is pressed over the element and released
		 */
		private ValueExpression _onkeypress;
		/**
		 * The client-side script method to be called when a key is pressed over the element and released
		 * Setter for onkeypress
		 * @param onkeypress - new value
		 */
		 public void setOnkeypress( ValueExpression  __onkeypress ){
			this._onkeypress = __onkeypress;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onkeyup
		 * The client-side script method to be called when a key is released
		 */
		private ValueExpression _onkeyup;
		/**
		 * The client-side script method to be called when a key is released
		 * Setter for onkeyup
		 * @param onkeyup - new value
		 */
		 public void setOnkeyup( ValueExpression  __onkeyup ){
			this._onkeyup = __onkeyup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onmousedown
		 * The client-side script method to be called when a mouse button is pressed down over the element
		 */
		private ValueExpression _onmousedown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down over the element
		 * Setter for onmousedown
		 * @param onmousedown - new value
		 */
		 public void setOnmousedown( ValueExpression  __onmousedown ){
			this._onmousedown = __onmousedown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onmousemove
		 * The client-side script method to be called when a pointer is moved within the element
		 */
		private ValueExpression _onmousemove;
		/**
		 * The client-side script method to be called when a pointer is moved within the element
		 * Setter for onmousemove
		 * @param onmousemove - new value
		 */
		 public void setOnmousemove( ValueExpression  __onmousemove ){
			this._onmousemove = __onmousemove;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onmouseout
		 * The client-side script method to be called when a pointer is moved away from the element
		 */
		private ValueExpression _onmouseout;
		/**
		 * The client-side script method to be called when a pointer is moved away from the element
		 * Setter for onmouseout
		 * @param onmouseout - new value
		 */
		 public void setOnmouseout( ValueExpression  __onmouseout ){
			this._onmouseout = __onmouseout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onmouseover
		 * The client-side script method to be called when a pointer is moved onto the element
		 */
		private ValueExpression _onmouseover;
		/**
		 * The client-side script method to be called when a pointer is moved onto the element
		 * Setter for onmouseover
		 * @param onmouseover - new value
		 */
		 public void setOnmouseover( ValueExpression  __onmouseover ){
			this._onmouseover = __onmouseover;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onmouseup
		 * The client-side script method to be called when a mouse button is released
		 */
		private ValueExpression _onmouseup;
		/**
		 * The client-side script method to be called when a mouse button is released
		 * Setter for onmouseup
		 * @param onmouseup - new value
		 */
		 public void setOnmouseup( ValueExpression  __onmouseup ){
			this._onmouseup = __onmouseup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * rel
		 * The relationship from the current document to the anchor specified by this hyperlink. The value of this attribute is a space-separated list of link types
		 */
		private ValueExpression _rel;
		/**
		 * The relationship from the current document to the anchor specified by this hyperlink. The value of this attribute is a space-separated list of link types
		 * Setter for rel
		 * @param rel - new value
		 */
		 public void setRel( ValueExpression  __rel ){
			this._rel = __rel;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * rev
		 * A reverse link from the anchor specified by this hyperlink to the current document. The value of this attribute is a space-separated list of link types
		 */
		private ValueExpression _rev;
		/**
		 * A reverse link from the anchor specified by this hyperlink to the current document. The value of this attribute is a space-separated list of link types
		 * Setter for rev
		 * @param rev - new value
		 */
		 public void setRev( ValueExpression  __rev ){
			this._rev = __rev;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * session
		 * If "true", a session for an object generation is restored.
		 */
		private ValueExpression _session;
		/**
		 * If "true", a session for an object generation is restored.
		 * Setter for session
		 * @param session - new value
		 */
		 public void setSession( ValueExpression  __session ){
			this._session = __session;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * shape
		 * This attribute specifies the shape of a region. The possible values are "default", "rect", "circle" and "poly".
		 */
		private ValueExpression _shape;
		/**
		 * This attribute specifies the shape of a region. The possible values are "default", "rect", "circle" and "poly".
		 * Setter for shape
		 * @param shape - new value
		 */
		 public void setShape( ValueExpression  __shape ){
			this._shape = __shape;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * standby
		 * message to show while loading
		 */
		private ValueExpression _standby;
		/**
		 * message to show while loading
		 * Setter for standby
		 * @param standby - new value
		 */
		 public void setStandby( ValueExpression  __standby ){
			this._standby = __standby;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * style
		 * CSS style rules to be applied to the component
		 */
		private ValueExpression _style;
		/**
		 * CSS style rules to be applied to the component
		 * Setter for style
		 * @param style - new value
		 */
		 public void setStyle( ValueExpression  __style ){
			this._style = __style;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * styleClass
		 * Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
		 */
		private ValueExpression _styleClass;
		/**
		 * Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
		 * Setter for styleClass
		 * @param styleClass - new value
		 */
		 public void setStyleClass( ValueExpression  __styleClass ){
			this._styleClass = __styleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * tabindex
		 * This attribute specifies the position of the current element in the tabbing order for the current document. This value must be a number between 0 and 32767. User agents should ignore leading zeros
		 */
		private ValueExpression _tabindex;
		/**
		 * This attribute specifies the position of the current element in the tabbing order for the current document. This value must be a number between 0 and 32767. User agents should ignore leading zeros
		 * Setter for tabindex
		 * @param tabindex - new value
		 */
		 public void setTabindex( ValueExpression  __tabindex ){
			this._tabindex = __tabindex;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * target
		 * This attribute specifies the name of a frame where a document is to be opened.
            
            By assigning a name to a frame via the name attribute, authors can refer to it as the "target" of links defined by other elements
		 */
		private ValueExpression _target;
		/**
		 * This attribute specifies the name of a frame where a document is to be opened.
            
            By assigning a name to a frame via the name attribute, authors can refer to it as the "target" of links defined by other elements
		 * Setter for target
		 * @param target - new value
		 */
		 public void setTarget( ValueExpression  __target ){
			this._target = __target;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * title
		 * Advisory title information about markup elements generated for this component
		 */
		private ValueExpression _title;
		/**
		 * Advisory title information about markup elements generated for this component
		 * Setter for title
		 * @param title - new value
		 */
		 public void setTitle( ValueExpression  __title ){
			this._title = __title;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * type
		 * The content type of the resource designated by this hyperlink
		 */
		private ValueExpression _type;
		/**
		 * The content type of the resource designated by this hyperlink
		 * Setter for type
		 * @param type - new value
		 */
		 public void setType( ValueExpression  __type ){
			this._type = __type;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * uriAttribute
		 * Name of attribute for resource-link attribute ( 'href' for &amp;lt;a&amp;gt;, 'src' for &amp;lt;img&amp;gt; or &amp;lt;script&amp;gt;, etc)
		 */
		private ValueExpression _uriAttribute;
		/**
		 * Name of attribute for resource-link attribute ( 'href' for &amp;lt;a&amp;gt;, 'src' for &amp;lt;img&amp;gt; or &amp;lt;script&amp;gt;, etc)
		 * Setter for uriAttribute
		 * @param uriAttribute - new value
		 */
		 public void setUriAttribute( ValueExpression  __uriAttribute ){
			this._uriAttribute = __uriAttribute;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * usemap
		 * Specifies an image as a client-side image-map
		 */
		private ValueExpression _usemap;
		/**
		 * Specifies an image as a client-side image-map
		 * Setter for usemap
		 * @param usemap - new value
		 */
		 public void setUsemap( ValueExpression  __usemap ){
			this._usemap = __usemap;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * value
		 * Data value calculated at render time and stored in  URI (also as part of cache Key ),
                at generation time passed to send method. Can be used for update cache at change of  generating
                conditions, and for creating  beans as "Lightweight" pattern components (request scope).
                IMPORTANT: Since serialized data stored in URI, avoid using big objects.
		 */
		private ValueExpression _value;
		/**
		 * Data value calculated at render time and stored in  URI (also as part of cache Key ),
                at generation time passed to send method. Can be used for update cache at change of  generating
                conditions, and for creating  beans as "Lightweight" pattern components (request scope).
                IMPORTANT: Since serialized data stored in URI, avoid using big objects.
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * vspace
		 * Deprecated. This attribute specifies the amount of white space to be inserted above and below an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 */
		private ValueExpression _vspace;
		/**
		 * Deprecated. This attribute specifies the amount of white space to be inserted above and below an IMG, APPLET, or OBJECT. The default value is not specified, but is generally a small, non-zero length
		 * Setter for vspace
		 * @param vspace - new value
		 */
		 public void setVspace( ValueExpression  __vspace ){
			this._vspace = __vspace;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._accesskey = null;
	 		 		    this._align = null;
	 		 		    this._archive = null;
	 		 		 		    this._border = null;
	 		 		    this._cacheable = null;
	 		 		    this._charset = null;
	 		 		    this._classid = null;
	 		 		    this._codebase = null;
	 		 		    this._codetype = null;
	 		 		    this._converter = null;
	 		 		    this._coords = null;
	 		 		    this._createContent = null;
	 		 		    this._createContentExpression = null;
	 		 		    this._declare = null;
	 		 		    this._dir = null;
	 		 		    this._element = null;
	 		 		    this._expires = null;
	 		 		 		    this._hreflang = null;
	 		 		    this._hspace = null;
	 		 		 		    this._ismap = null;
	 		 		    this._lang = null;
	 		 		    this._lastModified = null;
	 		 		 		    this._mimeType = null;
	 		 		    this._onblur = null;
	 		 		    this._onclick = null;
	 		 		    this._ondblclick = null;
	 		 		    this._onfocus = null;
	 		 		    this._onkeydown = null;
	 		 		    this._onkeypress = null;
	 		 		    this._onkeyup = null;
	 		 		    this._onmousedown = null;
	 		 		    this._onmousemove = null;
	 		 		    this._onmouseout = null;
	 		 		    this._onmouseover = null;
	 		 		    this._onmouseup = null;
	 		 		    this._rel = null;
	 		 		 		    this._rev = null;
	 		 		    this._session = null;
	 		 		    this._shape = null;
	 		 		    this._standby = null;
	 		 		    this._style = null;
	 		 		    this._styleClass = null;
	 		 		    this._tabindex = null;
	 		 		    this._target = null;
	 		 		    this._title = null;
	 		 		    this._type = null;
	 		 		    this._uriAttribute = null;
	 		 		    this._usemap = null;
	 		 		    this._value = null;
	 		 		    this._vspace = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		MediaOutput comp = (MediaOutput) component;
 		 			 
						if (this._accesskey != null) {
				if (this._accesskey.isLiteralText()) {
					try {
												
						java.lang.String __accesskey = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._accesskey.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAccesskey(__accesskey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("accesskey", this._accesskey);
				}
			}
					   		 			 
						if (this._align != null) {
				if (this._align.isLiteralText()) {
					try {
												
						java.lang.String __align = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._align.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAlign(__align);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("align", this._align);
				}
			}
					   		 			 
						if (this._archive != null) {
				if (this._archive.isLiteralText()) {
					try {
												
						java.lang.String __archive = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._archive.getExpressionString(), 
											java.lang.String.class);
					
												comp.setArchive(__archive);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("archive", this._archive);
				}
			}
					    		 			 
						if (this._border != null) {
				if (this._border.isLiteralText()) {
					try {
												
						java.lang.String __border = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._border.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBorder(__border);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("border", this._border);
				}
			}
					   		 			 
						if (this._cacheable != null) {
				if (this._cacheable.isLiteralText()) {
					try {
												
						Boolean __cacheable = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cacheable.getExpressionString(), 
											Boolean.class);
					
												comp.setCacheable(__cacheable.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cacheable", this._cacheable);
				}
			}
					   		 			 
						if (this._charset != null) {
				if (this._charset.isLiteralText()) {
					try {
												
						java.lang.String __charset = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._charset.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCharset(__charset);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("charset", this._charset);
				}
			}
					   		 			 
						if (this._classid != null) {
				if (this._classid.isLiteralText()) {
					try {
												
						java.lang.String __classid = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._classid.getExpressionString(), 
											java.lang.String.class);
					
												comp.setClassid(__classid);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("classid", this._classid);
				}
			}
					   		 			 
						if (this._codebase != null) {
				if (this._codebase.isLiteralText()) {
					try {
												
						java.lang.String __codebase = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._codebase.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCodebase(__codebase);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("codebase", this._codebase);
				}
			}
					   		 			 
						if (this._codetype != null) {
				if (this._codetype.isLiteralText()) {
					try {
												
						java.lang.String __codetype = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._codetype.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCodetype(__codetype);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("codetype", this._codetype);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._coords != null) {
				if (this._coords.isLiteralText()) {
					try {
												
						java.lang.String __coords = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._coords.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCoords(__coords);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("coords", this._coords);
				}
			}
					   		 			if(null != this._createContent){
             if (!this._createContent.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._createContent);
                ((MediaOutput)component).setCreateContent(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid createContent value: " + this._createContent);
             }
			}
		   		 			if(null != this._createContentExpression){
				((MediaOutput)component).setCreateContentExpression(this._createContentExpression);
			}		
		   		 			 
						if (this._declare != null) {
				if (this._declare.isLiteralText()) {
					try {
												
						java.lang.String __declare = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._declare.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDeclare(__declare);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("declare", this._declare);
				}
			}
					   		 			 
						if (this._dir != null) {
				if (this._dir.isLiteralText()) {
					try {
												
						java.lang.String __dir = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dir.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDir(__dir);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dir", this._dir);
				}
			}
					   		 			 
						if (this._element != null) {
				if (this._element.isLiteralText()) {
					try {
												
						java.lang.String __element = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._element.getExpressionString(), 
											java.lang.String.class);
					
												comp.setElement(__element);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("element", this._element);
				}
			}
					   		 			 
						if (this._expires != null) {
				if (this._expires.isLiteralText()) {
					try {
												
						java.util.Date __expires = (java.util.Date) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._expires.getExpressionString(), 
											java.util.Date.class);
					
												comp.setExpires(__expires);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("expires", this._expires);
				}
			}
					    		 			 
						if (this._hreflang != null) {
				if (this._hreflang.isLiteralText()) {
					try {
												
						java.lang.String __hreflang = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hreflang.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHreflang(__hreflang);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hreflang", this._hreflang);
				}
			}
					   		 			 
						if (this._hspace != null) {
				if (this._hspace.isLiteralText()) {
					try {
												
						java.lang.String __hspace = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._hspace.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHspace(__hspace);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("hspace", this._hspace);
				}
			}
					    		 			 
						if (this._ismap != null) {
				if (this._ismap.isLiteralText()) {
					try {
												
						Boolean __ismap = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ismap.getExpressionString(), 
											Boolean.class);
					
												comp.setIsmap(__ismap.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ismap", this._ismap);
				}
			}
					   		 			 
						if (this._lang != null) {
				if (this._lang.isLiteralText()) {
					try {
												
						java.lang.String __lang = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lang.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLang(__lang);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lang", this._lang);
				}
			}
					   		 			 
						if (this._lastModified != null) {
				if (this._lastModified.isLiteralText()) {
					try {
												
						java.util.Date __lastModified = (java.util.Date) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lastModified.getExpressionString(), 
											java.util.Date.class);
					
												comp.setLastModified(__lastModified);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lastModified", this._lastModified);
				}
			}
					    		 			 
						if (this._mimeType != null) {
				if (this._mimeType.isLiteralText()) {
					try {
												
						java.lang.String __mimeType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._mimeType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMimeType(__mimeType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("mimeType", this._mimeType);
				}
			}
					   		 			 
						if (this._onblur != null) {
				if (this._onblur.isLiteralText()) {
					try {
												
						java.lang.String __onblur = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onblur.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnblur(__onblur);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onblur", this._onblur);
				}
			}
					   		 			 
						if (this._onclick != null) {
				if (this._onclick.isLiteralText()) {
					try {
												
						java.lang.String __onclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnclick(__onclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onclick", this._onclick);
				}
			}
					   		 			 
						if (this._ondblclick != null) {
				if (this._ondblclick.isLiteralText()) {
					try {
												
						java.lang.String __ondblclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondblclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndblclick(__ondblclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondblclick", this._ondblclick);
				}
			}
					   		 			 
						if (this._onfocus != null) {
				if (this._onfocus.isLiteralText()) {
					try {
												
						java.lang.String __onfocus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfocus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfocus(__onfocus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfocus", this._onfocus);
				}
			}
					   		 			 
						if (this._onkeydown != null) {
				if (this._onkeydown.isLiteralText()) {
					try {
												
						java.lang.String __onkeydown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onkeydown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnkeydown(__onkeydown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onkeydown", this._onkeydown);
				}
			}
					   		 			 
						if (this._onkeypress != null) {
				if (this._onkeypress.isLiteralText()) {
					try {
												
						java.lang.String __onkeypress = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onkeypress.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnkeypress(__onkeypress);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onkeypress", this._onkeypress);
				}
			}
					   		 			 
						if (this._onkeyup != null) {
				if (this._onkeyup.isLiteralText()) {
					try {
												
						java.lang.String __onkeyup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onkeyup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnkeyup(__onkeyup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onkeyup", this._onkeyup);
				}
			}
					   		 			 
						if (this._onmousedown != null) {
				if (this._onmousedown.isLiteralText()) {
					try {
												
						java.lang.String __onmousedown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onmousedown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnmousedown(__onmousedown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onmousedown", this._onmousedown);
				}
			}
					   		 			 
						if (this._onmousemove != null) {
				if (this._onmousemove.isLiteralText()) {
					try {
												
						java.lang.String __onmousemove = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onmousemove.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnmousemove(__onmousemove);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onmousemove", this._onmousemove);
				}
			}
					   		 			 
						if (this._onmouseout != null) {
				if (this._onmouseout.isLiteralText()) {
					try {
												
						java.lang.String __onmouseout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onmouseout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnmouseout(__onmouseout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onmouseout", this._onmouseout);
				}
			}
					   		 			 
						if (this._onmouseover != null) {
				if (this._onmouseover.isLiteralText()) {
					try {
												
						java.lang.String __onmouseover = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onmouseover.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnmouseover(__onmouseover);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onmouseover", this._onmouseover);
				}
			}
					   		 			 
						if (this._onmouseup != null) {
				if (this._onmouseup.isLiteralText()) {
					try {
												
						java.lang.String __onmouseup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onmouseup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnmouseup(__onmouseup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onmouseup", this._onmouseup);
				}
			}
					   		 			 
						if (this._rel != null) {
				if (this._rel.isLiteralText()) {
					try {
												
						java.lang.String __rel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRel(__rel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rel", this._rel);
				}
			}
					    		 			 
						if (this._rev != null) {
				if (this._rev.isLiteralText()) {
					try {
												
						java.lang.String __rev = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rev.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRev(__rev);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rev", this._rev);
				}
			}
					   		 			 
						if (this._session != null) {
				if (this._session.isLiteralText()) {
					try {
												
						Boolean __session = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._session.getExpressionString(), 
											Boolean.class);
					
												comp.setSession(__session.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("session", this._session);
				}
			}
					   		 			 
						if (this._shape != null) {
				if (this._shape.isLiteralText()) {
					try {
												
						java.lang.String __shape = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._shape.getExpressionString(), 
											java.lang.String.class);
					
												comp.setShape(__shape);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("shape", this._shape);
				}
			}
					   		 			 
						if (this._standby != null) {
				if (this._standby.isLiteralText()) {
					try {
												
						java.lang.String __standby = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._standby.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStandby(__standby);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("standby", this._standby);
				}
			}
					   		 			 
						if (this._style != null) {
				if (this._style.isLiteralText()) {
					try {
												
						java.lang.String __style = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._style.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStyle(__style);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("style", this._style);
				}
			}
					   		 			 
						if (this._styleClass != null) {
				if (this._styleClass.isLiteralText()) {
					try {
												
						java.lang.String __styleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._styleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStyleClass(__styleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("styleClass", this._styleClass);
				}
			}
					   		 			 
						if (this._tabindex != null) {
				if (this._tabindex.isLiteralText()) {
					try {
												
						java.lang.String __tabindex = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tabindex.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTabindex(__tabindex);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tabindex", this._tabindex);
				}
			}
					   		 			 
						if (this._target != null) {
				if (this._target.isLiteralText()) {
					try {
												
						java.lang.String __target = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._target.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTarget(__target);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("target", this._target);
				}
			}
					   		 			 
						if (this._title != null) {
				if (this._title.isLiteralText()) {
					try {
												
						java.lang.String __title = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._title.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTitle(__title);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("title", this._title);
				}
			}
					   		 			 
						if (this._type != null) {
				if (this._type.isLiteralText()) {
					try {
												
						java.lang.String __type = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._type.getExpressionString(), 
											java.lang.String.class);
					
												comp.setType(__type);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("type", this._type);
				}
			}
					   		 			 
						if (this._uriAttribute != null) {
				if (this._uriAttribute.isLiteralText()) {
					try {
												
						java.lang.String __uriAttribute = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._uriAttribute.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUriAttribute(__uriAttribute);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("uriAttribute", this._uriAttribute);
				}
			}
					   		 			 
						if (this._usemap != null) {
				if (this._usemap.isLiteralText()) {
					try {
												
						java.lang.String __usemap = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._usemap.getExpressionString(), 
											java.lang.String.class);
					
												comp.setUsemap(__usemap);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("usemap", this._usemap);
				}
			}
					   		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			 
						if (this._vspace != null) {
				if (this._vspace.isLiteralText()) {
					try {
												
						java.lang.String __vspace = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._vspace.getExpressionString(), 
											java.lang.String.class);
					
												comp.setVspace(__vspace);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("vspace", this._vspace);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.MediaOutput";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.MediaOutputRenderer";
			}

}
