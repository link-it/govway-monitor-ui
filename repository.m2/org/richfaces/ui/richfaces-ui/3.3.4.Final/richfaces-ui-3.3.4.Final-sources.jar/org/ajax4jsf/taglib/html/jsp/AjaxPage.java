/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.el.MethodExpression ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.HtmlPage;

public class AjaxPage extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  	  	  
		/*
		 * ajaxListener
		 * MethodExpression representing an action listener method that will be notified when this component is activated by the ajax Request and handle it. The expression must evaluate to a public method that takes an AjaxEvent parameter, with a return type of void
		 */
		private MethodExpression _ajaxListener;
		/**
		 * MethodExpression representing an action listener method that will be notified when this component is activated by the ajax Request and handle it. The expression must evaluate to a public method that takes an AjaxEvent parameter, with a return type of void
		 * Setter for ajaxListener
		 * @param ajaxListener - new value
		 */
		 public void setAjaxListener( MethodExpression  __ajaxListener ){
			this._ajaxListener = __ajaxListener;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * contentType
		 * Set custom mime content type to response
		 */
		private ValueExpression _contentType;
		/**
		 * Set custom mime content type to response
		 * Setter for contentType
		 * @param contentType - new value
		 */
		 public void setContentType( ValueExpression  __contentType ){
			this._contentType = __contentType;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * format
		 * Page layout format ( html, xhtml, html-transitional, html-3.2 ) for encoding DOCTYPE, namespace and Content-Type definitions
		 */
		private ValueExpression _format;
		/**
		 * Page layout format ( html, xhtml, html-transitional, html-3.2 ) for encoding DOCTYPE, namespace and Content-Type definitions
		 * Setter for format
		 * @param format - new value
		 */
		 public void setFormat( ValueExpression  __format ){
			this._format = __format;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * Flag indicating that, if this component is activated by ajaxrequest, notifications should be delivered to interested listeners and actions immediately (that is, during Apply Request Values phase) rather than waiting until Invoke Application phase
		 */
		private ValueExpression _immediate;
		/**
		 * Flag indicating that, if this component is activated by ajaxrequest, notifications should be delivered to interested listeners and actions immediately (that is, during Apply Request Values phase) rather than waiting until Invoke Application phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * namespace
		 * Set html element default namespace
		 */
		private ValueExpression _namespace;
		/**
		 * Set html element default namespace
		 * Setter for namespace
		 * @param namespace - new value
		 */
		 public void setNamespace( ValueExpression  __namespace ){
			this._namespace = __namespace;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onload
		 * The client-side script method to be called before a page is loaded
		 */
		private ValueExpression _onload;
		/**
		 * The client-side script method to be called before a page is loaded
		 * Setter for onload
		 * @param onload - new value
		 */
		 public void setOnload( ValueExpression  __onload ){
			this._onload = __onload;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onunload
		 * The client-side script method to be called when a page is unloaded
		 */
		private ValueExpression _onunload;
		/**
		 * The client-side script method to be called when a page is unloaded
		 * Setter for onunload
		 * @param onunload - new value
		 */
		 public void setOnunload( ValueExpression  __onunload ){
			this._onunload = __onunload;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * pageTitle
		 * String for output as a page title.
		 */
		private ValueExpression _pageTitle;
		/**
		 * String for output as a page title.
		 * Setter for pageTitle
		 * @param pageTitle - new value
		 */
		 public void setPageTitle( ValueExpression  __pageTitle ){
			this._pageTitle = __pageTitle;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * selfRendered
		 * if "true", self-render subtree at InvokeApplication ( or Decode, if immediate property set to true )  phase
		 */
		private ValueExpression _selfRendered;
		/**
		 * if "true", self-render subtree at InvokeApplication ( or Decode, if immediate property set to true )  phase
		 * Setter for selfRendered
		 * @param selfRendered - new value
		 */
		 public void setSelfRendered( ValueExpression  __selfRendered ){
			this._selfRendered = __selfRendered;
	     }
	  
	 	 		 		 		 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxListener = null;
	 		 		 		 		    this._contentType = null;
	 		 		 		 		    this._format = null;
	 		 		 		    this._immediate = null;
	 		 		 		    this._namespace = null;
	 		 		    this._onload = null;
	 		 		    this._onunload = null;
	 		 		    this._pageTitle = null;
	 		 		 		 		    this._selfRendered = null;
	 		 		 		 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPage comp = (HtmlPage) component;
 		 			if(null != this._ajaxListener){
				((HtmlPage)component).setAjaxListener(this._ajaxListener);
			}		
		     		 			 
						if (this._contentType != null) {
				if (this._contentType.isLiteralText()) {
					try {
												
						java.lang.String __contentType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentType(__contentType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentType", this._contentType);
				}
			}
					     		 			 
						if (this._format != null) {
				if (this._format.isLiteralText()) {
					try {
												
						java.lang.String __format = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._format.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFormat(__format);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("format", this._format);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					    		 			 
						if (this._namespace != null) {
				if (this._namespace.isLiteralText()) {
					try {
												
						java.lang.String __namespace = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._namespace.getExpressionString(), 
											java.lang.String.class);
					
												comp.setNamespace(__namespace);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("namespace", this._namespace);
				}
			}
					   		 			 
						if (this._onload != null) {
				if (this._onload.isLiteralText()) {
					try {
												
						java.lang.String __onload = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onload.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnload(__onload);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onload", this._onload);
				}
			}
					   		 			 
						if (this._onunload != null) {
				if (this._onunload.isLiteralText()) {
					try {
												
						java.lang.String __onunload = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onunload.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnunload(__onunload);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onunload", this._onunload);
				}
			}
					   		 			 
						if (this._pageTitle != null) {
				if (this._pageTitle.isLiteralText()) {
					try {
												
						java.lang.String __pageTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._pageTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setPageTitle(__pageTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("pageTitle", this._pageTitle);
				}
			}
					     		 			 
						if (this._selfRendered != null) {
				if (this._selfRendered.isLiteralText()) {
					try {
												
						Boolean __selfRendered = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selfRendered.getExpressionString(), 
											Boolean.class);
					
												comp.setSelfRendered(__selfRendered.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selfRendered", this._selfRendered);
				}
			}
					          }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.components.Page";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.components.AjaxPageRenderer";
			}

}
