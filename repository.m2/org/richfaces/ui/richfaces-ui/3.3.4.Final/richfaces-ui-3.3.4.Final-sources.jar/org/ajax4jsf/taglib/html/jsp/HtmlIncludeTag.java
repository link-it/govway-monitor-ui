/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import org.ajax4jsf.taglib.html.jsp.IncludeTag ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.Include;

public class HtmlIncludeTag extends org.ajax4jsf.taglib.html.jsp.IncludeTag {

		// Fields
		 	  			  		  	  
		/*
		 * ajaxRendered
		 * Defines, whether the content of this component must be
				(or not) included in AJAX response created by parent
				AJAX Container, even if it is not forced by reRender
				list of ajax action. Ignored if component marked to output by some Ajax action component.
				Default value is "true".
		 */
		private ValueExpression _ajaxRendered;
		/**
		 * Defines, whether the content of this component must be
				(or not) included in AJAX response created by parent
				AJAX Container, even if it is not forced by reRender
				list of ajax action. Ignored if component marked to output by some Ajax action component.
				Default value is "true".
		 * Setter for ajaxRendered
		 * @param ajaxRendered - new value
		 */
		 public void setAjaxRendered( ValueExpression  __ajaxRendered ){
			this._ajaxRendered = __ajaxRendered;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * dir
		 * Direction indication for text that does not inherit
			directionality. Valid values are "LTR" (left-to-right)
			and "RTL" (right-to-left)
		 */
		private ValueExpression _dir;
		/**
		 * Direction indication for text that does not inherit
			directionality. Valid values are "LTR" (left-to-right)
			and "RTL" (right-to-left)
		 * Setter for dir
		 * @param dir - new value
		 */
		 public void setDir( ValueExpression  __dir ){
			this._dir = __dir;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * keepTransient
		 * Flag for mark all child components to non-transient. If
            true, all children components will be set to non-transient state
            and keep in saved components tree. For output in self-renderer
            region all content ( By default, all content in &amp;lt;f:verbatim&amp;gt;
            tags and non-jsf elements in facelets, marked as transient -
            since, self-rendered ajax regions don't plain output for ajax
            processing ).
		 */
		private ValueExpression _keepTransient;
		/**
		 * Flag for mark all child components to non-transient. If
            true, all children components will be set to non-transient state
            and keep in saved components tree. For output in self-renderer
            region all content ( By default, all content in &amp;lt;f:verbatim&amp;gt;
            tags and non-jsf elements in facelets, marked as transient -
            since, self-rendered ajax regions don't plain output for ajax
            processing ).
		 * Setter for keepTransient
		 * @param keepTransient - new value
		 */
		 public void setKeepTransient( ValueExpression  __keepTransient ){
			this._keepTransient = __keepTransient;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * lang
		 * Code describing the language used in the generated markup for this component
		 */
		private ValueExpression _lang;
		/**
		 * Code describing the language used in the generated markup for this component
		 * Setter for lang
		 * @param lang - new value
		 */
		 public void setLang( ValueExpression  __lang ){
			this._lang = __lang;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * layout
		 * HTML layout for generated markup. Possible values: "block"
            for generating an HTML &amp;lt;div&amp;gt; element, "inline" for
            generating an HTML &amp;lt;span&amp;gt; element, and "none" for generating
            no HTML element. There is a minor exception for the "none" case
            where a child element has the property "rendered" set to "false".
            In this case, we create an empty &amp;lt;span&amp;gt; element with same ID
            as the child element to use as a placeholder for later
            processing. Default value is &amp;quot;inline&amp;quot;
		 */
		private ValueExpression _layout;
		/**
		 * HTML layout for generated markup. Possible values: "block"
            for generating an HTML &amp;lt;div&amp;gt; element, "inline" for
            generating an HTML &amp;lt;span&amp;gt; element, and "none" for generating
            no HTML element. There is a minor exception for the "none" case
            where a child element has the property "rendered" set to "false".
            In this case, we create an empty &amp;lt;span&amp;gt; element with same ID
            as the child element to use as a placeholder for later
            processing. Default value is &amp;quot;inline&amp;quot;
		 * Setter for layout
		 * @param layout - new value
		 */
		 public void setLayout( ValueExpression  __layout ){
			this._layout = __layout;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * style
		 * CSS style rules to be applied to the component
		 */
		private ValueExpression _style;
		/**
		 * CSS style rules to be applied to the component
		 * Setter for style
		 * @param style - new value
		 */
		 public void setStyle( ValueExpression  __style ){
			this._style = __style;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * styleClass
		 * Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
		 */
		private ValueExpression _styleClass;
		/**
		 * Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
		 * Setter for styleClass
		 * @param styleClass - new value
		 */
		 public void setStyleClass( ValueExpression  __styleClass ){
			this._styleClass = __styleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * title
		 * Advisory title information about markup elements generated for this component
		 */
		private ValueExpression _title;
		/**
		 * Advisory title information about markup elements generated for this component
		 * Setter for title
		 * @param title - new value
		 */
		 public void setTitle( ValueExpression  __title ){
			this._title = __title;
	     }
	  
	 	 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxRendered = null;
	 		 		 		    this._dir = null;
	 		 		 		 		    this._keepTransient = null;
	 		 		    this._lang = null;
	 		 		    this._layout = null;
	 		 		 		    this._style = null;
	 		 		    this._styleClass = null;
	 		 		    this._title = null;
	 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		Include comp = (Include) component;
 		 			 
						if (this._ajaxRendered != null) {
				if (this._ajaxRendered.isLiteralText()) {
					try {
												
						Boolean __ajaxRendered = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxRendered.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxRendered(__ajaxRendered.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxRendered", this._ajaxRendered);
				}
			}
					    		 			 
						if (this._dir != null) {
				if (this._dir.isLiteralText()) {
					try {
												
						java.lang.String __dir = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dir.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDir(__dir);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dir", this._dir);
				}
			}
					     		 			 
						if (this._keepTransient != null) {
				if (this._keepTransient.isLiteralText()) {
					try {
												
						Boolean __keepTransient = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._keepTransient.getExpressionString(), 
											Boolean.class);
					
												comp.setKeepTransient(__keepTransient.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("keepTransient", this._keepTransient);
				}
			}
					   		 			 
						if (this._lang != null) {
				if (this._lang.isLiteralText()) {
					try {
												
						java.lang.String __lang = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._lang.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLang(__lang);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("lang", this._lang);
				}
			}
					   		 			 
						if (this._layout != null) {
				if (this._layout.isLiteralText()) {
					try {
												
						java.lang.String __layout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._layout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLayout(__layout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("layout", this._layout);
				}
			}
					    		 			 
						if (this._style != null) {
				if (this._style.isLiteralText()) {
					try {
												
						java.lang.String __style = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._style.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStyle(__style);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("style", this._style);
				}
			}
					   		 			 
						if (this._styleClass != null) {
				if (this._styleClass.isLiteralText()) {
					try {
												
						java.lang.String __styleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._styleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStyleClass(__styleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("styleClass", this._styleClass);
				}
			}
					   		 			 
						if (this._title != null) {
				if (this._title.isLiteralText()) {
					try {
												
						java.lang.String __title = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._title.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTitle(__title);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("title", this._title);
				}
			}
					       }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.Include";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.components.AjaxIncludeRenderer";
			}

}
