/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.HtmlLoadStyle;

public class LoadStyleTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 		 	  			  		  	  
		/*
		 * media
		 * This attribute defines the device to which it is necessary to apply style registration. 
				The possible values are "all", "screen" (by default), "print", "projection", "projection", "braille" and "speech".
		 */
		private ValueExpression _media;
		/**
		 * This attribute defines the device to which it is necessary to apply style registration. 
				The possible values are "all", "screen" (by default), "print", "projection", "projection", "braille" and "speech".
		 * Setter for media
		 * @param media - new value
		 */
		 public void setMedia( ValueExpression  __media ){
			this._media = __media;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * src
		 * Defines the context relative path to the style sheet file.
		 */
		private ValueExpression _src;
		/**
		 * Defines the context relative path to the style sheet file.
		 * Setter for src
		 * @param src - new value
		 */
		 public void setSrc( ValueExpression  __src ){
			this._src = __src;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		    this._media = null;
	 		 		 		    this._src = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlLoadStyle comp = (HtmlLoadStyle) component;
    		 			 
						if (this._media != null) {
				if (this._media.isLiteralText()) {
					try {
												
						java.lang.String __media = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._media.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMedia(__media);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("media", this._media);
				}
			}
					    		 			 
						if (this._src != null) {
				if (this._src.isLiteralText()) {
					try {
												
						java.lang.Object __src = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._src.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setSrc(__src);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("src", this._src);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.LoadStyle";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.LoadStyleRenderer";
			}

}
