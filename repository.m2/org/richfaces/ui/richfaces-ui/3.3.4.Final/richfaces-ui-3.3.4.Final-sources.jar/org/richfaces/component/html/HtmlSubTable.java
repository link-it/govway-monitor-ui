package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.MethodExpression;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UISubTable;
import org.richfaces.model.Ordering;

public class HtmlSubTable extends UISubTable{

final static public  String COMPONENT_FAMILY = "org.richfaces.SubTable";

final static public  String COMPONENT_TYPE = "org.richfaces.SubTable";

/*
* Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
*/
private  String _columnClasses = null;

/*
* filterMethod
*/
private  MethodExpression _filterMethod = null;

/*
* filterValue
*/
private  String _filterValue = null;

/*
* Assigns one or more space-separated CSS class names to any footer generated for this component
*/
private  String _footerClass = null;

/*
* Assigns one or more space-separated CSS class names to any header generated for this component
*/
private  String _headerClass = null;

/*
* The client-side script method to be called when the row is clicked
*/
private  String _onRowClick = null;

/*
* The client-side script method to be called when the row is double-clicked
*/
private  String _onRowDblClick = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the row
*/
private  String _onRowMouseDown = null;

/*
* The client-side script method to be called when a pointer is moved within the row
*/
private  String _onRowMouseMove = null;

/*
* The client-side script method to be called when a pointer is moved away from the row
*/
private  String _onRowMouseOut = null;

/*
* The client-side script method to be called when a pointer is moved onto the row
*/
private  String _onRowMouseOver = null;

/*
* The client-side script method to be called when a mouse button is released over the row
*/
private  String _onRowMouseUp = null;

/*
* The client-side script method to be called when the element is clicked
*/
private  String _onclick = null;

/*
* The client-side script method to be called when the element is double-clicked
*/
private  String _ondblclick = null;

/*
* The client-side script method to be called when a key is pressed down over the element
*/
private  String _onkeydown = null;

/*
* The client-side script method to be called when a key is pressed over the element and released
*/
private  String _onkeypress = null;

/*
* The client-side script method to be called when a key is released
*/
private  String _onkeyup = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the element
*/
private  String _onmousedown = null;

/*
* The client-side script method to be called when a pointer is moved within the element
*/
private  String _onmousemove = null;

/*
* The client-side script method to be called when a pointer is moved away from the element
*/
private  String _onmouseout = null;

/*
* The client-side script method to be called when a pointer is moved onto the element
*/
private  String _onmouseover = null;

/*
* The client-side script method to be called when a mouse button is released
*/
private  String _onmouseup = null;

/*
* Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
*/
private  String _rowClasses = null;

/*
* selfSorted
*/
private  boolean _selfSorted = false;

private  boolean _selfSortedSet = false;

/*
* sortMode
*/
private  String _sortMode = null;

/*
* sortOrder
*/
private  Ordering _sortOrder = null;

/*
* 
*/
private  boolean _sortable = true;

private  boolean _sortableSet = false;

/*
* null
*/
private  Object _summary = null;


public HtmlSubTable(){
setRendererType("org.richfaces.SubTableRenderer");
}

public String getColumnClasses(){
	if (this._columnClasses != null) {
		return this._columnClasses;
	}
	ValueExpression ve = getValueExpression("columnClasses");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setColumnClasses(String _columnClasses){
this._columnClasses = _columnClasses;
}

public MethodExpression getFilterMethod(){
	if (this._filterMethod != null) {
		return this._filterMethod;
	}
	ValueExpression ve = getValueExpression("filterMethod");
	if (ve != null) {
	    MethodExpression value = null;
	    
	    try {
			value = (MethodExpression) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFilterMethod(MethodExpression _filterMethod){
this._filterMethod = _filterMethod;
}

public String getFilterValue(){
	if (this._filterValue != null) {
		return this._filterValue;
	}
	ValueExpression ve = getValueExpression("filterValue");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFilterValue(String _filterValue){
this._filterValue = _filterValue;
}

public String getFooterClass(){
	if (this._footerClass != null) {
		return this._footerClass;
	}
	ValueExpression ve = getValueExpression("footerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFooterClass(String _footerClass){
this._footerClass = _footerClass;
}

public String getHeaderClass(){
	if (this._headerClass != null) {
		return this._headerClass;
	}
	ValueExpression ve = getValueExpression("headerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setHeaderClass(String _headerClass){
this._headerClass = _headerClass;
}

public String getOnRowClick(){
	if (this._onRowClick != null) {
		return this._onRowClick;
	}
	ValueExpression ve = getValueExpression("onRowClick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowClick(String _onRowClick){
this._onRowClick = _onRowClick;
}

public String getOnRowDblClick(){
	if (this._onRowDblClick != null) {
		return this._onRowDblClick;
	}
	ValueExpression ve = getValueExpression("onRowDblClick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowDblClick(String _onRowDblClick){
this._onRowDblClick = _onRowDblClick;
}

public String getOnRowMouseDown(){
	if (this._onRowMouseDown != null) {
		return this._onRowMouseDown;
	}
	ValueExpression ve = getValueExpression("onRowMouseDown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseDown(String _onRowMouseDown){
this._onRowMouseDown = _onRowMouseDown;
}

public String getOnRowMouseMove(){
	if (this._onRowMouseMove != null) {
		return this._onRowMouseMove;
	}
	ValueExpression ve = getValueExpression("onRowMouseMove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseMove(String _onRowMouseMove){
this._onRowMouseMove = _onRowMouseMove;
}

public String getOnRowMouseOut(){
	if (this._onRowMouseOut != null) {
		return this._onRowMouseOut;
	}
	ValueExpression ve = getValueExpression("onRowMouseOut");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseOut(String _onRowMouseOut){
this._onRowMouseOut = _onRowMouseOut;
}

public String getOnRowMouseOver(){
	if (this._onRowMouseOver != null) {
		return this._onRowMouseOver;
	}
	ValueExpression ve = getValueExpression("onRowMouseOver");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseOver(String _onRowMouseOver){
this._onRowMouseOver = _onRowMouseOver;
}

public String getOnRowMouseUp(){
	if (this._onRowMouseUp != null) {
		return this._onRowMouseUp;
	}
	ValueExpression ve = getValueExpression("onRowMouseUp");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseUp(String _onRowMouseUp){
this._onRowMouseUp = _onRowMouseUp;
}

public String getOnclick(){
	if (this._onclick != null) {
		return this._onclick;
	}
	ValueExpression ve = getValueExpression("onclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnclick(String _onclick){
this._onclick = _onclick;
}

public String getOndblclick(){
	if (this._ondblclick != null) {
		return this._ondblclick;
	}
	ValueExpression ve = getValueExpression("ondblclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOndblclick(String _ondblclick){
this._ondblclick = _ondblclick;
}

public String getOnkeydown(){
	if (this._onkeydown != null) {
		return this._onkeydown;
	}
	ValueExpression ve = getValueExpression("onkeydown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeydown(String _onkeydown){
this._onkeydown = _onkeydown;
}

public String getOnkeypress(){
	if (this._onkeypress != null) {
		return this._onkeypress;
	}
	ValueExpression ve = getValueExpression("onkeypress");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeypress(String _onkeypress){
this._onkeypress = _onkeypress;
}

public String getOnkeyup(){
	if (this._onkeyup != null) {
		return this._onkeyup;
	}
	ValueExpression ve = getValueExpression("onkeyup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeyup(String _onkeyup){
this._onkeyup = _onkeyup;
}

public String getOnmousedown(){
	if (this._onmousedown != null) {
		return this._onmousedown;
	}
	ValueExpression ve = getValueExpression("onmousedown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousedown(String _onmousedown){
this._onmousedown = _onmousedown;
}

public String getOnmousemove(){
	if (this._onmousemove != null) {
		return this._onmousemove;
	}
	ValueExpression ve = getValueExpression("onmousemove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousemove(String _onmousemove){
this._onmousemove = _onmousemove;
}

public String getOnmouseout(){
	if (this._onmouseout != null) {
		return this._onmouseout;
	}
	ValueExpression ve = getValueExpression("onmouseout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseout(String _onmouseout){
this._onmouseout = _onmouseout;
}

public String getOnmouseover(){
	if (this._onmouseover != null) {
		return this._onmouseover;
	}
	ValueExpression ve = getValueExpression("onmouseover");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseover(String _onmouseover){
this._onmouseover = _onmouseover;
}

public String getOnmouseup(){
	if (this._onmouseup != null) {
		return this._onmouseup;
	}
	ValueExpression ve = getValueExpression("onmouseup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseup(String _onmouseup){
this._onmouseup = _onmouseup;
}

public String getRowClasses(){
	if (this._rowClasses != null) {
		return this._rowClasses;
	}
	ValueExpression ve = getValueExpression("rowClasses");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setRowClasses(String _rowClasses){
this._rowClasses = _rowClasses;
}

public boolean isSelfSorted(){
	if (this._selfSortedSet) {
	    return (this._selfSorted);
	}
	ValueExpression ve = getValueExpression("selfSorted");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._selfSorted);
	    }
	    
	    return value;
	} else {
	    return (this._selfSorted);
	}

}

public void setSelfSorted(boolean _selfSorted){
this._selfSorted = _selfSorted;
this._selfSortedSet = true;
}

public String getSortMode(){
	if (this._sortMode != null) {
		return this._sortMode;
	}
	ValueExpression ve = getValueExpression("sortMode");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSortMode(String _sortMode){
this._sortMode = _sortMode;
}

public Ordering getSortOrder(){
	if (this._sortOrder != null) {
		return this._sortOrder;
	}
	ValueExpression ve = getValueExpression("sortOrder");
	if (ve != null) {
	    Ordering value = null;
	    
	    try {
			value = (Ordering) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSortOrder(Ordering _sortOrder){
this._sortOrder = _sortOrder;
}

public boolean isSortable(){
	if (this._sortableSet) {
	    return (this._sortable);
	}
	ValueExpression ve = getValueExpression("sortable");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._sortable);
	    }
	    
	    return value;
	} else {
	    return (this._sortable);
	}

}

public void setSortable(boolean _sortable){
this._sortable = _sortable;
this._sortableSet = true;
}

public Object getSummary(){
	if (this._summary != null) {
		return this._summary;
	}
	ValueExpression ve = getValueExpression("summary");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSummary(Object _summary){
this._summary = _summary;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[31];
state[0] = super.saveState(context);
state[1] = _columnClasses;
state[2] = saveAttachedState(context, _filterMethod);
state[3] = _filterValue;
state[4] = _footerClass;
state[5] = _headerClass;
state[6] = _onRowClick;
state[7] = _onRowDblClick;
state[8] = _onRowMouseDown;
state[9] = _onRowMouseMove;
state[10] = _onRowMouseOut;
state[11] = _onRowMouseOver;
state[12] = _onRowMouseUp;
state[13] = _onclick;
state[14] = _ondblclick;
state[15] = _onkeydown;
state[16] = _onkeypress;
state[17] = _onkeyup;
state[18] = _onmousedown;
state[19] = _onmousemove;
state[20] = _onmouseout;
state[21] = _onmouseover;
state[22] = _onmouseup;
state[23] = _rowClasses;
state[24] = Boolean.valueOf(_selfSorted);
state[25] = Boolean.valueOf(_selfSortedSet);
state[26] = _sortMode;
state[27] = saveAttachedState(context, _sortOrder);
state[28] = Boolean.valueOf(_sortable);
state[29] = Boolean.valueOf(_sortableSet);
state[30] = saveAttachedState(context, _summary);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_columnClasses = (String)states[1];;
		_filterMethod = (MethodExpression)restoreAttachedState(context, states[2]);
		_filterValue = (String)states[3];;
		_footerClass = (String)states[4];;
		_headerClass = (String)states[5];;
		_onRowClick = (String)states[6];;
		_onRowDblClick = (String)states[7];;
		_onRowMouseDown = (String)states[8];;
		_onRowMouseMove = (String)states[9];;
		_onRowMouseOut = (String)states[10];;
		_onRowMouseOver = (String)states[11];;
		_onRowMouseUp = (String)states[12];;
		_onclick = (String)states[13];;
		_ondblclick = (String)states[14];;
		_onkeydown = (String)states[15];;
		_onkeypress = (String)states[16];;
		_onkeyup = (String)states[17];;
		_onmousedown = (String)states[18];;
		_onmousemove = (String)states[19];;
		_onmouseout = (String)states[20];;
		_onmouseover = (String)states[21];;
		_onmouseup = (String)states[22];;
		_rowClasses = (String)states[23];;
		_selfSorted = ((Boolean)states[24]).booleanValue();
		_selfSortedSet = ((Boolean)states[25]).booleanValue();
		_sortMode = (String)states[26];;
		_sortOrder = (Ordering)restoreAttachedState(context, states[27]);
		_sortable = ((Boolean)states[28]).booleanValue();
		_sortableSet = ((Boolean)states[29]).booleanValue();
		_summary = (Object)restoreAttachedState(context, states[30]);
	
}

}
