/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
//
//
//


import org.richfaces.renderkit.html.PanelMenuGroupRenderer;



/**
 * Renderer for component class org.richfaces.renderkit.html.HtmlPanelMenuGroupRenderer
 */
public class HtmlPanelMenuGroupRenderer extends PanelMenuGroupRenderer {

	public HtmlPanelMenuGroupRenderer () {
		super();
	}

	// 
	// Declarations
	//
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIPanelMenuGroup.class;
	}

	
	public void doEncodeBegin(ResponseWriter writer, FacesContext context, UIComponent component ) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeBegin(writer, context, (org.richfaces.component.UIPanelMenuGroup)component, variables );
	}		

	public void doEncodeBegin(ResponseWriter writer, FacesContext context, org.richfaces.component.UIPanelMenuGroup component, ComponentVariables variables ) throws IOException {
	    java.lang.String clientId = component.getClientId(context);

	 
			variables.setVariable("cspValue", getUtils().getCspNonceValue(context));
			variables.setVariable("cssId", getUtils().getCssId(clientId));
	
	
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("." + convertToString(variables.getVariable("cssId")) + "-div-style { " + convertToString(getHideStyle(context,component)) + " }\n		." + convertToString(variables.getVariable("cssId")) + "-table-style { " + convertToString(getFullStyle(context,component)) + " }\n		." + convertToString(variables.getVariable("cssId")) + "-table-td-style { width:100%; }\n		." + convertToString(variables.getVariable("cssId")) + "-script { display:none;}"),null);

writer.endElement("style");
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", convertToString(getDivClass(context,component)) + " " + convertToString(variables.getVariable("cssId")) + "-div-style" );
						getUtils().writeAttribute(writer, "id", clientId );
			
boolean isNodeSelected  =  false  ;

		     
		          String isNodeOpened = isOpened(context, component) ? "opened" : "closed";
		          
		          //marks current selection in renderer helper object - method should be called 
		          //even if return value is not necessary
		          isNodeSelected = queryAndMarkSelection(context, component);
		      
		
writer.startElement("table", component);
			getUtils().writeAttribute(writer, "border", "0" );
						getUtils().writeAttribute(writer, "cellpadding", "0" );
						getUtils().writeAttribute(writer, "cellspacing", "0" );
						getUtils().writeAttribute(writer, "class", convertToString(getTableClass(context,component)) + " rich-pmenu-group " + convertToString(getFullStyleClass(context,component)) + " " + convertToString(variables.getVariable("cssId")) + "-table-style" );
						getUtils().writeAttribute(writer, "id", "tablehide" + convertToString(clientId) );
			//
// pass thru attributes
//
getUtils().encodeAttributesFromArray(context,component,new String[] {
    "align" ,
	    "bgcolor" ,
	    "dir" ,
	    "frame" ,
	    "lang" ,
	    "onclick" ,
	    "ondblclick" ,
	    "onkeydown" ,
	    "onkeypress" ,
	    "onkeyup" ,
	    "onmousedown" ,
	    "onmousemove" ,
	    "onmouseout" ,
	    "onmouseover" ,
	    "onmouseup" ,
	    "rules" ,
	    "summary" ,
	    "title" ,
	    "width" ,
	    "xml:lang" });
//
//
//

writer.startElement("tbody", component);

writer.startElement("tr", component);
			getUtils().writeAttribute(writer, "class", getSelectedClass(isNodeSelected) );
						getUtils().writeAttribute(writer, "id", "row_" + convertToString(clientId) );
			
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-pmenu-nowrap " + convertToString(getIconClass(context,component,"left")) );
			
insertSpacerImages(context, component);

insertImage(context, component, "left");

writer.endElement("td");
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-pmenu-group-self-label " + convertToString(getLabelClass(context,component)) + " " + convertToString(variables.getVariable("cssId")) + "-table-td-style" );
						getUtils().writeAttribute(writer, "id", "icon" + convertToString(clientId) );
			
writer.startElement("input", component);
			getUtils().writeAttribute(writer, "autocomplete", "off" );
						getUtils().writeAttribute(writer, "name", "panelMenuState" + convertToString(clientId) );
						getUtils().writeAttribute(writer, "type", "hidden" );
						getUtils().writeAttribute(writer, "value", variables.getVariable("isNodeOpened") );
			
writer.endElement("input");
writer.startElement("input", component);
			getUtils().writeAttribute(writer, "autocomplete", "off" );
						getUtils().writeAttribute(writer, "name", "panelMenuAction" + convertToString(clientId) );
						getUtils().writeAttribute(writer, "type", "hidden" );
						getUtils().writeAttribute(writer, "value", "" );
			
writer.endElement("input");
insertLabel(context, component);

writer.endElement("td");
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", getIconClass(context,component,"right") );
			
insertImage(context, component, "right");

writer.endElement("td");
writer.endElement("tr");
writer.endElement("tbody");
writer.endElement("table");

	}		
	
    public void doEncodeChildren(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeChildren(writer, context, (org.richfaces.component.UIPanelMenuGroup)component, variables );
	}		

    public void doEncodeChildren(ResponseWriter writer, FacesContext context, org.richfaces.component.UIPanelMenuGroup component, ComponentVariables variables) throws IOException {
	    
renderChildren(context, component);


	}		

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getRendersChildren()
	 */
	public boolean getRendersChildren() {
		return true;
	}

	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIPanelMenuGroup component, ComponentVariables variables) throws IOException {
	  
writer.endElement("div");

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIPanelMenuGroup)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
