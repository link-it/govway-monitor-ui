/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
import org.richfaces.component.util.HtmlUtil;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.resource.InternetResource;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
import org.ajax4jsf.renderkit.RendererUtils.ScriptHashVariableWrapper;
//
//
//


import org.richfaces.renderkit.OrderingListRendererBase;



/**
 * Renderer for component class org.richfaces.renderkit.html.OrderingListRenderer
 */
public class OrderingListRenderer extends OrderingListRendererBase {

	public OrderingListRenderer () {
		super();
	}

	// 
	// Declarations
	//
	private final InternetResource[] styles = {
						getResource("css/orderingList.xcss")
	};

private InternetResource[] stylesAll = null;

protected InternetResource[] getStyles() {
	synchronized (this) {
		if (stylesAll == null) {
			InternetResource[] rsrcs = super.getStyles();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = styles == null || styles.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					stylesAll = new InternetResource[0];	
				} else {
					stylesAll = styles;
				}
			} else {
				if (ignoreThis) {
					stylesAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < styles.length; i++ ) {
						rsrcsSet.add(styles[i]);
					}

					stylesAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return stylesAll;
}
	private final InternetResource[] scripts = {
						new org.ajax4jsf.javascript.PrototypeScript()
						,
				getResource("/org/richfaces/renderkit/html/scripts/utils.js")
						,
				getResource("scripts/ShuttleUtils.js")
						,
				getResource("scripts/SelectItem.js")
						,
				getResource("scripts/LayoutManager.js")
						,
				getResource("scripts/Control.js")
						,
				getResource("scripts/ListBase.js")
						,
				getResource("scripts/OrderingList.js")
	};

private InternetResource[] scriptsAll = null;

protected InternetResource[] getScripts() {
	synchronized (this) {
		if (scriptsAll == null) {
			InternetResource[] rsrcs = super.getScripts();
			boolean ignoreSuper = rsrcs == null || rsrcs.length == 0;
			boolean ignoreThis = scripts == null || scripts.length == 0;
			
			if (ignoreSuper) {
				if (ignoreThis) {
					scriptsAll = new InternetResource[0];	
				} else {
					scriptsAll = scripts;
				}
			} else {
				if (ignoreThis) {
					scriptsAll = rsrcs;
				} else {
					java.util.Set rsrcsSet = new java.util.LinkedHashSet();

					for (int i = 0; i < rsrcs.length; i++ ) {
						rsrcsSet.add(rsrcs[i]);
					}

					for (int i = 0; i < scripts.length; i++ ) {
						rsrcsSet.add(scripts[i]);
					}

					scriptsAll = (InternetResource[]) rsrcsSet.toArray(new InternetResource[rsrcsSet.size()]);
				}
			}
		}
	}
	
	return scriptsAll;
}
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIOrderingList.class;
	}

	
	public void doEncodeBegin(ResponseWriter writer, FacesContext context, UIComponent component ) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeBegin(writer, context, (org.richfaces.component.UIOrderingList)component, variables );
	}		

	public void doEncodeBegin(ResponseWriter writer, FacesContext context, org.richfaces.component.UIOrderingList component, ComponentVariables variables ) throws IOException {
	    java.lang.String clientId = component.getClientId(context);

	 
			variables.setVariable("cspValue", getUtils().getCspNonceValue(context));
			variables.setVariable("cssId", getUtils().getCssId(clientId));
	
	
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("." + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-focus-keeper-style { width: 1px; position: absolute; left: -32767px; }\n		." + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-td-controls-va-style { vertical-align: " + convertToString(component.getAttributes().get("controlsVerticalAlign")) + "; }\n		." + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-tr-caption-style { " + convertToString(getCaptionDisplay(context,component)) + " }"),null);

writer.endElement("style");
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-ds " + convertToString(component.getAttributes().get("styleClass")) );
						getUtils().writeAttribute(writer, "id", clientId );
			//
// pass thru attributes
//
getUtils().encodeAttributesFromArray(context,component,new String[] {
    "align" ,
	    "dir" ,
	    "lang" ,
	    "onclick" ,
	    "ondblclick" ,
	    "onkeydown" ,
	    "onkeypress" ,
	    "onkeyup" ,
	    "onmousedown" ,
	    "onmousemove" ,
	    "onmouseout" ,
	    "onmouseover" ,
	    "onmouseup" ,
	    "style" ,
	    "title" ,
	    "xml:lang" });
//
//
//

writer.startElement("input", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-focus-keeper-style" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "focusKeeper" );
						getUtils().writeAttribute(writer, "type", "button" );
						getUtils().writeAttribute(writer, "value", "" );
			
writer.endElement("input");
writer.startElement("table", component);
			getUtils().writeAttribute(writer, "cellpadding", "0" );
						getUtils().writeAttribute(writer, "cellspacing", "0" );
						getUtils().writeAttribute(writer, "class", "rich-ordering-list-body" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "table" );
			
writer.startElement("tbody", component);

writer.startElement("tr", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-tr-caption-style" );
			

			        	if ("left".equals(component.getAttributes().get("controlsHorizontalAlign"))) {
                	
writer.startElement("td", component);

writer.endElement("td");

						}
                	
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-caption" );
						getUtils().writeAttribute(writer, "colspan", "2" );
			
encodeCaption(context, component);

writer.endElement("td");

			        	if (!"left".equals(component.getAttributes().get("controlsHorizontalAlign"))) {
                	
writer.startElement("td", component);

writer.endElement("td");

						}
                	
writer.endElement("tr");
writer.startElement("tr", component);


			        	if ("left".equals(component.getAttributes().get("controlsHorizontalAlign"))) {
                	
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-button-valign " + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-td-controls-va-style" );
			
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-button-layout" );
			
encodeControlsFacets(context, component);

writer.endElement("div");
writer.endElement("td");

						}
                	
writer.startElement("td", component);

writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-output" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "headerBox" );
			

			                	String contentContainerStyle = "";
			                	
			                	String listWidthValue = (String) component.getAttributes().get("listWidth");
			                	if (listWidthValue != null) {
			                		contentContainerStyle = contentContainerStyle.concat("width:").concat(HtmlUtil.qualifySize(listWidthValue)).concat(";");
			                		variables.setVariable("contentContainerStyle", contentContainerStyle);
		                		}
			                	if (isHeaderExists(context, component)) {
                			
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-header " + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-header-style" );
			
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("." + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-header-style { " + convertToString(variables.getVariable("contentContainerStyle")) + "; }"),null);

writer.endElement("style");
writer.startElement("table", component);
			getUtils().writeAttribute(writer, "cellpadding", "0" );
						getUtils().writeAttribute(writer, "cellspacing", "0" );
						getUtils().writeAttribute(writer, "class", "rich-ordering-list-items-header" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "internal_header_tab" );
			
encodeHeader(context, component);

writer.endElement("table");
writer.endElement("div");

			                	}
								String listHeightValue = (String) component.getAttributes().get("listHeight");
			                	if (listHeightValue != null) {
			                		contentContainerStyle = contentContainerStyle.concat("height:").concat(HtmlUtil.qualifySize(listHeightValue)).concat(";");
			                		variables.setVariable("contentContainerStyle", contentContainerStyle);
			                	}
                			
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("." + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-content-style { " + convertToString(variables.getVariable("contentContainerStyle")) + "; }"),null);

writer.endElement("style");
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-content " + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-content-style" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "contentBox" );
			
writer.startElement("table", component);
			getUtils().writeAttribute(writer, "cellpadding", "0" );
						getUtils().writeAttribute(writer, "cellspacing", "0" );
						getUtils().writeAttribute(writer, "class", "rich-ordering-list-items" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "internal_tab" );
			
writer.startElement("tbody", component);
			getUtils().writeAttribute(writer, "id", convertToString(clientId) + "tbody" );
			

	}		
	
    public void doEncodeChildren(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeChildren(writer, context, (org.richfaces.component.UIOrderingList)component, variables );
	}		

    public void doEncodeChildren(ResponseWriter writer, FacesContext context, org.richfaces.component.UIOrderingList component, ComponentVariables variables) throws IOException {
	    
encodeRows(context, component);


	}		

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getRendersChildren()
	 */
	public boolean getRendersChildren() {
		return true;
	}

	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIOrderingList component, ComponentVariables variables) throws IOException {
	  
writer.endElement("tbody");
writer.endElement("table");
writer.endElement("div");
writer.endElement("div");
writer.endElement("td");

			        	if (!"left".equals(component.getAttributes().get("controlsHorizontalAlign"))) {
                	
writer.startElement("td", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-button-valign " + convertToString(variables.getVariable("cssId")) + "-rich-ordering-list-td-controls-va-style" );
			
writer.startElement("div", component);
			getUtils().writeAttribute(writer, "class", "rich-ordering-list-button-layout" );
			
encodeControlsFacets(context, component);

writer.endElement("div");
writer.endElement("td");

						}
                	
writer.endElement("tr");
writer.endElement("tbody");
writer.endElement("table");
java.lang.String cId = component.getClientId(context);
java.util.HashMap events = new java.util.HashMap();
	getUtils().addToScriptHash(events, "onorderchanged", component.getAttributes().get("onorderchanged"),  null , ScriptHashVariableWrapper.EVENT_HANDLER);
	getUtils().addToScriptHash(events, "onorderchange", component.getAttributes().get("onorderchange"),  null , ScriptHashVariableWrapper.EVENT_HANDLER);
	getUtils().addToScriptHash(events, "ontopclick", component.getAttributes().get("ontopclick"),  null , ScriptHashVariableWrapper.EVENT_HANDLER);
	getUtils().addToScriptHash(events, "onbottomclick", component.getAttributes().get("onbottomclick"),  null , ScriptHashVariableWrapper.EVENT_HANDLER);
	getUtils().addToScriptHash(events, "onupclick", component.getAttributes().get("onupclick"),  null , ScriptHashVariableWrapper.EVENT_HANDLER);
	getUtils().addToScriptHash(events, "ondownclick", component.getAttributes().get("ondownclick"),  null , ScriptHashVariableWrapper.EVENT_HANDLER);

java.util.HashMap classes = new java.util.HashMap();
	getUtils().addToScriptHash(classes, "columnClasses", component.getAttributes().get("columnClasses"),  null , ScriptHashVariableWrapper.AS_ARRAY);
	getUtils().addToScriptHash(classes, "rowClasses", component.getAttributes().get("rowClasses"),  null , ScriptHashVariableWrapper.AS_ARRAY);

java.util.HashMap options = new java.util.HashMap();
	getUtils().addToScriptHash(options, "events", events,  null , ScriptHashVariableWrapper.DEFAULT);
	getUtils().addToScriptHash(options, "classes", classes,  null , ScriptHashVariableWrapper.DEFAULT);

writer.startElement("script", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/javascript" );
			
writer.writeText(convertToString("new Richfaces.OrderingList('" + convertToString(cId) + "'"),null);

if ( Boolean.valueOf( String.valueOf( ( !  getUtils().isEmpty( options )  ) ) ).booleanValue() ) {


writer.writeText(convertToString(","),null);

org.ajax4jsf.javascript.ScriptUtils.writeToStream(writer, options);

}
writer.writeText(convertToString(");"),null);

writer.endElement("script");
writer.endElement("div");

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIOrderingList)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
