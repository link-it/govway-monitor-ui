package org.richfaces.component.html;

import java.util.List;
import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIExtendedDataTable;
import org.richfaces.model.selection.Selection;

public class HtmlExtendedDataTable extends UIExtendedDataTable{

static public final  String COMPONENT_FAMILY = "org.richfaces.ExtendedDataTable";

static public final  String COMPONENT_TYPE = "org.richfaces.ExtendedDataTable";

/*
* Assigns one or more space-separated CSS class names to the component active row
*/
private  String _activeClass = null;

/*
* Request scope attribute under which the activeRowKey will
                                        be accessible
*/
private  Object _activeRowKey = null;

/*
* Deprecated. This attribute specifies the position of the table with respect to the document. 
            The possible values are "left", "center" and "right". The default value is "left".
*/
private  String _align = null;

/*
* Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
*/
private  String _bgcolor = null;

/*
* This attributes specifies the width of the frame around a
                                        component. Default value is "0"
*/
private  String _border = null;

/*
* Assigns one or more space-separated CSS class names to the component caption
*/
private  String _captionClass = null;

/*
* CSS style rules to be applied to the component caption
*/
private  String _captionStyle = null;

/*
* This attribute specifies the amount of space between the
                                        border of the cell and its contents. Default value is "0"
*/
private  String _cellpadding = null;

/*
* The cellspacing attribute specifies the space between cells. Default value is "0"
*/
private  String _cellspacing = null;

/*
* Assigns one or more space-separated CSS class names to the columns of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular column in the order they follow in the attribute. If you have less class names than columns, 
        the class will be applied to every n-fold column where n is the order in which the class is listed in the attribute. If there are more class names than columns, 
        the overflow ones are ignored.
*/
private  String _columnClasses = null;

/*
* Direction indication for text that does not inherit
			directionality. Valid values are "LTR" (left-to-right)
			and "RTL" (right-to-left)
*/
private  String _dir = null;

/*
* If set to true, table header context menu will be enabled
*/
private  Boolean _enableContextMenu = null;

/*
* filterFields
*/
private  List _filterFields = null;

/*
* Assigns one or more space-separated CSS class names to the component footer
*/
private  String _footerClass = null;

/*
* This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
*/
private  String _frame = null;

/*
* Defines an id of column which the data is grouped by.
*/
private  String _groupingColumn = null;

/*
* Assigns one or more space-separated CSS class names to the component header
*/
private  String _headerClass = null;

/*
* Defines a height of the component. Default value is "500px"
*/
private  String _height = null;

/*
* Code describing the language used in the generated markup for this component
*/
private  String _lang = null;

/*
* Defines label to be displayed in case there are no data rows.
*/
private  String _noDataLabel = null;

/*
* The client-side script method to be called when the row is clicked
*/
private  String _onRowClick = null;

/*
* The client-side script method to be called when the row is double-clicked
*/
private  String _onRowDblClick = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the row
*/
private  String _onRowMouseDown = null;

/*
* The client-side script method to be called when a pointer is moved within the row
*/
private  String _onRowMouseMove = null;

/*
* The client-side script method to be called when a pointer is moved away from the row
*/
private  String _onRowMouseOut = null;

/*
* The client-side script method to be called when a pointer is moved onto the rows
*/
private  String _onRowMouseOver = null;

/*
* The client-side script method to be called when a pointer is released over the row
*/
private  String _onRowMouseUp = null;

/*
* The client-side script method to be called when the element is clicked
*/
private  String _onclick = null;

/*
* The client-side script method to be called when the element is double-clicked
*/
private  String _ondblclick = null;

/*
* The client-side script method to be called when a key is pressed down over the element
*/
private  String _onkeydown = null;

/*
* The client-side script method to be called when a key is pressed over the element and released
*/
private  String _onkeypress = null;

/*
* The client-side script method to be called when a key is released
*/
private  String _onkeyup = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the element
*/
private  String _onmousedown = null;

/*
* The client-side script method to be called when a pointer is moved within the element
*/
private  String _onmousemove = null;

/*
* The client-side script method to be called when a pointer is moved away from the element
*/
private  String _onmouseout = null;

/*
* The client-side script method to be called when a pointer is moved onto the element
*/
private  String _onmouseover = null;

/*
* The client-side script method to be called when a mouse button is released
*/
private  String _onmouseup = null;

/*
* The client-side script method to be called when a selected row is changed
*/
private  String _onselectionchange = null;

/*
* Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
*/
private  Object _reRender = null;

/*
* Assigns one or more space-separated CSS class names to the rows of the table. If the CSS class names are comma-separated, 
        each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
        the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. If there are more class names than rows, 
        the overflow ones are ignored.
*/
private  String _rowClasses = null;

/*
* This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
*/
private  String _rules = null;

/*
* Assigns one or more space-separated CSS class names to the component rows selected
*/
private  String _selectedClass = null;

/*
* Value binding representing selected rows
*/
private  Selection _selection = null;

/*
* Single row can be selected. multi:
                                        Multiple rows can be selected. none: no rows can be
                                        selected. Default value is "single"
*/
private  String _selectionMode = null;

/*
* sortFields
*/
private  List _sortFields = null;

/*
* Defines mode of sorting. Possible values are 'single'
                                        for sorting of one column and 'multi' for some.
*/
private  String _sortMode = null;

/*
* CSS style rules to be applied to the component
*/
private  String _style = null;

/*
* Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
*/
private  String _styleClass = null;

/*
* null
*/
private  Object _summary = null;

/*
* ValueBinding pointing at a property of a String to hold
                                        table state
*/
private  String _tableState = null;

/*
* Advisory title information about markup elements generated for this component
*/
private  String _title = null;

/*
* This attribute specifies the desired width of the entire table and is intended for visual user agents. When the value is percentage value, the value is relative to the user agent's available horizontal space. In the absence of any width specification, table width is determined by the user agent
*/
private  String _width = null;


public HtmlExtendedDataTable(){
setRendererType("org.richfaces.ExtendedDataTableRenderer");
}

public String getActiveClass(){
	if (this._activeClass != null) {
		return this._activeClass;
	}
	ValueExpression ve = getValueExpression("activeClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setActiveClass(String _activeClass){
this._activeClass = _activeClass;
}

public Object getActiveRowKey(){
	if (this._activeRowKey != null) {
		return this._activeRowKey;
	}
	ValueExpression ve = getValueExpression("activeRowKey");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setActiveRowKey(Object _activeRowKey){
this._activeRowKey = _activeRowKey;
}

public String getAlign(){
	if (this._align != null) {
		return this._align;
	}
	ValueExpression ve = getValueExpression("align");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setAlign(String _align){
this._align = _align;
}

public String getBgcolor(){
	if (this._bgcolor != null) {
		return this._bgcolor;
	}
	ValueExpression ve = getValueExpression("bgcolor");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setBgcolor(String _bgcolor){
this._bgcolor = _bgcolor;
}

public String getBorder(){
	if (this._border != null) {
		return this._border;
	}
	ValueExpression ve = getValueExpression("border");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "0";
	

}

public void setBorder(String _border){
this._border = _border;
}

public String getCaptionClass(){
	if (this._captionClass != null) {
		return this._captionClass;
	}
	ValueExpression ve = getValueExpression("captionClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setCaptionClass(String _captionClass){
this._captionClass = _captionClass;
}

public String getCaptionStyle(){
	if (this._captionStyle != null) {
		return this._captionStyle;
	}
	ValueExpression ve = getValueExpression("captionStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setCaptionStyle(String _captionStyle){
this._captionStyle = _captionStyle;
}

public String getCellpadding(){
	if (this._cellpadding != null) {
		return this._cellpadding;
	}
	ValueExpression ve = getValueExpression("cellpadding");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "0";
	

}

public void setCellpadding(String _cellpadding){
this._cellpadding = _cellpadding;
}

public String getCellspacing(){
	if (this._cellspacing != null) {
		return this._cellspacing;
	}
	ValueExpression ve = getValueExpression("cellspacing");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "0";
	

}

public void setCellspacing(String _cellspacing){
this._cellspacing = _cellspacing;
}

public String getColumnClasses(){
	if (this._columnClasses != null) {
		return this._columnClasses;
	}
	ValueExpression ve = getValueExpression("columnClasses");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setColumnClasses(String _columnClasses){
this._columnClasses = _columnClasses;
}

public String getDir(){
	if (this._dir != null) {
		return this._dir;
	}
	ValueExpression ve = getValueExpression("dir");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setDir(String _dir){
this._dir = _dir;
}

public Boolean getEnableContextMenu(){
	if (this._enableContextMenu != null) {
		return this._enableContextMenu;
	}
	ValueExpression ve = getValueExpression("enableContextMenu");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return true;
	

}

public void setEnableContextMenu(Boolean _enableContextMenu){
this._enableContextMenu = _enableContextMenu;
}

public List getFilterFields(){
	if (this._filterFields != null) {
		return this._filterFields;
	}
	ValueExpression ve = getValueExpression("filterFields");
	if (ve != null) {
	    List value = null;
	    
	    try {
			value = (List) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFilterFields(List _filterFields){
this._filterFields = _filterFields;
}

public String getFooterClass(){
	if (this._footerClass != null) {
		return this._footerClass;
	}
	ValueExpression ve = getValueExpression("footerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setFooterClass(String _footerClass){
this._footerClass = _footerClass;
}

public String getFrame(){
	if (this._frame != null) {
		return this._frame;
	}
	ValueExpression ve = getValueExpression("frame");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFrame(String _frame){
this._frame = _frame;
}

public String getGroupingColumn(){
	if (this._groupingColumn != null) {
		return this._groupingColumn;
	}
	ValueExpression ve = getValueExpression("groupingColumn");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setGroupingColumn(String _groupingColumn){
this._groupingColumn = _groupingColumn;
}

public String getHeaderClass(){
	if (this._headerClass != null) {
		return this._headerClass;
	}
	ValueExpression ve = getValueExpression("headerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setHeaderClass(String _headerClass){
this._headerClass = _headerClass;
}

public String getHeight(){
	if (this._height != null) {
		return this._height;
	}
	ValueExpression ve = getValueExpression("height");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "500px";
	

}

public void setHeight(String _height){
this._height = _height;
}

public String getLang(){
	if (this._lang != null) {
		return this._lang;
	}
	ValueExpression ve = getValueExpression("lang");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setLang(String _lang){
this._lang = _lang;
}

public String getNoDataLabel(){
	if (this._noDataLabel != null) {
		return this._noDataLabel;
	}
	ValueExpression ve = getValueExpression("noDataLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setNoDataLabel(String _noDataLabel){
this._noDataLabel = _noDataLabel;
}

public String getOnRowClick(){
	if (this._onRowClick != null) {
		return this._onRowClick;
	}
	ValueExpression ve = getValueExpression("onRowClick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowClick(String _onRowClick){
this._onRowClick = _onRowClick;
}

public String getOnRowDblClick(){
	if (this._onRowDblClick != null) {
		return this._onRowDblClick;
	}
	ValueExpression ve = getValueExpression("onRowDblClick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowDblClick(String _onRowDblClick){
this._onRowDblClick = _onRowDblClick;
}

public String getOnRowMouseDown(){
	if (this._onRowMouseDown != null) {
		return this._onRowMouseDown;
	}
	ValueExpression ve = getValueExpression("onRowMouseDown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseDown(String _onRowMouseDown){
this._onRowMouseDown = _onRowMouseDown;
}

public String getOnRowMouseMove(){
	if (this._onRowMouseMove != null) {
		return this._onRowMouseMove;
	}
	ValueExpression ve = getValueExpression("onRowMouseMove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseMove(String _onRowMouseMove){
this._onRowMouseMove = _onRowMouseMove;
}

public String getOnRowMouseOut(){
	if (this._onRowMouseOut != null) {
		return this._onRowMouseOut;
	}
	ValueExpression ve = getValueExpression("onRowMouseOut");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseOut(String _onRowMouseOut){
this._onRowMouseOut = _onRowMouseOut;
}

public String getOnRowMouseOver(){
	if (this._onRowMouseOver != null) {
		return this._onRowMouseOver;
	}
	ValueExpression ve = getValueExpression("onRowMouseOver");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseOver(String _onRowMouseOver){
this._onRowMouseOver = _onRowMouseOver;
}

public String getOnRowMouseUp(){
	if (this._onRowMouseUp != null) {
		return this._onRowMouseUp;
	}
	ValueExpression ve = getValueExpression("onRowMouseUp");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnRowMouseUp(String _onRowMouseUp){
this._onRowMouseUp = _onRowMouseUp;
}

public String getOnclick(){
	if (this._onclick != null) {
		return this._onclick;
	}
	ValueExpression ve = getValueExpression("onclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnclick(String _onclick){
this._onclick = _onclick;
}

public String getOndblclick(){
	if (this._ondblclick != null) {
		return this._ondblclick;
	}
	ValueExpression ve = getValueExpression("ondblclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOndblclick(String _ondblclick){
this._ondblclick = _ondblclick;
}

public String getOnkeydown(){
	if (this._onkeydown != null) {
		return this._onkeydown;
	}
	ValueExpression ve = getValueExpression("onkeydown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeydown(String _onkeydown){
this._onkeydown = _onkeydown;
}

public String getOnkeypress(){
	if (this._onkeypress != null) {
		return this._onkeypress;
	}
	ValueExpression ve = getValueExpression("onkeypress");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeypress(String _onkeypress){
this._onkeypress = _onkeypress;
}

public String getOnkeyup(){
	if (this._onkeyup != null) {
		return this._onkeyup;
	}
	ValueExpression ve = getValueExpression("onkeyup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeyup(String _onkeyup){
this._onkeyup = _onkeyup;
}

public String getOnmousedown(){
	if (this._onmousedown != null) {
		return this._onmousedown;
	}
	ValueExpression ve = getValueExpression("onmousedown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousedown(String _onmousedown){
this._onmousedown = _onmousedown;
}

public String getOnmousemove(){
	if (this._onmousemove != null) {
		return this._onmousemove;
	}
	ValueExpression ve = getValueExpression("onmousemove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousemove(String _onmousemove){
this._onmousemove = _onmousemove;
}

public String getOnmouseout(){
	if (this._onmouseout != null) {
		return this._onmouseout;
	}
	ValueExpression ve = getValueExpression("onmouseout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseout(String _onmouseout){
this._onmouseout = _onmouseout;
}

public String getOnmouseover(){
	if (this._onmouseover != null) {
		return this._onmouseover;
	}
	ValueExpression ve = getValueExpression("onmouseover");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseover(String _onmouseover){
this._onmouseover = _onmouseover;
}

public String getOnmouseup(){
	if (this._onmouseup != null) {
		return this._onmouseup;
	}
	ValueExpression ve = getValueExpression("onmouseup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseup(String _onmouseup){
this._onmouseup = _onmouseup;
}

public String getOnselectionchange(){
	if (this._onselectionchange != null) {
		return this._onselectionchange;
	}
	ValueExpression ve = getValueExpression("onselectionchange");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnselectionchange(String _onselectionchange){
this._onselectionchange = _onselectionchange;
}

public Object getReRender(){
	if (this._reRender != null) {
		return this._reRender;
	}
	ValueExpression ve = getValueExpression("reRender");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setReRender(Object _reRender){
this._reRender = _reRender;
}

public String getRowClasses(){
	if (this._rowClasses != null) {
		return this._rowClasses;
	}
	ValueExpression ve = getValueExpression("rowClasses");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setRowClasses(String _rowClasses){
this._rowClasses = _rowClasses;
}

public String getRules(){
	if (this._rules != null) {
		return this._rules;
	}
	ValueExpression ve = getValueExpression("rules");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setRules(String _rules){
this._rules = _rules;
}

public String getSelectedClass(){
	if (this._selectedClass != null) {
		return this._selectedClass;
	}
	ValueExpression ve = getValueExpression("selectedClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSelectedClass(String _selectedClass){
this._selectedClass = _selectedClass;
}

public Selection getSelection(){
	if (this._selection != null) {
		return this._selection;
	}
	ValueExpression ve = getValueExpression("selection");
	if (ve != null) {
	    Selection value = null;
	    
	    try {
			value = (Selection) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSelection(Selection _selection){
this._selection = _selection;
}

public String getSelectionMode(){
	if (this._selectionMode != null) {
		return this._selectionMode;
	}
	ValueExpression ve = getValueExpression("selectionMode");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "single";
	

}

public void setSelectionMode(String _selectionMode){
this._selectionMode = _selectionMode;
}

public List getSortFields(){
	if (this._sortFields != null) {
		return this._sortFields;
	}
	ValueExpression ve = getValueExpression("sortFields");
	if (ve != null) {
	    List value = null;
	    
	    try {
			value = (List) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSortFields(List _sortFields){
this._sortFields = _sortFields;
}

public String getSortMode(){
	if (this._sortMode != null) {
		return this._sortMode;
	}
	ValueExpression ve = getValueExpression("sortMode");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSortMode(String _sortMode){
this._sortMode = _sortMode;
}

public String getStyle(){
	if (this._style != null) {
		return this._style;
	}
	ValueExpression ve = getValueExpression("style");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyle(String _style){
this._style = _style;
}

public String getStyleClass(){
	if (this._styleClass != null) {
		return this._styleClass;
	}
	ValueExpression ve = getValueExpression("styleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyleClass(String _styleClass){
this._styleClass = _styleClass;
}

public Object getSummary(){
	if (this._summary != null) {
		return this._summary;
	}
	ValueExpression ve = getValueExpression("summary");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSummary(Object _summary){
this._summary = _summary;
}

public String getTableState(){
	if (this._tableState != null) {
		return this._tableState;
	}
	ValueExpression ve = getValueExpression("tableState");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setTableState(String _tableState){
this._tableState = _tableState;
}

public String getTitle(){
	if (this._title != null) {
		return this._title;
	}
	ValueExpression ve = getValueExpression("title");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setTitle(String _title){
this._title = _title;
}

public String getWidth(){
	if (this._width != null) {
		return this._width;
	}
	ValueExpression ve = getValueExpression("width");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setWidth(String _width){
this._width = _width;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[53];
state[0] = super.saveState(context);
state[1] = _activeClass;
state[2] = saveAttachedState(context, _activeRowKey);
state[3] = _align;
state[4] = _bgcolor;
state[5] = _border;
state[6] = _captionClass;
state[7] = _captionStyle;
state[8] = _cellpadding;
state[9] = _cellspacing;
state[10] = _columnClasses;
state[11] = _dir;
state[12] = _enableContextMenu;
state[13] = saveAttachedState(context, _filterFields);
state[14] = _footerClass;
state[15] = _frame;
state[16] = _groupingColumn;
state[17] = _headerClass;
state[18] = _height;
state[19] = _lang;
state[20] = _noDataLabel;
state[21] = _onRowClick;
state[22] = _onRowDblClick;
state[23] = _onRowMouseDown;
state[24] = _onRowMouseMove;
state[25] = _onRowMouseOut;
state[26] = _onRowMouseOver;
state[27] = _onRowMouseUp;
state[28] = _onclick;
state[29] = _ondblclick;
state[30] = _onkeydown;
state[31] = _onkeypress;
state[32] = _onkeyup;
state[33] = _onmousedown;
state[34] = _onmousemove;
state[35] = _onmouseout;
state[36] = _onmouseover;
state[37] = _onmouseup;
state[38] = _onselectionchange;
state[39] = saveAttachedState(context, _reRender);
state[40] = _rowClasses;
state[41] = _rules;
state[42] = _selectedClass;
state[43] = saveAttachedState(context, _selection);
state[44] = _selectionMode;
state[45] = saveAttachedState(context, _sortFields);
state[46] = _sortMode;
state[47] = _style;
state[48] = _styleClass;
state[49] = saveAttachedState(context, _summary);
state[50] = _tableState;
state[51] = _title;
state[52] = _width;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_activeClass = (String)states[1];;
		_activeRowKey = (Object)restoreAttachedState(context, states[2]);
		_align = (String)states[3];;
		_bgcolor = (String)states[4];;
		_border = (String)states[5];;
		_captionClass = (String)states[6];;
		_captionStyle = (String)states[7];;
		_cellpadding = (String)states[8];;
		_cellspacing = (String)states[9];;
		_columnClasses = (String)states[10];;
		_dir = (String)states[11];;
		_enableContextMenu = (Boolean)states[12];;
		_filterFields = (List)restoreAttachedState(context, states[13]);
		_footerClass = (String)states[14];;
		_frame = (String)states[15];;
		_groupingColumn = (String)states[16];;
		_headerClass = (String)states[17];;
		_height = (String)states[18];;
		_lang = (String)states[19];;
		_noDataLabel = (String)states[20];;
		_onRowClick = (String)states[21];;
		_onRowDblClick = (String)states[22];;
		_onRowMouseDown = (String)states[23];;
		_onRowMouseMove = (String)states[24];;
		_onRowMouseOut = (String)states[25];;
		_onRowMouseOver = (String)states[26];;
		_onRowMouseUp = (String)states[27];;
		_onclick = (String)states[28];;
		_ondblclick = (String)states[29];;
		_onkeydown = (String)states[30];;
		_onkeypress = (String)states[31];;
		_onkeyup = (String)states[32];;
		_onmousedown = (String)states[33];;
		_onmousemove = (String)states[34];;
		_onmouseout = (String)states[35];;
		_onmouseover = (String)states[36];;
		_onmouseup = (String)states[37];;
		_onselectionchange = (String)states[38];;
		_reRender = (Object)restoreAttachedState(context, states[39]);
		_rowClasses = (String)states[40];;
		_rules = (String)states[41];;
		_selectedClass = (String)states[42];;
		_selection = (Selection)restoreAttachedState(context, states[43]);
		_selectionMode = (String)states[44];;
		_sortFields = (List)restoreAttachedState(context, states[45]);
		_sortMode = (String)states[46];;
		_style = (String)states[47];;
		_styleClass = (String)states[48];;
		_summary = (Object)restoreAttachedState(context, states[49]);
		_tableState = (String)states[50];;
		_title = (String)states[51];;
		_width = (String)states[52];;
	
}

}
