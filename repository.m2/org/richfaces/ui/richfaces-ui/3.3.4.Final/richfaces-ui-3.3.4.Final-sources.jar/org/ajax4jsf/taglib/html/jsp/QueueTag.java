/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.HtmlQueue;

public class QueueTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * disabled
		 * If "true", disables this component on page.
		 */
		private ValueExpression _disabled;
		/**
		 * If "true", disables this component on page.
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows you to ignore an Ajax response produced by a request if the newest 'similar' request is in the queue already.
				ignoreDupResponses="true" does not cancel the request while it is processed on the server, but just allows avoiding unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows you to ignore an Ajax response produced by a request if the newest 'similar' request is in the queue already.
				ignoreDupResponses="true" does not cancel the request while it is processed on the server, but just allows avoiding unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * name
		 * Specifies to name for the named queue.
		 */
		private ValueExpression _name;
		/**
		 * Specifies to name for the named queue.
		 * Setter for name
		 * @param name - new value
		 */
		 public void setName( ValueExpression  __name ){
			this._name = __name;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onbeforedomupdate
		 * The client-side script method to be called before DOM is updated
		 */
		private ValueExpression _onbeforedomupdate;
		/**
		 * The client-side script method to be called before DOM is updated
		 * Setter for onbeforedomupdate
		 * @param onbeforedomupdate - new value
		 */
		 public void setOnbeforedomupdate( ValueExpression  __onbeforedomupdate ){
			this._onbeforedomupdate = __onbeforedomupdate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the request is completed
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the request is completed
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onerror
		 * The client-side script method to be called whenever a JavaScript error occurs
		 */
		private ValueExpression _onerror;
		/**
		 * The client-side script method to be called whenever a JavaScript error occurs
		 * Setter for onerror
		 * @param onerror - new value
		 */
		 public void setOnerror( ValueExpression  __onerror ){
			this._onerror = __onerror;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onrequestdequeue
		 * The client-side script method to be called after the request is removed from the queue
		 */
		private ValueExpression _onrequestdequeue;
		/**
		 * The client-side script method to be called after the request is removed from the queue
		 * Setter for onrequestdequeue
		 * @param onrequestdequeue - new value
		 */
		 public void setOnrequestdequeue( ValueExpression  __onrequestdequeue ){
			this._onrequestdequeue = __onrequestdequeue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onrequestqueue
		 * The client-side script method to be called when the request is added to the queue
		 */
		private ValueExpression _onrequestqueue;
		/**
		 * The client-side script method to be called when the request is added to the queue
		 * Setter for onrequestqueue
		 * @param onrequestqueue - new value
		 */
		 public void setOnrequestqueue( ValueExpression  __onrequestqueue ){
			this._onrequestqueue = __onrequestqueue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onsizeexceeded
		 * The client-side script method to be called when a size is exceeded
		 */
		private ValueExpression _onsizeexceeded;
		/**
		 * The client-side script method to be called when a size is exceeded
		 * Setter for onsizeexceeded
		 * @param onsizeexceeded - new value
		 */
		 public void setOnsizeexceeded( ValueExpression  __onsizeexceeded ){
			this._onsizeexceeded = __onsizeexceeded;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onsubmit
		 * The client-side script method to be called before an ajax request is submitted
		 */
		private ValueExpression _onsubmit;
		/**
		 * The client-side script method to be called before an ajax request is submitted
		 * Setter for onsubmit
		 * @param onsubmit - new value
		 */
		 public void setOnsubmit( ValueExpression  __onsubmit ){
			this._onsubmit = __onsubmit;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * requestDelay
		 * Attribute defines the time (in ms) the request will be waiting in the queue before it is ready to be sent.
		 */
		private ValueExpression _requestDelay;
		/**
		 * Attribute defines the time (in ms) the request will be waiting in the queue before it is ready to be sent.
		 * Setter for requestDelay
		 * @param requestDelay - new value
		 */
		 public void setRequestDelay( ValueExpression  __requestDelay ){
			this._requestDelay = __requestDelay;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * size
		 * Defines the number of requests allowed in the queue at one time.
		 */
		private ValueExpression _size;
		/**
		 * Defines the number of requests allowed in the queue at one time.
		 * Setter for size
		 * @param size - new value
		 */
		 public void setSize( ValueExpression  __size ){
			this._size = __size;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * sizeExceededBehavior
		 * Defines the strategies of the queue's behavior if the number of the requests waiting in the queue is exceeded. 
				There are four strategies: dropNext (by default), dropNew, fireNext , fireNew.
		 */
		private ValueExpression _sizeExceededBehavior;
		/**
		 * Defines the strategies of the queue's behavior if the number of the requests waiting in the queue is exceeded. 
				There are four strategies: dropNext (by default), dropNew, fireNext , fireNew.
		 * Setter for sizeExceededBehavior
		 * @param sizeExceededBehavior - new value
		 */
		 public void setSizeExceededBehavior( ValueExpression  __sizeExceededBehavior ){
			this._sizeExceededBehavior = __sizeExceededBehavior;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * timeout
		 * Waiting time for response on a particular request. If no response is received during this time, the request is aborted
		 */
		private ValueExpression _timeout;
		/**
		 * Waiting time for response on a particular request. If no response is received during this time, the request is aborted
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._disabled = null;
	 		 		 		 		    this._ignoreDupResponses = null;
	 		 		    this._name = null;
	 		 		    this._onbeforedomupdate = null;
	 		 		    this._oncomplete = null;
	 		 		    this._onerror = null;
	 		 		    this._onrequestdequeue = null;
	 		 		    this._onrequestqueue = null;
	 		 		    this._onsizeexceeded = null;
	 		 		    this._onsubmit = null;
	 		 		 		    this._requestDelay = null;
	 		 		    this._size = null;
	 		 		    this._sizeExceededBehavior = null;
	 		 		    this._status = null;
	 		 		    this._timeout = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlQueue comp = (HtmlQueue) component;
  		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					     		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					   		 			 
						if (this._name != null) {
				if (this._name.isLiteralText()) {
					try {
												
						java.lang.String __name = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._name.getExpressionString(), 
											java.lang.String.class);
					
												comp.setName(__name);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("name", this._name);
				}
			}
					   		 			 
						if (this._onbeforedomupdate != null) {
				if (this._onbeforedomupdate.isLiteralText()) {
					try {
												
						java.lang.String __onbeforedomupdate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbeforedomupdate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbeforedomupdate(__onbeforedomupdate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbeforedomupdate", this._onbeforedomupdate);
				}
			}
					   		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					   		 			 
						if (this._onerror != null) {
				if (this._onerror.isLiteralText()) {
					try {
												
						java.lang.String __onerror = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onerror.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnerror(__onerror);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onerror", this._onerror);
				}
			}
					   		 			 
						if (this._onrequestdequeue != null) {
				if (this._onrequestdequeue.isLiteralText()) {
					try {
												
						java.lang.String __onrequestdequeue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onrequestdequeue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnrequestdequeue(__onrequestdequeue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onrequestdequeue", this._onrequestdequeue);
				}
			}
					   		 			 
						if (this._onrequestqueue != null) {
				if (this._onrequestqueue.isLiteralText()) {
					try {
												
						java.lang.String __onrequestqueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onrequestqueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnrequestqueue(__onrequestqueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onrequestqueue", this._onrequestqueue);
				}
			}
					   		 			 
						if (this._onsizeexceeded != null) {
				if (this._onsizeexceeded.isLiteralText()) {
					try {
												
						java.lang.String __onsizeexceeded = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsizeexceeded.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsizeexceeded(__onsizeexceeded);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsizeexceeded", this._onsizeexceeded);
				}
			}
					   		 			 
						if (this._onsubmit != null) {
				if (this._onsubmit.isLiteralText()) {
					try {
												
						java.lang.String __onsubmit = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsubmit.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsubmit(__onsubmit);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsubmit", this._onsubmit);
				}
			}
					    		 			 
						if (this._requestDelay != null) {
				if (this._requestDelay.isLiteralText()) {
					try {
												
						Integer __requestDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requestDelay.getExpressionString(), 
											Integer.class);
					
												comp.setRequestDelay(__requestDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requestDelay", this._requestDelay);
				}
			}
					   		 			 
						if (this._size != null) {
				if (this._size.isLiteralText()) {
					try {
												
						Integer __size = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._size.getExpressionString(), 
											Integer.class);
					
												comp.setSize(__size.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("size", this._size);
				}
			}
					   		 			 
						if (this._sizeExceededBehavior != null) {
				if (this._sizeExceededBehavior.isLiteralText()) {
					try {
												
						java.lang.String __sizeExceededBehavior = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sizeExceededBehavior.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSizeExceededBehavior(__sizeExceededBehavior);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sizeExceededBehavior", this._sizeExceededBehavior);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					   		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.Queue";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.QueueRenderer";
			}

}
