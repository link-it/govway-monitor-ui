/**
 * License Agreement.
 *
 * Ajax4jsf 1.1 - Natural Ajax for Java Server Faces (JSF)
 *
 * Copyright (C) 2007 Exadel, Inc.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 */

package org.richfaces.renderkit.html;


// 
// Imports
//
import java.util.Iterator;
import java.util.Collection;
import java.util.Map;
import java.io.IOException;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import org.ajax4jsf.renderkit.ComponentsVariableResolver;
import org.ajax4jsf.renderkit.ComponentVariables;
//
//
//


import org.richfaces.renderkit.html.ToolTipRenderer;



/**
 * Renderer for component class org.richfaces.renderkit.html.HtmlToolTipRenderer
 */
public class HtmlToolTipRenderer extends ToolTipRenderer {

	public HtmlToolTipRenderer () {
		super();
	}

	// 
	// Declarations
	//
	// 
	// 
	//

	private String convertToString(Object obj ) {
		return ( obj == null ? "" : obj.toString() );
	}
	private String convertToString(boolean b ) {
		return String.valueOf(b);
	}
	private String convertToString(int b ) {
		return b!=Integer.MIN_VALUE?String.valueOf(b):"";
	}
	private String convertToString(long b ) {
		return b!=Long.MIN_VALUE?String.valueOf(b):"";
	}
	
	/**
	 * Get base component class, targetted for this renderer. Used for check arguments in decode/encode.
	 * @return
	 */
	protected Class getComponentClass() {
		return org.richfaces.component.UIToolTip.class;
	}

	
	public void doEncodeBegin(ResponseWriter writer, FacesContext context, UIComponent component ) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeBegin(writer, context, (org.richfaces.component.UIToolTip)component, variables );
	}		

	public void doEncodeBegin(ResponseWriter writer, FacesContext context, org.richfaces.component.UIToolTip component, ComponentVariables variables ) throws IOException {
	    java.lang.String clientId = component.getClientId(context);

	 
			variables.setVariable("cspValue", getUtils().getCspNonceValue(context));
			variables.setVariable("cssId", getUtils().getCssId(clientId));
	
	
writer.startElement("style", component);
			getUtils().writeAttribute(writer, "nonce", variables.getVariable("cspValue") );
						getUtils().writeAttribute(writer, "type", "text/css" );
			
writer.writeText(convertToString("." + convertToString(variables.getVariable("cssId")) + "-tooltip {\n			z-index:" + convertToString(component.getAttributes().get("zorder")) + "; " + convertToString(component.getAttributes().get("style")) + "\n		}\n		." + convertToString(variables.getVariable("cssId")) + "-defaultContent { display:none;}\n		." + convertToString(variables.getVariable("cssId")) + "-script { display:none;}"),null);

writer.endElement("style");
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", "rich-tool-tip " + convertToString(component.getAttributes().get("styleClass")) + " " + convertToString(variables.getVariable("cssId")) + "-tooltip" );
						getUtils().writeAttribute(writer, "id", clientId );
			
getUtils().encodePassThruWithExclusions(context, component, "id,style,class,disabled");


			if("ajax".equals(component.getMode()) && component.getFacet("defaultContent")!=null) {
		 
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-defaultContent" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "defaultContent" );
			
UIComponent indexChildren_83 = component.getFacet("defaultContent");
if (null != indexChildren_83 && indexChildren_83 .isRendered()) {
	renderChild(context, indexChildren_83);
}

writer.endElement("span");

			}
		 

	}		
	
    public void doEncodeChildren(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeChildren(writer, context, (org.richfaces.component.UIToolTip)component, variables );
	}		

    public void doEncodeChildren(ResponseWriter writer, FacesContext context, org.richfaces.component.UIToolTip component, ComponentVariables variables) throws IOException {
	    
encodeTooltipText(context, component);


	}		

	/* (non-Javadoc)
	 * @see javax.faces.render.Renderer#getRendersChildren()
	 */
	public boolean getRendersChildren() {
		return true;
	}

	public void doEncodeEnd(ResponseWriter writer, FacesContext context, org.richfaces.component.UIToolTip component, ComponentVariables variables) throws IOException {
	  
java.lang.String clientId = component.getClientId(context);
writer.startElement("span", component);
			getUtils().writeAttribute(writer, "class", convertToString(variables.getVariable("cssId")) + "-script" );
						getUtils().writeAttribute(writer, "id", convertToString(clientId) + "script" );
			
insertScript(context, component);

writer.endElement("span");
writer.endElement("span");

	}		
	
	public void doEncodeEnd(ResponseWriter writer, FacesContext context, UIComponent component) throws IOException {
		ComponentVariables variables = ComponentsVariableResolver.getVariables(this, component);
		doEncodeEnd(writer, context, (org.richfaces.component.UIToolTip)component, variables );

		ComponentsVariableResolver.removeVariables(this, component);
	}		
	

}
