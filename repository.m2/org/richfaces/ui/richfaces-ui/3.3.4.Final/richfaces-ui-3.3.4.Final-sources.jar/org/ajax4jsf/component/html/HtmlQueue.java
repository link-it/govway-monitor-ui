package org.ajax4jsf.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.ajax4jsf.component.UIQueue;

public class HtmlQueue extends UIQueue{

final static public  String COMPONENT_FAMILY = "org.ajax4jsf.Queue";

final static public  String COMPONENT_TYPE = "org.ajax4jsf.Queue";

/*
* If "true", disables this component on page.
*/
private  boolean _disabled = false;

private  boolean _disabledSet = false;

/*
* Attribute allows you to ignore an Ajax response produced by a request if the newest 'similar' request is in the queue already.
				ignoreDupResponses="true" does not cancel the request while it is processed on the server, but just allows avoiding unnecessary updates on the client side if the response isn't actual now
*/
private  boolean _ignoreDupResponses = false;

private  boolean _ignoreDupResponsesSet = false;

/*
* Specifies to name for the named queue.
*/
private  String _name = null;

/*
* The client-side script method to be called before DOM is updated
*/
private  String _onbeforedomupdate = null;

/*
* The client-side script method to be called after the request is completed
*/
private  String _oncomplete = null;

/*
* The client-side script method to be called whenever a JavaScript error occurs
*/
private  String _onerror = null;

/*
* The client-side script method to be called after the request is removed from the queue
*/
private  String _onrequestdequeue = null;

/*
* The client-side script method to be called when the request is added to the queue
*/
private  String _onrequestqueue = null;

/*
* The client-side script method to be called when a size is exceeded
*/
private  String _onsizeexceeded = null;

/*
* The client-side script method to be called before an ajax request is submitted
*/
private  String _onsubmit = null;

/*
* Attribute defines the time (in ms) the request will be waiting in the queue before it is ready to be sent.
*/
private  int _requestDelay = Integer.MIN_VALUE;

private  boolean _requestDelaySet = false;

/*
* Defines the number of requests allowed in the queue at one time.
*/
private  int _size = Integer.MIN_VALUE;

private  boolean _sizeSet = false;

/*
* Defines the strategies of the queue's behavior if the number of the requests waiting in the queue is exceeded. 
				There are four strategies: dropNext (by default), dropNew, fireNext , fireNew.
*/
private  String _sizeExceededBehavior = null;

/*
* ID (in format of call UIComponent.findComponent()) of Request status component
*/
private  String _status = null;

/*
* Waiting time for response on a particular request. If no response is received during this time, the request is aborted
*/
private  int _timeout = Integer.MIN_VALUE;

private  boolean _timeoutSet = false;


public HtmlQueue(){
setRendererType("org.ajax4jsf.QueueRenderer");
}

public boolean isDisabled(){
	if (this._disabledSet) {
	    return (this._disabled);
	}
	ValueExpression ve = getValueExpression("disabled");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._disabled);
	    }
	    
	    return value;
	} else {
	    return (this._disabled);
	}

}

public void setDisabled(boolean _disabled){
this._disabled = _disabled;
this._disabledSet = true;
}

public boolean isIgnoreDupResponses(){
	if (this._ignoreDupResponsesSet) {
	    return (this._ignoreDupResponses);
	}
	ValueExpression ve = getValueExpression("ignoreDupResponses");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._ignoreDupResponses);
	    }
	    
	    return value;
	} else {
	    return (this._ignoreDupResponses);
	}

}

public void setIgnoreDupResponses(boolean _ignoreDupResponses){
this._ignoreDupResponses = _ignoreDupResponses;
this._ignoreDupResponsesSet = true;
}

public String getName(){
	if (this._name != null) {
		return this._name;
	}
	ValueExpression ve = getValueExpression("name");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setName(String _name){
this._name = _name;
}

public String getOnbeforedomupdate(){
	if (this._onbeforedomupdate != null) {
		return this._onbeforedomupdate;
	}
	ValueExpression ve = getValueExpression("onbeforedomupdate");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnbeforedomupdate(String _onbeforedomupdate){
this._onbeforedomupdate = _onbeforedomupdate;
}

public String getOncomplete(){
	if (this._oncomplete != null) {
		return this._oncomplete;
	}
	ValueExpression ve = getValueExpression("oncomplete");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOncomplete(String _oncomplete){
this._oncomplete = _oncomplete;
}

public String getOnerror(){
	if (this._onerror != null) {
		return this._onerror;
	}
	ValueExpression ve = getValueExpression("onerror");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnerror(String _onerror){
this._onerror = _onerror;
}

public String getOnrequestdequeue(){
	if (this._onrequestdequeue != null) {
		return this._onrequestdequeue;
	}
	ValueExpression ve = getValueExpression("onrequestdequeue");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnrequestdequeue(String _onrequestdequeue){
this._onrequestdequeue = _onrequestdequeue;
}

public String getOnrequestqueue(){
	if (this._onrequestqueue != null) {
		return this._onrequestqueue;
	}
	ValueExpression ve = getValueExpression("onrequestqueue");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnrequestqueue(String _onrequestqueue){
this._onrequestqueue = _onrequestqueue;
}

public String getOnsizeexceeded(){
	if (this._onsizeexceeded != null) {
		return this._onsizeexceeded;
	}
	ValueExpression ve = getValueExpression("onsizeexceeded");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnsizeexceeded(String _onsizeexceeded){
this._onsizeexceeded = _onsizeexceeded;
}

public String getOnsubmit(){
	if (this._onsubmit != null) {
		return this._onsubmit;
	}
	ValueExpression ve = getValueExpression("onsubmit");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnsubmit(String _onsubmit){
this._onsubmit = _onsubmit;
}

public int getRequestDelay(){
	if (this._requestDelaySet) {
	    return (this._requestDelay);
	}
	ValueExpression ve = getValueExpression("requestDelay");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._requestDelay);
	    }
	    
	    return value;
	} else {
	    return (this._requestDelay);
	}

}

public void setRequestDelay(int _requestDelay){
this._requestDelay = _requestDelay;
this._requestDelaySet = true;
}

public int getSize(){
	if (this._sizeSet) {
	    return (this._size);
	}
	ValueExpression ve = getValueExpression("size");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._size);
	    }
	    
	    return value;
	} else {
	    return (this._size);
	}

}

public void setSize(int _size){
this._size = _size;
this._sizeSet = true;
}

public String getSizeExceededBehavior(){
	if (this._sizeExceededBehavior != null) {
		return this._sizeExceededBehavior;
	}
	ValueExpression ve = getValueExpression("sizeExceededBehavior");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSizeExceededBehavior(String _sizeExceededBehavior){
this._sizeExceededBehavior = _sizeExceededBehavior;
}

public String getStatus(){
	if (this._status != null) {
		return this._status;
	}
	ValueExpression ve = getValueExpression("status");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStatus(String _status){
this._status = _status;
}

public int getTimeout(){
	if (this._timeoutSet) {
	    return (this._timeout);
	}
	ValueExpression ve = getValueExpression("timeout");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._timeout);
	    }
	    
	    return value;
	} else {
	    return (this._timeout);
	}

}

public void setTimeout(int _timeout){
this._timeout = _timeout;
this._timeoutSet = true;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[21];
state[0] = super.saveState(context);
state[1] = Boolean.valueOf(_disabled);
state[2] = Boolean.valueOf(_disabledSet);
state[3] = Boolean.valueOf(_ignoreDupResponses);
state[4] = Boolean.valueOf(_ignoreDupResponsesSet);
state[5] = _name;
state[6] = _onbeforedomupdate;
state[7] = _oncomplete;
state[8] = _onerror;
state[9] = _onrequestdequeue;
state[10] = _onrequestqueue;
state[11] = _onsizeexceeded;
state[12] = _onsubmit;
state[13] = Integer.valueOf(_requestDelay);
state[14] = Boolean.valueOf(_requestDelaySet);
state[15] = Integer.valueOf(_size);
state[16] = Boolean.valueOf(_sizeSet);
state[17] = _sizeExceededBehavior;
state[18] = _status;
state[19] = Integer.valueOf(_timeout);
state[20] = Boolean.valueOf(_timeoutSet);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_disabled = ((Boolean)states[1]).booleanValue();
		_disabledSet = ((Boolean)states[2]).booleanValue();
		_ignoreDupResponses = ((Boolean)states[3]).booleanValue();
		_ignoreDupResponsesSet = ((Boolean)states[4]).booleanValue();
		_name = (String)states[5];;
		_onbeforedomupdate = (String)states[6];;
		_oncomplete = (String)states[7];;
		_onerror = (String)states[8];;
		_onrequestdequeue = (String)states[9];;
		_onrequestqueue = (String)states[10];;
		_onsizeexceeded = (String)states[11];;
		_onsubmit = (String)states[12];;
		_requestDelay = ((Integer)states[13]).intValue();
		_requestDelaySet = ((Boolean)states[14]).booleanValue();
		_size = ((Integer)states[15]).intValue();
		_sizeSet = ((Boolean)states[16]).booleanValue();
		_sizeExceededBehavior = (String)states[17];;
		_status = (String)states[18];;
		_timeout = ((Integer)states[19]).intValue();
		_timeoutSet = ((Boolean)states[20]).booleanValue();
	
}

}
