/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.HtmlLoadScript;

public class LoadScriptTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 		 		 		 	  			  		  	  
		/*
		 * src
		 * name of JavaScript resource to load.
		 */
		private ValueExpression _src;
		/**
		 * name of JavaScript resource to load.
		 * Setter for src
		 * @param src - new value
		 */
		 public void setSrc( ValueExpression  __src ){
			this._src = __src;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		 		 		    this._src = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlLoadScript comp = (HtmlLoadScript) component;
     		 			 
						if (this._src != null) {
				if (this._src.isLiteralText()) {
					try {
												
						java.lang.Object __src = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._src.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setSrc(__src);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("src", this._src);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.LoadScript";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.LoadScriptRenderer";
			}

}
