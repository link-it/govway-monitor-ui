/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import java.lang.String ;
import javax.faces.component.UIComponent ;
import org.ajax4jsf.webapp.taglib.UIComponentTagBase ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.AjaxLoadBundle;

public class LoadBundle extends org.ajax4jsf.webapp.taglib.UIComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * basename
		 * Base name of the resource bundle to be loaded.
		 */
		private ValueExpression _basename;
		/**
		 * Base name of the resource bundle to be loaded.
		 * Setter for basename
		 * @param basename - new value
		 */
		 public void setBasename( ValueExpression  __basename ){
			this._basename = __basename;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * var
		 * Name of a request scope attribute under which the
				resource bundle will be exposed as a Map.
		 */
		private String _var;
		/**
		 * Name of a request scope attribute under which the
				resource bundle will be exposed as a Map.
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._basename = null;
	 		 		 		 		 		 		    this._var = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		AjaxLoadBundle comp = (AjaxLoadBundle) component;
 		 			 
						if (this._basename != null) {
				if (this._basename.isLiteralText()) {
					try {
												
						java.lang.String __basename = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._basename.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBasename(__basename);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("basename", this._basename);
				}
			}
					       		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.Bundle";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return null;
			}

}
