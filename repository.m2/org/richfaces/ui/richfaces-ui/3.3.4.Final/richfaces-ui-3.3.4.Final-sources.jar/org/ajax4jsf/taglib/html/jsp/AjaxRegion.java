/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.ajax4jsf.taglib.html.jsp;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.el.MethodExpression ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.ajax4jsf.component.html.HtmlAjaxRegion;

public class AjaxRegion extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  	  	  
		/*
		 * ajaxListener
		 * MethodExpression representing an action listener method that will be notified when this component is activated by the ajax Request and handle it. The expression must evaluate to a public method that takes an AjaxEvent parameter, with a return type of void
		 */
		private MethodExpression _ajaxListener;
		/**
		 * MethodExpression representing an action listener method that will be notified when this component is activated by the ajax Request and handle it. The expression must evaluate to a public method that takes an AjaxEvent parameter, with a return type of void
		 * Setter for ajaxListener
		 * @param ajaxListener - new value
		 */
		 public void setAjaxListener( MethodExpression  __ajaxListener ){
			this._ajaxListener = __ajaxListener;
	     }
	  
	 	 		 		 		 		 		 	  			  		  	  
		/*
		 * immediate
		 * Flag indicating that, if this component is activated by ajaxrequest, notifications should be delivered to interested listeners and actions immediately (that is, during Apply Request Values phase) rather than waiting until Invoke Application phase
		 */
		private ValueExpression _immediate;
		/**
		 * Flag indicating that, if this component is activated by ajaxrequest, notifications should be delivered to interested listeners and actions immediately (that is, during Apply Request Values phase) rather than waiting until Invoke Application phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * renderRegionOnly
		 * Excludes all the components from the outside of the region from updating on the page on Renderer Response phase.
			      Default value is "false".
		 */
		private ValueExpression _renderRegionOnly;
		/**
		 * Excludes all the components from the outside of the region from updating on the page on Renderer Response phase.
			      Default value is "false".
		 * Setter for renderRegionOnly
		 * @param renderRegionOnly - new value
		 */
		 public void setRenderRegionOnly( ValueExpression  __renderRegionOnly ){
			this._renderRegionOnly = __renderRegionOnly;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * selfRendered
		 * if "true", self-render subtree at InvokeApplication ( or Decode, if immediate property set to true )  phase
		 */
		private ValueExpression _selfRendered;
		/**
		 * if "true", self-render subtree at InvokeApplication ( or Decode, if immediate property set to true )  phase
		 * Setter for selfRendered
		 * @param selfRendered - new value
		 */
		 public void setSelfRendered( ValueExpression  __selfRendered ){
			this._selfRendered = __selfRendered;
	     }
	  
	 	 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxListener = null;
	 		 		 		 		 		 		    this._immediate = null;
	 		 		    this._renderRegionOnly = null;
	 		 		 		    this._selfRendered = null;
	 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlAjaxRegion comp = (HtmlAjaxRegion) component;
 		 			if(null != this._ajaxListener){
				((HtmlAjaxRegion)component).setAjaxListener(this._ajaxListener);
			}		
		       		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._renderRegionOnly != null) {
				if (this._renderRegionOnly.isLiteralText()) {
					try {
												
						Boolean __renderRegionOnly = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._renderRegionOnly.getExpressionString(), 
											Boolean.class);
					
												comp.setRenderRegionOnly(__renderRegionOnly.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("renderRegionOnly", this._renderRegionOnly);
				}
			}
					    		 			 
						if (this._selfRendered != null) {
				if (this._selfRendered.isLiteralText()) {
					try {
												
						Boolean __selfRendered = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selfRendered.getExpressionString(), 
											Boolean.class);
					
												comp.setSelfRendered(__selfRendered.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selfRendered", this._selfRendered);
				}
			}
					       }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.ajax4jsf.AjaxRegion";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.ajax4jsf.components.AjaxRegionRenderer";
			}

}
