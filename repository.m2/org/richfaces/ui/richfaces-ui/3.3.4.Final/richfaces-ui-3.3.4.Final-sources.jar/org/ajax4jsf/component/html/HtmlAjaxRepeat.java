package org.ajax4jsf.component.html;

import javax.faces.context.FacesContext;
import org.ajax4jsf.component.UIRepeat;

public class HtmlAjaxRepeat extends UIRepeat{

final static public  String COMPONENT_FAMILY = "javax.faces.Data";

final static public  String COMPONENT_TYPE = "org.ajax4jsf.Repeat";


public HtmlAjaxRepeat(){
setRendererType("org.ajax4jsf.components.RepeatRenderer");
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[1];
state[0] = super.saveState(context);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);

}

}
