/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlComponentControl;

public class ComponentControlTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * attachTiming
		 * Defines the page loading phase when componentControl is attached to another component. Default value is "onavailable"
		 */
		private ValueExpression _attachTiming;
		/**
		 * Defines the page loading phase when componentControl is attached to another component. Default value is "onavailable"
		 * Setter for attachTiming
		 * @param attachTiming - new value
		 */
		 public void setAttachTiming( ValueExpression  __attachTiming ){
			this._attachTiming = __attachTiming;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * attachTo
		 * Client identifier of the component or id of the existing DOM element that is a source
				for given event. If attachTo is defined, the event is attached on the client according
				to the attachTiming attribute.
				If attachTo is not defined, the event is attached on the server to the closest in the
				component tree parent component.
		 */
		private ValueExpression _attachTo;
		/**
		 * Client identifier of the component or id of the existing DOM element that is a source
				for given event. If attachTo is defined, the event is attached on the client according
				to the attachTiming attribute.
				If attachTo is not defined, the event is attached on the server to the closest in the
				component tree parent component.
		 * Setter for attachTo
		 * @param attachTo - new value
		 */
		 public void setAttachTo( ValueExpression  __attachTo ){
			this._attachTo = __attachTo;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * disableDefault
		 * Disable default action for target event. If the attribute is not set, it's made "true" by default if the event oncontextmenu is used and false in all other cases. if the attribute set, its value is used.
		 */
		private ValueExpression _disableDefault;
		/**
		 * Disable default action for target event. If the attribute is not set, it's made "true" by default if the event oncontextmenu is used and false in all other cases. if the attribute set, its value is used.
		 * Setter for disableDefault
		 * @param disableDefault - new value
		 */
		 public void setDisableDefault( ValueExpression  __disableDefault ){
			this._disableDefault = __disableDefault;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * event
		 * The Event that is used to trigger the operation on the target component
		 */
		private ValueExpression _event;
		/**
		 * The Event that is used to trigger the operation on the target component
		 * Setter for event
		 * @param event - new value
		 */
		 public void setEvent( ValueExpression  __event ){
			this._event = __event;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * for
		 * Client identifier of the target component.
		 */
		private ValueExpression _for;
		/**
		 * Client identifier of the target component.
		 * Setter for for
		 * @param for - new value
		 */
		 public void setFor( ValueExpression  __for ){
			this._for = __for;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * name
		 * The optional name of the function that might be used to trigger the operation on the target component
		 */
		private ValueExpression _name;
		/**
		 * The optional name of the function that might be used to trigger the operation on the target component
		 * Setter for name
		 * @param name - new value
		 */
		 public void setName( ValueExpression  __name ){
			this._name = __name;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * operation
		 * The function of JavaScript API that will be invoked. The API method
				is attached to the 'component' property of the root DOM element that represents
				the target component. The function has two parameters - event and params. See: 'params'
				attribute for details.
		 */
		private ValueExpression _operation;
		/**
		 * The function of JavaScript API that will be invoked. The API method
				is attached to the 'component' property of the root DOM element that represents
				the target component. The function has two parameters - event and params. See: 'params'
				attribute for details.
		 * Setter for operation
		 * @param operation - new value
		 */
		 public void setOperation( ValueExpression  __operation ){
			this._operation = __operation;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * params
		 * The set of parameters passed to the function of Javascript API that will be invoked. 
				The JSON syntax is used to define the parameters, but without open and closed curve 
				bracket.
				As an alternative, the set of f:param can be used to define the parameters passed to the 
				API function. If both way are used to define the parameters, both set are concatenated.
				if names are equals, the f:param has a priority.
		 */
		private ValueExpression _params;
		/**
		 * The set of parameters passed to the function of Javascript API that will be invoked. 
				The JSON syntax is used to define the parameters, but without open and closed curve 
				bracket.
				As an alternative, the set of f:param can be used to define the parameters passed to the 
				API function. If both way are used to define the parameters, both set are concatenated.
				if names are equals, the f:param has a priority.
		 * Setter for params
		 * @param params - new value
		 */
		 public void setParams( ValueExpression  __params ){
			this._params = __params;
	     }
	  
	 	 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._attachTiming = null;
	 		 		    this._attachTo = null;
	 		 		 		    this._disableDefault = null;
	 		 		 		    this._event = null;
	 		 		 		 		    this._for = null;
	 		 		 		    this._name = null;
	 		 		 		    this._operation = null;
	 		 		    this._params = null;
	 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlComponentControl comp = (HtmlComponentControl) component;
 		 			 
						if (this._attachTiming != null) {
				if (this._attachTiming.isLiteralText()) {
					try {
												
						java.lang.String __attachTiming = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._attachTiming.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAttachTiming(__attachTiming);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("attachTiming", this._attachTiming);
				}
			}
					   		 			 
						if (this._attachTo != null) {
				if (this._attachTo.isLiteralText()) {
					try {
												
						java.lang.String __attachTo = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._attachTo.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAttachTo(__attachTo);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("attachTo", this._attachTo);
				}
			}
					    		 			 
						if (this._disableDefault != null) {
				if (this._disableDefault.isLiteralText()) {
					try {
												
						Boolean __disableDefault = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disableDefault.getExpressionString(), 
											Boolean.class);
					
												comp.setDisableDefault(__disableDefault.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disableDefault", this._disableDefault);
				}
			}
					    		 			 
						if (this._event != null) {
				if (this._event.isLiteralText()) {
					try {
												
						java.lang.String __event = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._event.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEvent(__event);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("event", this._event);
				}
			}
					     		 			 
						if (this._for != null) {
				if (this._for.isLiteralText()) {
					try {
												
						java.lang.String __for = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._for.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFor(__for);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("for", this._for);
				}
			}
					    		 			 
						if (this._name != null) {
				if (this._name.isLiteralText()) {
					try {
												
						java.lang.String __name = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._name.getExpressionString(), 
											java.lang.String.class);
					
												comp.setName(__name);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("name", this._name);
				}
			}
					    		 			 
						if (this._operation != null) {
				if (this._operation.isLiteralText()) {
					try {
												
						java.lang.String __operation = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._operation.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOperation(__operation);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("operation", this._operation);
				}
			}
					   		 			 
						if (this._params != null) {
				if (this._params.isLiteralText()) {
					try {
												
						java.lang.String __params = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._params.getExpressionString(), 
											java.lang.String.class);
					
												comp.setParams(__params);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("params", this._params);
				}
			}
					       }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ComponentControl";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.ComponentControlRenderer";
			}

}
