/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlDragSupport;

public class DragSupportTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  	  	  
		/*
		 * action
		 * MethodBinding pointing at the application action to be invoked,
            if this UIComponent is activated by you, during the Apply
            Request Values or Invoke Application phase of the request
            processing lifecycle, depending on the value of the immediate
            property
		 */
		private MethodExpression _action;
		/**
		 * MethodBinding pointing at the application action to be invoked,
            if this UIComponent is activated by you, during the Apply
            Request Values or Invoke Application phase of the request
            processing lifecycle, depending on the value of the immediate
            property
		 * Setter for action
		 * @param action - new value
		 */
		 public void setAction( MethodExpression  __action ){
			this._action = __action;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * actionListener
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 */
		private MethodExpression _actionListener;
		/**
		 * MethodBinding pointing at method accepting  an ActionEvent with return type void
		 * Setter for actionListener
		 * @param actionListener - new value
		 */
		 public void setActionListener( MethodExpression  __actionListener ){
			this._actionListener = __actionListener;
	     }
	  
	 	 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * disableDefault
		 * Disable default action for target event (append "return false;" to JavaScript)
		 */
		private ValueExpression _disableDefault;
		/**
		 * Disable default action for target event (append "return false;" to JavaScript)
		 * Setter for disableDefault
		 * @param disableDefault - new value
		 */
		 public void setDisableDefault( ValueExpression  __disableDefault ){
			this._disableDefault = __disableDefault;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * dragIndicator
		 * Id of a component that is used as drag pointer during the drag operation
		 */
		private ValueExpression _dragIndicator;
		/**
		 * Id of a component that is used as drag pointer during the drag operation
		 * Setter for dragIndicator
		 * @param dragIndicator - new value
		 */
		 public void setDragIndicator( ValueExpression  __dragIndicator ){
			this._dragIndicator = __dragIndicator;
	     }
	  
	 	 		 	  	  	  
		/*
		 * dragListener
		 * MethodBinding representing an action listener method that will be notified after drag operation
		 */
		private MethodExpression _dragListener;
		/**
		 * MethodBinding representing an action listener method that will be notified after drag operation
		 * Setter for dragListener
		 * @param dragListener - new value
		 */
		 public void setDragListener( MethodExpression  __dragListener ){
			this._dragListener = __dragListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * dragType
		 * A drag zone type that is used for zone definition, which elements can be accepted by a drop zone
		 */
		private ValueExpression _dragType;
		/**
		 * A drag zone type that is used for zone definition, which elements can be accepted by a drop zone
		 * Setter for dragType
		 * @param dragType - new value
		 */
		 public void setDragType( ValueExpression  __dragType ){
			this._dragType = __dragType;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * dragValue
		 * Data to be sent to a drop zone after a drop event
		 */
		private ValueExpression _dragValue;
		/**
		 * Data to be sent to a drop zone after a drop event
		 * Setter for dragValue
		 * @param dragValue - new value
		 */
		 public void setDragValue( ValueExpression  __dragValue ){
			this._dragValue = __dragValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * eventsQueue
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 */
		private ValueExpression _eventsQueue;
		/**
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 * Setter for eventsQueue
		 * @param eventsQueue - new value
		 */
		 public void setEventsQueue( ValueExpression  __eventsQueue ){
			this._eventsQueue = __eventsQueue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * focus
		 * ID of an element to set focus after request is completed on client side
		 */
		private ValueExpression _focus;
		/**
		 * ID of an element to set focus after request is completed on client side
		 * Setter for focus
		 * @param focus - new value
		 */
		 public void setFocus( ValueExpression  __focus ){
			this._focus = __focus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * grabCursors
		 * List of comma separated cursors that indicates then you can grab and drag an object
		 */
		private ValueExpression _grabCursors;
		/**
		 * List of comma separated cursors that indicates then you can grab and drag an object
		 * Setter for grabCursors
		 * @param grabCursors - new value
		 */
		 public void setGrabCursors( ValueExpression  __grabCursors ){
			this._grabCursors = __grabCursors;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * grabbingCursors
		 * list of comma separated cursors that indicates then the you has grabbed something
		 */
		private ValueExpression _grabbingCursors;
		/**
		 * list of comma separated cursors that indicates then the you has grabbed something
		 * Setter for grabbingCursors
		 * @param grabbingCursors - new value
		 */
		 public void setGrabbingCursors( ValueExpression  __grabbingCursors ){
			this._grabbingCursors = __grabbingCursors;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * immediate
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 */
		private ValueExpression _immediate;
		/**
		 * True means, that the default ActionListener should be executed
            immediately (i.e. during Apply Request Values phase of the
            request processing lifecycle), rather than waiting until the
            Invoke Application phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * limitToList
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 */
		private ValueExpression _limitToList;
		/**
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 * Setter for limitToList
		 * @param limitToList - new value
		 */
		 public void setLimitToList( ValueExpression  __limitToList ){
			this._limitToList = __limitToList;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onbeforedomupdate
		 * The client-side script method to be called before DOM is updated
		 */
		private ValueExpression _onbeforedomupdate;
		/**
		 * The client-side script method to be called before DOM is updated
		 * Setter for onbeforedomupdate
		 * @param onbeforedomupdate - new value
		 */
		 public void setOnbeforedomupdate( ValueExpression  __onbeforedomupdate ){
			this._onbeforedomupdate = __onbeforedomupdate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the request is completed
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the request is completed
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondragend
		 * The client-side script method to be called when the dragging operation is finished
		 */
		private ValueExpression _ondragend;
		/**
		 * The client-side script method to be called when the dragging operation is finished
		 * Setter for ondragend
		 * @param ondragend - new value
		 */
		 public void setOndragend( ValueExpression  __ondragend ){
			this._ondragend = __ondragend;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondragstart
		 * The client-side script method to be called when the dragging operation is started
		 */
		private ValueExpression _ondragstart;
		/**
		 * The client-side script method to be called when the dragging operation is started
		 * Setter for ondragstart
		 * @param ondragstart - new value
		 */
		 public void setOndragstart( ValueExpression  __ondragstart ){
			this._ondragstart = __ondragstart;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondropout
		 * The client-side script method to be called when the draggable object is moved away from the drop zone
		 */
		private ValueExpression _ondropout;
		/**
		 * The client-side script method to be called when the draggable object is moved away from the drop zone
		 * Setter for ondropout
		 * @param ondropout - new value
		 */
		 public void setOndropout( ValueExpression  __ondropout ){
			this._ondropout = __ondropout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * ondropover
		 * The client-side script method to be called when the draggable object is over the drop zone
		 */
		private ValueExpression _ondropover;
		/**
		 * The client-side script method to be called when the draggable object is over the drop zone
		 * Setter for ondropover
		 * @param ondropover - new value
		 */
		 public void setOndropover( ValueExpression  __ondropover ){
			this._ondropover = __ondropover;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * requestDelay
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 */
		private ValueExpression _requestDelay;
		/**
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 * Setter for requestDelay
		 * @param requestDelay - new value
		 */
		 public void setRequestDelay( ValueExpression  __requestDelay ){
			this._requestDelay = __requestDelay;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * similarityGroupingId
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 */
		private ValueExpression _similarityGroupingId;
		/**
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 * Setter for similarityGroupingId
		 * @param similarityGroupingId - new value
		 */
		 public void setSimilarityGroupingId( ValueExpression  __similarityGroupingId ){
			this._similarityGroupingId = __similarityGroupingId;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * timeout
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 */
		private ValueExpression _timeout;
		/**
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * value
		 * The current value for this component
		 */
		private ValueExpression _value;
		/**
		 * The current value for this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._action = null;
	 		 		 		    this._actionListener = null;
	 		 		 		 		 		 		 		 		    this._disableDefault = null;
	 		 		    this._dragIndicator = null;
	 		 		    this._dragListener = null;
	 		 		 		    this._dragType = null;
	 		 		    this._dragValue = null;
	 		 		    this._eventsQueue = null;
	 		 		 		    this._focus = null;
	 		 		    this._grabCursors = null;
	 		 		    this._grabbingCursors = null;
	 		 		 		    this._ignoreDupResponses = null;
	 		 		    this._immediate = null;
	 		 		    this._limitToList = null;
	 		 		    this._onbeforedomupdate = null;
	 		 		    this._oncomplete = null;
	 		 		    this._ondragend = null;
	 		 		    this._ondragstart = null;
	 		 		    this._ondropout = null;
	 		 		    this._ondropover = null;
	 		 		 		    this._reRender = null;
	 		 		 		    this._requestDelay = null;
	 		 		    this._similarityGroupingId = null;
	 		 		    this._status = null;
	 		 		    this._timeout = null;
	 		 		    this._value = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlDragSupport comp = (HtmlDragSupport) component;
 		 			setActionProperty(comp, this._action);
		    		 			setActionListenerProperty(comp, this._actionListener);
		         		 			 
						if (this._disableDefault != null) {
				if (this._disableDefault.isLiteralText()) {
					try {
												
						java.lang.String __disableDefault = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disableDefault.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisableDefault(__disableDefault);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disableDefault", this._disableDefault);
				}
			}
					   		 			 
						if (this._dragIndicator != null) {
				if (this._dragIndicator.isLiteralText()) {
					try {
												
						java.lang.String __dragIndicator = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dragIndicator.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDragIndicator(__dragIndicator);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dragIndicator", this._dragIndicator);
				}
			}
					   		 			if(null != this._dragListener){
             if (!this._dragListener.isLiteralText())
             {
                MethodBinding mb = new MethodBindingMethodExpressionAdaptor(this._dragListener);
                ((HtmlDragSupport)component).setDragListener(mb);
             }
             else
             {
                getFacesContext().getExternalContext().log("Component " + component.getClientId(getFacesContext()) + " has invalid dragListener value: " + this._dragListener);
             }
			}
		    		 			 
						if (this._dragType != null) {
				if (this._dragType.isLiteralText()) {
					try {
												
						java.lang.String __dragType = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dragType.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDragType(__dragType);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dragType", this._dragType);
				}
			}
					   		 			 
						if (this._dragValue != null) {
				if (this._dragValue.isLiteralText()) {
					try {
												
						java.lang.Object __dragValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._dragValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setDragValue(__dragValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("dragValue", this._dragValue);
				}
			}
					   		 			 
						if (this._eventsQueue != null) {
				if (this._eventsQueue.isLiteralText()) {
					try {
												
						java.lang.String __eventsQueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._eventsQueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEventsQueue(__eventsQueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("eventsQueue", this._eventsQueue);
				}
			}
					    		 			 
						if (this._focus != null) {
				if (this._focus.isLiteralText()) {
					try {
												
						java.lang.String __focus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._focus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFocus(__focus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("focus", this._focus);
				}
			}
					   		 			 
						if (this._grabCursors != null) {
				if (this._grabCursors.isLiteralText()) {
					try {
												
						java.lang.String __grabCursors = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._grabCursors.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGrabCursors(__grabCursors);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("grabCursors", this._grabCursors);
				}
			}
					   		 			 
						if (this._grabbingCursors != null) {
				if (this._grabbingCursors.isLiteralText()) {
					try {
												
						java.lang.String __grabbingCursors = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._grabbingCursors.getExpressionString(), 
											java.lang.String.class);
					
												comp.setGrabbingCursors(__grabbingCursors);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("grabbingCursors", this._grabbingCursors);
				}
			}
					    		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					   		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._limitToList != null) {
				if (this._limitToList.isLiteralText()) {
					try {
												
						Boolean __limitToList = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._limitToList.getExpressionString(), 
											Boolean.class);
					
												comp.setLimitToList(__limitToList.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("limitToList", this._limitToList);
				}
			}
					   		 			 
						if (this._onbeforedomupdate != null) {
				if (this._onbeforedomupdate.isLiteralText()) {
					try {
												
						java.lang.String __onbeforedomupdate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbeforedomupdate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbeforedomupdate(__onbeforedomupdate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbeforedomupdate", this._onbeforedomupdate);
				}
			}
					   		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					   		 			 
						if (this._ondragend != null) {
				if (this._ondragend.isLiteralText()) {
					try {
												
						java.lang.String __ondragend = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondragend.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndragend(__ondragend);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondragend", this._ondragend);
				}
			}
					   		 			 
						if (this._ondragstart != null) {
				if (this._ondragstart.isLiteralText()) {
					try {
												
						java.lang.String __ondragstart = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondragstart.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndragstart(__ondragstart);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondragstart", this._ondragstart);
				}
			}
					   		 			 
						if (this._ondropout != null) {
				if (this._ondropout.isLiteralText()) {
					try {
												
						java.lang.String __ondropout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondropout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndropout(__ondropout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondropout", this._ondropout);
				}
			}
					   		 			 
						if (this._ondropover != null) {
				if (this._ondropover.isLiteralText()) {
					try {
												
						java.lang.String __ondropover = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondropover.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndropover(__ondropover);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondropover", this._ondropover);
				}
			}
					    		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					    		 			 
						if (this._requestDelay != null) {
				if (this._requestDelay.isLiteralText()) {
					try {
												
						Integer __requestDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requestDelay.getExpressionString(), 
											Integer.class);
					
												comp.setRequestDelay(__requestDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requestDelay", this._requestDelay);
				}
			}
					   		 			 
						if (this._similarityGroupingId != null) {
				if (this._similarityGroupingId.isLiteralText()) {
					try {
												
						java.lang.String __similarityGroupingId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._similarityGroupingId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSimilarityGroupingId(__similarityGroupingId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("similarityGroupingId", this._similarityGroupingId);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					   		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					   		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.DragSupport";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.DragSupportRenderer";
			}

}
