/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import javax.faces.component.UIComponent;
import org.richfaces.event.DropSource;

import java.io.IOException;

import javax.faces.*;
import javax.faces.el.*;

import javax.el.*;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
import com.sun.facelets.tag.jsf.*;

public class DropListenerHandler extends TagHandler {

	private Class listenerType;

    private final TagAttribute type;

    private final TagAttribute binding;

	public DropListenerHandler(TagConfig config) {
	    super(config);
		this.binding = this.getAttribute("binding");
        this.type = this.getAttribute("type");
        if (type != null) {
            if (!type.isLiteral()) {
                throw new TagAttributeException(this.tag, this.type, "Must be literal");
            }
            try {
                this.listenerType = Class.forName(type.getValue());
            } catch (Exception e) {
                throw new TagAttributeException(this.tag, this.type, e);
            }
        }
  	}

  	 public void apply(FaceletContext ctx, UIComponent parent)
            throws IOException, FacesException, FaceletException, ELException {
        if (parent instanceof org.richfaces.event.DropSource) {
            // only process if parent was just created
            if (parent.getParent() == null) {
                org.richfaces.event.DropSource src = (org.richfaces.event.DropSource) parent;
                org.richfaces.event.DropListener listener = null;
                ValueExpression ve = null;
                if (this.binding != null) {
                    ve = this.binding.getValueExpression(ctx,
                            org.richfaces.event.DropListener.class);
                    listener = (org.richfaces.event.DropListener) ve.getValue(ctx);
                }
                if (listener == null) {
                    try {
                        listener = (org.richfaces.event.DropListener) listenerType.newInstance();
                    } catch (Exception e) {
                        throw new TagAttributeException(this.tag, this.type, e.getCause());
                    }
                    if (ve != null) {
                        ve.setValue(ctx, ve);
                    }
                }
								 								 				
                src.addDropListener(listener);
            }
        } else {
            throw new TagException(this.tag,
                    "Parent is not of type org.richfaces.event.DropSource, type is: " + parent);
        }
    }
  	
}
