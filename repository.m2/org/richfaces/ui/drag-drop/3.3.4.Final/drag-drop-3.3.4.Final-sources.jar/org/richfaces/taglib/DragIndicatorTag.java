/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlDragIndicator;

public class DragIndicatorTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * acceptClass
		 * Assigns one or more space-separated CSS class names to the indicator which are applied when a drop is accepted
		 */
		private ValueExpression _acceptClass;
		/**
		 * Assigns one or more space-separated CSS class names to the indicator which are applied when a drop is accepted
		 * Setter for acceptClass
		 * @param acceptClass - new value
		 */
		 public void setAcceptClass( ValueExpression  __acceptClass ){
			this._acceptClass = __acceptClass;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * rejectClass
		 * Assigns one or more space-separated CSS class names to the indicator which are applied when a drop is rejected
		 */
		private ValueExpression _rejectClass;
		/**
		 * Assigns one or more space-separated CSS class names to the indicator which are applied when a drop is rejected
		 * Setter for rejectClass
		 * @param rejectClass - new value
		 */
		 public void setRejectClass( ValueExpression  __rejectClass ){
			this._rejectClass = __rejectClass;
	     }
	  
	 	 		 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._acceptClass = null;
	 		 		 		 		 		    this._rejectClass = null;
	 		 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlDragIndicator comp = (HtmlDragIndicator) component;
 		 			 
						if (this._acceptClass != null) {
				if (this._acceptClass.isLiteralText()) {
					try {
												
						java.lang.String __acceptClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._acceptClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAcceptClass(__acceptClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("acceptClass", this._acceptClass);
				}
			}
					      		 			 
						if (this._rejectClass != null) {
				if (this._rejectClass.isLiteralText()) {
					try {
												
						java.lang.String __rejectClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rejectClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRejectClass(__rejectClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rejectClass", this._rejectClass);
				}
			}
					        }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.DragIndicator";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.DragIndicatorRenderer";
			}

}
