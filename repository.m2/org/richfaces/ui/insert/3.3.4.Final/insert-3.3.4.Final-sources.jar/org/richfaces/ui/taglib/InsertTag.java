/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.ui.taglib;

import org.richfaces.ui.taglib.InsertTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.ui.component.html.HtmlInsert;

public class InsertTag extends org.richfaces.ui.taglib.InsertTagBase {

		// Fields
		 		 		 	  			  		  	  
		/*
		 * encoding
		 * Attribute defines encoding for inserted content
		 */
		private ValueExpression _encoding;
		/**
		 * Attribute defines encoding for inserted content
		 * Setter for encoding
		 * @param encoding - new value
		 */
		 public void setEncoding( ValueExpression  __encoding ){
			this._encoding = __encoding;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * errorContent
		 * Attribute defines the alternative content that will be shown in case
component cannot read the resource defined with 'src' attribute. If "errorContent" attribute is not defined,
the component shown the actual error message in the place where the content is expected
		 */
		private ValueExpression _errorContent;
		/**
		 * Attribute defines the alternative content that will be shown in case
component cannot read the resource defined with 'src' attribute. If "errorContent" attribute is not defined,
the component shown the actual error message in the place where the content is expected
		 * Setter for errorContent
		 * @param errorContent - new value
		 */
		 public void setErrorContent( ValueExpression  __errorContent ){
			this._errorContent = __errorContent;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * highlight
		 * Defines a type of code
		 */
		private ValueExpression _highlight;
		/**
		 * Defines a type of code
		 * Setter for highlight
		 * @param highlight - new value
		 */
		 public void setHighlight( ValueExpression  __highlight ){
			this._highlight = __highlight;
	     }
	  
	 	 		 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		 		    this._encoding = null;
	 		 		    this._errorContent = null;
	 		 		 		    this._highlight = null;
	 		 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlInsert comp = (HtmlInsert) component;
   		 			 
						if (this._encoding != null) {
				if (this._encoding.isLiteralText()) {
					try {
												
						java.lang.String __encoding = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._encoding.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEncoding(__encoding);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("encoding", this._encoding);
				}
			}
					   		 			 
						if (this._errorContent != null) {
				if (this._errorContent.isLiteralText()) {
					try {
												
						java.lang.String __errorContent = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._errorContent.getExpressionString(), 
											java.lang.String.class);
					
												comp.setErrorContent(__errorContent);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("errorContent", this._errorContent);
				}
			}
					    		 			 
						if (this._highlight != null) {
				if (this._highlight.isLiteralText()) {
					try {
												
						java.lang.String __highlight = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._highlight.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHighlight(__highlight);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("highlight", this._highlight);
				}
			}
					        }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.ui.Insert";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.ui.InsertRenderer";
			}

}
