/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.el.MethodExpression ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlSuggestionBox;

public class SuggestionBoxTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * ajaxSingle
		 * Boolean attribute which provides possibility to limit JSF tree processing(decoding, conversion/validation, value applying) to the component which send the request only.
                Default value is "true"
		 */
		private ValueExpression _ajaxSingle;
		/**
		 * Boolean attribute which provides possibility to limit JSF tree processing(decoding, conversion/validation, value applying) to the component which send the request only.
                Default value is "true"
		 * Setter for ajaxSingle
		 * @param ajaxSingle - new value
		 */
		 public void setAjaxSingle( ValueExpression  __ajaxSingle ){
			this._ajaxSingle = __ajaxSingle;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * bgcolor
		 * Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
		 */
		private ValueExpression _bgcolor;
		/**
		 * Deprecated. This attribute sets the background color for the document body or table cells.
            
            This attribute sets the background color of the canvas for the document body (the BODY element) or for tables (the TABLE, TR, TH, and TD elements). Additional attributes for specifying text color can be used with the BODY element.
            
            This attribute has been deprecated in favor of style sheets for specifying background color information
		 * Setter for bgcolor
		 * @param bgcolor - new value
		 */
		 public void setBgcolor( ValueExpression  __bgcolor ){
			this._bgcolor = __bgcolor;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * border
		 * This attributes specifies the width (in pixels only) of the frame around a table
		 */
		private ValueExpression _border;
		/**
		 * This attributes specifies the width (in pixels only) of the frame around a table
		 * Setter for border
		 * @param border - new value
		 */
		 public void setBorder( ValueExpression  __border ){
			this._border = __border;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * bypassUpdates
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 */
		private ValueExpression _bypassUpdates;
		/**
		 * If "true", after process validations phase it skips updates of model beans on a force render response. It can be used for validating components input
		 * Setter for bypassUpdates
		 * @param bypassUpdates - new value
		 */
		 public void setBypassUpdates( ValueExpression  __bypassUpdates ){
			this._bypassUpdates = __bypassUpdates;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cellpadding
		 * This attribute specifies the amount of space between the
                border of the cell and its contents. If the value of
                this attribute is a pixel length, all four margins
                should be this distance from the contents. If the value
                of the attribute is percentage length, the top and
                bottom margins should be equally separated from the
                content based on percentage of the available vertical
                space, and the left and right margins should be equally
                separated from the content based on percentage of the
                available horizontal space
		 */
		private ValueExpression _cellpadding;
		/**
		 * This attribute specifies the amount of space between the
                border of the cell and its contents. If the value of
                this attribute is a pixel length, all four margins
                should be this distance from the contents. If the value
                of the attribute is percentage length, the top and
                bottom margins should be equally separated from the
                content based on percentage of the available vertical
                space, and the left and right margins should be equally
                separated from the content based on percentage of the
                available horizontal space
		 * Setter for cellpadding
		 * @param cellpadding - new value
		 */
		 public void setCellpadding( ValueExpression  __cellpadding ){
			this._cellpadding = __cellpadding;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cellspacing
		 * This attribute specifies how much space the user agent
                should leave between the table and the column on all
                four sides. The attribute also specifies the amount of
                space to leave between cells
		 */
		private ValueExpression _cellspacing;
		/**
		 * This attribute specifies how much space the user agent
                should leave between the table and the column on all
                four sides. The attribute also specifies the amount of
                space to leave between cells
		 * Setter for cellspacing
		 * @param cellspacing - new value
		 */
		 public void setCellspacing( ValueExpression  __cellspacing ){
			this._cellspacing = __cellspacing;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * entryClass
		 * Assigns one or more space-separated CSS class names to the suggestion entry elements (table rows)
		 */
		private ValueExpression _entryClass;
		/**
		 * Assigns one or more space-separated CSS class names to the suggestion entry elements (table rows)
		 * Setter for entryClass
		 * @param entryClass - new value
		 */
		 public void setEntryClass( ValueExpression  __entryClass ){
			this._entryClass = __entryClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * eventsQueue
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 */
		private ValueExpression _eventsQueue;
		/**
		 * Name of requests queue to avoid send next request before complete other from same event. Can be used to reduce number of requests of frequently events (key press, mouse move etc.)
		 * Setter for eventsQueue
		 * @param eventsQueue - new value
		 */
		 public void setEventsQueue( ValueExpression  __eventsQueue ){
			this._eventsQueue = __eventsQueue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fetchValue
		 * A value to set in the target input element on a choice
                suggestion that isn't shown in the suggestion table. It
                can be used for descriptive output comments or
                suggestions. If not set, all text in the suggestion row
                is set as a value
		 */
		private ValueExpression _fetchValue;
		/**
		 * A value to set in the target input element on a choice
                suggestion that isn't shown in the suggestion table. It
                can be used for descriptive output comments or
                suggestions. If not set, all text in the suggestion row
                is set as a value
		 * Setter for fetchValue
		 * @param fetchValue - new value
		 */
		 public void setFetchValue( ValueExpression  __fetchValue ){
			this._fetchValue = __fetchValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * first
		 * A zero-relative row number of the first row to display
		 */
		private ValueExpression _first;
		/**
		 * A zero-relative row number of the first row to display
		 * Setter for first
		 * @param first - new value
		 */
		 public void setFirst( ValueExpression  __first ){
			this._first = __first;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * for
		 * id (or full path of id's) of target components, for which this element must provide support.
		If a target component inside of the same &amp;lt;code&amp;gt;NamingContainer&amp;lt;/code&amp;gt; (UIForm, UIData in base implementations), can be simple value of the "id" attribute.
		For other cases must include id's of &amp;lt;code&amp;gt;NamingContainer&amp;lt;/code&amp;gt; components, separated by ':'. For search from the root of components, must be started with ':'.
		 */
		private ValueExpression _for;
		/**
		 * id (or full path of id's) of target components, for which this element must provide support.
		If a target component inside of the same &amp;lt;code&amp;gt;NamingContainer&amp;lt;/code&amp;gt; (UIForm, UIData in base implementations), can be simple value of the "id" attribute.
		For other cases must include id's of &amp;lt;code&amp;gt;NamingContainer&amp;lt;/code&amp;gt; components, separated by ':'. For search from the root of components, must be started with ':'.
		 * Setter for for
		 * @param for - new value
		 */
		 public void setFor( ValueExpression  __for ){
			this._for = __for;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * frame
		 * This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
		 */
		private ValueExpression _frame;
		/**
		 * This attribute specifies which sides of the frame surrounding a table will be visible. Possible values:  "void", "above", "below", "hsides", "lhs", "rhs", "vsides", "box" and "border".
        The default value is "void".
		 * Setter for frame
		 * @param frame - new value
		 */
		 public void setFrame( ValueExpression  __frame ){
			this._frame = __frame;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * frequency
		 * Delay (in seconds) before activating the suggestion
                pop-up. Default value is 400ms
		 */
		private ValueExpression _frequency;
		/**
		 * Delay (in seconds) before activating the suggestion
                pop-up. Default value is 400ms
		 * Setter for frequency
		 * @param frequency - new value
		 */
		 public void setFrequency( ValueExpression  __frequency ){
			this._frequency = __frequency;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * height
		 * Height of the pop-up window in pixels. Default value is "200".
		 */
		private ValueExpression _height;
		/**
		 * Height of the pop-up window in pixels. Default value is "200".
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * ignoreDupResponses
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 */
		private ValueExpression _ignoreDupResponses;
		/**
		 * Attribute allows to ignore an Ajax Response produced by a request if the newest 'similar' request is
in a queue already. ignoreDupResponses="true" does not cancel the request while it is processed on the server,
but just allows to avoid unnecessary updates on the client side if the response isn't actual now
		 * Setter for ignoreDupResponses
		 * @param ignoreDupResponses - new value
		 */
		 public void setIgnoreDupResponses( ValueExpression  __ignoreDupResponses ){
			this._ignoreDupResponses = __ignoreDupResponses;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted and validated immediately (that is, during Apply Request Values phase), rather than waiting until a Process Validations phase.
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted and validated immediately (that is, during Apply Request Values phase), rather than waiting until a Process Validations phase.
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * limitToList
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 */
		private ValueExpression _limitToList;
		/**
		 * If "true", then of all AJAX-rendered on the page components only those will be updated, 
		which ID's are passed to the "reRender" attribute of the describable component. 
		"false"-the default value-means that all components with ajaxRendered="true" will be updated.
		 * Setter for limitToList
		 * @param limitToList - new value
		 */
		 public void setLimitToList( ValueExpression  __limitToList ){
			this._limitToList = __limitToList;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * minChars
		 * Minimal number of chars in input to activate suggestion
                pop-up
		 */
		private ValueExpression _minChars;
		/**
		 * Minimal number of chars in input to activate suggestion
                pop-up
		 * Setter for minChars
		 * @param minChars - new value
		 */
		 public void setMinChars( ValueExpression  __minChars ){
			this._minChars = __minChars;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * nothingLabel
		 * "nothingLabel" is inserted to popup list if the autocomplete returns empty list. 
				It isn't selectable and list is closed as always after click on it and nothing is put to input.
		 */
		private ValueExpression _nothingLabel;
		/**
		 * "nothingLabel" is inserted to popup list if the autocomplete returns empty list. 
				It isn't selectable and list is closed as always after click on it and nothing is put to input.
		 * Setter for nothingLabel
		 * @param nothingLabel - new value
		 */
		 public void setNothingLabel( ValueExpression  __nothingLabel ){
			this._nothingLabel = __nothingLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onbeforedomupdate
		 * The client-side script method to be called before DOM is updated
		 */
		private ValueExpression _onbeforedomupdate;
		/**
		 * The client-side script method to be called before DOM is updated
		 * Setter for onbeforedomupdate
		 * @param onbeforedomupdate - new value
		 */
		 public void setOnbeforedomupdate( ValueExpression  __onbeforedomupdate ){
			this._onbeforedomupdate = __onbeforedomupdate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oncomplete
		 * The client-side script method to be called after the request is completed
		 */
		private ValueExpression _oncomplete;
		/**
		 * The client-side script method to be called after the request is completed
		 * Setter for oncomplete
		 * @param oncomplete - new value
		 */
		 public void setOncomplete( ValueExpression  __oncomplete ){
			this._oncomplete = __oncomplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onobjectchange
		 * The client-side script method to be called before the list of suggested objects is changed
		 */
		private ValueExpression _onobjectchange;
		/**
		 * The client-side script method to be called before the list of suggested objects is changed
		 * Setter for onobjectchange
		 * @param onobjectchange - new value
		 */
		 public void setOnobjectchange( ValueExpression  __onobjectchange ){
			this._onobjectchange = __onobjectchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onselect
		 * The client-side script method to be called after the
                value of the target element is updated
		 */
		private ValueExpression _onselect;
		/**
		 * The client-side script method to be called after the
                value of the target element is updated
		 * Setter for onselect
		 * @param onselect - new value
		 */
		 public void setOnselect( ValueExpression  __onselect ){
			this._onselect = __onselect;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onsubmit
		 * The client-side script method to be called before an ajax event is submitted
		 */
		private ValueExpression _onsubmit;
		/**
		 * The client-side script method to be called before an ajax event is submitted
		 * Setter for onsubmit
		 * @param onsubmit - new value
		 */
		 public void setOnsubmit( ValueExpression  __onsubmit ){
			this._onsubmit = __onsubmit;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * param
		 * Name the HTTP request parameter with the value of input
                element token. If not set, it be will sent as an input
                element name. In this case, input will perform
                validation and update the value. Default value is "inputvalue".
		 */
		private ValueExpression _param;
		/**
		 * Name the HTTP request parameter with the value of input
                element token. If not set, it be will sent as an input
                element name. In this case, input will perform
                validation and update the value. Default value is "inputvalue".
		 * Setter for param
		 * @param param - new value
		 */
		 public void setParam( ValueExpression  __param ){
			this._param = __param;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * popupClass
		 * Assigns one or more space-separated CSS class names to the content of the pop-up suggestion element
		 */
		private ValueExpression _popupClass;
		/**
		 * Assigns one or more space-separated CSS class names to the content of the pop-up suggestion element
		 * Setter for popupClass
		 * @param popupClass - new value
		 */
		 public void setPopupClass( ValueExpression  __popupClass ){
			this._popupClass = __popupClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * popupStyle
		 * CSS style rules to be applied to the content of the pop-up suggestion element
		 */
		private ValueExpression _popupStyle;
		/**
		 * CSS style rules to be applied to the content of the pop-up suggestion element
		 * Setter for popupStyle
		 * @param popupStyle - new value
		 */
		 public void setPopupStyle( ValueExpression  __popupStyle ){
			this._popupStyle = __popupStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * process
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _process;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, processed at the phases 2-5 in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for process
		 * @param process - new value
		 */
		 public void setProcess( ValueExpression  __process ){
			this._process = __process;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * reRender
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 */
		private ValueExpression _reRender;
		/**
		 * Id['s] (in format of call  UIComponent.findComponent()) of components, rendered in case of AjaxRequest  caused by this component. Can be single id, comma-separated list of Id's, or EL Expression  with array or Collection
		 * Setter for reRender
		 * @param reRender - new value
		 */
		 public void setReRender( ValueExpression  __reRender ){
			this._reRender = __reRender;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * requestDelay
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 */
		private ValueExpression _requestDelay;
		/**
		 * Attribute defines the time (in ms.) that the request will be wait in the queue before it is ready to send.
When the delay time is over, the request will be sent to the server or removed if the newest 'similar' request is in a queue already
		 * Setter for requestDelay
		 * @param requestDelay - new value
		 */
		 public void setRequestDelay( ValueExpression  __requestDelay ){
			this._requestDelay = __requestDelay;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * rowClasses
		 * Assigns one or more space-separated CSS class names to the rows. If the CSS class names are comma-separated, 
            	each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
            	the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. 
            	If there are more class names than rows, the overflow ones are ignored.
		 */
		private ValueExpression _rowClasses;
		/**
		 * Assigns one or more space-separated CSS class names to the rows. If the CSS class names are comma-separated, 
            	each class will be assigned to a particular row in the order they follow in the attribute. If you have less class names than rows, 
            	the class will be applied to every n-fold row where n is the order in which the class is listed in the attribute. 
            	If there are more class names than rows, the overflow ones are ignored.
		 * Setter for rowClasses
		 * @param rowClasses - new value
		 */
		 public void setRowClasses( ValueExpression  __rowClasses ){
			this._rowClasses = __rowClasses;
	     }
	  
	 	 		 		 		 		 		 		 	  			  		  	  
		/*
		 * rules
		 * This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
		 */
		private ValueExpression _rules;
		/**
		 * This attribute specifies which rules will appear between cells within a table. The rendering of rules is user agent dependent. Possible values:
            
            * none: No rules. This is the default value.
            * groups: Rules will appear between row groups (see THEAD, TFOOT, and TBODY) and column groups (see COLGROUP and COL) only.
            * rows: Rules will appear between rows only.
            * cols: Rules will appear between columns only.
            * all: Rules will appear between all rows and columns
		 * Setter for rules
		 * @param rules - new value
		 */
		 public void setRules( ValueExpression  __rules ){
			this._rules = __rules;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectValueClass
		 * Assigns one or more space-separated CSS class names to the cells of the selected suggestion entry (table cells)
		 */
		private ValueExpression _selectValueClass;
		/**
		 * Assigns one or more space-separated CSS class names to the cells of the selected suggestion entry (table cells)
		 * Setter for selectValueClass
		 * @param selectValueClass - new value
		 */
		 public void setSelectValueClass( ValueExpression  __selectValueClass ){
			this._selectValueClass = __selectValueClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selectedClass
		 * Assigns one or more space-separated CSS class names to the selected suggestion entry (table rows)
		 */
		private ValueExpression _selectedClass;
		/**
		 * Assigns one or more space-separated CSS class names to the selected suggestion entry (table rows)
		 * Setter for selectedClass
		 * @param selectedClass - new value
		 */
		 public void setSelectedClass( ValueExpression  __selectedClass ){
			this._selectedClass = __selectedClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * selfRendered
		 * If "true", forces active Ajax region render response
                directly from stored components tree, bypasses page
                processing. Can be used for increase performance. Also,
                must be set to 'true' inside iteration components, such
                as dataTable.
		 */
		private ValueExpression _selfRendered;
		/**
		 * If "true", forces active Ajax region render response
                directly from stored components tree, bypasses page
                processing. Can be used for increase performance. Also,
                must be set to 'true' inside iteration components, such
                as dataTable.
		 * Setter for selfRendered
		 * @param selfRendered - new value
		 */
		 public void setSelfRendered( ValueExpression  __selfRendered ){
			this._selfRendered = __selfRendered;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * shadowDepth
		 * Pop-up shadow depth for suggestion content
		 */
		private ValueExpression _shadowDepth;
		/**
		 * Pop-up shadow depth for suggestion content
		 * Setter for shadowDepth
		 * @param shadowDepth - new value
		 */
		 public void setShadowDepth( ValueExpression  __shadowDepth ){
			this._shadowDepth = __shadowDepth;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * shadowOpacity
		 * Attribute defines shadow opacity for suggestion content
		 */
		private ValueExpression _shadowOpacity;
		/**
		 * Attribute defines shadow opacity for suggestion content
		 * Setter for shadowOpacity
		 * @param shadowOpacity - new value
		 */
		 public void setShadowOpacity( ValueExpression  __shadowOpacity ){
			this._shadowOpacity = __shadowOpacity;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * similarityGroupingId
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 */
		private ValueExpression _similarityGroupingId;
		/**
		 * If there are any component requests with identical IDs then these requests will be grouped.
		 * Setter for similarityGroupingId
		 * @param similarityGroupingId - new value
		 */
		 public void setSimilarityGroupingId( ValueExpression  __similarityGroupingId ){
			this._similarityGroupingId = __similarityGroupingId;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * status
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 */
		private ValueExpression _status;
		/**
		 * ID (in format of call UIComponent.findComponent()) of Request status component
		 * Setter for status
		 * @param status - new value
		 */
		 public void setStatus( ValueExpression  __status ){
			this._status = __status;
	     }
	  
	 	 		 		 		 		 		 	  	  	  
		/*
		 * suggestionAction
		 * Method calls an expression to get a collection of suggestion data on request. It must have one parameter with a type of Object with content of input component and must return any type allowed for &amp;lt;h:datatable&amp;gt;
		 */
		private MethodExpression _suggestionAction;
		/**
		 * Method calls an expression to get a collection of suggestion data on request. It must have one parameter with a type of Object with content of input component and must return any type allowed for &amp;lt;h:datatable&amp;gt;
		 * Setter for suggestionAction
		 * @param suggestionAction - new value
		 */
		 public void setSuggestionAction( MethodExpression  __suggestionAction ){
			this._suggestionAction = __suggestionAction;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * summary
		 * This attribute provides a summary of the table's purpose and structure for user agents rendering to non-visual media such as speech and Braille
		 */
		private ValueExpression _summary;
		/**
		 * This attribute provides a summary of the table's purpose and structure for user agents rendering to non-visual media such as speech and Braille
		 * Setter for summary
		 * @param summary - new value
		 */
		 public void setSummary( ValueExpression  __summary ){
			this._summary = __summary;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * timeout
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 */
		private ValueExpression _timeout;
		/**
		 * Response waiting time on a particular request. If a response is not received during this time, the request is aborted
		 * Setter for timeout
		 * @param timeout - new value
		 */
		 public void setTimeout( ValueExpression  __timeout ){
			this._timeout = __timeout;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * tokens
		 * The list (or single value) of symbols which can be used
                for division chosen of suggestion pop-up values in a
                target element. After input of a symbol from the list
                suggestion pop-up it is caused again
		 */
		private ValueExpression _tokens;
		/**
		 * The list (or single value) of symbols which can be used
                for division chosen of suggestion pop-up values in a
                target element. After input of a symbol from the list
                suggestion pop-up it is caused again
		 * Setter for tokens
		 * @param tokens - new value
		 */
		 public void setTokens( ValueExpression  __tokens ){
			this._tokens = __tokens;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * usingSuggestObjects
		 * if true, a suggested object list will be created and will be updated every time when  an input value is changed. Default value is "false".
		 */
		private ValueExpression _usingSuggestObjects;
		/**
		 * if true, a suggested object list will be created and will be updated every time when  an input value is changed. Default value is "false".
		 * Setter for usingSuggestObjects
		 * @param usingSuggestObjects - new value
		 */
		 public void setUsingSuggestObjects( ValueExpression  __usingSuggestObjects ){
			this._usingSuggestObjects = __usingSuggestObjects;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * var
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 */
		private String _var;
		/**
		 * A request-scope attribute via which the data object for the
            current row will be used when iterating
		 * Setter for var
		 * @param var - new value
		 */
		 public void setVar( String  __var ){
			this._var = __var;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * width
		 * Width of the pop-up window in pixels. Default value is "200".
		 */
		private ValueExpression _width;
		/**
		 * Width of the pop-up window in pixels. Default value is "200".
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * zindex
		 * Attribute is similar to the standard HTML attribute and can specify window placement relative to the content. Default value is "200".
		 */
		private ValueExpression _zindex;
		/**
		 * Attribute is similar to the standard HTML attribute and can specify window placement relative to the content. Default value is "200".
		 * Setter for zindex
		 * @param zindex - new value
		 */
		 public void setZindex( ValueExpression  __zindex ){
			this._zindex = __zindex;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._ajaxSingle = null;
	 		 		 		    this._bgcolor = null;
	 		 		 		    this._border = null;
	 		 		    this._bypassUpdates = null;
	 		 		    this._cellpadding = null;
	 		 		    this._cellspacing = null;
	 		 		 		 		 		    this._entryClass = null;
	 		 		    this._eventsQueue = null;
	 		 		 		    this._fetchValue = null;
	 		 		    this._first = null;
	 		 		 		 		    this._for = null;
	 		 		    this._frame = null;
	 		 		    this._frequency = null;
	 		 		 		    this._height = null;
	 		 		 		    this._ignoreDupResponses = null;
	 		 		    this._immediate = null;
	 		 		 		    this._limitToList = null;
	 		 		 		    this._minChars = null;
	 		 		    this._nothingLabel = null;
	 		 		    this._onbeforedomupdate = null;
	 		 		    this._oncomplete = null;
	 		 		    this._onobjectchange = null;
	 		 		    this._onselect = null;
	 		 		    this._onsubmit = null;
	 		 		    this._param = null;
	 		 		    this._popupClass = null;
	 		 		    this._popupStyle = null;
	 		 		    this._process = null;
	 		 		    this._reRender = null;
	 		 		 		    this._requestDelay = null;
	 		 		 		    this._rowClasses = null;
	 		 		 		 		 		 		 		    this._rules = null;
	 		 		    this._selectValueClass = null;
	 		 		    this._selectedClass = null;
	 		 		    this._selfRendered = null;
	 		 		    this._shadowDepth = null;
	 		 		    this._shadowOpacity = null;
	 		 		    this._similarityGroupingId = null;
	 		 		    this._status = null;
	 		 		 		 		 		 		    this._suggestionAction = null;
	 		 		    this._summary = null;
	 		 		    this._timeout = null;
	 		 		 		    this._tokens = null;
	 		 		 		    this._usingSuggestObjects = null;
	 		 		 		    this._var = null;
	 		 		    this._width = null;
	 		 		    this._zindex = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlSuggestionBox comp = (HtmlSuggestionBox) component;
  		 			 
						if (this._ajaxSingle != null) {
				if (this._ajaxSingle.isLiteralText()) {
					try {
												
						Boolean __ajaxSingle = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxSingle.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxSingle(__ajaxSingle.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxSingle", this._ajaxSingle);
				}
			}
					    		 			 
						if (this._bgcolor != null) {
				if (this._bgcolor.isLiteralText()) {
					try {
												
						java.lang.String __bgcolor = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bgcolor.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBgcolor(__bgcolor);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bgcolor", this._bgcolor);
				}
			}
					    		 			 
						if (this._border != null) {
				if (this._border.isLiteralText()) {
					try {
												
						java.lang.String __border = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._border.getExpressionString(), 
											java.lang.String.class);
					
												comp.setBorder(__border);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("border", this._border);
				}
			}
					   		 			 
						if (this._bypassUpdates != null) {
				if (this._bypassUpdates.isLiteralText()) {
					try {
												
						Boolean __bypassUpdates = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._bypassUpdates.getExpressionString(), 
											Boolean.class);
					
												comp.setBypassUpdates(__bypassUpdates.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("bypassUpdates", this._bypassUpdates);
				}
			}
					   		 			 
						if (this._cellpadding != null) {
				if (this._cellpadding.isLiteralText()) {
					try {
												
						java.lang.String __cellpadding = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cellpadding.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCellpadding(__cellpadding);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cellpadding", this._cellpadding);
				}
			}
					   		 			 
						if (this._cellspacing != null) {
				if (this._cellspacing.isLiteralText()) {
					try {
												
						java.lang.String __cellspacing = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cellspacing.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCellspacing(__cellspacing);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cellspacing", this._cellspacing);
				}
			}
					      		 			 
						if (this._entryClass != null) {
				if (this._entryClass.isLiteralText()) {
					try {
												
						java.lang.String __entryClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._entryClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEntryClass(__entryClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("entryClass", this._entryClass);
				}
			}
					   		 			 
						if (this._eventsQueue != null) {
				if (this._eventsQueue.isLiteralText()) {
					try {
												
						java.lang.String __eventsQueue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._eventsQueue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEventsQueue(__eventsQueue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("eventsQueue", this._eventsQueue);
				}
			}
					    		 			 
						if (this._fetchValue != null) {
				if (this._fetchValue.isLiteralText()) {
					try {
												
						java.lang.Object __fetchValue = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fetchValue.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setFetchValue(__fetchValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fetchValue", this._fetchValue);
				}
			}
					   		 			 
						if (this._first != null) {
				if (this._first.isLiteralText()) {
					try {
												
						Integer __first = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._first.getExpressionString(), 
											Integer.class);
					
												comp.setFirst(__first.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("first", this._first);
				}
			}
					     		 			 
						if (this._for != null) {
				if (this._for.isLiteralText()) {
					try {
												
						java.lang.String __for = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._for.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFor(__for);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("for", this._for);
				}
			}
					   		 			 
						if (this._frame != null) {
				if (this._frame.isLiteralText()) {
					try {
												
						java.lang.String __frame = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._frame.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFrame(__frame);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("frame", this._frame);
				}
			}
					   		 			 
						if (this._frequency != null) {
				if (this._frequency.isLiteralText()) {
					try {
												
						Double __frequency = (Double) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._frequency.getExpressionString(), 
											Double.class);
					
												comp.setFrequency(__frequency.doubleValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("frequency", this._frequency);
				}
			}
					    		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						java.lang.String __height = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeight(__height);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					    		 			 
						if (this._ignoreDupResponses != null) {
				if (this._ignoreDupResponses.isLiteralText()) {
					try {
												
						Boolean __ignoreDupResponses = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ignoreDupResponses.getExpressionString(), 
											Boolean.class);
					
												comp.setIgnoreDupResponses(__ignoreDupResponses.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ignoreDupResponses", this._ignoreDupResponses);
				}
			}
					   		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					    		 			 
						if (this._limitToList != null) {
				if (this._limitToList.isLiteralText()) {
					try {
												
						Boolean __limitToList = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._limitToList.getExpressionString(), 
											Boolean.class);
					
												comp.setLimitToList(__limitToList.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("limitToList", this._limitToList);
				}
			}
					    		 			 
						if (this._minChars != null) {
				if (this._minChars.isLiteralText()) {
					try {
												
						java.lang.String __minChars = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._minChars.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMinChars(__minChars);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("minChars", this._minChars);
				}
			}
					   		 			 
						if (this._nothingLabel != null) {
				if (this._nothingLabel.isLiteralText()) {
					try {
												
						java.lang.String __nothingLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._nothingLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setNothingLabel(__nothingLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("nothingLabel", this._nothingLabel);
				}
			}
					   		 			 
						if (this._onbeforedomupdate != null) {
				if (this._onbeforedomupdate.isLiteralText()) {
					try {
												
						java.lang.String __onbeforedomupdate = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onbeforedomupdate.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnbeforedomupdate(__onbeforedomupdate);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onbeforedomupdate", this._onbeforedomupdate);
				}
			}
					   		 			 
						if (this._oncomplete != null) {
				if (this._oncomplete.isLiteralText()) {
					try {
												
						java.lang.String __oncomplete = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oncomplete.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOncomplete(__oncomplete);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oncomplete", this._oncomplete);
				}
			}
					   		 			 
						if (this._onobjectchange != null) {
				if (this._onobjectchange.isLiteralText()) {
					try {
												
						java.lang.String __onobjectchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onobjectchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnobjectchange(__onobjectchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onobjectchange", this._onobjectchange);
				}
			}
					   		 			 
						if (this._onselect != null) {
				if (this._onselect.isLiteralText()) {
					try {
												
						java.lang.String __onselect = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselect.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselect(__onselect);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselect", this._onselect);
				}
			}
					   		 			 
						if (this._onsubmit != null) {
				if (this._onsubmit.isLiteralText()) {
					try {
												
						java.lang.String __onsubmit = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onsubmit.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnsubmit(__onsubmit);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onsubmit", this._onsubmit);
				}
			}
					   		 			 
						if (this._param != null) {
				if (this._param.isLiteralText()) {
					try {
												
						java.lang.String __param = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._param.getExpressionString(), 
											java.lang.String.class);
					
												comp.setParam(__param);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("param", this._param);
				}
			}
					   		 			 
						if (this._popupClass != null) {
				if (this._popupClass.isLiteralText()) {
					try {
												
						java.lang.String __popupClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._popupClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setPopupClass(__popupClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("popupClass", this._popupClass);
				}
			}
					   		 			 
						if (this._popupStyle != null) {
				if (this._popupStyle.isLiteralText()) {
					try {
												
						java.lang.String __popupStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._popupStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setPopupStyle(__popupStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("popupStyle", this._popupStyle);
				}
			}
					   		 			 
						if (this._process != null) {
				if (this._process.isLiteralText()) {
					try {
												
						java.lang.Object __process = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._process.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setProcess(__process);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("process", this._process);
				}
			}
					   		 			 
						if (this._reRender != null) {
				if (this._reRender.isLiteralText()) {
					try {
												
						java.lang.Object __reRender = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._reRender.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setReRender(__reRender);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("reRender", this._reRender);
				}
			}
					    		 			 
						if (this._requestDelay != null) {
				if (this._requestDelay.isLiteralText()) {
					try {
												
						Integer __requestDelay = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requestDelay.getExpressionString(), 
											Integer.class);
					
												comp.setRequestDelay(__requestDelay.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requestDelay", this._requestDelay);
				}
			}
					    		 			 
						if (this._rowClasses != null) {
				if (this._rowClasses.isLiteralText()) {
					try {
												
						java.lang.String __rowClasses = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rowClasses.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRowClasses(__rowClasses);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rowClasses", this._rowClasses);
				}
			}
					        		 			 
						if (this._rules != null) {
				if (this._rules.isLiteralText()) {
					try {
												
						java.lang.String __rules = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._rules.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRules(__rules);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("rules", this._rules);
				}
			}
					   		 			 
						if (this._selectValueClass != null) {
				if (this._selectValueClass.isLiteralText()) {
					try {
												
						java.lang.String __selectValueClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectValueClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectValueClass(__selectValueClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectValueClass", this._selectValueClass);
				}
			}
					   		 			 
						if (this._selectedClass != null) {
				if (this._selectedClass.isLiteralText()) {
					try {
												
						java.lang.String __selectedClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectedClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSelectedClass(__selectedClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectedClass", this._selectedClass);
				}
			}
					   		 			 
						if (this._selfRendered != null) {
				if (this._selfRendered.isLiteralText()) {
					try {
												
						Boolean __selfRendered = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selfRendered.getExpressionString(), 
											Boolean.class);
					
												comp.setSelfRendered(__selfRendered.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selfRendered", this._selfRendered);
				}
			}
					   		 			 
						if (this._shadowDepth != null) {
				if (this._shadowDepth.isLiteralText()) {
					try {
												
						java.lang.String __shadowDepth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._shadowDepth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setShadowDepth(__shadowDepth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("shadowDepth", this._shadowDepth);
				}
			}
					   		 			 
						if (this._shadowOpacity != null) {
				if (this._shadowOpacity.isLiteralText()) {
					try {
												
						java.lang.String __shadowOpacity = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._shadowOpacity.getExpressionString(), 
											java.lang.String.class);
					
												comp.setShadowOpacity(__shadowOpacity);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("shadowOpacity", this._shadowOpacity);
				}
			}
					   		 			 
						if (this._similarityGroupingId != null) {
				if (this._similarityGroupingId.isLiteralText()) {
					try {
												
						java.lang.String __similarityGroupingId = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._similarityGroupingId.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSimilarityGroupingId(__similarityGroupingId);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("similarityGroupingId", this._similarityGroupingId);
				}
			}
					   		 			 
						if (this._status != null) {
				if (this._status.isLiteralText()) {
					try {
												
						java.lang.String __status = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._status.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStatus(__status);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("status", this._status);
				}
			}
					       		 			if(null != this._suggestionAction){
				((HtmlSuggestionBox)component).setSuggestionAction(this._suggestionAction);
			}		
		   		 			 
						if (this._summary != null) {
				if (this._summary.isLiteralText()) {
					try {
												
						java.lang.String __summary = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._summary.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSummary(__summary);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("summary", this._summary);
				}
			}
					   		 			 
						if (this._timeout != null) {
				if (this._timeout.isLiteralText()) {
					try {
												
						Integer __timeout = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._timeout.getExpressionString(), 
											Integer.class);
					
												comp.setTimeout(__timeout.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("timeout", this._timeout);
				}
			}
					    		 			 
						if (this._tokens != null) {
				if (this._tokens.isLiteralText()) {
					try {
												
						java.lang.Object __tokens = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tokens.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setTokens(__tokens);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tokens", this._tokens);
				}
			}
					    		 			 
						if (this._usingSuggestObjects != null) {
				if (this._usingSuggestObjects.isLiteralText()) {
					try {
												
						Boolean __usingSuggestObjects = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._usingSuggestObjects.getExpressionString(), 
											Boolean.class);
					
												comp.setUsingSuggestObjects(__usingSuggestObjects.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("usingSuggestObjects", this._usingSuggestObjects);
				}
			}
					    		 			 
											if (this._var != null) {
					comp.setVar(this._var);
				}
									   		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					   		 			 
						if (this._zindex != null) {
				if (this._zindex.isLiteralText()) {
					try {
												
						Integer __zindex = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._zindex.getExpressionString(), 
											Integer.class);
					
												comp.setZindex(__zindex.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("zindex", this._zindex);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.SuggestionBox";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.SuggestionBox";
			}

}
