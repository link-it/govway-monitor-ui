/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlInputNumberSpinner;

public class InputNumberSpinnerTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * accesskey
		 * This attribute assigns an access key to an element. An access key is a single character from the document character set. Note: Authors should consider the input method of the expected reader when specifying an accesskey
		 */
		private ValueExpression _accesskey;
		/**
		 * This attribute assigns an access key to an element. An access key is a single character from the document character set. Note: Authors should consider the input method of the expected reader when specifying an accesskey
		 * Setter for accesskey
		 * @param accesskey - new value
		 */
		 public void setAccesskey( ValueExpression  __accesskey ){
			this._accesskey = __accesskey;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * clientErrorMessage
		 * An error message to use in client-side validation events
		 */
		private ValueExpression _clientErrorMessage;
		/**
		 * An error message to use in client-side validation events
		 * Setter for clientErrorMessage
		 * @param clientErrorMessage - new value
		 */
		 public void setClientErrorMessage( ValueExpression  __clientErrorMessage ){
			this._clientErrorMessage = __clientErrorMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * cycled
		 * If "true" after the current value reaches the border value it is reversed to another border value
	    		after next increasing/decreasing. In other case possibilities of next increasing (or decreasing) will be locked. Default value is " true ".
		 */
		private ValueExpression _cycled;
		/**
		 * If "true" after the current value reaches the border value it is reversed to another border value
	    		after next increasing/decreasing. In other case possibilities of next increasing (or decreasing) will be locked. Default value is " true ".
		 * Setter for cycled
		 * @param cycled - new value
		 */
		 public void setCycled( ValueExpression  __cycled ){
			this._cycled = __cycled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disableBrowserAutoComplete
		 * Disable browser's auto completion. Default value is "false"
		 */
		private ValueExpression _disableBrowserAutoComplete;
		/**
		 * Disable browser's auto completion. Default value is "false"
		 * Setter for disableBrowserAutoComplete
		 * @param disableBrowserAutoComplete - new value
		 */
		 public void setDisableBrowserAutoComplete( ValueExpression  __disableBrowserAutoComplete ){
			this._disableBrowserAutoComplete = __disableBrowserAutoComplete;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabled
		 * When set for a form control, this boolean attribute disables the control for your input
		 */
		private ValueExpression _disabled;
		/**
		 * When set for a form control, this boolean attribute disables the control for your input
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * enableManualInput
		 * if "false" your's input to the text field using keyboard will be locked. Default value is "true"
		 */
		private ValueExpression _enableManualInput;
		/**
		 * if "false" your's input to the text field using keyboard will be locked. Default value is "true"
		 * Setter for enableManualInput
		 * @param enableManualInput - new value
		 */
		 public void setEnableManualInput( ValueExpression  __enableManualInput ){
			this._enableManualInput = __enableManualInput;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * inputClass
		 * Assigns one or more space-separated CSS class names to the component input field
		 */
		private ValueExpression _inputClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component input field
		 * Setter for inputClass
		 * @param inputClass - new value
		 */
		 public void setInputClass( ValueExpression  __inputClass ){
			this._inputClass = __inputClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * inputSize
		 * Attribute specifies the initial length of input in characters. Default value is "10".
		 */
		private ValueExpression _inputSize;
		/**
		 * Attribute specifies the initial length of input in characters. Default value is "10".
		 * Setter for inputSize
		 * @param inputSize - new value
		 */
		 public void setInputSize( ValueExpression  __inputSize ){
			this._inputSize = __inputSize;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * inputStyle
		 * CSS style rules to be applied to the component input field
		 */
		private ValueExpression _inputStyle;
		/**
		 * CSS style rules to be applied to the component input field
		 * Setter for inputStyle
		 * @param inputStyle - new value
		 */
		 public void setInputStyle( ValueExpression  __inputStyle ){
			this._inputStyle = __inputStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * maxValue
		 * Maximum value. Default value is "100".
		 */
		private ValueExpression _maxValue;
		/**
		 * Maximum value. Default value is "100".
		 * Setter for maxValue
		 * @param maxValue - new value
		 */
		 public void setMaxValue( ValueExpression  __maxValue ){
			this._maxValue = __maxValue;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * minValue
		 * Minimum value. Default value is "0".
		 */
		private ValueExpression _minValue;
		/**
		 * Minimum value. Default value is "0".
		 * Setter for minValue
		 * @param minValue - new value
		 */
		 public void setMinValue( ValueExpression  __minValue ){
			this._minValue = __minValue;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onblur
		 * The client-side script method to be called when the element loses the focus
		 */
		private ValueExpression _onblur;
		/**
		 * The client-side script method to be called when the element loses the focus
		 * Setter for onblur
		 * @param onblur - new value
		 */
		 public void setOnblur( ValueExpression  __onblur ){
			this._onblur = __onblur;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onchange
		 * The client-side script method to be called when the element value is changed
		 */
		private ValueExpression _onchange;
		/**
		 * The client-side script method to be called when the element value is changed
		 * Setter for onchange
		 * @param onchange - new value
		 */
		 public void setOnchange( ValueExpression  __onchange ){
			this._onchange = __onchange;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * ondownclick
		 * The client-side script method to be called when the 'Down' button is clicked
		 */
		private ValueExpression _ondownclick;
		/**
		 * The client-side script method to be called when the 'Down' button is clicked
		 * Setter for ondownclick
		 * @param ondownclick - new value
		 */
		 public void setOndownclick( ValueExpression  __ondownclick ){
			this._ondownclick = __ondownclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onerror
		 * The client-side script method to be called whenever a JavaScript error occurs
		 */
		private ValueExpression _onerror;
		/**
		 * The client-side script method to be called whenever a JavaScript error occurs
		 * Setter for onerror
		 * @param onerror - new value
		 */
		 public void setOnerror( ValueExpression  __onerror ){
			this._onerror = __onerror;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onfocus
		 * The client-side script method to be called when the element gets the focus
		 */
		private ValueExpression _onfocus;
		/**
		 * The client-side script method to be called when the element gets the focus
		 * Setter for onfocus
		 * @param onfocus - new value
		 */
		 public void setOnfocus( ValueExpression  __onfocus ){
			this._onfocus = __onfocus;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputclick
		 * The client-side script method to be called when the component input field is clicked
		 */
		private ValueExpression _oninputclick;
		/**
		 * The client-side script method to be called when the component input field is clicked
		 * Setter for oninputclick
		 * @param oninputclick - new value
		 */
		 public void setOninputclick( ValueExpression  __oninputclick ){
			this._oninputclick = __oninputclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputdblclick
		 * The client-side script method to be called when the component input field is double-clicked
		 */
		private ValueExpression _oninputdblclick;
		/**
		 * The client-side script method to be called when the component input field is double-clicked
		 * Setter for oninputdblclick
		 * @param oninputdblclick - new value
		 */
		 public void setOninputdblclick( ValueExpression  __oninputdblclick ){
			this._oninputdblclick = __oninputdblclick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeydown
		 * The client-side script method to be called when a key is pressed down in the input field
		 */
		private ValueExpression _oninputkeydown;
		/**
		 * The client-side script method to be called when a key is pressed down in the input field
		 * Setter for oninputkeydown
		 * @param oninputkeydown - new value
		 */
		 public void setOninputkeydown( ValueExpression  __oninputkeydown ){
			this._oninputkeydown = __oninputkeydown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeypress
		 * The client-side script method to be called when a key is pressed and released in the input field
		 */
		private ValueExpression _oninputkeypress;
		/**
		 * The client-side script method to be called when a key is pressed and released in the input field
		 * Setter for oninputkeypress
		 * @param oninputkeypress - new value
		 */
		 public void setOninputkeypress( ValueExpression  __oninputkeypress ){
			this._oninputkeypress = __oninputkeypress;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputkeyup
		 * The client-side script method to be called when a key is released in the input field
		 */
		private ValueExpression _oninputkeyup;
		/**
		 * The client-side script method to be called when a key is released in the input field
		 * Setter for oninputkeyup
		 * @param oninputkeyup - new value
		 */
		 public void setOninputkeyup( ValueExpression  __oninputkeyup ){
			this._oninputkeyup = __oninputkeyup;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmousedown
		 * The client-side script method to be called when a mouse button is pressed down in the input field
		 */
		private ValueExpression _oninputmousedown;
		/**
		 * The client-side script method to be called when a mouse button is pressed down in the input field
		 * Setter for oninputmousedown
		 * @param oninputmousedown - new value
		 */
		 public void setOninputmousedown( ValueExpression  __oninputmousedown ){
			this._oninputmousedown = __oninputmousedown;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmousemove
		 * The client-side script method to be called when a pointer is moved within the input field
		 */
		private ValueExpression _oninputmousemove;
		/**
		 * The client-side script method to be called when a pointer is moved within the input field
		 * Setter for oninputmousemove
		 * @param oninputmousemove - new value
		 */
		 public void setOninputmousemove( ValueExpression  __oninputmousemove ){
			this._oninputmousemove = __oninputmousemove;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmouseout
		 * The client-side script method to be called when a pointer is moved away from the input field
		 */
		private ValueExpression _oninputmouseout;
		/**
		 * The client-side script method to be called when a pointer is moved away from the input field
		 * Setter for oninputmouseout
		 * @param oninputmouseout - new value
		 */
		 public void setOninputmouseout( ValueExpression  __oninputmouseout ){
			this._oninputmouseout = __oninputmouseout;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmouseover
		 * The client-side script method to be called when a pointer is moved onto the input field
		 */
		private ValueExpression _oninputmouseover;
		/**
		 * The client-side script method to be called when a pointer is moved onto the input field
		 * Setter for oninputmouseover
		 * @param oninputmouseover - new value
		 */
		 public void setOninputmouseover( ValueExpression  __oninputmouseover ){
			this._oninputmouseover = __oninputmouseover;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * oninputmouseup
		 * The client-side script method to be called when a mouse button is released in the input field
		 */
		private ValueExpression _oninputmouseup;
		/**
		 * The client-side script method to be called when a mouse button is released in the input field
		 * Setter for oninputmouseup
		 * @param oninputmouseup - new value
		 */
		 public void setOninputmouseup( ValueExpression  __oninputmouseup ){
			this._oninputmouseup = __oninputmouseup;
	     }
	  
	 	 		 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * onselect
		 * The client-side script method to be called when some text is selected in the text field. This attribute can be used with the INPUT and TEXTAREA elements.
		 */
		private ValueExpression _onselect;
		/**
		 * The client-side script method to be called when some text is selected in the text field. This attribute can be used with the INPUT and TEXTAREA elements.
		 * Setter for onselect
		 * @param onselect - new value
		 */
		 public void setOnselect( ValueExpression  __onselect ){
			this._onselect = __onselect;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onupclick
		 * The client-side script method to be called when the 'Up' button is clicked
		 */
		private ValueExpression _onupclick;
		/**
		 * The client-side script method to be called when the 'Up' button is clicked
		 * Setter for onupclick
		 * @param onupclick - new value
		 */
		 public void setOnupclick( ValueExpression  __onupclick ){
			this._onupclick = __onupclick;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * step
		 * Parameter that determines the step between nearest values while using controls. Default value is "1"
		 */
		private ValueExpression _step;
		/**
		 * Parameter that determines the step between nearest values while using controls. Default value is "1"
		 * Setter for step
		 * @param step - new value
		 */
		 public void setStep( ValueExpression  __step ){
			this._step = __step;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * tabindex
		 * This attribute specifies the position of the current element in the tabbing order for the current document. This value must be a number between 0 and 32767. User agents should ignore leading zeros
		 */
		private ValueExpression _tabindex;
		/**
		 * This attribute specifies the position of the current element in the tabbing order for the current document. This value must be a number between 0 and 32767. User agents should ignore leading zeros
		 * Setter for tabindex
		 * @param tabindex - new value
		 */
		 public void setTabindex( ValueExpression  __tabindex ){
			this._tabindex = __tabindex;
	     }
	  
	 	 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._accesskey = null;
	 		 		 		 		    this._clientErrorMessage = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._cycled = null;
	 		 		    this._disableBrowserAutoComplete = null;
	 		 		    this._disabled = null;
	 		 		    this._enableManualInput = null;
	 		 		 		 		    this._immediate = null;
	 		 		    this._inputClass = null;
	 		 		    this._inputSize = null;
	 		 		    this._inputStyle = null;
	 		 		    this._label = null;
	 		 		 		 		    this._maxValue = null;
	 		 		 		    this._minValue = null;
	 		 		    this._onblur = null;
	 		 		    this._onchange = null;
	 		 		 		 		    this._ondownclick = null;
	 		 		    this._onerror = null;
	 		 		    this._onfocus = null;
	 		 		    this._oninputclick = null;
	 		 		    this._oninputdblclick = null;
	 		 		    this._oninputkeydown = null;
	 		 		    this._oninputkeypress = null;
	 		 		    this._oninputkeyup = null;
	 		 		    this._oninputmousedown = null;
	 		 		    this._oninputmousemove = null;
	 		 		    this._oninputmouseout = null;
	 		 		    this._oninputmouseover = null;
	 		 		    this._oninputmouseup = null;
	 		 		 		 		 		 		 		 		 		 		    this._onselect = null;
	 		 		    this._onupclick = null;
	 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		 		    this._step = null;
	 		 		 		 		    this._tabindex = null;
	 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlInputNumberSpinner comp = (HtmlInputNumberSpinner) component;
 		 			 
						if (this._accesskey != null) {
				if (this._accesskey.isLiteralText()) {
					try {
												
						java.lang.String __accesskey = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._accesskey.getExpressionString(), 
											java.lang.String.class);
					
												comp.setAccesskey(__accesskey);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("accesskey", this._accesskey);
				}
			}
					     		 			 
						if (this._clientErrorMessage != null) {
				if (this._clientErrorMessage.isLiteralText()) {
					try {
												
						java.lang.String __clientErrorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._clientErrorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setClientErrorMessage(__clientErrorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("clientErrorMessage", this._clientErrorMessage);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._cycled != null) {
				if (this._cycled.isLiteralText()) {
					try {
												
						Boolean __cycled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._cycled.getExpressionString(), 
											Boolean.class);
					
												comp.setCycled(__cycled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("cycled", this._cycled);
				}
			}
					   		 			 
						if (this._disableBrowserAutoComplete != null) {
				if (this._disableBrowserAutoComplete.isLiteralText()) {
					try {
												
						Boolean __disableBrowserAutoComplete = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disableBrowserAutoComplete.getExpressionString(), 
											Boolean.class);
					
												comp.setDisableBrowserAutoComplete(__disableBrowserAutoComplete.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disableBrowserAutoComplete", this._disableBrowserAutoComplete);
				}
			}
					   		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					   		 			 
						if (this._enableManualInput != null) {
				if (this._enableManualInput.isLiteralText()) {
					try {
												
						Boolean __enableManualInput = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enableManualInput.getExpressionString(), 
											Boolean.class);
					
												comp.setEnableManualInput(__enableManualInput.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enableManualInput", this._enableManualInput);
				}
			}
					     		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._inputClass != null) {
				if (this._inputClass.isLiteralText()) {
					try {
												
						java.lang.String __inputClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._inputClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInputClass(__inputClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("inputClass", this._inputClass);
				}
			}
					   		 			 
						if (this._inputSize != null) {
				if (this._inputSize.isLiteralText()) {
					try {
												
						Integer __inputSize = (Integer) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._inputSize.getExpressionString(), 
											Integer.class);
					
												comp.setInputSize(__inputSize.intValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("inputSize", this._inputSize);
				}
			}
					   		 			 
						if (this._inputStyle != null) {
				if (this._inputStyle.isLiteralText()) {
					try {
												
						java.lang.String __inputStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._inputStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInputStyle(__inputStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("inputStyle", this._inputStyle);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					     		 			 
						if (this._maxValue != null) {
				if (this._maxValue.isLiteralText()) {
					try {
												
						java.lang.String __maxValue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._maxValue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMaxValue(__maxValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("maxValue", this._maxValue);
				}
			}
					    		 			 
						if (this._minValue != null) {
				if (this._minValue.isLiteralText()) {
					try {
												
						java.lang.String __minValue = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._minValue.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMinValue(__minValue);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("minValue", this._minValue);
				}
			}
					   		 			 
						if (this._onblur != null) {
				if (this._onblur.isLiteralText()) {
					try {
												
						java.lang.String __onblur = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onblur.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnblur(__onblur);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onblur", this._onblur);
				}
			}
					   		 			 
						if (this._onchange != null) {
				if (this._onchange.isLiteralText()) {
					try {
												
						java.lang.String __onchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnchange(__onchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onchange", this._onchange);
				}
			}
					     		 			 
						if (this._ondownclick != null) {
				if (this._ondownclick.isLiteralText()) {
					try {
												
						java.lang.String __ondownclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ondownclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOndownclick(__ondownclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ondownclick", this._ondownclick);
				}
			}
					   		 			 
						if (this._onerror != null) {
				if (this._onerror.isLiteralText()) {
					try {
												
						java.lang.String __onerror = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onerror.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnerror(__onerror);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onerror", this._onerror);
				}
			}
					   		 			 
						if (this._onfocus != null) {
				if (this._onfocus.isLiteralText()) {
					try {
												
						java.lang.String __onfocus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfocus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfocus(__onfocus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfocus", this._onfocus);
				}
			}
					   		 			 
						if (this._oninputclick != null) {
				if (this._oninputclick.isLiteralText()) {
					try {
												
						java.lang.String __oninputclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputclick(__oninputclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputclick", this._oninputclick);
				}
			}
					   		 			 
						if (this._oninputdblclick != null) {
				if (this._oninputdblclick.isLiteralText()) {
					try {
												
						java.lang.String __oninputdblclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputdblclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputdblclick(__oninputdblclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputdblclick", this._oninputdblclick);
				}
			}
					   		 			 
						if (this._oninputkeydown != null) {
				if (this._oninputkeydown.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeydown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeydown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeydown(__oninputkeydown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeydown", this._oninputkeydown);
				}
			}
					   		 			 
						if (this._oninputkeypress != null) {
				if (this._oninputkeypress.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeypress = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeypress.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeypress(__oninputkeypress);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeypress", this._oninputkeypress);
				}
			}
					   		 			 
						if (this._oninputkeyup != null) {
				if (this._oninputkeyup.isLiteralText()) {
					try {
												
						java.lang.String __oninputkeyup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputkeyup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputkeyup(__oninputkeyup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputkeyup", this._oninputkeyup);
				}
			}
					   		 			 
						if (this._oninputmousedown != null) {
				if (this._oninputmousedown.isLiteralText()) {
					try {
												
						java.lang.String __oninputmousedown = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmousedown.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmousedown(__oninputmousedown);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmousedown", this._oninputmousedown);
				}
			}
					   		 			 
						if (this._oninputmousemove != null) {
				if (this._oninputmousemove.isLiteralText()) {
					try {
												
						java.lang.String __oninputmousemove = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmousemove.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmousemove(__oninputmousemove);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmousemove", this._oninputmousemove);
				}
			}
					   		 			 
						if (this._oninputmouseout != null) {
				if (this._oninputmouseout.isLiteralText()) {
					try {
												
						java.lang.String __oninputmouseout = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmouseout.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmouseout(__oninputmouseout);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmouseout", this._oninputmouseout);
				}
			}
					   		 			 
						if (this._oninputmouseover != null) {
				if (this._oninputmouseover.isLiteralText()) {
					try {
												
						java.lang.String __oninputmouseover = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmouseover.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmouseover(__oninputmouseover);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmouseover", this._oninputmouseover);
				}
			}
					   		 			 
						if (this._oninputmouseup != null) {
				if (this._oninputmouseup.isLiteralText()) {
					try {
												
						java.lang.String __oninputmouseup = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._oninputmouseup.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOninputmouseup(__oninputmouseup);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("oninputmouseup", this._oninputmouseup);
				}
			}
					           		 			 
						if (this._onselect != null) {
				if (this._onselect.isLiteralText()) {
					try {
												
						java.lang.String __onselect = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onselect.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnselect(__onselect);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onselect", this._onselect);
				}
			}
					   		 			 
						if (this._onupclick != null) {
				if (this._onupclick.isLiteralText()) {
					try {
												
						java.lang.String __onupclick = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onupclick.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnupclick(__onupclick);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onupclick", this._onupclick);
				}
			}
					    		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					    		 			 
						if (this._step != null) {
				if (this._step.isLiteralText()) {
					try {
												
						java.lang.String __step = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._step.getExpressionString(), 
											java.lang.String.class);
					
												comp.setStep(__step);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("step", this._step);
				}
			}
					     		 			 
						if (this._tabindex != null) {
				if (this._tabindex.isLiteralText()) {
					try {
												
						java.lang.String __tabindex = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tabindex.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTabindex(__tabindex);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tabindex", this._tabindex);
				}
			}
					    		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		      }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.inputNumberSpinner";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.InputNumberSpinnerRenderer";
			}

}
