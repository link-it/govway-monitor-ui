package org.ajax4jsf.component.html;

import javax.faces.context.FacesContext;
import org.ajax4jsf.component.UIActionParameter;

public class HtmlActionParameter extends UIActionParameter{

static public final  String COMPONENT_FAMILY = "javax.faces.Parameter";

static public final  String COMPONENT_TYPE = "org.ajax4jsf.ActionParameter";


public HtmlActionParameter(){

}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[1];
state[0] = super.saveState(context);
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);

}

}
