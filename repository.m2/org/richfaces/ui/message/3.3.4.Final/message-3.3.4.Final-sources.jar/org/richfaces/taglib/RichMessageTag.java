/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlRichMessage;

public class RichMessageTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 	  			  		  	  
		/*
		 * ajaxRendered
		 * Define, must be (or not) content of this component will be included in AJAX response created by parent AJAX Container, even if not forced by reRender list of ajax action.
            Ignored if component marked to output by some Ajax action component. The default value is "true".
		 */
		private ValueExpression _ajaxRendered;
		/**
		 * Define, must be (or not) content of this component will be included in AJAX response created by parent AJAX Container, even if not forced by reRender list of ajax action.
            Ignored if component marked to output by some Ajax action component. The default value is "true".
		 * Setter for ajaxRendered
		 * @param ajaxRendered - new value
		 */
		 public void setAjaxRendered( ValueExpression  __ajaxRendered ){
			this._ajaxRendered = __ajaxRendered;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * errorClass
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "ERROR"
		 */
		private ValueExpression _errorClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "ERROR"
		 * Setter for errorClass
		 * @param errorClass - new value
		 */
		 public void setErrorClass( ValueExpression  __errorClass ){
			this._errorClass = __errorClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * errorLabelClass
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "ERROR"
		 */
		private ValueExpression _errorLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "ERROR"
		 * Setter for errorLabelClass
		 * @param errorLabelClass - new value
		 */
		 public void setErrorLabelClass( ValueExpression  __errorLabelClass ){
			this._errorLabelClass = __errorLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * errorMarkerClass
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class of "ERROR"
		 */
		private ValueExpression _errorMarkerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class of "ERROR"
		 * Setter for errorMarkerClass
		 * @param errorMarkerClass - new value
		 */
		 public void setErrorMarkerClass( ValueExpression  __errorMarkerClass ){
			this._errorMarkerClass = __errorMarkerClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fatalClass
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "FATAL"
		 */
		private ValueExpression _fatalClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "FATAL"
		 * Setter for fatalClass
		 * @param fatalClass - new value
		 */
		 public void setFatalClass( ValueExpression  __fatalClass ){
			this._fatalClass = __fatalClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * fatalLabelClass
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "FATAL"
		 */
		private ValueExpression _fatalLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "FATAL"
		 * Setter for fatalLabelClass
		 * @param fatalLabelClass - new value
		 */
		 public void setFatalLabelClass( ValueExpression  __fatalLabelClass ){
			this._fatalLabelClass = __fatalLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * fatalMarkerClass
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class of "FATAL"
		 */
		private ValueExpression _fatalMarkerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class of "FATAL"
		 * Setter for fatalMarkerClass
		 * @param fatalMarkerClass - new value
		 */
		 public void setFatalMarkerClass( ValueExpression  __fatalMarkerClass ){
			this._fatalMarkerClass = __fatalMarkerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * for
		 * Client identifier of the component for which to display messages
		 */
		private ValueExpression _for;
		/**
		 * Client identifier of the component for which to display messages
		 * Setter for for
		 * @param for - new value
		 */
		 public void setFor( ValueExpression  __for ){
			this._for = __for;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * infoClass
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "INFO"
		 */
		private ValueExpression _infoClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "INFO"
		 * Setter for infoClass
		 * @param infoClass - new value
		 */
		 public void setInfoClass( ValueExpression  __infoClass ){
			this._infoClass = __infoClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * infoLabelClass
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "INFO"
		 */
		private ValueExpression _infoLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "INFO"
		 * Setter for infoLabelClass
		 * @param infoLabelClass - new value
		 */
		 public void setInfoLabelClass( ValueExpression  __infoLabelClass ){
			this._infoLabelClass = __infoLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * infoMarkerClass
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class of "INFO"
		 */
		private ValueExpression _infoMarkerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class of "INFO"
		 * Setter for infoMarkerClass
		 * @param infoMarkerClass - new value
		 */
		 public void setInfoMarkerClass( ValueExpression  __infoMarkerClass ){
			this._infoMarkerClass = __infoMarkerClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * labelClass
		 * Assigns one or more space-separated CSS class names to the message label
		 */
		private ValueExpression _labelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message label
		 * Setter for labelClass
		 * @param labelClass - new value
		 */
		 public void setLabelClass( ValueExpression  __labelClass ){
			this._labelClass = __labelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * level
		 * Defines a comma-separated list of messages categories to display. Default value is "ALL".
		 */
		private ValueExpression _level;
		/**
		 * Defines a comma-separated list of messages categories to display. Default value is "ALL".
		 * Setter for level
		 * @param level - new value
		 */
		 public void setLevel( ValueExpression  __level ){
			this._level = __level;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * markerClass
		 * Assigns one or more space-separated CSS class names to the message marker
		 */
		private ValueExpression _markerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message marker
		 * Setter for markerClass
		 * @param markerClass - new value
		 */
		 public void setMarkerClass( ValueExpression  __markerClass ){
			this._markerClass = __markerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * markerStyle
		 * CSS style rules to be applied to the message marker
		 */
		private ValueExpression _markerStyle;
		/**
		 * CSS style rules to be applied to the message marker
		 * Setter for markerStyle
		 * @param markerStyle - new value
		 */
		 public void setMarkerStyle( ValueExpression  __markerStyle ){
			this._markerStyle = __markerStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * minLevel
		 * Defines a minimum level of messages categories to display.
		 */
		private ValueExpression _minLevel;
		/**
		 * Defines a minimum level of messages categories to display.
		 * Setter for minLevel
		 * @param minLevel - new value
		 */
		 public void setMinLevel( ValueExpression  __minLevel ){
			this._minLevel = __minLevel;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * showDetail
		 * Flag indicating whether detailed information of a displayed messages should be included.  Default value is "true".
		 */
		private ValueExpression _showDetail;
		/**
		 * Flag indicating whether detailed information of a displayed messages should be included.  Default value is "true".
		 * Setter for showDetail
		 * @param showDetail - new value
		 */
		 public void setShowDetail( ValueExpression  __showDetail ){
			this._showDetail = __showDetail;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * showSummary
		 * Flag indicating whether the summary portion of displayed messages should be included.  Default value is "false".
		 */
		private ValueExpression _showSummary;
		/**
		 * Flag indicating whether the summary portion of displayed messages should be included.  Default value is "false".
		 * Setter for showSummary
		 * @param showSummary - new value
		 */
		 public void setShowSummary( ValueExpression  __showSummary ){
			this._showSummary = __showSummary;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * tooltip
		 * Flag indicating whether the detail portion of the message should be displayed as a tooltip.  Default value is "false".
		 */
		private ValueExpression _tooltip;
		/**
		 * Flag indicating whether the detail portion of the message should be displayed as a tooltip.  Default value is "false".
		 * Setter for tooltip
		 * @param tooltip - new value
		 */
		 public void setTooltip( ValueExpression  __tooltip ){
			this._tooltip = __tooltip;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * warnClass
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "WARN"
		 */
		private ValueExpression _warnClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message with a severity class of "WARN"
		 * Setter for warnClass
		 * @param warnClass - new value
		 */
		 public void setWarnClass( ValueExpression  __warnClass ){
			this._warnClass = __warnClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * warnLabelClass
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "WARN"
		 */
		private ValueExpression _warnLabelClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message label with a severity class of "WARN"
		 * Setter for warnLabelClass
		 * @param warnLabelClass - new value
		 */
		 public void setWarnLabelClass( ValueExpression  __warnLabelClass ){
			this._warnLabelClass = __warnLabelClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * warnMarkerClass
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class ofS "WARN"
		 */
		private ValueExpression _warnMarkerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the message marker with a severity class ofS "WARN"
		 * Setter for warnMarkerClass
		 * @param warnMarkerClass - new value
		 */
		 public void setWarnMarkerClass( ValueExpression  __warnMarkerClass ){
			this._warnMarkerClass = __warnMarkerClass;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		    this._ajaxRendered = null;
	 		 		 		    this._errorClass = null;
	 		 		    this._errorLabelClass = null;
	 		 		    this._errorMarkerClass = null;
	 		 		 		    this._fatalClass = null;
	 		 		    this._fatalLabelClass = null;
	 		 		    this._fatalMarkerClass = null;
	 		 		    this._for = null;
	 		 		 		    this._infoClass = null;
	 		 		    this._infoLabelClass = null;
	 		 		    this._infoMarkerClass = null;
	 		 		 		    this._labelClass = null;
	 		 		    this._level = null;
	 		 		    this._markerClass = null;
	 		 		    this._markerStyle = null;
	 		 		    this._minLevel = null;
	 		 		 		 		 		    this._showDetail = null;
	 		 		    this._showSummary = null;
	 		 		 		 		 		    this._tooltip = null;
	 		 		    this._warnClass = null;
	 		 		    this._warnLabelClass = null;
	 		 		    this._warnMarkerClass = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlRichMessage comp = (HtmlRichMessage) component;
 		 			 
						if (this._ajaxRendered != null) {
				if (this._ajaxRendered.isLiteralText()) {
					try {
												
						Boolean __ajaxRendered = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._ajaxRendered.getExpressionString(), 
											Boolean.class);
					
												comp.setAjaxRendered(__ajaxRendered.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("ajaxRendered", this._ajaxRendered);
				}
			}
					    		 			 
						if (this._errorClass != null) {
				if (this._errorClass.isLiteralText()) {
					try {
												
						java.lang.String __errorClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._errorClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setErrorClass(__errorClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("errorClass", this._errorClass);
				}
			}
					   		 			 
						if (this._errorLabelClass != null) {
				if (this._errorLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __errorLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._errorLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setErrorLabelClass(__errorLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("errorLabelClass", this._errorLabelClass);
				}
			}
					   		 			 
						if (this._errorMarkerClass != null) {
				if (this._errorMarkerClass.isLiteralText()) {
					try {
												
						java.lang.String __errorMarkerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._errorMarkerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setErrorMarkerClass(__errorMarkerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("errorMarkerClass", this._errorMarkerClass);
				}
			}
					    		 			 
						if (this._fatalClass != null) {
				if (this._fatalClass.isLiteralText()) {
					try {
												
						java.lang.String __fatalClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fatalClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFatalClass(__fatalClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fatalClass", this._fatalClass);
				}
			}
					   		 			 
						if (this._fatalLabelClass != null) {
				if (this._fatalLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __fatalLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fatalLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFatalLabelClass(__fatalLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fatalLabelClass", this._fatalLabelClass);
				}
			}
					   		 			 
						if (this._fatalMarkerClass != null) {
				if (this._fatalMarkerClass.isLiteralText()) {
					try {
												
						java.lang.String __fatalMarkerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fatalMarkerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFatalMarkerClass(__fatalMarkerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fatalMarkerClass", this._fatalMarkerClass);
				}
			}
					   		 			 
						if (this._for != null) {
				if (this._for.isLiteralText()) {
					try {
												
						java.lang.String __for = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._for.getExpressionString(), 
											java.lang.String.class);
					
												comp.setFor(__for);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("for", this._for);
				}
			}
					    		 			 
						if (this._infoClass != null) {
				if (this._infoClass.isLiteralText()) {
					try {
												
						java.lang.String __infoClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._infoClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInfoClass(__infoClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("infoClass", this._infoClass);
				}
			}
					   		 			 
						if (this._infoLabelClass != null) {
				if (this._infoLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __infoLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._infoLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInfoLabelClass(__infoLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("infoLabelClass", this._infoLabelClass);
				}
			}
					   		 			 
						if (this._infoMarkerClass != null) {
				if (this._infoMarkerClass.isLiteralText()) {
					try {
												
						java.lang.String __infoMarkerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._infoMarkerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setInfoMarkerClass(__infoMarkerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("infoMarkerClass", this._infoMarkerClass);
				}
			}
					    		 			 
						if (this._labelClass != null) {
				if (this._labelClass.isLiteralText()) {
					try {
												
						java.lang.String __labelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._labelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabelClass(__labelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("labelClass", this._labelClass);
				}
			}
					   		 			 
						if (this._level != null) {
				if (this._level.isLiteralText()) {
					try {
												
						java.lang.String __level = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._level.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLevel(__level);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("level", this._level);
				}
			}
					   		 			 
						if (this._markerClass != null) {
				if (this._markerClass.isLiteralText()) {
					try {
												
						java.lang.String __markerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._markerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMarkerClass(__markerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("markerClass", this._markerClass);
				}
			}
					   		 			 
						if (this._markerStyle != null) {
				if (this._markerStyle.isLiteralText()) {
					try {
												
						java.lang.String __markerStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._markerStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMarkerStyle(__markerStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("markerStyle", this._markerStyle);
				}
			}
					   		 			 
						if (this._minLevel != null) {
				if (this._minLevel.isLiteralText()) {
					try {
												
						java.lang.String __minLevel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._minLevel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMinLevel(__minLevel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("minLevel", this._minLevel);
				}
			}
					      		 			 
						if (this._showDetail != null) {
				if (this._showDetail.isLiteralText()) {
					try {
												
						Boolean __showDetail = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showDetail.getExpressionString(), 
											Boolean.class);
					
												comp.setShowDetail(__showDetail.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showDetail", this._showDetail);
				}
			}
					   		 			 
						if (this._showSummary != null) {
				if (this._showSummary.isLiteralText()) {
					try {
												
						Boolean __showSummary = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showSummary.getExpressionString(), 
											Boolean.class);
					
												comp.setShowSummary(__showSummary.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showSummary", this._showSummary);
				}
			}
					      		 			 
						if (this._tooltip != null) {
				if (this._tooltip.isLiteralText()) {
					try {
												
						Boolean __tooltip = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._tooltip.getExpressionString(), 
											Boolean.class);
					
												comp.setTooltip(__tooltip.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("tooltip", this._tooltip);
				}
			}
					   		 			 
						if (this._warnClass != null) {
				if (this._warnClass.isLiteralText()) {
					try {
												
						java.lang.String __warnClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._warnClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWarnClass(__warnClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("warnClass", this._warnClass);
				}
			}
					   		 			 
						if (this._warnLabelClass != null) {
				if (this._warnLabelClass.isLiteralText()) {
					try {
												
						java.lang.String __warnLabelClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._warnLabelClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWarnLabelClass(__warnLabelClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("warnLabelClass", this._warnLabelClass);
				}
			}
					   		 			 
						if (this._warnMarkerClass != null) {
				if (this._warnMarkerClass.isLiteralText()) {
					try {
												
						java.lang.String __warnMarkerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._warnMarkerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWarnMarkerClass(__warnMarkerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("warnMarkerClass", this._warnMarkerClass);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.component.RichMessage";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.RichMessageRenderer";
			}

}
