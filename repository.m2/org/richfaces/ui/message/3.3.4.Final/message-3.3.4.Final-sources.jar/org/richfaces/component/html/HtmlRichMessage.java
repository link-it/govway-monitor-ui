package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIRichMessage;

public class HtmlRichMessage extends UIRichMessage{

final static public  String COMPONENT_FAMILY = "org.richfaces.component.RichMessage";

final static public  String COMPONENT_TYPE = "org.richfaces.component.RichMessage";

/*
* Assigns one or more space-separated CSS class names to the message with a severity class of "ERROR"
*/
private  String _errorClass = null;

/*
* Assigns one or more space-separated CSS class names to the message label with a severity class of "ERROR"
*/
private  String _errorLabelClass = null;

/*
* Assigns one or more space-separated CSS class names to the message marker with a severity class of "ERROR"
*/
private  String _errorMarkerClass = null;

/*
* Assigns one or more space-separated CSS class names to the message with a severity class of "FATAL"
*/
private  String _fatalClass = null;

/*
* Assigns one or more space-separated CSS class names to the message label with a severity class of "FATAL"
*/
private  String _fatalLabelClass = null;

/*
* Assigns one or more space-separated CSS class names to the message marker with a severity class of "FATAL"
*/
private  String _fatalMarkerClass = null;

/*
* Assigns one or more space-separated CSS class names to the message with a severity class of "INFO"
*/
private  String _infoClass = null;

/*
* Assigns one or more space-separated CSS class names to the message label with a severity class of "INFO"
*/
private  String _infoLabelClass = null;

/*
* Assigns one or more space-separated CSS class names to the message marker with a severity class of "INFO"
*/
private  String _infoMarkerClass = null;

/*
* keepTransient
*/
private  boolean _keepTransient = false;

private  boolean _keepTransientSet = false;

/*
* Assigns one or more space-separated CSS class names to the message label
*/
private  String _labelClass = null;

/*
* Defines a comma-separated list of messages categories to display. Default value is "ALL".
*/
private  String _level = null;

/*
* Assigns one or more space-separated CSS class names to the message marker
*/
private  String _markerClass = null;

/*
* CSS style rules to be applied to the message marker
*/
private  String _markerStyle = null;

/*
* Defines a minimum level of messages categories to display.
*/
private  String _minLevel = null;

/*
* Attribute should define the label to be displayed when no message appears
*/
private  String _passedLabel = null;

/*
* CSS style rules to be applied to the component
*/
private  String _style = null;

/*
* Assigns one or more space-separated CSS class names to the component. Corresponds to the HTML "class" attribute.
*/
private  String _styleClass = null;

/*
* Advisory title information about markup elements generated for this component
*/
private  String _title = null;

/*
* Flag indicating whether the detail portion of the message should be displayed as a tooltip.  Default value is "false".
*/
private  boolean _tooltip = false;

private  boolean _tooltipSet = false;

/*
* Assigns one or more space-separated CSS class names to the message with a severity class of "WARN"
*/
private  String _warnClass = null;

/*
* Assigns one or more space-separated CSS class names to the message label with a severity class of "WARN"
*/
private  String _warnLabelClass = null;

/*
* Assigns one or more space-separated CSS class names to the message marker with a severity class ofS "WARN"
*/
private  String _warnMarkerClass = null;


public HtmlRichMessage(){
setRendererType("org.richfaces.RichMessageRenderer");
}

public String getErrorClass(){
	if (this._errorClass != null) {
		return this._errorClass;
	}
	ValueExpression ve = getValueExpression("errorClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setErrorClass(String _errorClass){
this._errorClass = _errorClass;
}

public String getErrorLabelClass(){
	if (this._errorLabelClass != null) {
		return this._errorLabelClass;
	}
	ValueExpression ve = getValueExpression("errorLabelClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setErrorLabelClass(String _errorLabelClass){
this._errorLabelClass = _errorLabelClass;
}

public String getErrorMarkerClass(){
	if (this._errorMarkerClass != null) {
		return this._errorMarkerClass;
	}
	ValueExpression ve = getValueExpression("errorMarkerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setErrorMarkerClass(String _errorMarkerClass){
this._errorMarkerClass = _errorMarkerClass;
}

public String getFatalClass(){
	if (this._fatalClass != null) {
		return this._fatalClass;
	}
	ValueExpression ve = getValueExpression("fatalClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFatalClass(String _fatalClass){
this._fatalClass = _fatalClass;
}

public String getFatalLabelClass(){
	if (this._fatalLabelClass != null) {
		return this._fatalLabelClass;
	}
	ValueExpression ve = getValueExpression("fatalLabelClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFatalLabelClass(String _fatalLabelClass){
this._fatalLabelClass = _fatalLabelClass;
}

public String getFatalMarkerClass(){
	if (this._fatalMarkerClass != null) {
		return this._fatalMarkerClass;
	}
	ValueExpression ve = getValueExpression("fatalMarkerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setFatalMarkerClass(String _fatalMarkerClass){
this._fatalMarkerClass = _fatalMarkerClass;
}

public String getInfoClass(){
	if (this._infoClass != null) {
		return this._infoClass;
	}
	ValueExpression ve = getValueExpression("infoClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setInfoClass(String _infoClass){
this._infoClass = _infoClass;
}

public String getInfoLabelClass(){
	if (this._infoLabelClass != null) {
		return this._infoLabelClass;
	}
	ValueExpression ve = getValueExpression("infoLabelClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setInfoLabelClass(String _infoLabelClass){
this._infoLabelClass = _infoLabelClass;
}

public String getInfoMarkerClass(){
	if (this._infoMarkerClass != null) {
		return this._infoMarkerClass;
	}
	ValueExpression ve = getValueExpression("infoMarkerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setInfoMarkerClass(String _infoMarkerClass){
this._infoMarkerClass = _infoMarkerClass;
}

public boolean isKeepTransient(){
	if (this._keepTransientSet) {
	    return (this._keepTransient);
	}
	ValueExpression ve = getValueExpression("keepTransient");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._keepTransient);
	    }
	    
	    return value;
	} else {
	    return (this._keepTransient);
	}

}

public void setKeepTransient(boolean _keepTransient){
this._keepTransient = _keepTransient;
this._keepTransientSet = true;
}

public String getLabelClass(){
	if (this._labelClass != null) {
		return this._labelClass;
	}
	ValueExpression ve = getValueExpression("labelClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setLabelClass(String _labelClass){
this._labelClass = _labelClass;
}

public String getLevel(){
	if (this._level != null) {
		return this._level;
	}
	ValueExpression ve = getValueExpression("level");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setLevel(String _level){
this._level = _level;
}

public String getMarkerClass(){
	if (this._markerClass != null) {
		return this._markerClass;
	}
	ValueExpression ve = getValueExpression("markerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setMarkerClass(String _markerClass){
this._markerClass = _markerClass;
}

public String getMarkerStyle(){
	if (this._markerStyle != null) {
		return this._markerStyle;
	}
	ValueExpression ve = getValueExpression("markerStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setMarkerStyle(String _markerStyle){
this._markerStyle = _markerStyle;
}

public String getMinLevel(){
	if (this._minLevel != null) {
		return this._minLevel;
	}
	ValueExpression ve = getValueExpression("minLevel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setMinLevel(String _minLevel){
this._minLevel = _minLevel;
}

public String getPassedLabel(){
	if (this._passedLabel != null) {
		return this._passedLabel;
	}
	ValueExpression ve = getValueExpression("passedLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setPassedLabel(String _passedLabel){
this._passedLabel = _passedLabel;
}

public String getStyle(){
	if (this._style != null) {
		return this._style;
	}
	ValueExpression ve = getValueExpression("style");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyle(String _style){
this._style = _style;
}

public String getStyleClass(){
	if (this._styleClass != null) {
		return this._styleClass;
	}
	ValueExpression ve = getValueExpression("styleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyleClass(String _styleClass){
this._styleClass = _styleClass;
}

public String getTitle(){
	if (this._title != null) {
		return this._title;
	}
	ValueExpression ve = getValueExpression("title");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setTitle(String _title){
this._title = _title;
}

public boolean isTooltip(){
	if (this._tooltipSet) {
	    return (this._tooltip);
	}
	ValueExpression ve = getValueExpression("tooltip");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._tooltip);
	    }
	    
	    return value;
	} else {
	    return (this._tooltip);
	}

}

public void setTooltip(boolean _tooltip){
this._tooltip = _tooltip;
this._tooltipSet = true;
}

public String getWarnClass(){
	if (this._warnClass != null) {
		return this._warnClass;
	}
	ValueExpression ve = getValueExpression("warnClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setWarnClass(String _warnClass){
this._warnClass = _warnClass;
}

public String getWarnLabelClass(){
	if (this._warnLabelClass != null) {
		return this._warnLabelClass;
	}
	ValueExpression ve = getValueExpression("warnLabelClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setWarnLabelClass(String _warnLabelClass){
this._warnLabelClass = _warnLabelClass;
}

public String getWarnMarkerClass(){
	if (this._warnMarkerClass != null) {
		return this._warnMarkerClass;
	}
	ValueExpression ve = getValueExpression("warnMarkerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setWarnMarkerClass(String _warnMarkerClass){
this._warnMarkerClass = _warnMarkerClass;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[26];
state[0] = super.saveState(context);
state[1] = _errorClass;
state[2] = _errorLabelClass;
state[3] = _errorMarkerClass;
state[4] = _fatalClass;
state[5] = _fatalLabelClass;
state[6] = _fatalMarkerClass;
state[7] = _infoClass;
state[8] = _infoLabelClass;
state[9] = _infoMarkerClass;
state[10] = Boolean.valueOf(_keepTransient);
state[11] = Boolean.valueOf(_keepTransientSet);
state[12] = _labelClass;
state[13] = _level;
state[14] = _markerClass;
state[15] = _markerStyle;
state[16] = _minLevel;
state[17] = _passedLabel;
state[18] = _style;
state[19] = _styleClass;
state[20] = _title;
state[21] = Boolean.valueOf(_tooltip);
state[22] = Boolean.valueOf(_tooltipSet);
state[23] = _warnClass;
state[24] = _warnLabelClass;
state[25] = _warnMarkerClass;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_errorClass = (String)states[1];;
		_errorLabelClass = (String)states[2];;
		_errorMarkerClass = (String)states[3];;
		_fatalClass = (String)states[4];;
		_fatalLabelClass = (String)states[5];;
		_fatalMarkerClass = (String)states[6];;
		_infoClass = (String)states[7];;
		_infoLabelClass = (String)states[8];;
		_infoMarkerClass = (String)states[9];;
		_keepTransient = ((Boolean)states[10]).booleanValue();
		_keepTransientSet = ((Boolean)states[11]).booleanValue();
		_labelClass = (String)states[12];;
		_level = (String)states[13];;
		_markerClass = (String)states[14];;
		_markerStyle = (String)states[15];;
		_minLevel = (String)states[16];;
		_passedLabel = (String)states[17];;
		_style = (String)states[18];;
		_styleClass = (String)states[19];;
		_title = (String)states[20];;
		_tooltip = ((Boolean)states[21]).booleanValue();
		_tooltipSet = ((Boolean)states[22]).booleanValue();
		_warnClass = (String)states[23];;
		_warnLabelClass = (String)states[24];;
		_warnMarkerClass = (String)states[25];;
	
}

}
