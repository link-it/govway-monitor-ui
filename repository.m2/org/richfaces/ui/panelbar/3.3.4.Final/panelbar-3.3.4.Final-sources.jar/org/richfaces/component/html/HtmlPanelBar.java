package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIPanelBar;

public class HtmlPanelBar extends UIPanelBar{

public static final  String COMPONENT_FAMILY = "org.richfaces.PanelBar";

public static final  String COMPONENT_TYPE = "org.richfaces.PanelBar";

/*
* Assigns one or more space-separated CSS class names to the component content
*/
private  String _contentClass = null;

/*
* CSS style rules to be applied to the component content
*/
private  String _contentStyle = null;

/*
* Assigns one or more space-separated CSS class names to the component header
*/
private  String _headerClass = null;

/*
* Assigns one or more space-separated CSS class names to the header of the active component item
*/
private  String _headerClassActive = null;

/*
* CSS style rules to be applied to the component header
*/
private  String _headerStyle = null;

/*
* CSS style rules to be applied to the header of the active component item
*/
private  String _headerStyleActive = null;

/*
* The height of the slide panel. Might be defined as pixels or as percentage.
	    		Default value is "100%".
*/
private  String _height = null;

/*
* The client-side script method to be called when a panel bar is clicked
*/
private  String _onclick = null;

/*
* The client-side script method to be called when a panel bar item is changed
*/
private  String _onitemchange = null;

/*
* The client-side script method to be called after a panel bar item has been changed
*/
private  String _onitemchanged = null;

/*
* The client-side script method to be called when a pointer is moved within the component
*/
private  String _onmousemove = null;

/*
* The client-side script method to be called when a pointer is moved away from the component
*/
private  String _onmouseout = null;

/*
* The client-side script method to be called when a pointer is moved onto the component
*/
private  String _onmouseover = null;

/*
* Attribure defines name of selected item
*/
private  Object _selectedPanel = null;

/*
* CSS style rules to be applied to the component
*/
private  String _style = null;

/*
* Assigns one or more space-separated CSS class names to the component. Corresponds to the HTML "class" attribute.
*/
private  String _styleClass = null;

/*
* The width of the slide panel. Might be defined as pixels or as percentage.
	    	Default value is "100%".
*/
private  String _width = null;


public HtmlPanelBar(){
setRendererType("org.richfaces.PanelBarRenderer");
}

public String getContentClass(){
	if (this._contentClass != null) {
		return this._contentClass;
	}
	ValueExpression ve = getValueExpression("contentClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setContentClass(String _contentClass){
this._contentClass = _contentClass;
}

public String getContentStyle(){
	if (this._contentStyle != null) {
		return this._contentStyle;
	}
	ValueExpression ve = getValueExpression("contentStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setContentStyle(String _contentStyle){
this._contentStyle = _contentStyle;
}

public String getHeaderClass(){
	if (this._headerClass != null) {
		return this._headerClass;
	}
	ValueExpression ve = getValueExpression("headerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setHeaderClass(String _headerClass){
this._headerClass = _headerClass;
}

public String getHeaderClassActive(){
	if (this._headerClassActive != null) {
		return this._headerClassActive;
	}
	ValueExpression ve = getValueExpression("headerClassActive");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setHeaderClassActive(String _headerClassActive){
this._headerClassActive = _headerClassActive;
}

public String getHeaderStyle(){
	if (this._headerStyle != null) {
		return this._headerStyle;
	}
	ValueExpression ve = getValueExpression("headerStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setHeaderStyle(String _headerStyle){
this._headerStyle = _headerStyle;
}

public String getHeaderStyleActive(){
	if (this._headerStyleActive != null) {
		return this._headerStyleActive;
	}
	ValueExpression ve = getValueExpression("headerStyleActive");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setHeaderStyleActive(String _headerStyleActive){
this._headerStyleActive = _headerStyleActive;
}

public String getHeight(){
	if (this._height != null) {
		return this._height;
	}
	ValueExpression ve = getValueExpression("height");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "100%";
	

}

public void setHeight(String _height){
this._height = _height;
}

public String getOnclick(){
	if (this._onclick != null) {
		return this._onclick;
	}
	ValueExpression ve = getValueExpression("onclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnclick(String _onclick){
this._onclick = _onclick;
}

public String getOnitemchange(){
	if (this._onitemchange != null) {
		return this._onitemchange;
	}
	ValueExpression ve = getValueExpression("onitemchange");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnitemchange(String _onitemchange){
this._onitemchange = _onitemchange;
}

public String getOnitemchanged(){
	if (this._onitemchanged != null) {
		return this._onitemchanged;
	}
	ValueExpression ve = getValueExpression("onitemchanged");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnitemchanged(String _onitemchanged){
this._onitemchanged = _onitemchanged;
}

public String getOnmousemove(){
	if (this._onmousemove != null) {
		return this._onmousemove;
	}
	ValueExpression ve = getValueExpression("onmousemove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnmousemove(String _onmousemove){
this._onmousemove = _onmousemove;
}

public String getOnmouseout(){
	if (this._onmouseout != null) {
		return this._onmouseout;
	}
	ValueExpression ve = getValueExpression("onmouseout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnmouseout(String _onmouseout){
this._onmouseout = _onmouseout;
}

public String getOnmouseover(){
	if (this._onmouseover != null) {
		return this._onmouseover;
	}
	ValueExpression ve = getValueExpression("onmouseover");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnmouseover(String _onmouseover){
this._onmouseover = _onmouseover;
}

public Object getSelectedPanel(){
	if (this._selectedPanel != null) {
		return this._selectedPanel;
	}
	ValueExpression ve = getValueExpression("selectedPanel");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setSelectedPanel(Object _selectedPanel){
this._selectedPanel = _selectedPanel;
}

public String getStyle(){
	if (this._style != null) {
		return this._style;
	}
	ValueExpression ve = getValueExpression("style");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setStyle(String _style){
this._style = _style;
}

public String getStyleClass(){
	if (this._styleClass != null) {
		return this._styleClass;
	}
	ValueExpression ve = getValueExpression("styleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyleClass(String _styleClass){
this._styleClass = _styleClass;
}

public String getWidth(){
	if (this._width != null) {
		return this._width;
	}
	ValueExpression ve = getValueExpression("width");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "100%";
	

}

public void setWidth(String _width){
this._width = _width;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[18];
state[0] = super.saveState(context);
state[1] = _contentClass;
state[2] = _contentStyle;
state[3] = _headerClass;
state[4] = _headerClassActive;
state[5] = _headerStyle;
state[6] = _headerStyleActive;
state[7] = _height;
state[8] = _onclick;
state[9] = _onitemchange;
state[10] = _onitemchanged;
state[11] = _onmousemove;
state[12] = _onmouseout;
state[13] = _onmouseover;
state[14] = saveAttachedState(context, _selectedPanel);
state[15] = _style;
state[16] = _styleClass;
state[17] = _width;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_contentClass = (String)states[1];;
		_contentStyle = (String)states[2];;
		_headerClass = (String)states[3];;
		_headerClassActive = (String)states[4];;
		_headerStyle = (String)states[5];;
		_headerStyleActive = (String)states[6];;
		_height = (String)states[7];;
		_onclick = (String)states[8];;
		_onitemchange = (String)states[9];;
		_onitemchanged = (String)states[10];;
		_onmousemove = (String)states[11];;
		_onmouseout = (String)states[12];;
		_onmouseover = (String)states[13];;
		_selectedPanel = (Object)restoreAttachedState(context, states[14]);
		_style = (String)states[15];;
		_styleClass = (String)states[16];;
		_width = (String)states[17];;
	
}

}
