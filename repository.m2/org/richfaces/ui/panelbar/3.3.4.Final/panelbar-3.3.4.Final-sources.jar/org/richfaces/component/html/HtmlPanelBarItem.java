package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIPanelBarItem;

public class HtmlPanelBarItem extends UIPanelBarItem{

static public final  String COMPONENT_FAMILY = "org.richfaces.PanelBarItem";

static public final  String COMPONENT_TYPE = "org.richfaces.PanelBarItem";

/*
* Assigns one or more space-separated CSS class names to the component content
*/
private  String _contentClass = null;

/*
* CSS style rules to be applied to the component content
*/
private  String _contentStyle = null;

/*
* Notifies that an element has to be expanded. Default value is "false".
*/
private  String _expanded = null;

/*
* Assigns one or more space-separated CSS class names to the component header
*/
private  String _headerClass = null;

/*
* Assigns one or more space-separated CSS class names to the header of the active item
*/
private  String _headerClassActive = null;

/*
* CSS style rules to be applied to the component header
*/
private  String _headerStyle = null;

/*
* CSS style rules to be applied to the header of the active item
*/
private  String _headerStyleActive = null;

/*
* Label text appears on a panel item header. Default value is "auto generated label"
*/
private  String _label = null;

/*
* Attribute defines item name. Default value is "getId()".
*/
private  Object _name = null;

/*
* The client-side script method to be called when a panel bar item is opened
*/
private  String _onenter = null;

/*
* The client-side script method to be called when a panel bar item is leaved
*/
private  String _onleave = null;


public HtmlPanelBarItem(){
setRendererType("org.richfaces.PanelBarItemRenderer");
}

public String getContentClass(){
	if (this._contentClass != null) {
		return this._contentClass;
	}
	ValueExpression ve = getValueExpression("contentClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setContentClass(String _contentClass){
this._contentClass = _contentClass;
}

public String getContentStyle(){
	if (this._contentStyle != null) {
		return this._contentStyle;
	}
	ValueExpression ve = getValueExpression("contentStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setContentStyle(String _contentStyle){
this._contentStyle = _contentStyle;
}

public String getExpanded(){
	if (this._expanded != null) {
		return this._expanded;
	}
	ValueExpression ve = getValueExpression("expanded");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "false";
	

}

public void setExpanded(String _expanded){
this._expanded = _expanded;
}

public String getHeaderClass(){
	if (this._headerClass != null) {
		return this._headerClass;
	}
	ValueExpression ve = getValueExpression("headerClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setHeaderClass(String _headerClass){
this._headerClass = _headerClass;
}

public String getHeaderClassActive(){
	if (this._headerClassActive != null) {
		return this._headerClassActive;
	}
	ValueExpression ve = getValueExpression("headerClassActive");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setHeaderClassActive(String _headerClassActive){
this._headerClassActive = _headerClassActive;
}

public String getHeaderStyle(){
	if (this._headerStyle != null) {
		return this._headerStyle;
	}
	ValueExpression ve = getValueExpression("headerStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setHeaderStyle(String _headerStyle){
this._headerStyle = _headerStyle;
}

public String getHeaderStyleActive(){
	if (this._headerStyleActive != null) {
		return this._headerStyleActive;
	}
	ValueExpression ve = getValueExpression("headerStyleActive");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setHeaderStyleActive(String _headerStyleActive){
this._headerStyleActive = _headerStyleActive;
}

public String getLabel(){
	if (this._label != null) {
		return this._label;
	}
	ValueExpression ve = getValueExpression("label");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "auto generated label";
	

}

public void setLabel(String _label){
this._label = _label;
}

public Object getName(){
	if (this._name != null) {
		return this._name;
	}
	ValueExpression ve = getValueExpression("name");
	if (ve != null) {
	    Object value = null;
	    
	    try {
			value = (Object) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return getId();
	

}

public void setName(Object _name){
this._name = _name;
}

public String getOnenter(){
	if (this._onenter != null) {
		return this._onenter;
	}
	ValueExpression ve = getValueExpression("onenter");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnenter(String _onenter){
this._onenter = _onenter;
}

public String getOnleave(){
	if (this._onleave != null) {
		return this._onleave;
	}
	ValueExpression ve = getValueExpression("onleave");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setOnleave(String _onleave){
this._onleave = _onleave;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[12];
state[0] = super.saveState(context);
state[1] = _contentClass;
state[2] = _contentStyle;
state[3] = _expanded;
state[4] = _headerClass;
state[5] = _headerClassActive;
state[6] = _headerStyle;
state[7] = _headerStyleActive;
state[8] = _label;
state[9] = saveAttachedState(context, _name);
state[10] = _onenter;
state[11] = _onleave;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_contentClass = (String)states[1];;
		_contentStyle = (String)states[2];;
		_expanded = (String)states[3];;
		_headerClass = (String)states[4];;
		_headerClassActive = (String)states[5];;
		_headerStyle = (String)states[6];;
		_headerStyleActive = (String)states[7];;
		_label = (String)states[8];;
		_name = (Object)restoreAttachedState(context, states[9]);
		_onenter = (String)states[10];;
		_onleave = (String)states[11];;
	
}

}
