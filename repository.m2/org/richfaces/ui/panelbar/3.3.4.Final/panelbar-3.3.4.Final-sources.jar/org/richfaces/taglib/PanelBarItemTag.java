/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPanelBarItem;

public class PanelBarItemTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * contentClass
		 * Assigns one or more space-separated CSS class names to the component content
		 */
		private ValueExpression _contentClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component content
		 * Setter for contentClass
		 * @param contentClass - new value
		 */
		 public void setContentClass( ValueExpression  __contentClass ){
			this._contentClass = __contentClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * contentStyle
		 * CSS style rules to be applied to the component content
		 */
		private ValueExpression _contentStyle;
		/**
		 * CSS style rules to be applied to the component content
		 * Setter for contentStyle
		 * @param contentStyle - new value
		 */
		 public void setContentStyle( ValueExpression  __contentStyle ){
			this._contentStyle = __contentStyle;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the component header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerClassActive
		 * Assigns one or more space-separated CSS class names to the header of the active item
		 */
		private ValueExpression _headerClassActive;
		/**
		 * Assigns one or more space-separated CSS class names to the header of the active item
		 * Setter for headerClassActive
		 * @param headerClassActive - new value
		 */
		 public void setHeaderClassActive( ValueExpression  __headerClassActive ){
			this._headerClassActive = __headerClassActive;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerStyle
		 * CSS style rules to be applied to the component header
		 */
		private ValueExpression _headerStyle;
		/**
		 * CSS style rules to be applied to the component header
		 * Setter for headerStyle
		 * @param headerStyle - new value
		 */
		 public void setHeaderStyle( ValueExpression  __headerStyle ){
			this._headerStyle = __headerStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerStyleActive
		 * CSS style rules to be applied to the header of the active item
		 */
		private ValueExpression _headerStyleActive;
		/**
		 * CSS style rules to be applied to the header of the active item
		 * Setter for headerStyleActive
		 * @param headerStyleActive - new value
		 */
		 public void setHeaderStyleActive( ValueExpression  __headerStyleActive ){
			this._headerStyleActive = __headerStyleActive;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * label
		 * Label text appears on a panel item header. Default value is "auto generated label"
		 */
		private ValueExpression _label;
		/**
		 * Label text appears on a panel item header. Default value is "auto generated label"
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * name
		 * Attribute defines item name. Default value is "getId()".
		 */
		private ValueExpression _name;
		/**
		 * Attribute defines item name. Default value is "getId()".
		 * Setter for name
		 * @param name - new value
		 */
		 public void setName( ValueExpression  __name ){
			this._name = __name;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onenter
		 * The client-side script method to be called when a panel bar item is opened
		 */
		private ValueExpression _onenter;
		/**
		 * The client-side script method to be called when a panel bar item is opened
		 * Setter for onenter
		 * @param onenter - new value
		 */
		 public void setOnenter( ValueExpression  __onenter ){
			this._onenter = __onenter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onleave
		 * The client-side script method to be called when a panel bar item is leaved
		 */
		private ValueExpression _onleave;
		/**
		 * The client-side script method to be called when a panel bar item is leaved
		 * Setter for onleave
		 * @param onleave - new value
		 */
		 public void setOnleave( ValueExpression  __onleave ){
			this._onleave = __onleave;
	     }
	  
	 	 		 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._contentClass = null;
	 		 		    this._contentStyle = null;
	 		 		 		 		    this._headerClass = null;
	 		 		    this._headerClassActive = null;
	 		 		    this._headerStyle = null;
	 		 		    this._headerStyleActive = null;
	 		 		 		    this._label = null;
	 		 		    this._name = null;
	 		 		    this._onenter = null;
	 		 		    this._onleave = null;
	 		 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPanelBarItem comp = (HtmlPanelBarItem) component;
  		 			 
						if (this._contentClass != null) {
				if (this._contentClass.isLiteralText()) {
					try {
												
						java.lang.String __contentClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentClass(__contentClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentClass", this._contentClass);
				}
			}
					   		 			 
						if (this._contentStyle != null) {
				if (this._contentStyle.isLiteralText()) {
					try {
												
						java.lang.String __contentStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentStyle(__contentStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentStyle", this._contentStyle);
				}
			}
					     		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					   		 			 
						if (this._headerClassActive != null) {
				if (this._headerClassActive.isLiteralText()) {
					try {
												
						java.lang.String __headerClassActive = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClassActive.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClassActive(__headerClassActive);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClassActive", this._headerClassActive);
				}
			}
					   		 			 
						if (this._headerStyle != null) {
				if (this._headerStyle.isLiteralText()) {
					try {
												
						java.lang.String __headerStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderStyle(__headerStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerStyle", this._headerStyle);
				}
			}
					   		 			 
						if (this._headerStyleActive != null) {
				if (this._headerStyleActive.isLiteralText()) {
					try {
												
						java.lang.String __headerStyleActive = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerStyleActive.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderStyleActive(__headerStyleActive);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerStyleActive", this._headerStyleActive);
				}
			}
					    		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					   		 			 
						if (this._name != null) {
				if (this._name.isLiteralText()) {
					try {
												
						java.lang.Object __name = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._name.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setName(__name);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("name", this._name);
				}
			}
					   		 			 
						if (this._onenter != null) {
				if (this._onenter.isLiteralText()) {
					try {
												
						java.lang.String __onenter = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onenter.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnenter(__onenter);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onenter", this._onenter);
				}
			}
					   		 			 
						if (this._onleave != null) {
				if (this._onleave.isLiteralText()) {
					try {
												
						java.lang.String __onleave = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onleave.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnleave(__onleave);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onleave", this._onleave);
				}
			}
					       }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.PanelBarItem";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.PanelBarItemRenderer";
			}

}
