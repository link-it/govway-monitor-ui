/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPanelBar;

public class PanelBarTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * contentClass
		 * Assigns one or more space-separated CSS class names to the component content
		 */
		private ValueExpression _contentClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component content
		 * Setter for contentClass
		 * @param contentClass - new value
		 */
		 public void setContentClass( ValueExpression  __contentClass ){
			this._contentClass = __contentClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * contentStyle
		 * CSS style rules to be applied to the component content
		 */
		private ValueExpression _contentStyle;
		/**
		 * CSS style rules to be applied to the component content
		 * Setter for contentStyle
		 * @param contentStyle - new value
		 */
		 public void setContentStyle( ValueExpression  __contentStyle ){
			this._contentStyle = __contentStyle;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * headerClass
		 * Assigns one or more space-separated CSS class names to the component header
		 */
		private ValueExpression _headerClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component header
		 * Setter for headerClass
		 * @param headerClass - new value
		 */
		 public void setHeaderClass( ValueExpression  __headerClass ){
			this._headerClass = __headerClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerClassActive
		 * Assigns one or more space-separated CSS class names to the header of the active component item
		 */
		private ValueExpression _headerClassActive;
		/**
		 * Assigns one or more space-separated CSS class names to the header of the active component item
		 * Setter for headerClassActive
		 * @param headerClassActive - new value
		 */
		 public void setHeaderClassActive( ValueExpression  __headerClassActive ){
			this._headerClassActive = __headerClassActive;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerStyle
		 * CSS style rules to be applied to the component header
		 */
		private ValueExpression _headerStyle;
		/**
		 * CSS style rules to be applied to the component header
		 * Setter for headerStyle
		 * @param headerStyle - new value
		 */
		 public void setHeaderStyle( ValueExpression  __headerStyle ){
			this._headerStyle = __headerStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * headerStyleActive
		 * CSS style rules to be applied to the header of the active component item
		 */
		private ValueExpression _headerStyleActive;
		/**
		 * CSS style rules to be applied to the header of the active component item
		 * Setter for headerStyleActive
		 * @param headerStyleActive - new value
		 */
		 public void setHeaderStyleActive( ValueExpression  __headerStyleActive ){
			this._headerStyleActive = __headerStyleActive;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * height
		 * The height of the slide panel. Might be defined as pixels or as percentage.
	    		Default value is "100%".
		 */
		private ValueExpression _height;
		/**
		 * The height of the slide panel. Might be defined as pixels or as percentage.
	    		Default value is "100%".
		 * Setter for height
		 * @param height - new value
		 */
		 public void setHeight( ValueExpression  __height ){
			this._height = __height;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * onitemchange
		 * The client-side script method to be called when a panel bar item is changed
		 */
		private ValueExpression _onitemchange;
		/**
		 * The client-side script method to be called when a panel bar item is changed
		 * Setter for onitemchange
		 * @param onitemchange - new value
		 */
		 public void setOnitemchange( ValueExpression  __onitemchange ){
			this._onitemchange = __onitemchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onitemchanged
		 * The client-side script method to be called after a panel bar item has been changed
		 */
		private ValueExpression _onitemchanged;
		/**
		 * The client-side script method to be called after a panel bar item has been changed
		 * Setter for onitemchanged
		 * @param onitemchanged - new value
		 */
		 public void setOnitemchanged( ValueExpression  __onitemchanged ){
			this._onitemchanged = __onitemchanged;
	     }
	  
	 	 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * selectedPanel
		 * Attribure defines name of selected item
		 */
		private ValueExpression _selectedPanel;
		/**
		 * Attribure defines name of selected item
		 * Setter for selectedPanel
		 * @param selectedPanel - new value
		 */
		 public void setSelectedPanel( ValueExpression  __selectedPanel ){
			this._selectedPanel = __selectedPanel;
	     }
	  
	 	 		 		 		 		 		 		 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * width
		 * The width of the slide panel. Might be defined as pixels or as percentage.
	    	Default value is "100%".
		 */
		private ValueExpression _width;
		/**
		 * The width of the slide panel. Might be defined as pixels or as percentage.
	    	Default value is "100%".
		 * Setter for width
		 * @param width - new value
		 */
		 public void setWidth( ValueExpression  __width ){
			this._width = __width;
	     }
	  
	 	 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._contentClass = null;
	 		 		    this._contentStyle = null;
	 		 		 		 		 		    this._headerClass = null;
	 		 		    this._headerClassActive = null;
	 		 		    this._headerStyle = null;
	 		 		    this._headerStyleActive = null;
	 		 		    this._height = null;
	 		 		 		    this._immediate = null;
	 		 		 		 		 		    this._onitemchange = null;
	 		 		    this._onitemchanged = null;
	 		 		 		 		 		 		 		 		    this._selectedPanel = null;
	 		 		 		 		 		 		 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		 		    this._width = null;
	 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPanelBar comp = (HtmlPanelBar) component;
  		 			 
						if (this._contentClass != null) {
				if (this._contentClass.isLiteralText()) {
					try {
												
						java.lang.String __contentClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentClass(__contentClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentClass", this._contentClass);
				}
			}
					   		 			 
						if (this._contentStyle != null) {
				if (this._contentStyle.isLiteralText()) {
					try {
												
						java.lang.String __contentStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._contentStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setContentStyle(__contentStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("contentStyle", this._contentStyle);
				}
			}
					      		 			 
						if (this._headerClass != null) {
				if (this._headerClass.isLiteralText()) {
					try {
												
						java.lang.String __headerClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClass(__headerClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClass", this._headerClass);
				}
			}
					   		 			 
						if (this._headerClassActive != null) {
				if (this._headerClassActive.isLiteralText()) {
					try {
												
						java.lang.String __headerClassActive = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerClassActive.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderClassActive(__headerClassActive);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerClassActive", this._headerClassActive);
				}
			}
					   		 			 
						if (this._headerStyle != null) {
				if (this._headerStyle.isLiteralText()) {
					try {
												
						java.lang.String __headerStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderStyle(__headerStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerStyle", this._headerStyle);
				}
			}
					   		 			 
						if (this._headerStyleActive != null) {
				if (this._headerStyleActive.isLiteralText()) {
					try {
												
						java.lang.String __headerStyleActive = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._headerStyleActive.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeaderStyleActive(__headerStyleActive);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("headerStyleActive", this._headerStyleActive);
				}
			}
					   		 			 
						if (this._height != null) {
				if (this._height.isLiteralText()) {
					try {
												
						java.lang.String __height = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._height.getExpressionString(), 
											java.lang.String.class);
					
												comp.setHeight(__height);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("height", this._height);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					      		 			 
						if (this._onitemchange != null) {
				if (this._onitemchange.isLiteralText()) {
					try {
												
						java.lang.String __onitemchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onitemchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnitemchange(__onitemchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onitemchange", this._onitemchange);
				}
			}
					   		 			 
						if (this._onitemchanged != null) {
				if (this._onitemchanged.isLiteralText()) {
					try {
												
						java.lang.String __onitemchanged = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onitemchanged.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnitemchanged(__onitemchanged);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onitemchanged", this._onitemchanged);
				}
			}
					         		 			 
						if (this._selectedPanel != null) {
				if (this._selectedPanel.isLiteralText()) {
					try {
												
						java.lang.Object __selectedPanel = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._selectedPanel.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setSelectedPanel(__selectedPanel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("selectedPanel", this._selectedPanel);
				}
			}
					          		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		    		 			 
						if (this._width != null) {
				if (this._width.isLiteralText()) {
					try {
												
						java.lang.String __width = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._width.getExpressionString(), 
											java.lang.String.class);
					
												comp.setWidth(__width);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("width", this._width);
				}
			}
					     }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.PanelBar";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.PanelBarRenderer";
			}

}
