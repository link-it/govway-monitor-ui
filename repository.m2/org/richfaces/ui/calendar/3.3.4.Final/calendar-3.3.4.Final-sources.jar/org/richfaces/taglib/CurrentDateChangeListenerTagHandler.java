/**
 * GENERATED FILE - DO NOT EDIT
 *
 */

package org.richfaces.taglib;

import javax.faces.component.UIComponent;
import org.richfaces.component.UICalendar;

import java.io.IOException;

import javax.faces.*;
import javax.faces.el.*;

import javax.el.*;

import com.sun.facelets.*;
import com.sun.facelets.el.*;
import com.sun.facelets.tag.*;
import com.sun.facelets.tag.jsf.*;

public class CurrentDateChangeListenerTagHandler extends TagHandler {

	private Class listenerType;

    private final TagAttribute type;

    private final TagAttribute binding;

	public CurrentDateChangeListenerTagHandler(TagConfig config) {
	    super(config);
		this.binding = this.getAttribute("binding");
        this.type = this.getAttribute("type");
        if (type != null) {
            if (!type.isLiteral()) {
                throw new TagAttributeException(this.tag, this.type, "Must be literal");
            }
            try {
                this.listenerType = Class.forName(type.getValue());
            } catch (Exception e) {
                throw new TagAttributeException(this.tag, this.type, e);
            }
        }
  	}

  	 public void apply(FaceletContext ctx, UIComponent parent)
            throws IOException, FacesException, FaceletException, ELException {
        if (parent instanceof org.richfaces.component.UICalendar) {
            // only process if parent was just created
            if (parent.getParent() == null) {
                org.richfaces.component.UICalendar src = (org.richfaces.component.UICalendar) parent;
                org.richfaces.event.CurrentDateChangeListener listener = null;
                ValueExpression ve = null;
                if (this.binding != null) {
                    ve = this.binding.getValueExpression(ctx,
                            org.richfaces.event.CurrentDateChangeListener.class);
                    listener = (org.richfaces.event.CurrentDateChangeListener) ve.getValue(ctx);
                }
                if (listener == null) {
                    try {
                        listener = (org.richfaces.event.CurrentDateChangeListener) listenerType.newInstance();
                    } catch (Exception e) {
                        throw new TagAttributeException(this.tag, this.type, e.getCause());
                    }
                    if (ve != null) {
                        ve.setValue(ctx, ve);
                    }
                }
				
                src.addCurrentDateChangeListener(listener);
            }
        } else {
            throw new TagException(this.tag,
                    "Parent is not of type org.richfaces.component.UICalendar, type is: " + parent);
        }
    }
  	
}
