/**
 * GENERATED FILE - DO NOT EDIT
 *
 */
package org.richfaces.taglib;

import org.ajax4jsf.webapp.taglib.HtmlComponentTagBase ;
import javax.faces.convert.Converter ;
import java.lang.Object ;
import java.lang.String ;
import javax.faces.el.MethodBinding ;
import javax.faces.component.UIComponent ;

import javax.el.ELException;
import javax.faces.FacesException;
import javax.faces.component.UIComponent;
import javax.el.MethodExpression;
import javax.faces.el.MethodBinding;
import javax.faces.el.ValueBinding;
import javax.el.ValueExpression;
import org.richfaces.webapp.taglib.MethodBindingMethodExpressionAdaptor;
import org.richfaces.webapp.taglib.ValueBindingValueExpressionAdaptor;
import org.richfaces.component.html.HtmlPickList;

public class PickListTag extends org.ajax4jsf.webapp.taglib.HtmlComponentTagBase {

		// Fields
		 		 	  			  		  	  
		/*
		 * controlClass
		 * Assigns one or more space-separated CSS class names to the component controls
		 */
		private ValueExpression _controlClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component controls
		 * Setter for controlClass
		 * @param controlClass - new value
		 */
		 public void setControlClass( ValueExpression  __controlClass ){
			this._controlClass = __controlClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converter
		 * Id of Converter to be used or reference to a Converter
		 */
		private ValueExpression _converter;
		/**
		 * Id of Converter to be used or reference to a Converter
		 * Setter for converter
		 * @param converter - new value
		 */
		 public void setConverter( ValueExpression  __converter ){
			this._converter = __converter;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * converterMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 */
		private ValueExpression _converterMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the converter message,
			replacing any message that comes from the converter
		 * Setter for converterMessage
		 * @param converterMessage - new value
		 */
		 public void setConverterMessage( ValueExpression  __converterMessage ){
			this._converterMessage = __converterMessage;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyAllControlLabel
		 * Defines a label for a "Copy all" control
		 */
		private ValueExpression _copyAllControlLabel;
		/**
		 * Defines a label for a "Copy all" control
		 * Setter for copyAllControlLabel
		 * @param copyAllControlLabel - new value
		 */
		 public void setCopyAllControlLabel( ValueExpression  __copyAllControlLabel ){
			this._copyAllControlLabel = __copyAllControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyAllTitle
		 * HTML: alt for a "Copy all" button
		 */
		private ValueExpression _copyAllTitle;
		/**
		 * HTML: alt for a "Copy all" button
		 * Setter for copyAllTitle
		 * @param copyAllTitle - new value
		 */
		 public void setCopyAllTitle( ValueExpression  __copyAllTitle ){
			this._copyAllTitle = __copyAllTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyAllVisible
		 * If "false", the 'Copy All' control will not be displayed. Even if this value is "true", the 'Copy All' control will not be displayed if the "fastMoveControlsVisible" attribute is "false". Default value is "true".
		 */
		private ValueExpression _copyAllVisible;
		/**
		 * If "false", the 'Copy All' control will not be displayed. Even if this value is "true", the 'Copy All' control will not be displayed if the "fastMoveControlsVisible" attribute is "false". Default value is "true".
		 * Setter for copyAllVisible
		 * @param copyAllVisible - new value
		 */
		 public void setCopyAllVisible( ValueExpression  __copyAllVisible ){
			this._copyAllVisible = __copyAllVisible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyControlLabel
		 * Defines a label for a "Copy" control
		 */
		private ValueExpression _copyControlLabel;
		/**
		 * Defines a label for a "Copy" control
		 * Setter for copyControlLabel
		 * @param copyControlLabel - new value
		 */
		 public void setCopyControlLabel( ValueExpression  __copyControlLabel ){
			this._copyControlLabel = __copyControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyTitle
		 * HTML: alt for a "Copy" button
		 */
		private ValueExpression _copyTitle;
		/**
		 * HTML: alt for a "Copy" button
		 * Setter for copyTitle
		 * @param copyTitle - new value
		 */
		 public void setCopyTitle( ValueExpression  __copyTitle ){
			this._copyTitle = __copyTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * copyVisible
		 * If "false", the 'Copy' control will not be displayed. Even if this value is "true", the 'Copy' control will not be displayed if the "moveControlsVisible" attribute is "false". Default value is "true".
		 */
		private ValueExpression _copyVisible;
		/**
		 * If "false", the 'Copy' control will not be displayed. Even if this value is "true", the 'Copy' control will not be displayed if the "moveControlsVisible" attribute is "false". Default value is "true".
		 * Setter for copyVisible
		 * @param copyVisible - new value
		 */
		 public void setCopyVisible( ValueExpression  __copyVisible ){
			this._copyVisible = __copyVisible;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * disabled
		 * If  "true", disable this component on page.
		 */
		private ValueExpression _disabled;
		/**
		 * If  "true", disable this component on page.
		 * Setter for disabled
		 * @param disabled - new value
		 */
		 public void setDisabled( ValueExpression  __disabled ){
			this._disabled = __disabled;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledStyle
		 * CSS style rules to be applied to the component disabled controls
		 */
		private ValueExpression _disabledStyle;
		/**
		 * CSS style rules to be applied to the component disabled controls
		 * Setter for disabledStyle
		 * @param disabledStyle - new value
		 */
		 public void setDisabledStyle( ValueExpression  __disabledStyle ){
			this._disabledStyle = __disabledStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * disabledStyleClass
		 * Assigns one or more space-separated CSS class names to the component disabled controls
		 */
		private ValueExpression _disabledStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component disabled controls
		 * Setter for disabledStyleClass
		 * @param disabledStyleClass - new value
		 */
		 public void setDisabledStyleClass( ValueExpression  __disabledStyleClass ){
			this._disabledStyleClass = __disabledStyleClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * enabledStyle
		 * CSS style rules to be applied to the component enabled controls
		 */
		private ValueExpression _enabledStyle;
		/**
		 * CSS style rules to be applied to the component enabled controls
		 * Setter for enabledStyle
		 * @param enabledStyle - new value
		 */
		 public void setEnabledStyle( ValueExpression  __enabledStyle ){
			this._enabledStyle = __enabledStyle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * enabledStyleClass
		 * Assigns one or more space-separated CSS class names to the component enabled controls
		 */
		private ValueExpression _enabledStyleClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component enabled controls
		 * Setter for enabledStyleClass
		 * @param enabledStyleClass - new value
		 */
		 public void setEnabledStyleClass( ValueExpression  __enabledStyleClass ){
			this._enabledStyleClass = __enabledStyleClass;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * fastMoveControlsVisible
		 * If "false", 'Copy All' and 'Remove All' controls aren't displayed. Even if this value is "true", the 'Copy All' and 'Remove All' controls will not be displayed if the "copyAllVisible" and "removeAllVisible" attribute values are "false". Default value is "true".
		 */
		private ValueExpression _fastMoveControlsVisible;
		/**
		 * If "false", 'Copy All' and 'Remove All' controls aren't displayed. Even if this value is "true", the 'Copy All' and 'Remove All' controls will not be displayed if the "copyAllVisible" and "removeAllVisible" attribute values are "false". Default value is "true".
		 * Setter for fastMoveControlsVisible
		 * @param fastMoveControlsVisible - new value
		 */
		 public void setFastMoveControlsVisible( ValueExpression  __fastMoveControlsVisible ){
			this._fastMoveControlsVisible = __fastMoveControlsVisible;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * immediate
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 */
		private ValueExpression _immediate;
		/**
		 * A flag indicating that this component value must be converted
            and validated immediately (that is, during Apply Request Values
            phase), rather than waiting until a Process Validations phase
		 * Setter for immediate
		 * @param immediate - new value
		 */
		 public void setImmediate( ValueExpression  __immediate ){
			this._immediate = __immediate;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * label
		 * A localized user presentable name for this component.
		 */
		private ValueExpression _label;
		/**
		 * A localized user presentable name for this component.
		 * Setter for label
		 * @param label - new value
		 */
		 public void setLabel( ValueExpression  __label ){
			this._label = __label;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * listClass
		 * Assigns one or more space-separated CSS class names to the component lists
		 */
		private ValueExpression _listClass;
		/**
		 * Assigns one or more space-separated CSS class names to the component lists
		 * Setter for listClass
		 * @param listClass - new value
		 */
		 public void setListClass( ValueExpression  __listClass ){
			this._listClass = __listClass;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * listsHeight
		 * Defines height of the list. Default value is "140px"
		 */
		private ValueExpression _listsHeight;
		/**
		 * Defines height of the list. Default value is "140px"
		 * Setter for listsHeight
		 * @param listsHeight - new value
		 */
		 public void setListsHeight( ValueExpression  __listsHeight ){
			this._listsHeight = __listsHeight;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * moveControlsVerticalAlign
		 * Customizes vertically a position of move/copy controls relatively to lists. Default value is "center".
		 */
		private ValueExpression _moveControlsVerticalAlign;
		/**
		 * Customizes vertically a position of move/copy controls relatively to lists. Default value is "center".
		 * Setter for moveControlsVerticalAlign
		 * @param moveControlsVerticalAlign - new value
		 */
		 public void setMoveControlsVerticalAlign( ValueExpression  __moveControlsVerticalAlign ){
			this._moveControlsVerticalAlign = __moveControlsVerticalAlign;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * moveControlsVisible
		 * If "false", 'Copy' and 'Remove' controls aren't displayed. Even if this value is "true", the 'Copy' and 'Remove' controls will not be displayed if the "copyVisible" and "removeVisible" attribute values are "false". Default value is "true".
		 */
		private ValueExpression _moveControlsVisible;
		/**
		 * If "false", 'Copy' and 'Remove' controls aren't displayed. Even if this value is "true", the 'Copy' and 'Remove' controls will not be displayed if the "copyVisible" and "removeVisible" attribute values are "false". Default value is "true".
		 * Setter for moveControlsVisible
		 * @param moveControlsVisible - new value
		 */
		 public void setMoveControlsVisible( ValueExpression  __moveControlsVisible ){
			this._moveControlsVisible = __moveControlsVisible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onblur
		 * The client-side script method to be called when the component loses the focus
		 */
		private ValueExpression _onblur;
		/**
		 * The client-side script method to be called when the component loses the focus
		 * Setter for onblur
		 * @param onblur - new value
		 */
		 public void setOnblur( ValueExpression  __onblur ){
			this._onblur = __onblur;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * onfocus
		 * The client-side script method to be called when the component gets the focus
		 */
		private ValueExpression _onfocus;
		/**
		 * The client-side script method to be called when the component gets the focus
		 * Setter for onfocus
		 * @param onfocus - new value
		 */
		 public void setOnfocus( ValueExpression  __onfocus ){
			this._onfocus = __onfocus;
	     }
	  
	 	 		 		 		 		 	  			  		  	  
		/*
		 * onlistchange
		 * The client-side script method to be called when the list is changed
		 */
		private ValueExpression _onlistchange;
		/**
		 * The client-side script method to be called when the list is changed
		 * Setter for onlistchange
		 * @param onlistchange - new value
		 */
		 public void setOnlistchange( ValueExpression  __onlistchange ){
			this._onlistchange = __onlistchange;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * onlistchanged
		 * The client-side script method to be called before the list is changed
		 */
		private ValueExpression _onlistchanged;
		/**
		 * The client-side script method to be called before the list is changed
		 * Setter for onlistchanged
		 * @param onlistchanged - new value
		 */
		 public void setOnlistchanged( ValueExpression  __onlistchanged ){
			this._onlistchanged = __onlistchanged;
	     }
	  
	 	 		 		 		 		 		 		 	  			  		  	  
		/*
		 * removeAllControlLabel
		 * Defines a label for a "Remove all" control
		 */
		private ValueExpression _removeAllControlLabel;
		/**
		 * Defines a label for a "Remove all" control
		 * Setter for removeAllControlLabel
		 * @param removeAllControlLabel - new value
		 */
		 public void setRemoveAllControlLabel( ValueExpression  __removeAllControlLabel ){
			this._removeAllControlLabel = __removeAllControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeAllTitle
		 * HTML: alt for a "Remove" all button
		 */
		private ValueExpression _removeAllTitle;
		/**
		 * HTML: alt for a "Remove" all button
		 * Setter for removeAllTitle
		 * @param removeAllTitle - new value
		 */
		 public void setRemoveAllTitle( ValueExpression  __removeAllTitle ){
			this._removeAllTitle = __removeAllTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeAllVisible
		 * If "false", the 'Remove All' control will not be displayed. Even if this value is "true", the 'Remove All' control will not be displayed if the "fastMoveControlsVisible" attribute is "false". Default value is "true".
		 */
		private ValueExpression _removeAllVisible;
		/**
		 * If "false", the 'Remove All' control will not be displayed. Even if this value is "true", the 'Remove All' control will not be displayed if the "fastMoveControlsVisible" attribute is "false". Default value is "true".
		 * Setter for removeAllVisible
		 * @param removeAllVisible - new value
		 */
		 public void setRemoveAllVisible( ValueExpression  __removeAllVisible ){
			this._removeAllVisible = __removeAllVisible;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeControlLabel
		 * Defines a label for a "Remove" control
		 */
		private ValueExpression _removeControlLabel;
		/**
		 * Defines a label for a "Remove" control
		 * Setter for removeControlLabel
		 * @param removeControlLabel - new value
		 */
		 public void setRemoveControlLabel( ValueExpression  __removeControlLabel ){
			this._removeControlLabel = __removeControlLabel;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeTitle
		 * HTML: alt for a "Remove" button
		 */
		private ValueExpression _removeTitle;
		/**
		 * HTML: alt for a "Remove" button
		 * Setter for removeTitle
		 * @param removeTitle - new value
		 */
		 public void setRemoveTitle( ValueExpression  __removeTitle ){
			this._removeTitle = __removeTitle;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * removeVisible
		 * If "false", the 'Remove' control will not be displayed. Even if this value is "true", the 'Remove' control will not be displayed if the "moveControlsVisible" attribute is "false". Default value is "true".
		 */
		private ValueExpression _removeVisible;
		/**
		 * If "false", the 'Remove' control will not be displayed. Even if this value is "true", the 'Remove' control will not be displayed if the "moveControlsVisible" attribute is "false". Default value is "true".
		 * Setter for removeVisible
		 * @param removeVisible - new value
		 */
		 public void setRemoveVisible( ValueExpression  __removeVisible ){
			this._removeVisible = __removeVisible;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * required
		 * If "true", this component is checked for non-empty input
		 */
		private ValueExpression _required;
		/**
		 * If "true", this component is checked for non-empty input
		 * Setter for required
		 * @param required - new value
		 */
		 public void setRequired( ValueExpression  __required ){
			this._required = __required;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * requiredMessage
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 */
		private ValueExpression _requiredMessage;
		/**
		 * A ValueExpression enabled attribute which defines  text of validation message to show, if a required field is missing
		 * Setter for requiredMessage
		 * @param requiredMessage - new value
		 */
		 public void setRequiredMessage( ValueExpression  __requiredMessage ){
			this._requiredMessage = __requiredMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * showButtonsLabel
		 * Shows a label for a button. Default value is "true"
		 */
		private ValueExpression _showButtonsLabel;
		/**
		 * Shows a label for a button. Default value is "true"
		 * Setter for showButtonsLabel
		 * @param showButtonsLabel - new value
		 */
		 public void setShowButtonsLabel( ValueExpression  __showButtonsLabel ){
			this._showButtonsLabel = __showButtonsLabel;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * sourceListWidth
		 * Defines width of a source list. Default value is "140px"
		 */
		private ValueExpression _sourceListWidth;
		/**
		 * Defines width of a source list. Default value is "140px"
		 * Setter for sourceListWidth
		 * @param sourceListWidth - new value
		 */
		 public void setSourceListWidth( ValueExpression  __sourceListWidth ){
			this._sourceListWidth = __sourceListWidth;
	     }
	  
	 	 		 		 		 	  			  		  	  
		/*
		 * switchByClick
		 * If "true", items can be moved between the lists by clicking on them. Default value is "false".
		 */
		private ValueExpression _switchByClick;
		/**
		 * If "true", items can be moved between the lists by clicking on them. Default value is "false".
		 * Setter for switchByClick
		 * @param switchByClick - new value
		 */
		 public void setSwitchByClick( ValueExpression  __switchByClick ){
			this._switchByClick = __switchByClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * switchByDblClick
		 * If "true", items can be moved between the lists by double-clicking on them. Default value is "true".
		 */
		private ValueExpression _switchByDblClick;
		/**
		 * If "true", items can be moved between the lists by double-clicking on them. Default value is "true".
		 * Setter for switchByDblClick
		 * @param switchByDblClick - new value
		 */
		 public void setSwitchByDblClick( ValueExpression  __switchByDblClick ){
			this._switchByDblClick = __switchByDblClick;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * targetListWidth
		 * Defines width of a target list. Default value is "140px"
		 */
		private ValueExpression _targetListWidth;
		/**
		 * Defines width of a target list. Default value is "140px"
		 * Setter for targetListWidth
		 * @param targetListWidth - new value
		 */
		 public void setTargetListWidth( ValueExpression  __targetListWidth ){
			this._targetListWidth = __targetListWidth;
	     }
	  
	 	 		 		 		 	  	  	  
		/*
		 * validator
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 */
		private MethodExpression _validator;
		/**
		 * MethodBinding pointing at a method that is called during
            Process Validations phase of the request processing lifecycle,
            to validate the current value of this component
		 * Setter for validator
		 * @param validator - new value
		 */
		 public void setValidator( MethodExpression  __validator ){
			this._validator = __validator;
	     }
	  
	 	 		 	  			  		  	  
		/*
		 * validatorMessage
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 */
		private ValueExpression _validatorMessage;
		/**
		 * A ValueExpression enabled attribute that, if present,
			will be used as the text of the validator message,
			replacing any message that comes from the validator
		 * Setter for validatorMessage
		 * @param validatorMessage - new value
		 */
		 public void setValidatorMessage( ValueExpression  __validatorMessage ){
			this._validatorMessage = __validatorMessage;
	     }
	  
	 	 		 		 	  			  		  	  
		/*
		 * value
		 * The current value of this component
		 */
		private ValueExpression _value;
		/**
		 * The current value of this component
		 * Setter for value
		 * @param value - new value
		 */
		 public void setValue( ValueExpression  __value ){
			this._value = __value;
	     }
	  
	 	 		 	  	  	  
		/*
		 * valueChangeListener
		 * Listener for value changes
		 */
		private MethodExpression _valueChangeListener;
		/**
		 * Listener for value changes
		 * Setter for valueChangeListener
		 * @param valueChangeListener - new value
		 */
		 public void setValueChangeListener( MethodExpression  __valueChangeListener ){
			this._valueChangeListener = __valueChangeListener;
	     }
	  
	 	 		 	
	
    public void release()
    {
        // TODO Auto-generated method stub
        super.release();
        		 		 		    this._controlClass = null;
	 		 		    this._converter = null;
	 		 		    this._converterMessage = null;
	 		 		    this._copyAllControlLabel = null;
	 		 		    this._copyAllTitle = null;
	 		 		    this._copyAllVisible = null;
	 		 		    this._copyControlLabel = null;
	 		 		    this._copyTitle = null;
	 		 		    this._copyVisible = null;
	 		 		 		    this._disabled = null;
	 		 		    this._disabledStyle = null;
	 		 		    this._disabledStyleClass = null;
	 		 		    this._enabledStyle = null;
	 		 		    this._enabledStyleClass = null;
	 		 		 		    this._fastMoveControlsVisible = null;
	 		 		 		    this._immediate = null;
	 		 		    this._label = null;
	 		 		 		    this._listClass = null;
	 		 		    this._listsHeight = null;
	 		 		 		 		    this._moveControlsVerticalAlign = null;
	 		 		    this._moveControlsVisible = null;
	 		 		    this._onblur = null;
	 		 		 		 		 		    this._onfocus = null;
	 		 		 		 		 		    this._onlistchange = null;
	 		 		    this._onlistchanged = null;
	 		 		 		 		 		 		 		    this._removeAllControlLabel = null;
	 		 		    this._removeAllTitle = null;
	 		 		    this._removeAllVisible = null;
	 		 		    this._removeControlLabel = null;
	 		 		    this._removeTitle = null;
	 		 		    this._removeVisible = null;
	 		 		 		    this._required = null;
	 		 		    this._requiredMessage = null;
	 		 		 		    this._showButtonsLabel = null;
	 		 		 		    this._sourceListWidth = null;
	 		 		 		 		    this._switchByClick = null;
	 		 		    this._switchByDblClick = null;
	 		 		    this._targetListWidth = null;
	 		 		 		 		    this._validator = null;
	 		 		    this._validatorMessage = null;
	 		 		 		    this._value = null;
	 		 		    this._valueChangeListener = null;
	 		 		}
	
    /* (non-Javadoc)
     * @see org.ajax4jsf.components.taglib.html.HtmlCommandButtonTagBase#setProperties(javax.faces.component.UIComponent)
     */
    protected void setProperties(UIComponent component)
    {
        // TODO Auto-generated method stub
        super.setProperties(component);
		HtmlPickList comp = (HtmlPickList) component;
  		 			 
						if (this._controlClass != null) {
				if (this._controlClass.isLiteralText()) {
					try {
												
						java.lang.String __controlClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._controlClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setControlClass(__controlClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("controlClass", this._controlClass);
				}
			}
					   		 			setConverterProperty(comp, this._converter);
		   		 			 
						if (this._converterMessage != null) {
				if (this._converterMessage.isLiteralText()) {
					try {
												
						java.lang.String __converterMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._converterMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setConverterMessage(__converterMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("converterMessage", this._converterMessage);
				}
			}
					   		 			 
						if (this._copyAllControlLabel != null) {
				if (this._copyAllControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __copyAllControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyAllControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyAllControlLabel(__copyAllControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyAllControlLabel", this._copyAllControlLabel);
				}
			}
					   		 			 
						if (this._copyAllTitle != null) {
				if (this._copyAllTitle.isLiteralText()) {
					try {
												
						java.lang.String __copyAllTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyAllTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyAllTitle(__copyAllTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyAllTitle", this._copyAllTitle);
				}
			}
					   		 			 
						if (this._copyAllVisible != null) {
				if (this._copyAllVisible.isLiteralText()) {
					try {
												
						Boolean __copyAllVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyAllVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setCopyAllVisible(__copyAllVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyAllVisible", this._copyAllVisible);
				}
			}
					   		 			 
						if (this._copyControlLabel != null) {
				if (this._copyControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __copyControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyControlLabel(__copyControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyControlLabel", this._copyControlLabel);
				}
			}
					   		 			 
						if (this._copyTitle != null) {
				if (this._copyTitle.isLiteralText()) {
					try {
												
						java.lang.String __copyTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setCopyTitle(__copyTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyTitle", this._copyTitle);
				}
			}
					   		 			 
						if (this._copyVisible != null) {
				if (this._copyVisible.isLiteralText()) {
					try {
												
						Boolean __copyVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._copyVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setCopyVisible(__copyVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("copyVisible", this._copyVisible);
				}
			}
					    		 			 
						if (this._disabled != null) {
				if (this._disabled.isLiteralText()) {
					try {
												
						Boolean __disabled = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabled.getExpressionString(), 
											Boolean.class);
					
												comp.setDisabled(__disabled.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabled", this._disabled);
				}
			}
					   		 			 
						if (this._disabledStyle != null) {
				if (this._disabledStyle.isLiteralText()) {
					try {
												
						java.lang.String __disabledStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledStyle(__disabledStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledStyle", this._disabledStyle);
				}
			}
					   		 			 
						if (this._disabledStyleClass != null) {
				if (this._disabledStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __disabledStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._disabledStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setDisabledStyleClass(__disabledStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("disabledStyleClass", this._disabledStyleClass);
				}
			}
					   		 			 
						if (this._enabledStyle != null) {
				if (this._enabledStyle.isLiteralText()) {
					try {
												
						java.lang.String __enabledStyle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enabledStyle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEnabledStyle(__enabledStyle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enabledStyle", this._enabledStyle);
				}
			}
					   		 			 
						if (this._enabledStyleClass != null) {
				if (this._enabledStyleClass.isLiteralText()) {
					try {
												
						java.lang.String __enabledStyleClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._enabledStyleClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setEnabledStyleClass(__enabledStyleClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("enabledStyleClass", this._enabledStyleClass);
				}
			}
					    		 			 
						if (this._fastMoveControlsVisible != null) {
				if (this._fastMoveControlsVisible.isLiteralText()) {
					try {
												
						Boolean __fastMoveControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._fastMoveControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setFastMoveControlsVisible(__fastMoveControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("fastMoveControlsVisible", this._fastMoveControlsVisible);
				}
			}
					    		 			 
						if (this._immediate != null) {
				if (this._immediate.isLiteralText()) {
					try {
												
						Boolean __immediate = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._immediate.getExpressionString(), 
											Boolean.class);
					
												comp.setImmediate(__immediate.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("immediate", this._immediate);
				}
			}
					   		 			 
						if (this._label != null) {
				if (this._label.isLiteralText()) {
					try {
												
						java.lang.String __label = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._label.getExpressionString(), 
											java.lang.String.class);
					
												comp.setLabel(__label);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("label", this._label);
				}
			}
					    		 			 
						if (this._listClass != null) {
				if (this._listClass.isLiteralText()) {
					try {
												
						java.lang.String __listClass = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listClass.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListClass(__listClass);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listClass", this._listClass);
				}
			}
					   		 			 
						if (this._listsHeight != null) {
				if (this._listsHeight.isLiteralText()) {
					try {
												
						java.lang.String __listsHeight = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._listsHeight.getExpressionString(), 
											java.lang.String.class);
					
												comp.setListsHeight(__listsHeight);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("listsHeight", this._listsHeight);
				}
			}
					     		 			 
						if (this._moveControlsVerticalAlign != null) {
				if (this._moveControlsVerticalAlign.isLiteralText()) {
					try {
												
						java.lang.String __moveControlsVerticalAlign = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._moveControlsVerticalAlign.getExpressionString(), 
											java.lang.String.class);
					
												comp.setMoveControlsVerticalAlign(__moveControlsVerticalAlign);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("moveControlsVerticalAlign", this._moveControlsVerticalAlign);
				}
			}
					   		 			 
						if (this._moveControlsVisible != null) {
				if (this._moveControlsVisible.isLiteralText()) {
					try {
												
						Boolean __moveControlsVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._moveControlsVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setMoveControlsVisible(__moveControlsVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("moveControlsVisible", this._moveControlsVisible);
				}
			}
					   		 			 
						if (this._onblur != null) {
				if (this._onblur.isLiteralText()) {
					try {
												
						java.lang.String __onblur = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onblur.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnblur(__onblur);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onblur", this._onblur);
				}
			}
					      		 			 
						if (this._onfocus != null) {
				if (this._onfocus.isLiteralText()) {
					try {
												
						java.lang.String __onfocus = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onfocus.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnfocus(__onfocus);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onfocus", this._onfocus);
				}
			}
					      		 			 
						if (this._onlistchange != null) {
				if (this._onlistchange.isLiteralText()) {
					try {
												
						java.lang.String __onlistchange = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onlistchange.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnlistchange(__onlistchange);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onlistchange", this._onlistchange);
				}
			}
					   		 			 
						if (this._onlistchanged != null) {
				if (this._onlistchanged.isLiteralText()) {
					try {
												
						java.lang.String __onlistchanged = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._onlistchanged.getExpressionString(), 
											java.lang.String.class);
					
												comp.setOnlistchanged(__onlistchanged);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("onlistchanged", this._onlistchanged);
				}
			}
					        		 			 
						if (this._removeAllControlLabel != null) {
				if (this._removeAllControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __removeAllControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeAllControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveAllControlLabel(__removeAllControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeAllControlLabel", this._removeAllControlLabel);
				}
			}
					   		 			 
						if (this._removeAllTitle != null) {
				if (this._removeAllTitle.isLiteralText()) {
					try {
												
						java.lang.String __removeAllTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeAllTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveAllTitle(__removeAllTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeAllTitle", this._removeAllTitle);
				}
			}
					   		 			 
						if (this._removeAllVisible != null) {
				if (this._removeAllVisible.isLiteralText()) {
					try {
												
						Boolean __removeAllVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeAllVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setRemoveAllVisible(__removeAllVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeAllVisible", this._removeAllVisible);
				}
			}
					   		 			 
						if (this._removeControlLabel != null) {
				if (this._removeControlLabel.isLiteralText()) {
					try {
												
						java.lang.String __removeControlLabel = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeControlLabel.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveControlLabel(__removeControlLabel);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeControlLabel", this._removeControlLabel);
				}
			}
					   		 			 
						if (this._removeTitle != null) {
				if (this._removeTitle.isLiteralText()) {
					try {
												
						java.lang.String __removeTitle = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeTitle.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRemoveTitle(__removeTitle);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeTitle", this._removeTitle);
				}
			}
					   		 			 
						if (this._removeVisible != null) {
				if (this._removeVisible.isLiteralText()) {
					try {
												
						Boolean __removeVisible = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._removeVisible.getExpressionString(), 
											Boolean.class);
					
												comp.setRemoveVisible(__removeVisible.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("removeVisible", this._removeVisible);
				}
			}
					    		 			 
						if (this._required != null) {
				if (this._required.isLiteralText()) {
					try {
												
						Boolean __required = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._required.getExpressionString(), 
											Boolean.class);
					
												comp.setRequired(__required.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("required", this._required);
				}
			}
					   		 			 
						if (this._requiredMessage != null) {
				if (this._requiredMessage.isLiteralText()) {
					try {
												
						java.lang.String __requiredMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._requiredMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setRequiredMessage(__requiredMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("requiredMessage", this._requiredMessage);
				}
			}
					    		 			 
						if (this._showButtonsLabel != null) {
				if (this._showButtonsLabel.isLiteralText()) {
					try {
												
						Boolean __showButtonsLabel = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._showButtonsLabel.getExpressionString(), 
											Boolean.class);
					
												comp.setShowButtonsLabel(__showButtonsLabel.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("showButtonsLabel", this._showButtonsLabel);
				}
			}
					    		 			 
						if (this._sourceListWidth != null) {
				if (this._sourceListWidth.isLiteralText()) {
					try {
												
						java.lang.String __sourceListWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._sourceListWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setSourceListWidth(__sourceListWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("sourceListWidth", this._sourceListWidth);
				}
			}
					     		 			 
						if (this._switchByClick != null) {
				if (this._switchByClick.isLiteralText()) {
					try {
												
						Boolean __switchByClick = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._switchByClick.getExpressionString(), 
											Boolean.class);
					
												comp.setSwitchByClick(__switchByClick.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("switchByClick", this._switchByClick);
				}
			}
					   		 			 
						if (this._switchByDblClick != null) {
				if (this._switchByDblClick.isLiteralText()) {
					try {
												
						Boolean __switchByDblClick = (Boolean) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._switchByDblClick.getExpressionString(), 
											Boolean.class);
					
												comp.setSwitchByDblClick(__switchByDblClick.booleanValue());
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("switchByDblClick", this._switchByDblClick);
				}
			}
					   		 			 
						if (this._targetListWidth != null) {
				if (this._targetListWidth.isLiteralText()) {
					try {
												
						java.lang.String __targetListWidth = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._targetListWidth.getExpressionString(), 
											java.lang.String.class);
					
												comp.setTargetListWidth(__targetListWidth);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("targetListWidth", this._targetListWidth);
				}
			}
					     		 			setValidatorProperty(comp, this._validator);
		   		 			 
						if (this._validatorMessage != null) {
				if (this._validatorMessage.isLiteralText()) {
					try {
												
						java.lang.String __validatorMessage = (java.lang.String) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._validatorMessage.getExpressionString(), 
											java.lang.String.class);
					
												comp.setValidatorMessage(__validatorMessage);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("validatorMessage", this._validatorMessage);
				}
			}
					    		 			 
						if (this._value != null) {
				if (this._value.isLiteralText()) {
					try {
												
						java.lang.Object __value = (java.lang.Object) getFacesContext().
							getApplication().
								getExpressionFactory().
									coerceToType(this._value.getExpressionString(), 
											java.lang.Object.class);
					
												comp.setValue(__value);
											} catch (ELException e) {
						throw new FacesException(e);
					}
				} else {
					component.setValueExpression("value", this._value);
				}
			}
					   		 			setValueChangeListenerProperty(comp, this._valueChangeListener);
		      }
	
	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getComponentType()
	 */
	public String getComponentType() {
		// TODO Auto-generated method stub
		return "org.richfaces.PickList";
	}

	/* (non-Javadoc)
	 * @see javax.faces.webapp.UIComponentTag#getRendererType()
	 */
	public String getRendererType() {
				return "org.richfaces.PickListRenderer";
			}

}
