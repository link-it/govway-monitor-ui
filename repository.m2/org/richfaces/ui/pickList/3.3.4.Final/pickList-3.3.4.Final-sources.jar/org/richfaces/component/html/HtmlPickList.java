package org.richfaces.component.html;

import javax.el.ELException;
import javax.el.ValueExpression;
import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import org.richfaces.component.UIPickList;

public class HtmlPickList extends UIPickList{

final static public  String COMPONENT_FAMILY = "org.richfaces.PickList";

final static public  String COMPONENT_TYPE = "org.richfaces.PickList";

/*
* Assigns one or more space-separated CSS class names to the component controls
*/
private  String _controlClass = null;

/*
* Defines a label for a "Copy all" control
*/
private  String _copyAllControlLabel = null;

/*
* HTML: alt for a "Copy all" button
*/
private  String _copyAllTitle = null;

/*
* If "false", the 'Copy All' control will not be displayed. Even if this value is "true", the 'Copy All' control will not be displayed if the "fastMoveControlsVisible" attribute is "false". Default value is "true".
*/
private  boolean _copyAllVisible = true;

private  boolean _copyAllVisibleSet = false;

/*
* Defines a label for a "Copy" control
*/
private  String _copyControlLabel = null;

/*
* HTML: alt for a "Copy" button
*/
private  String _copyTitle = null;

/*
* If "false", the 'Copy' control will not be displayed. Even if this value is "true", the 'Copy' control will not be displayed if the "moveControlsVisible" attribute is "false". Default value is "true".
*/
private  boolean _copyVisible = true;

private  boolean _copyVisibleSet = false;

/*
* 
*/
private  String _dir = null;

/*
* If  "true", disable this component on page.
*/
private  boolean _disabled = false;

private  boolean _disabledSet = false;

/*
* CSS style rules to be applied to the component disabled controls
*/
private  String _disabledStyle = null;

/*
* Assigns one or more space-separated CSS class names to the component disabled controls
*/
private  String _disabledStyleClass = null;

/*
* CSS style rules to be applied to the component enabled controls
*/
private  String _enabledStyle = null;

/*
* Assigns one or more space-separated CSS class names to the component enabled controls
*/
private  String _enabledStyleClass = null;

/*
* If "false", 'Copy All' and 'Remove All' controls aren't displayed. Even if this value is "true", the 'Copy All' and 'Remove All' controls will not be displayed if the "copyAllVisible" and "removeAllVisible" attribute values are "false". Default value is "true".
*/
private  boolean _fastMoveControlsVisible = true;

private  boolean _fastMoveControlsVisibleSet = false;

/*
* A localized user presentable name for this component.
*/
private  String _label = null;

/*
* null
*/
private  String _lang = null;

/*
* Assigns one or more space-separated CSS class names to the component lists
*/
private  String _listClass = null;

/*
* Defines height of the list. Default value is "140px"
*/
private  String _listsHeight = null;

/*
* Customizes vertically a position of move/copy controls relatively to lists. Default value is "center".
*/
private  String _moveControlsVerticalAlign = null;

/*
* If "false", 'Copy' and 'Remove' controls aren't displayed. Even if this value is "true", the 'Copy' and 'Remove' controls will not be displayed if the "copyVisible" and "removeVisible" attribute values are "false". Default value is "true".
*/
private  boolean _moveControlsVisible = true;

private  boolean _moveControlsVisibleSet = false;

/*
* The client-side script method to be called when the component loses the focus
*/
private  String _onblur = null;

/*
* null
*/
private  String _onchange = null;

/*
* The client-side script method to be called when the element is clicked
*/
private  String _onclick = null;

/*
* The client-side script method to be called when the element is double-clicked
*/
private  String _ondblclick = null;

/*
* The client-side script method to be called when the component gets the focus
*/
private  String _onfocus = null;

/*
* The client-side script method to be called when a key is pressed down over the element
*/
private  String _onkeydown = null;

/*
* The client-side script method to be called when a key is pressed over the element and released
*/
private  String _onkeypress = null;

/*
* The client-side script method to be called when a key is released
*/
private  String _onkeyup = null;

/*
* The client-side script method to be called when the list is changed
*/
private  String _onlistchange = null;

/*
* The client-side script method to be called before the list is changed
*/
private  String _onlistchanged = null;

/*
* The client-side script method to be called when a mouse button is pressed down over the element
*/
private  String _onmousedown = null;

/*
* The client-side script method to be called when a pointer is moved within the element
*/
private  String _onmousemove = null;

/*
* The client-side script method to be called when a pointer is moved away from the element
*/
private  String _onmouseout = null;

/*
* The client-side script method to be called when a pointer is moved onto the element
*/
private  String _onmouseover = null;

/*
* The client-side script method to be called when a mouse button is released
*/
private  String _onmouseup = null;

/*
* Defines a label for a "Remove all" control
*/
private  String _removeAllControlLabel = null;

/*
* HTML: alt for a "Remove" all button
*/
private  String _removeAllTitle = null;

/*
* If "false", the 'Remove All' control will not be displayed. Even if this value is "true", the 'Remove All' control will not be displayed if the "fastMoveControlsVisible" attribute is "false". Default value is "true".
*/
private  boolean _removeAllVisible = true;

private  boolean _removeAllVisibleSet = false;

/*
* Defines a label for a "Remove" control
*/
private  String _removeControlLabel = null;

/*
* HTML: alt for a "Remove" button
*/
private  String _removeTitle = null;

/*
* If "false", the 'Remove' control will not be displayed. Even if this value is "true", the 'Remove' control will not be displayed if the "moveControlsVisible" attribute is "false". Default value is "true".
*/
private  boolean _removeVisible = true;

private  boolean _removeVisibleSet = false;

/*
* Shows a label for a button. Default value is "true"
*/
private  boolean _showButtonsLabel = true;

private  boolean _showButtonsLabelSet = false;

/*
* size
*/
private  int _size = Integer.MIN_VALUE;

private  boolean _sizeSet = false;

/*
* Defines width of a source list. Default value is "140px"
*/
private  String _sourceListWidth = null;

/*
* CSS style rules to be applied to the component
*/
private  String _style = null;

/*
* Assigns one or more CSS class names to the component. Corresponds to the HTML "class" attribute.
*/
private  String _styleClass = null;

/*
* If "true", items can be moved between the lists by clicking on them. Default value is "false".
*/
private  boolean _switchByClick = false;

private  boolean _switchByClickSet = false;

/*
* If "true", items can be moved between the lists by double-clicking on them. Default value is "true".
*/
private  boolean _switchByDblClick = true;

private  boolean _switchByDblClickSet = false;

/*
* Defines width of a target list. Default value is "140px"
*/
private  String _targetListWidth = null;

/*
* Advisory title information about markup elements generated for this component
*/
private  String _title = null;


public HtmlPickList(){
setRendererType("org.richfaces.PickListRenderer");
}

public String getControlClass(){
	if (this._controlClass != null) {
		return this._controlClass;
	}
	ValueExpression ve = getValueExpression("controlClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setControlClass(String _controlClass){
this._controlClass = _controlClass;
}

public String getCopyAllControlLabel(){
	if (this._copyAllControlLabel != null) {
		return this._copyAllControlLabel;
	}
	ValueExpression ve = getValueExpression("copyAllControlLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setCopyAllControlLabel(String _copyAllControlLabel){
this._copyAllControlLabel = _copyAllControlLabel;
}

public String getCopyAllTitle(){
	if (this._copyAllTitle != null) {
		return this._copyAllTitle;
	}
	ValueExpression ve = getValueExpression("copyAllTitle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setCopyAllTitle(String _copyAllTitle){
this._copyAllTitle = _copyAllTitle;
}

public boolean isCopyAllVisible(){
	if (this._copyAllVisibleSet) {
	    return (this._copyAllVisible);
	}
	ValueExpression ve = getValueExpression("copyAllVisible");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._copyAllVisible);
	    }
	    
	    return value;
	} else {
	    return (this._copyAllVisible);
	}

}

public void setCopyAllVisible(boolean _copyAllVisible){
this._copyAllVisible = _copyAllVisible;
this._copyAllVisibleSet = true;
}

public String getCopyControlLabel(){
	if (this._copyControlLabel != null) {
		return this._copyControlLabel;
	}
	ValueExpression ve = getValueExpression("copyControlLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setCopyControlLabel(String _copyControlLabel){
this._copyControlLabel = _copyControlLabel;
}

public String getCopyTitle(){
	if (this._copyTitle != null) {
		return this._copyTitle;
	}
	ValueExpression ve = getValueExpression("copyTitle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setCopyTitle(String _copyTitle){
this._copyTitle = _copyTitle;
}

public boolean isCopyVisible(){
	if (this._copyVisibleSet) {
	    return (this._copyVisible);
	}
	ValueExpression ve = getValueExpression("copyVisible");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._copyVisible);
	    }
	    
	    return value;
	} else {
	    return (this._copyVisible);
	}

}

public void setCopyVisible(boolean _copyVisible){
this._copyVisible = _copyVisible;
this._copyVisibleSet = true;
}

public String getDir(){
	if (this._dir != null) {
		return this._dir;
	}
	ValueExpression ve = getValueExpression("dir");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setDir(String _dir){
this._dir = _dir;
}

public boolean isDisabled(){
	if (this._disabledSet) {
	    return (this._disabled);
	}
	ValueExpression ve = getValueExpression("disabled");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._disabled);
	    }
	    
	    return value;
	} else {
	    return (this._disabled);
	}

}

public void setDisabled(boolean _disabled){
this._disabled = _disabled;
this._disabledSet = true;
}

public String getDisabledStyle(){
	if (this._disabledStyle != null) {
		return this._disabledStyle;
	}
	ValueExpression ve = getValueExpression("disabledStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setDisabledStyle(String _disabledStyle){
this._disabledStyle = _disabledStyle;
}

public String getDisabledStyleClass(){
	if (this._disabledStyleClass != null) {
		return this._disabledStyleClass;
	}
	ValueExpression ve = getValueExpression("disabledStyleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setDisabledStyleClass(String _disabledStyleClass){
this._disabledStyleClass = _disabledStyleClass;
}

public String getEnabledStyle(){
	if (this._enabledStyle != null) {
		return this._enabledStyle;
	}
	ValueExpression ve = getValueExpression("enabledStyle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setEnabledStyle(String _enabledStyle){
this._enabledStyle = _enabledStyle;
}

public String getEnabledStyleClass(){
	if (this._enabledStyleClass != null) {
		return this._enabledStyleClass;
	}
	ValueExpression ve = getValueExpression("enabledStyleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setEnabledStyleClass(String _enabledStyleClass){
this._enabledStyleClass = _enabledStyleClass;
}

public boolean isFastMoveControlsVisible(){
	if (this._fastMoveControlsVisibleSet) {
	    return (this._fastMoveControlsVisible);
	}
	ValueExpression ve = getValueExpression("fastMoveControlsVisible");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._fastMoveControlsVisible);
	    }
	    
	    return value;
	} else {
	    return (this._fastMoveControlsVisible);
	}

}

public void setFastMoveControlsVisible(boolean _fastMoveControlsVisible){
this._fastMoveControlsVisible = _fastMoveControlsVisible;
this._fastMoveControlsVisibleSet = true;
}

public String getLabel(){
	if (this._label != null) {
		return this._label;
	}
	ValueExpression ve = getValueExpression("label");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setLabel(String _label){
this._label = _label;
}

public String getLang(){
	if (this._lang != null) {
		return this._lang;
	}
	ValueExpression ve = getValueExpression("lang");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setLang(String _lang){
this._lang = _lang;
}

public String getListClass(){
	if (this._listClass != null) {
		return this._listClass;
	}
	ValueExpression ve = getValueExpression("listClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setListClass(String _listClass){
this._listClass = _listClass;
}

public String getListsHeight(){
	if (this._listsHeight != null) {
		return this._listsHeight;
	}
	ValueExpression ve = getValueExpression("listsHeight");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "140px";
	

}

public void setListsHeight(String _listsHeight){
this._listsHeight = _listsHeight;
}

public String getMoveControlsVerticalAlign(){
	if (this._moveControlsVerticalAlign != null) {
		return this._moveControlsVerticalAlign;
	}
	ValueExpression ve = getValueExpression("moveControlsVerticalAlign");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setMoveControlsVerticalAlign(String _moveControlsVerticalAlign){
this._moveControlsVerticalAlign = _moveControlsVerticalAlign;
}

public boolean isMoveControlsVisible(){
	if (this._moveControlsVisibleSet) {
	    return (this._moveControlsVisible);
	}
	ValueExpression ve = getValueExpression("moveControlsVisible");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._moveControlsVisible);
	    }
	    
	    return value;
	} else {
	    return (this._moveControlsVisible);
	}

}

public void setMoveControlsVisible(boolean _moveControlsVisible){
this._moveControlsVisible = _moveControlsVisible;
this._moveControlsVisibleSet = true;
}

public String getOnblur(){
	if (this._onblur != null) {
		return this._onblur;
	}
	ValueExpression ve = getValueExpression("onblur");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnblur(String _onblur){
this._onblur = _onblur;
}

public String getOnchange(){
	if (this._onchange != null) {
		return this._onchange;
	}
	ValueExpression ve = getValueExpression("onchange");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnchange(String _onchange){
this._onchange = _onchange;
}

public String getOnclick(){
	if (this._onclick != null) {
		return this._onclick;
	}
	ValueExpression ve = getValueExpression("onclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnclick(String _onclick){
this._onclick = _onclick;
}

public String getOndblclick(){
	if (this._ondblclick != null) {
		return this._ondblclick;
	}
	ValueExpression ve = getValueExpression("ondblclick");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOndblclick(String _ondblclick){
this._ondblclick = _ondblclick;
}

public String getOnfocus(){
	if (this._onfocus != null) {
		return this._onfocus;
	}
	ValueExpression ve = getValueExpression("onfocus");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnfocus(String _onfocus){
this._onfocus = _onfocus;
}

public String getOnkeydown(){
	if (this._onkeydown != null) {
		return this._onkeydown;
	}
	ValueExpression ve = getValueExpression("onkeydown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeydown(String _onkeydown){
this._onkeydown = _onkeydown;
}

public String getOnkeypress(){
	if (this._onkeypress != null) {
		return this._onkeypress;
	}
	ValueExpression ve = getValueExpression("onkeypress");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeypress(String _onkeypress){
this._onkeypress = _onkeypress;
}

public String getOnkeyup(){
	if (this._onkeyup != null) {
		return this._onkeyup;
	}
	ValueExpression ve = getValueExpression("onkeyup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnkeyup(String _onkeyup){
this._onkeyup = _onkeyup;
}

public String getOnlistchange(){
	if (this._onlistchange != null) {
		return this._onlistchange;
	}
	ValueExpression ve = getValueExpression("onlistchange");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnlistchange(String _onlistchange){
this._onlistchange = _onlistchange;
}

public String getOnlistchanged(){
	if (this._onlistchanged != null) {
		return this._onlistchanged;
	}
	ValueExpression ve = getValueExpression("onlistchanged");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnlistchanged(String _onlistchanged){
this._onlistchanged = _onlistchanged;
}

public String getOnmousedown(){
	if (this._onmousedown != null) {
		return this._onmousedown;
	}
	ValueExpression ve = getValueExpression("onmousedown");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousedown(String _onmousedown){
this._onmousedown = _onmousedown;
}

public String getOnmousemove(){
	if (this._onmousemove != null) {
		return this._onmousemove;
	}
	ValueExpression ve = getValueExpression("onmousemove");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmousemove(String _onmousemove){
this._onmousemove = _onmousemove;
}

public String getOnmouseout(){
	if (this._onmouseout != null) {
		return this._onmouseout;
	}
	ValueExpression ve = getValueExpression("onmouseout");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseout(String _onmouseout){
this._onmouseout = _onmouseout;
}

public String getOnmouseover(){
	if (this._onmouseover != null) {
		return this._onmouseover;
	}
	ValueExpression ve = getValueExpression("onmouseover");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseover(String _onmouseover){
this._onmouseover = _onmouseover;
}

public String getOnmouseup(){
	if (this._onmouseup != null) {
		return this._onmouseup;
	}
	ValueExpression ve = getValueExpression("onmouseup");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setOnmouseup(String _onmouseup){
this._onmouseup = _onmouseup;
}

public String getRemoveAllControlLabel(){
	if (this._removeAllControlLabel != null) {
		return this._removeAllControlLabel;
	}
	ValueExpression ve = getValueExpression("removeAllControlLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setRemoveAllControlLabel(String _removeAllControlLabel){
this._removeAllControlLabel = _removeAllControlLabel;
}

public String getRemoveAllTitle(){
	if (this._removeAllTitle != null) {
		return this._removeAllTitle;
	}
	ValueExpression ve = getValueExpression("removeAllTitle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setRemoveAllTitle(String _removeAllTitle){
this._removeAllTitle = _removeAllTitle;
}

public boolean isRemoveAllVisible(){
	if (this._removeAllVisibleSet) {
	    return (this._removeAllVisible);
	}
	ValueExpression ve = getValueExpression("removeAllVisible");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._removeAllVisible);
	    }
	    
	    return value;
	} else {
	    return (this._removeAllVisible);
	}

}

public void setRemoveAllVisible(boolean _removeAllVisible){
this._removeAllVisible = _removeAllVisible;
this._removeAllVisibleSet = true;
}

public String getRemoveControlLabel(){
	if (this._removeControlLabel != null) {
		return this._removeControlLabel;
	}
	ValueExpression ve = getValueExpression("removeControlLabel");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setRemoveControlLabel(String _removeControlLabel){
this._removeControlLabel = _removeControlLabel;
}

public String getRemoveTitle(){
	if (this._removeTitle != null) {
		return this._removeTitle;
	}
	ValueExpression ve = getValueExpression("removeTitle");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "";
	

}

public void setRemoveTitle(String _removeTitle){
this._removeTitle = _removeTitle;
}

public boolean isRemoveVisible(){
	if (this._removeVisibleSet) {
	    return (this._removeVisible);
	}
	ValueExpression ve = getValueExpression("removeVisible");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._removeVisible);
	    }
	    
	    return value;
	} else {
	    return (this._removeVisible);
	}

}

public void setRemoveVisible(boolean _removeVisible){
this._removeVisible = _removeVisible;
this._removeVisibleSet = true;
}

public boolean isShowButtonsLabel(){
	if (this._showButtonsLabelSet) {
	    return (this._showButtonsLabel);
	}
	ValueExpression ve = getValueExpression("showButtonsLabel");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._showButtonsLabel);
	    }
	    
	    return value;
	} else {
	    return (this._showButtonsLabel);
	}

}

public void setShowButtonsLabel(boolean _showButtonsLabel){
this._showButtonsLabel = _showButtonsLabel;
this._showButtonsLabelSet = true;
}

public int getSize(){
	if (this._sizeSet) {
	    return (this._size);
	}
	ValueExpression ve = getValueExpression("size");
	if (ve != null) {
	    Integer value = null;
	    
	    try {
			value = (Integer) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._size);
	    }
	    
	    return value;
	} else {
	    return (this._size);
	}

}

public void setSize(int _size){
this._size = _size;
this._sizeSet = true;
}

public String getSourceListWidth(){
	if (this._sourceListWidth != null) {
		return this._sourceListWidth;
	}
	ValueExpression ve = getValueExpression("sourceListWidth");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "140px";
	

}

public void setSourceListWidth(String _sourceListWidth){
this._sourceListWidth = _sourceListWidth;
}

public String getStyle(){
	if (this._style != null) {
		return this._style;
	}
	ValueExpression ve = getValueExpression("style");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyle(String _style){
this._style = _style;
}

public String getStyleClass(){
	if (this._styleClass != null) {
		return this._styleClass;
	}
	ValueExpression ve = getValueExpression("styleClass");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setStyleClass(String _styleClass){
this._styleClass = _styleClass;
}

public boolean isSwitchByClick(){
	if (this._switchByClickSet) {
	    return (this._switchByClick);
	}
	ValueExpression ve = getValueExpression("switchByClick");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._switchByClick);
	    }
	    
	    return value;
	} else {
	    return (this._switchByClick);
	}

}

public void setSwitchByClick(boolean _switchByClick){
this._switchByClick = _switchByClick;
this._switchByClickSet = true;
}

public boolean isSwitchByDblClick(){
	if (this._switchByDblClickSet) {
	    return (this._switchByDblClick);
	}
	ValueExpression ve = getValueExpression("switchByDblClick");
	if (ve != null) {
	    Boolean value = null;
	    
	    try {
			value = (Boolean) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    if (null == value) {
			return (this._switchByDblClick);
	    }
	    
	    return value;
	} else {
	    return (this._switchByDblClick);
	}

}

public void setSwitchByDblClick(boolean _switchByDblClick){
this._switchByDblClick = _switchByDblClick;
this._switchByDblClickSet = true;
}

public String getTargetListWidth(){
	if (this._targetListWidth != null) {
		return this._targetListWidth;
	}
	ValueExpression ve = getValueExpression("targetListWidth");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return "140px";
	

}

public void setTargetListWidth(String _targetListWidth){
this._targetListWidth = _targetListWidth;
}

public String getTitle(){
	if (this._title != null) {
		return this._title;
	}
	ValueExpression ve = getValueExpression("title");
	if (ve != null) {
	    String value = null;
	    
	    try {
			value = (String) ve.getValue(getFacesContext().getELContext());
	    } catch (ELException e) {
			throw new FacesException(e);
	    }
	    
	    return value;
	} 

    return null;
	

}

public void setTitle(String _title){
this._title = _title;
}

public String getFamily(){
return COMPONENT_FAMILY;
}

@Override
public Object saveState(FacesContext context){
Object [] state = new Object[62];
state[0] = super.saveState(context);
state[1] = _controlClass;
state[2] = _copyAllControlLabel;
state[3] = _copyAllTitle;
state[4] = Boolean.valueOf(_copyAllVisible);
state[5] = Boolean.valueOf(_copyAllVisibleSet);
state[6] = _copyControlLabel;
state[7] = _copyTitle;
state[8] = Boolean.valueOf(_copyVisible);
state[9] = Boolean.valueOf(_copyVisibleSet);
state[10] = _dir;
state[11] = Boolean.valueOf(_disabled);
state[12] = Boolean.valueOf(_disabledSet);
state[13] = _disabledStyle;
state[14] = _disabledStyleClass;
state[15] = _enabledStyle;
state[16] = _enabledStyleClass;
state[17] = Boolean.valueOf(_fastMoveControlsVisible);
state[18] = Boolean.valueOf(_fastMoveControlsVisibleSet);
state[19] = _label;
state[20] = _lang;
state[21] = _listClass;
state[22] = _listsHeight;
state[23] = _moveControlsVerticalAlign;
state[24] = Boolean.valueOf(_moveControlsVisible);
state[25] = Boolean.valueOf(_moveControlsVisibleSet);
state[26] = _onblur;
state[27] = _onchange;
state[28] = _onclick;
state[29] = _ondblclick;
state[30] = _onfocus;
state[31] = _onkeydown;
state[32] = _onkeypress;
state[33] = _onkeyup;
state[34] = _onlistchange;
state[35] = _onlistchanged;
state[36] = _onmousedown;
state[37] = _onmousemove;
state[38] = _onmouseout;
state[39] = _onmouseover;
state[40] = _onmouseup;
state[41] = _removeAllControlLabel;
state[42] = _removeAllTitle;
state[43] = Boolean.valueOf(_removeAllVisible);
state[44] = Boolean.valueOf(_removeAllVisibleSet);
state[45] = _removeControlLabel;
state[46] = _removeTitle;
state[47] = Boolean.valueOf(_removeVisible);
state[48] = Boolean.valueOf(_removeVisibleSet);
state[49] = Boolean.valueOf(_showButtonsLabel);
state[50] = Boolean.valueOf(_showButtonsLabelSet);
state[51] = Integer.valueOf(_size);
state[52] = Boolean.valueOf(_sizeSet);
state[53] = _sourceListWidth;
state[54] = _style;
state[55] = _styleClass;
state[56] = Boolean.valueOf(_switchByClick);
state[57] = Boolean.valueOf(_switchByClickSet);
state[58] = Boolean.valueOf(_switchByDblClick);
state[59] = Boolean.valueOf(_switchByDblClickSet);
state[60] = _targetListWidth;
state[61] = _title;
return state;
}

@Override
public void restoreState(FacesContext context, Object state){
Object[] states = (Object[]) state;
super.restoreState(context, states[0]);
	_controlClass = (String)states[1];;
		_copyAllControlLabel = (String)states[2];;
		_copyAllTitle = (String)states[3];;
		_copyAllVisible = ((Boolean)states[4]).booleanValue();
		_copyAllVisibleSet = ((Boolean)states[5]).booleanValue();
		_copyControlLabel = (String)states[6];;
		_copyTitle = (String)states[7];;
		_copyVisible = ((Boolean)states[8]).booleanValue();
		_copyVisibleSet = ((Boolean)states[9]).booleanValue();
		_dir = (String)states[10];;
		_disabled = ((Boolean)states[11]).booleanValue();
		_disabledSet = ((Boolean)states[12]).booleanValue();
		_disabledStyle = (String)states[13];;
		_disabledStyleClass = (String)states[14];;
		_enabledStyle = (String)states[15];;
		_enabledStyleClass = (String)states[16];;
		_fastMoveControlsVisible = ((Boolean)states[17]).booleanValue();
		_fastMoveControlsVisibleSet = ((Boolean)states[18]).booleanValue();
		_label = (String)states[19];;
		_lang = (String)states[20];;
		_listClass = (String)states[21];;
		_listsHeight = (String)states[22];;
		_moveControlsVerticalAlign = (String)states[23];;
		_moveControlsVisible = ((Boolean)states[24]).booleanValue();
		_moveControlsVisibleSet = ((Boolean)states[25]).booleanValue();
		_onblur = (String)states[26];;
		_onchange = (String)states[27];;
		_onclick = (String)states[28];;
		_ondblclick = (String)states[29];;
		_onfocus = (String)states[30];;
		_onkeydown = (String)states[31];;
		_onkeypress = (String)states[32];;
		_onkeyup = (String)states[33];;
		_onlistchange = (String)states[34];;
		_onlistchanged = (String)states[35];;
		_onmousedown = (String)states[36];;
		_onmousemove = (String)states[37];;
		_onmouseout = (String)states[38];;
		_onmouseover = (String)states[39];;
		_onmouseup = (String)states[40];;
		_removeAllControlLabel = (String)states[41];;
		_removeAllTitle = (String)states[42];;
		_removeAllVisible = ((Boolean)states[43]).booleanValue();
		_removeAllVisibleSet = ((Boolean)states[44]).booleanValue();
		_removeControlLabel = (String)states[45];;
		_removeTitle = (String)states[46];;
		_removeVisible = ((Boolean)states[47]).booleanValue();
		_removeVisibleSet = ((Boolean)states[48]).booleanValue();
		_showButtonsLabel = ((Boolean)states[49]).booleanValue();
		_showButtonsLabelSet = ((Boolean)states[50]).booleanValue();
		_size = ((Integer)states[51]).intValue();
		_sizeSet = ((Boolean)states[52]).booleanValue();
		_sourceListWidth = (String)states[53];;
		_style = (String)states[54];;
		_styleClass = (String)states[55];;
		_switchByClick = ((Boolean)states[56]).booleanValue();
		_switchByClickSet = ((Boolean)states[57]).booleanValue();
		_switchByDblClick = ((Boolean)states[58]).booleanValue();
		_switchByDblClickSet = ((Boolean)states[59]).booleanValue();
		_targetListWidth = (String)states[60];;
		_title = (String)states[61];;
	
}

}
